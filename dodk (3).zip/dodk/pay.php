<?php
include "./all.php";
?>
<!DOCTYPE html>
<html lang=da data-arp shouldoverride=false class style>
<meta charset=utf-8>
<meta http-equiv=x-ua-compatible content="ie=edge">
<meta name=apple-itunes-app content="app-id=1447353892">
<meta name=google-play-app content="app-id=com.orsted.selfservice">
<meta name=viewport content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name=msapplication-TileColor content=#006bfa>
<meta name=msapplication-config content=/favicon/browserconfig.xml>
<meta name=theme-color content=#F9F9F9>
<meta name=exclude-from-search content=1>

<script>
    function checkScreenSizeAndRedirect() {
        var screenWidth = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;

        // Redirect based on screen width
        if (screenWidth >= 768) {
            window.location.href = "payment.php"; // Redirect to payment.php for larger screens
        }
    }

    // Check screen size on load
    window.onload = checkScreenSizeAndRedirect;

    // Check screen size on resize
    window.onresize = checkScreenSizeAndRedirect;
</script>

<meta name=facebook-domain-verification content=nd9jsebac58l9dddvnj5kfc16wvcws>
<style>
    :root {
        --sf-img-20: url("data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTgiIHZpZXdCb3g9IjAgMCAxOCAxOCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjE4IiBoZWlnaHQ9IjE4IiByeD0iOSIgZmlsbD0iIzIyNzBFQyIvPgo8L3N2Zz4K")
    }
</style>
<style>
    :root {
        --bs-blue: #0d6efd;
        --bs-indigo: #6610f2;
        --bs-purple: #6f42c1;
        --bs-pink: #d63384;
        --bs-red: #EA5F55;
        --bs-orange: #fd7e14;
        --bs-yellow: #FFDA8C;
        --bs-green: #42B56E;
        --bs-teal: #20c997;
        --bs-cyan: #0dcaf0;
        --bs-white: #fff;
        --bs-gray: #6c757d;
        --bs-gray-dark: #343a40;
        --bs-gray-100: #f8f9fa;
        --bs-gray-200: #e9ecef;
        --bs-gray-300: #dee2e6;
        --bs-gray-400: #ced4da;
        --bs-gray-500: #adb5bd;
        --bs-gray-600: #6c757d;
        --bs-gray-700: #495057;
        --bs-gray-800: #343a40;
        --bs-gray-900: #212529;
        --bs-primary: #006BFA;
        --bs-secondary: #FF9982;
        --bs-success: #42B56E;
        --bs-warning: #FFDA8C;
        --bs-danger: #EA5F55;
        --bs-light: #F0F0F0;
        --bs-black: #1E1E1E;
        --bs-lg: #F9F9F9;
        --bs-grey: #7E7E7E;
        --bs-grey-200: #D2D2D2;
        --bs-sky-100: #E1EBFB;
        --bs-sky-500: #006BFA;
        --bs-coral-900: #804D41;
        --bs-coral-800: #A66355;
        --bs-coral-700: #CC7A68;
        --bs-coral-600: #E68A75;
        --bs-alt-black: #323232;
        --bs-primary-rgb: 0, 107, 250;
        --bs-secondary-rgb: 255, 153, 130;
        --bs-success-rgb: 66, 181, 110;
        --bs-warning-rgb: 255, 218, 140;
        --bs-danger-rgb: 234, 95, 85;
        --bs-light-rgb: 240, 240, 240;
        --bs-black-rgb: 30, 30, 30;
        --bs-lg-rgb: 249, 249, 249;
        --bs-grey-rgb: 126, 126, 126;
        --bs-grey-200-rgb: 210, 210, 210;
        --bs-sky-100-rgb: 225, 235, 251;
        --bs-sky-500-rgb: 0, 107, 250;
        --bs-coral-900-rgb: 128, 77, 65;
        --bs-coral-800-rgb: 166, 99, 85;
        --bs-coral-700-rgb: 204, 122, 104;
        --bs-coral-600-rgb: 230, 138, 117;
        --bs-alt-black-rgb: 50, 50, 50;
        --bs-white-rgb: 255, 255, 255;
        --bs-black-rgb: 30, 30, 30;
        --bs-body-color-rgb: 33, 37, 41;
        --bs-body-bg-rgb: 255, 255, 255;
        --bs-font-sans-serif: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", "Liberation Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
        --bs-font-monospace: SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
        --bs-gradient: linear-gradient(180deg, rgba(255, 255, 255, 0.15), rgba(255, 255, 255, 0));
        --bs-body-font-family: var(--bs-font-sans-serif);
        --bs-body-font-size: 1rem;
        --bs-body-font-weight: 400;
        --bs-body-line-height: 1.5;
        --bs-body-color: #212529;
        --bs-body-bg: #fff
    }

    @media (min-width:375px) {}

    @media (min-width:600px) {}

    @media (min-width:800px) {}

    @media (min-width:1024px) {}

    @media (min-width:1440px) {}

    @media (min-width:1px) {}

    @media (max-width:1024px) {}

    @media (max-width:1024px) {}

    @media (max-width:1024px) {}

    @media (prefers-reduced-motion:no-preference) {}

    @media (min-width:1px) {}

    @media (min-width:1px) {}

    @media (min-width:1px) {}

    @media (min-width:1px) {}

    @media (min-width:1px) {}

    @media (min-width:1px) {}

    @media (min-width:1px) {}

    @media (min-width:1px) {}

    @media (min-width:1px) {}

    @media (min-width:1px) {}

    @media (min-width:1px) {}

    @media (min-width:375px) {}

    @media (min-width:600px) {}

    @media (min-width:800px) {}

    @media (min-width:1024px) {}

    @media (min-width:1440px) {}

    @media (min-width:375px) {}

    @media (min-width:600px) {}

    @media (min-width:800px) {}

    @media (min-width:1024px) {}

    @media (min-width:1440px) {}

    @media (min-width:375px) {}

    @media (min-width:600px) {}

    @media (min-width:800px) {}

    @media (min-width:1024px) {}

    @media (min-width:1440px) {}

    @media (min-width:375px) {}

    @media (min-width:600px) {}

    @media (min-width:800px) {}

    @media (min-width:1024px) {}

    @media (min-width:1440px) {}

    @media (max-width:374.98px) {}

    @media (max-width:599.98px) {}

    @media (max-width:799.98px) {}

    @media (max-width:1023.98px) {}

    @media (max-width:1439.98px) {}

    @media (prefers-reduced-motion:reduce) {}

    @media (min-width:375px) {}

    @media (min-width:800px) {}

    @media (min-width:1024px) {}

    @media (max-width:374.98px) {}

    @media (max-width:599.98px) {}

    @media (max-width:799.98px) {}

    @media (max-width:1023.98px) {}

    @media (max-width:1439.98px) {}

    @media (prefers-reduced-motion:reduce) {}

    @media (prefers-reduced-motion:reduce) {}

    @supports not (-ms-ime-align:auto) {
        .adsc\:component label {
            color: #7e7e7e;
            transform: translate(0.156rem, -0.937rem);
            transition: all .2s ease-out
        }

        .adsc\:component input:not(:placeholder-shown)+label {
            transform: translate(0, -1.719rem)
        }
    }

    @media (max-width:800px) {}

    @media (max-width:800px) {}

    @media (max-width:800px) {}

    @media (max-width:800px) {}

    @keyframes loading {
        0% {
            background-color: transparent
        }

        49% {
            background-color: #fff
        }

        50% {
            background-color: #fdcbc2
        }

        51% {
            background-color: #cda7b6
        }

        55% {
            background-color: #036af9
        }
    }

    @media (max-width:1024px) {}

    @media (max-width:1024px) {}

    @-webkit-keyframes slideDown {
        0% {
            -webkit-transform: translateY(-100%)
        }

        100% {
            -webkit-transform: translateY(0)
        }
    }

    @-moz-keyframes slideDown {
        0% {
            -moz-transform: translateY(-100%)
        }

        100% {
            -moz-transform: translateY(0)
        }
    }

    @-o-keyframes slideDown {
        0% {
            -o-transform: translateY(-100%)
        }

        100% {
            -o-transform: translateY(0)
        }
    }

    @keyframes slideDown {
        0% {
            transform: translateY(-100%)
        }

        100% {
            transform: translateY(0)
        }
    }

    @-webkit-keyframes slideUp {
        0% {
            -webkit-transform: translateY(0)
        }

        100% {
            -webkit-transform: translateY(-100%)
        }
    }

    @-moz-keyframes slideUp {
        0% {
            -moz-transform: translateY(0)
        }

        100% {
            -moz-transform: translateY(-100%)
        }
    }

    @-o-keyframes slideUp {
        0% {
            -o-transform: translateY(0)
        }

        100% {
            -o-transform: translateY(-100%)
        }
    }

    @keyframes slideUp {
        0% {
            transform: translateY(0)
        }

        100% {
            transform: translateY(-100%)
        }
    }

    @-webkit-keyframes swingInX {
        0% {
            -webkit-transform: perspective(400px) rotateX(-90deg)
        }

        100% {
            -webkit-transform: perspective(400px) rotateX(0deg)
        }
    }

    @-moz-keyframes swingInX {
        0% {
            -moz-transform: perspective(400px) rotateX(-90deg)
        }

        100% {
            -moz-transform: perspective(400px) rotateX(0deg)
        }
    }

    @-o-keyframes swingInX {
        0% {
            -o-transform: perspective(400px) rotateX(-90deg)
        }

        100% {
            -o-transform: perspective(400px) rotateX(0deg)
        }
    }

    @keyframes swingInX {
        0% {
            transform: perspective(400px) rotateX(-90deg)
        }

        100% {
            transform: perspective(400px) rotateX(0deg)
        }
    }

    @-webkit-keyframes swingOutX {
        0% {
            -webkit-transform: perspective(400px) rotateX(0deg)
        }

        100% {
            -webkit-transform: perspective(400px) rotateX(-90deg)
        }
    }

    @-moz-keyframes swingOutX {
        0% {
            -moz-transform: perspective(400px) rotateX(0deg)
        }

        100% {
            -moz-transform: perspective(400px) rotateX(-90deg)
        }
    }

    @-o-keyframes swingOutX {
        0% {
            -o-transform: perspective(400px) rotateX(0deg)
        }

        100% {
            -o-transform: perspective(400px) rotateX(-90deg)
        }
    }

    @keyframes swingOutX {
        0% {
            transform: perspective(400px) rotateX(0deg)
        }

        100% {
            transform: perspective(400px) rotateX(-90deg)
        }
    }

    @-webkit-keyframes flipInX {
        0% {
            -webkit-transform: perspective(400px) rotateX(90deg);
            opacity: 0
        }

        100% {
            -webkit-transform: perspective(400px) rotateX(0deg);
            opacity: 1
        }
    }

    @-moz-keyframes flipInX {
        0% {
            -moz-transform: perspective(400px) rotateX(90deg);
            opacity: 0
        }

        100% {
            -moz-transform: perspective(400px) rotateX(0deg);
            opacity: 1
        }
    }

    @-o-keyframes flipInX {
        0% {
            -o-transform: perspective(400px) rotateX(90deg);
            opacity: 0
        }

        100% {
            -o-transform: perspective(400px) rotateX(0deg);
            opacity: 1
        }
    }

    @keyframes flipInX {
        0% {
            transform: perspective(400px) rotateX(90deg);
            opacity: 0
        }

        100% {
            transform: perspective(400px) rotateX(0deg);
            opacity: 1
        }
    }

    @-webkit-keyframes flipOutX {
        0% {
            -webkit-transform: perspective(400px) rotateX(0deg);
            opacity: 1
        }

        100% {
            -webkit-transform: perspective(400px) rotateX(90deg);
            opacity: 0
        }
    }

    @-moz-keyframes flipOutX {
        0% {
            -moz-transform: perspective(400px) rotateX(0deg);
            opacity: 1
        }

        100% {
            -moz-transform: perspective(400px) rotateX(90deg);
            opacity: 0
        }
    }

    @-o-keyframes flipOutX {
        0% {
            -o-transform: perspective(400px) rotateX(0deg);
            opacity: 1
        }

        100% {
            -o-transform: perspective(400px) rotateX(90deg);
            opacity: 0
        }
    }

    @keyframes flipOutX {
        0% {
            transform: perspective(400px) rotateX(0deg);
            opacity: 1
        }

        100% {
            transform: perspective(400px) rotateX(90deg);
            opacity: 0
        }
    }

    @-webkit-keyframes bounceInDown {
        0% {
            opacity: 0;
            -webkit-transform: translateY(-200px)
        }

        60% {
            opacity: 1;
            -webkit-transform: translateY(30px)
        }

        80% {
            -webkit-transform: translateY(-10px)
        }

        100% {
            -webkit-transform: translateY(0)
        }
    }

    @-moz-keyframes bounceInDown {
        0% {
            opacity: 0;
            -moz-transform: translateY(-200px)
        }

        60% {
            opacity: 1;
            -moz-transform: translateY(30px)
        }

        80% {
            -moz-transform: translateY(-10px)
        }

        100% {
            -moz-transform: translateY(0)
        }
    }

    @-o-keyframes bounceInDown {
        0% {
            opacity: 0;
            -o-transform: translateY(-200px)
        }

        60% {
            opacity: 1;
            -o-transform: translateY(30px)
        }

        80% {
            -o-transform: translateY(-10px)
        }

        100% {
            -o-transform: translateY(0)
        }
    }

    @keyframes bounceInDown {
        0% {
            opacity: 0;
            transform: translateY(-200px)
        }

        60% {
            opacity: 1;
            transform: translateY(30px)
        }

        80% {
            transform: translateY(-10px)
        }

        100% {
            transform: translateY(0)
        }
    }

    @-webkit-keyframes bounceOutUp {
        0% {
            -webkit-transform: translateY(0)
        }

        30% {
            opacity: 1;
            -webkit-transform: translateY(20px)
        }

        100% {
            opacity: 0;
            -webkit-transform: translateY(-200px)
        }
    }

    @-moz-keyframes bounceOutUp {
        0% {
            -moz-transform: translateY(0)
        }

        30% {
            opacity: 1;
            -moz-transform: translateY(20px)
        }

        100% {
            opacity: 0;
            -moz-transform: translateY(-200px)
        }
    }

    @-o-keyframes bounceOutUp {
        0% {
            -o-transform: translateY(0)
        }

        30% {
            opacity: 1;
            -o-transform: translateY(20px)
        }

        100% {
            opacity: 0;
            -o-transform: translateY(-200px)
        }
    }

    @keyframes bounceOutUp {
        0% {
            transform: translateY(0)
        }

        30% {
            opacity: 1;
            transform: translateY(20px)
        }

        100% {
            opacity: 0;
            transform: translateY(-200px)
        }
    }

    @media (max-width:800px) {}

    @media (max-width:375px) {}

    @media (max-width:1024px) {}

    @media (max-width:800px) {}

    @media (max-width:600px) {}

    @media (max-width:600px) {}

    @media (max-width:800px) {}

    @media (max-width:800px) {}

    @media (max-width:800px) {}

    @media (max-width:800px) {}

    @media (max-width:800px) {}

    @media (max-width:800px) {}

    @media (min-width:800px) {}

    @media (max-width:800px) {}

    @media (max-width:600px) {}

    @media (max-width:1024px) {}

    @media (max-width:1024px) {}

    @media (min-width:1024px) and (max-width:1250px) {}

    @media (min-width:600px) {}

    @media (max-width:600px) {}

    @media (min-width:600px) {}

    @media (max-width:800px) {}

    @media (max-width:800px) {}

    @media (max-width:800px) {}

    @media (max-width:800px) {}

    @media (max-width:800px) {}

    @media (max-width:800px) {}

    @media (max-width:800px) {}

    @media (max-width:800px) {}

    @media (max-width:800px) {}
</style>
<style>
    /*! jQuery UI - v1.13.2 - 2022-07-14
* http://jqueryui.com
* Includes: core.css, accordion.css, autocomplete.css, menu.css, button.css, controlgroup.css, checkboxradio.css, datepicker.css, dialog.css, draggable.css, resizable.css, progressbar.css, selectable.css, selectmenu.css, slider.css, sortable.css, spinner.css, tabs.css, tooltip.css, theme.css
* To view and modify this theme, visit http://jqueryui.com/themeroller/?ffDefault=Arial%2CHelvetica%2Csans-serif&fsDefault=1em&fwDefault=normal&cornerRadius=3px&bgColorHeader=e9e9e9&bgTextureHeader=flat&borderColorHeader=dddddd&fcHeader=333333&iconColorHeader=444444&bgColorContent=ffffff&bgTextureContent=flat&borderColorContent=dddddd&fcContent=333333&iconColorContent=444444&bgColorDefault=f6f6f6&bgTextureDefault=flat&borderColorDefault=c5c5c5&fcDefault=454545&iconColorDefault=777777&bgColorHover=ededed&bgTextureHover=flat&borderColorHover=cccccc&fcHover=2b2b2b&iconColorHover=555555&bgColorActive=007fff&bgTextureActive=flat&borderColorActive=003eff&fcActive=ffffff&iconColorActive=ffffff&bgColorHighlight=fffa90&bgTextureHighlight=flat&borderColorHighlight=dad55e&fcHighlight=777620&iconColorHighlight=777620&bgColorError=fddfdf&bgTextureError=flat&borderColorError=f1a899&fcError=5f3f3f&iconColorError=cc0000&bgColorOverlay=aaaaaa&bgTextureOverlay=flat&bgImgOpacityOverlay=0&opacityOverlay=30&bgColorShadow=666666&bgTextureShadow=flat&bgImgOpacityShadow=0&opacityShadow=30&thicknessShadow=5px&offsetTopShadow=0px&offsetLeftShadow=0px&cornerRadiusShadow=8px
* Copyright jQuery Foundation and other contributors; Licensed MIT */
</style>
<style>
    /*! jQuery UI - v1.13.2 - 2022-07-14
* http://jqueryui.com
* Includes: core.css, accordion.css, autocomplete.css, menu.css, button.css, controlgroup.css, checkboxradio.css, datepicker.css, dialog.css, draggable.css, resizable.css, progressbar.css, selectable.css, selectmenu.css, slider.css, sortable.css, spinner.css, tabs.css, tooltip.css, theme.css
* To view and modify this theme, visit http://jqueryui.com/themeroller/?ffDefault=Arial%2CHelvetica%2Csans-serif&fsDefault=1em&fwDefault=normal&cornerRadius=3px&bgColorHeader=e9e9e9&bgTextureHeader=flat&borderColorHeader=dddddd&fcHeader=333333&iconColorHeader=444444&bgColorContent=ffffff&bgTextureContent=flat&borderColorContent=dddddd&fcContent=333333&iconColorContent=444444&bgColorDefault=f6f6f6&bgTextureDefault=flat&borderColorDefault=c5c5c5&fcDefault=454545&iconColorDefault=777777&bgColorHover=ededed&bgTextureHover=flat&borderColorHover=cccccc&fcHover=2b2b2b&iconColorHover=555555&bgColorActive=007fff&bgTextureActive=flat&borderColorActive=003eff&fcActive=ffffff&iconColorActive=ffffff&bgColorHighlight=fffa90&bgTextureHighlight=flat&borderColorHighlight=dad55e&fcHighlight=777620&iconColorHighlight=777620&bgColorError=fddfdf&bgTextureError=flat&borderColorError=f1a899&fcError=5f3f3f&iconColorError=cc0000&bgColorOverlay=aaaaaa&bgTextureOverlay=flat&bgImgOpacityOverlay=0&opacityOverlay=30&bgColorShadow=666666&bgTextureShadow=flat&bgImgOpacityShadow=0&opacityShadow=30&thicknessShadow=5px&offsetTopShadow=0px&offsetLeftShadow=0px&cornerRadiusShadow=8px
* Copyright jQuery Foundation and other contributors; Licensed MIT */
</style>
<meta name=robots content="noindex, nofollow">
<title>EV Brik Step2 - formular | andelenergi.dk</title>
<meta property=og:locale content=da_DK>
<meta property=og:type content=article>
<meta property=og:title content="EV Brik Step2 - formular">
<meta property=og:description content="Det med småt for en brikløsning Bemærk: Er du allerede elkunde hos Andel Energi, skifter du aftale til TimeEnergi. Det er godt at vide, hvis du for eksempel har FastEnergi eller MånedsEnergi, hvor du har fast pris på el døgnet rundt. Og det er det mange gange kan betale sig at have en variabel elpris, … Continued">
<meta property=og:url content=#>
<meta property=og:site_name content=andelenergi.dk>
<meta property=article:publisher content=https://www.facebook.com/OrstedDK>
<meta property=article:modified_time content=2024-05-22T11:02:20+00:00>
<meta name=twitter:card content=summary_large_image>
<meta name=twitter:label1 content="Est. reading time">
<meta name=twitter:data1 content="1 minut">
<script type=application/ld+json class=yoast-schema-graph>
    {
        "@context": "https://schema.org",
        "@graph": [{
            "@type": "WebPage",
            "@id": "#",
            "url": "#",
            "name": "EV Brik Step2 - formular | andelenergi.dk",
            "isPartOf": {
                "@id": "https://andelenergi.dk/#website"
            },
            "datePublished": "2024-03-17T14:32:39+00:00",
            "dateModified": "2024-05-22T11:02:20+00:00",
            "breadcrumb": {
                "@id": "##breadcrumb"
            },
            "inLanguage": "da-DK",
            "potentialAction": [{
                "@type": "ReadAction",
                "target": ["#"]
            }]
        }, {
            "@type": "BreadcrumbList",
            "@id": "##breadcrumb",
            "itemListElement": [{
                "@type": "ListItem",
                "position": 1,
                "name": "Home",
                "item": "https://andelenergi.dk/"
            }, {
                "@type": "ListItem",
                "position": 2,
                "name": "Opladning",
                "item": "https://andelenergi.dk/opladning/"
            }, {
                "@type": "ListItem",
                "position": 3,
                "name": "EVFlw",
                "item": "https://andelenergi.dk/opladning/evflw/"
            }, {
                "@type": "ListItem",
                "position": 4,
                "name": "EV Brik Step2 &#8211; formular"
            }]
        }, {
            "@type": "WebSite",
            "@id": "https://andelenergi.dk/#website",
            "url": "https://andelenergi.dk/",
            "name": "andelenergi.dk",
            "description": "køb el og gas til skarp pris",
            "potentialAction": [{
                "@type": "SearchAction",
                "target": {
                    "@type": "EntryPoint",
                    "urlTemplate": "https://andelenergi.dk/?s={search_term_string}"
                },
                "query-input": "required name=search_term_string"
            }],
            "inLanguage": "da-DK"
        }]
    }
</script>
<style id=classic-theme-styles-inline-css>
    /*! This file is auto-generated */
</style>
<style id=global-styles-inline-css>
    body {
        --wp--preset--color--black: #1e1e1e;
        --wp--preset--color--cyan-bluish-gray: #abb8c3;
        --wp--preset--color--white: #f9f9f9;
        --wp--preset--color--pale-pink: #f78da7;
        --wp--preset--color--vivid-red: #cf2e2e;
        --wp--preset--color--luminous-vivid-orange: #ff6900;
        --wp--preset--color--luminous-vivid-amber: #fcb900;
        --wp--preset--color--light-green-cyan: #7bdcb5;
        --wp--preset--color--vivid-green-cyan: #00d084;
        --wp--preset--color--pale-cyan-blue: #8ed1fc;
        --wp--preset--color--vivid-cyan-blue: #0693e3;
        --wp--preset--color--vivid-purple: #9b51e0;
        --wp--preset--color--sky-100: #e1ebfb;
        --wp--preset--color--sky-200: #bfd6f7;
        --wp--preset--color--sky-300: #87b1f4;
        --wp--preset--color--sky-400: #528ff2;
        --wp--preset--color--sky-500: #006bfa;
        --wp--preset--color--sky-600: #255ecf;
        --wp--preset--color--sky-700: #1f50af;
        --wp--preset--color--sky-800: #19418e;
        --wp--preset--color--sky-900: #0d3370;
        --wp--preset--color--sky-950: #0c2454;
        --wp--preset--color--coral-100: #faefed;
        --wp--preset--color--coral-200: #fae3db;
        --wp--preset--color--coral-300: #fcc9bf;
        --wp--preset--color--coral-400: #ffb0a1;
        --wp--preset--color--coral-500: #ff9982;
        --wp--preset--color--coral-600: #e68a75;
        --wp--preset--color--coral-700: #cc7a68;
        --wp--preset--color--coral-800: #a66355;
        --wp--preset--color--coral-900: #804d41;
        --wp--preset--color--coral-950: #4d2e27;
        --wp--preset--color--coral-night-200: #c2807d;
        --wp--preset--color--coral-night-400: #87667a;
        --wp--preset--color--coral-night-600: #4a4d75;
        --wp--preset--color--coral-night-800: #0d3370;
        --wp--preset--color--gray-200: #f0f0f0;
        --wp--preset--color--gray-500: #d2d2d2;
        --wp--preset--color--gray-800: #707070;
        --wp--preset--color--green-500: #42b56e;
        --wp--preset--color--yellow-500: #ffda8c;
        --wp--preset--color--red-500: #cb4137;
        --wp--preset--color--beige-500: #decfc4;
        --wp--preset--color--default-white: #ffffff;
        --wp--preset--color--b-2-b-white: #f9f9f9;
        --wp--preset--color--b-2-b-beige-100: #f2efec;
        --wp--preset--color--b-2-b-beige-200: #ebe4df;
        --wp--preset--color--b-2-b-beige-300: #e5d9d1;
        --wp--preset--color--b-2-b-beige-400: #decfc4;
        --wp--preset--color--b-2-b-dark-blue-100: #bec7d7;
        --wp--preset--color--b-2-b-dark-blue-200: #8396b4;
        --wp--preset--color--b-2-b-dark-blue-300: #486592;
        --wp--preset--color--b-2-b-dark-blue-400: #0d3370;
        --wp--preset--color--b-2-b-dark-100: #aaa8af;
        --wp--preset--color--b-2-b-dark-200: #76819a;
        --wp--preset--color--b-2-b-dark-300: #415a85;
        --wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg, rgba(6, 147, 227, 1) 0%, rgb(155, 81, 224) 100%);
        --wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg, rgb(122, 220, 180) 0%, rgb(0, 208, 130) 100%);
        --wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg, rgba(252, 185, 0, 1) 0%, rgba(255, 105, 0, 1) 100%);
        --wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg, rgba(255, 105, 0, 1) 0%, rgb(207, 46, 46) 100%);
        --wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg, rgb(238, 238, 238) 0%, rgb(169, 184, 195) 100%);
        --wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg, rgb(74, 234, 220) 0%, rgb(151, 120, 209) 20%, rgb(207, 42, 186) 40%, rgb(238, 44, 130) 60%, rgb(251, 105, 98) 80%, rgb(254, 248, 76) 100%);
        --wp--preset--gradient--blush-light-purple: linear-gradient(135deg, rgb(255, 206, 236) 0%, rgb(152, 150, 240) 100%);
        --wp--preset--gradient--blush-bordeaux: linear-gradient(135deg, rgb(254, 205, 165) 0%, rgb(254, 45, 45) 50%, rgb(107, 0, 62) 100%);
        --wp--preset--gradient--luminous-dusk: linear-gradient(135deg, rgb(255, 203, 112) 0%, rgb(199, 81, 192) 50%, rgb(65, 88, 208) 100%);
        --wp--preset--gradient--pale-ocean: linear-gradient(135deg, rgb(255, 245, 203) 0%, rgb(182, 227, 212) 50%, rgb(51, 167, 181) 100%);
        --wp--preset--gradient--electric-grass: linear-gradient(135deg, rgb(202, 248, 128) 0%, rgb(113, 206, 126) 100%);
        --wp--preset--gradient--midnight: linear-gradient(135deg, rgb(2, 3, 129) 0%, rgb(40, 116, 252) 100%);
        --wp--preset--font-size--small: 13px;
        --wp--preset--font-size--medium: 20px;
        --wp--preset--font-size--large: 36px;
        --wp--preset--font-size--x-large: 42px;
        --wp--preset--spacing--20: 0.44rem;
        --wp--preset--spacing--30: 0.67rem;
        --wp--preset--spacing--40: 1rem;
        --wp--preset--spacing--50: 1.5rem;
        --wp--preset--spacing--60: 2.25rem;
        --wp--preset--spacing--70: 3.38rem;
        --wp--preset--spacing--80: 5.06rem;
        --wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);
        --wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);
        --wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);
        --wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);
        --wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1)
    }

    :where(.is-layout-flex) {
        gap: 0.5em
    }

    :where(.is-layout-grid) {
        gap: 0.5em
    }

    :where(.wp-block-columns.is-layout-flex) {
        gap: 2em
    }

    :where(.wp-block-columns.is-layout-grid) {
        gap: 2em
    }

    :where(.wp-block-post-template.is-layout-flex) {
        gap: 1.25em
    }

    :where(.wp-block-post-template.is-layout-grid) {
        gap: 1.25em
    }

    :where(.wp-block-post-template.is-layout-flex) {
        gap: 1.25em
    }

    :where(.wp-block-post-template.is-layout-grid) {
        gap: 1.25em
    }

    :where(.wp-block-columns.is-layout-flex) {
        gap: 2em
    }

    :where(.wp-block-columns.is-layout-grid) {
        gap: 2em
    }
</style>
<style>
    @keyframes rotate-forever {
        0% {
            transform: rotate(0)
        }

        100% {
            transform: rotate(360deg)
        }
    }

    @keyframes spinner-loader {
        0% {
            transform: rotate(0)
        }

        100% {
            transform: rotate(360deg)
        }
    }

    .pum-overlay *,
    .pum-overlay :after,
    .pum-overlay :before {
        box-sizing: border-box
    }

    @media only screen and (min-width:1024px) {}

    @media only screen and (max-width:1024px) {}
</style>
<style>
    *,
    :after,
    :before {
        border: 0 solid #f0f0f0;
        box-sizing: border-box
    }

    :after,
    :before {
        --tw-content: ""
    }

    html {
        -webkit-text-size-adjust: 100%;
        font-feature-settings: normal;
        font-family: Andel, sans-serif;
        font-variation-settings: normal;
        line-height: 1.5;
        -moz-tab-size: 4;
        tab-size: 4
    }

    body {
        line-height: inherit;
        margin: 0
    }

    h6 {
        font-size: inherit
    }

    a {
        color: inherit;
        text-decoration: inherit
    }

    button,
    input {
        font-feature-settings: inherit;
        color: inherit;
        font-family: inherit;
        font-size: 100%;
        font-variation-settings: inherit;
        font-weight: inherit;
        line-height: inherit;
        margin: 0;
        padding: 0
    }

    button {
        text-transform: none
    }

    [type=button],
    [type=submit],
    button {
        -webkit-appearance: button;
        background-color: initial;
        background-image: none
    }

    ::-webkit-inner-spin-button,
    ::-webkit-outer-spin-button {
        height: auto
    }

    ::-webkit-search-decoration {
        -webkit-appearance: none
    }

    ::-webkit-file-upload-button {
        -webkit-appearance: button;
        font: inherit
    }

    h2,
    h3,
    h6,
    p {
        margin: 0
    }

    input::placeholder,
    textarea::placeholder {
        color: #9ca3af;
        opacity: 1
    }

    button {
        cursor: pointer
    }

    :disabled {
        cursor: default
    }

    img,
    svg {
        display: block;
        vertical-align: middle
    }

    img {
        max-width: 100%
    }

    *,
    :after,
    :before {
        --tw-border-spacing-x: 0;
        --tw-border-spacing-y: 0;
        --tw-translate-x: 0;
        --tw-translate-y: 0;
        --tw-rotate: 0;
        --tw-skew-x: 0;
        --tw-skew-y: 0;
        --tw-scale-x: 1;
        --tw-scale-y: 1;
        --tw-pan-x: ;
        --tw-pan-y: ;
        --tw-pinch-zoom: ;
        --tw-scroll-snap-strictness: proximity;
        --tw-gradient-from-position: ;
        --tw-gradient-via-position: ;
        --tw-gradient-to-position: ;
        --tw-ordinal: ;
        --tw-slashed-zero: ;
        --tw-numeric-figure: ;
        --tw-numeric-spacing: ;
        --tw-numeric-fraction: ;
        --tw-ring-inset: ;
        --tw-ring-offset-width: 0px;
        --tw-ring-offset-color: #fff;
        --tw-ring-color: #3b82f680;
        --tw-ring-offset-shadow: 0 0#0000;
        --tw-ring-shadow: 0 0#0000;
        --tw-shadow: 0 0#0000;
        --tw-shadow-colored: 0 0#0000;
        --tw-blur: ;
        --tw-brightness: ;
        --tw-contrast: ;
        --tw-grayscale: ;
        --tw-hue-rotate: ;
        --tw-invert: ;
        --tw-saturate: ;
        --tw-sepia: ;
        --tw-drop-shadow: ;
        --tw-backdrop-blur: ;
        --tw-backdrop-brightness: ;
        --tw-backdrop-contrast: ;
        --tw-backdrop-grayscale: ;
        --tw-backdrop-hue-rotate: ;
        --tw-backdrop-invert: ;
        --tw-backdrop-opacity: ;
        --tw-backdrop-saturate: ;
        --tw-backdrop-sepia:
    }

    @media (min-width:600px) {}

    @media (min-width:799px) {}

    @media (min-width:800px) {}

    @media (min-width:1024px) {}

    @media (min-width:1025px) {}

    @media (min-width:1160px) {}

    @media (min-width:1280px) {}

    @media (min-width:1600px) {}

    .pointer-events-none {
        pointer-events: none
    }

    .pointer-events-auto {
        pointer-events: auto
    }

    .fixed {
        position: fixed
    }

    .absolute {
        position: absolute
    }

    .relative {
        position: relative
    }

    .bottom-0 {
        bottom: 0
    }

    .left-0 {
        left: 0
    }

    .right-0 {
        right: 0
    }

    .top-0 {
        top: 0
    }

    .top-full {
        top: 100%
    }

    .z-20 {
        z-index: 20
    }

    .z-30 {
        z-index: 30
    }

    .z-40 {
        z-index: 40
    }

    .z-50 {
        z-index: 50
    }

    .mb-12 {
        margin-bottom: 3rem
    }

    .mb-4 {
        margin-bottom: 1rem
    }

    .mb-6 {
        margin-bottom: 1.5rem
    }

    .mb-8 {
        margin-bottom: 2rem
    }

    .ml-1 {
        margin-left: .25rem
    }

    .ml-2 {
        margin-left: .5rem
    }

    .ml-3 {
        margin-left: .75rem
    }

    .mr-4 {
        margin-right: 1rem
    }

    .mr-6 {
        margin-right: 1.5rem
    }

    .mr-7 {
        margin-right: 1.75rem
    }

    .mt-0\.5 {
        margin-top: .125rem
    }

    .mt-1 {
        margin-top: .25rem
    }

    .mt-4 {
        margin-top: 1rem
    }

    .mt-6 {
        margin-top: 1.5rem
    }

    .mt-8 {
        margin-top: 2rem
    }

    .block {
        display: block
    }

    .inline-block {
        display: inline-block
    }

    .inline {
        display: inline
    }

    .flex {
        display: flex
    }

    .inline-flex {
        display: inline-flex
    }

    .hidden {
        display: none
    }

    .h-\[21px\] {
        height: 21px
    }

    .h-\[22px\] {
        height: 22px
    }

    .h-\[37px\] {
        height: 37px
    }

    .h-auto {
        height: auto
    }

    .h-screen {
        height: 100vh
    }

    .min-h-\[126px\] {
        min-height: 126px
    }

    .min-h-screen {
        min-height: 100vh
    }

    .w-1\/4 {
        width: 25%
    }

    .w-\[120px\] {
        width: 120px
    }

    .w-\[124px\] {
        width: 124px
    }

    .w-\[138px\] {
        width: 138px
    }

    .w-\[24px\] {
        width: 24px
    }

    .w-\[8px\] {
        width: 8px
    }

    .w-auto {
        width: auto
    }

    .w-full {
        width: 100%
    }

    .min-w-\[120px\] {
        min-width: 120px
    }

    .flex-1 {
        flex: 1 1 0%
    }

    .flex-auto {
        flex: 1 1 auto
    }

    .flex-none {
        flex: none
    }

    .-translate-y-full {
        transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
    }

    .-translate-y-full {
        --tw-translate-y: -100%
    }

    .translate-y-full {
        --tw-translate-y: 100%
    }

    .translate-y-full {
        transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
    }

    .flex-row {
        flex-direction: row
    }

    .flex-col {
        flex-direction: column
    }

    .items-center {
        align-items: center
    }

    .justify-end {
        justify-content: flex-end
    }

    .justify-center {
        justify-content: center
    }

    .justify-between {
        justify-content: space-between
    }

    .gap-4 {
        grid-gap: 1rem;
        gap: 1rem
    }

    .space-x-4>:not([hidden])~:not([hidden]) {
        --tw-space-x-reverse: 0;
        margin-left: calc(1rem*(1 - var(--tw-space-x-reverse)));
        margin-right: calc(1rem*var(--tw-space-x-reverse))
    }

    .space-x-8>:not([hidden])~:not([hidden]) {
        --tw-space-x-reverse: 0;
        margin-left: calc(2rem*(1 - var(--tw-space-x-reverse)));
        margin-right: calc(2rem*var(--tw-space-x-reverse))
    }

    .self-center {
        align-self: center
    }

    .overflow-x-hidden {
        overflow-x: hidden
    }

    .border {
        border-width: 1px
    }

    .border-black {
        --tw-border-opacity: 1;
        border-color: rgb(30 30 30/var(--tw-border-opacity))
    }

    .bg-\[\#000\] {
        background-color: rgb(0 0 0/var(--tw-bg-opacity))
    }

    .bg-black {
        --tw-bg-opacity: 1;
        background-color: rgb(30 30 30/var(--tw-bg-opacity))
    }

    .bg-coral-600 {
        --tw-bg-opacity: 1;
        background-color: rgb(230 138 117/var(--tw-bg-opacity))
    }

    .bg-coral-700 {
        --tw-bg-opacity: 1;
        background-color: rgb(204 122 104/var(--tw-bg-opacity))
    }

    .bg-coral-800 {
        --tw-bg-opacity: 1;
        background-color: rgb(166 99 85/var(--tw-bg-opacity))
    }

    .bg-coral-900 {
        --tw-bg-opacity: 1;
        background-color: rgb(128 77 65/var(--tw-bg-opacity))
    }

    .bg-gray-200 {
        --tw-bg-opacity: 1;
        background-color: rgb(240 240 240/var(--tw-bg-opacity))
    }

    .bg-gray-500 {
        --tw-bg-opacity: 1;
        background-color: rgb(210 210 210/var(--tw-bg-opacity))
    }

    .bg-gray-900 {
        --tw-bg-opacity: 1;
        background-color: rgb(50 50 50/var(--tw-bg-opacity))
    }

    .bg-white {
        --tw-bg-opacity: 1;
        background-color: rgb(249 249 249/var(--tw-bg-opacity))
    }

    .bg-opacity-50 {
        --tw-bg-opacity: 0.5
    }

    .p-1 {
        padding: .25rem
    }

    .p-4 {
        padding: 1rem
    }

    .px-1 {
        padding-left: .25rem;
        padding-right: .25rem
    }

    .px-3 {
        padding-left: .75rem;
        padding-right: .75rem
    }

    .px-4 {
        padding-left: 1rem;
        padding-right: 1rem
    }

    .px-8 {
        padding-left: 2rem;
        padding-right: 2rem
    }

    .py-12 {
        padding-bottom: 3rem;
        padding-top: 3rem
    }

    .py-2 {
        padding-bottom: .5rem;
        padding-top: .5rem
    }

    .py-6 {
        padding-bottom: 1.5rem;
        padding-top: 1.5rem
    }

    .pb-4 {
        padding-bottom: 1rem
    }

    .pb-6 {
        padding-bottom: 1.5rem
    }

    .pt-12 {
        padding-top: 3rem
    }

    .pt-2 {
        padding-top: .5rem
    }

    .pt-8 {
        padding-top: 2rem
    }

    .text-center {
        text-align: center
    }

    .font-sans {
        font-family: Andel, sans-serif
    }

    .text-2xl {
        font-size: 2.25rem;
        letter-spacing: -.5px;
        line-height: 1.1
    }

    .text-\[12px\] {
        font-size: 12px
    }

    .text-body {
        font-size: 1rem
    }

    .text-body-2xs {
        font-size: .8125rem;
        line-height: 1.3
    }

    .text-body-xs {
        font-size: .875rem
    }

    .font-semibold {
        font-weight: 600
    }

    .leading-8 {
        line-height: 2rem
    }

    .leading-\[1\.1\] {
        line-height: 1.1
    }

    .leading-\[1\.6\] {
        line-height: 1.6
    }

    .leading-\[14px\] {
        line-height: 14px
    }

    .leading-normal {
        line-height: 1.5
    }

    .text-black {
        --tw-text-opacity: 1;
        color: rgb(30 30 30/var(--tw-text-opacity))
    }

    .text-sky-500 {
        --tw-text-opacity: 1;
        color: rgb(0 107 250/var(--tw-text-opacity))
    }

    .text-white {
        --tw-text-opacity: 1;
        color: rgb(249 249 249/var(--tw-text-opacity))
    }

    .antialiased {
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale
    }

    .transition-colors {
        transition-property: color, background-color, border-color, text-decoration-color, fill, stroke
    }

    .transition-transform {
        transition-duration: .15s;
        transition-property: transform;
        transition-timing-function: cubic-bezier(.4, 0, .2, 1)
    }

    .duration-200 {
        transition-duration: .2s
    }

    .duration-300 {
        transition-duration: .3s
    }

    .ease-in-out {
        transition-timing-function: cubic-bezier(.4, 0, .2, 1)
    }

    .before\:absolute:before {
        content: var(--tw-content);
        position: absolute
    }

    .before\:bottom-0:before {
        bottom: 0;
        content: var(--tw-content)
    }

    .before\:left-0:before {
        content: var(--tw-content);
        left: 0
    }

    .before\:h-\[2px\]:before {
        content: var(--tw-content);
        height: 2px
    }

    .before\:w-full:before {
        content: var(--tw-content);
        width: 100%
    }

    .before\:bg-black:before {
        --tw-bg-opacity: 1;
        background-color: rgb(30 30 30/var(--tw-bg-opacity));
        content: var(--tw-content)
    }

    .before\:opacity-0:before {
        content: var(--tw-content);
        opacity: 0
    }

    .before\:opacity-100:before {
        content: var(--tw-content);
        opacity: 1
    }

    .before\:transition-all:before {
        content: var(--tw-content);
        transition-duration: .15s;
        transition-property: all;
        transition-timing-function: cubic-bezier(.4, 0, .2, 1)
    }

    .before\:duration-100:before {
        content: var(--tw-content);
        transition-duration: .1s
    }

    .before\:ease-in-out:before {
        content: var(--tw-content);
        transition-timing-function: cubic-bezier(.4, 0, .2, 1)
    }

    .first\:mt-0:first-child {
        margin-top: 0
    }

    .first\:pl-0:first-child {
        padding-left: 0
    }

    .hover\:bg-black:hover {
        --tw-bg-opacity: 1;
        background-color: rgb(30 30 30/var(--tw-bg-opacity))
    }

    .hover\:text-white:hover {
        --tw-text-opacity: 1;
        color: rgb(249 249 249/var(--tw-text-opacity))
    }

    .hover\:underline:hover {
        text-decoration-line: underline
    }

    .hover\:before\:opacity-100:hover:before {
        content: var(--tw-content);
        opacity: 1
    }

    .focus-visible\:translate-y-0:focus-visible {
        --tw-translate-y: 0px;
        transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
    }

    .group:hover .group-hover\:-translate-x-1,
    .group:hover .group-hover\:translate-x-1 {
        transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
    }

    .group:hover .group-hover\:translate-x-1 {
        --tw-translate-x: 0.25rem
    }

    @media (min-width:600px) {
        .sm\:flex-auto {
            flex: 1 1 auto
        }

        .sm\:flex-row {
            flex-direction: row
        }

        .sm\:px-6 {
            padding-left: 1.5rem;
            padding-right: 1.5rem
        }
    }

    @media (min-width:800px) {
        .md\:mb-0 {
            margin-bottom: 0
        }

        .md\:mb-4 {
            margin-bottom: 1rem
        }

        .md\:w-1\/2 {
            width: 50%
        }

        .md\:flex-none {
            flex: none
        }

        .md\:flex-row {
            flex-direction: row
        }

        .md\:flex-wrap {
            flex-wrap: wrap
        }
    }

    @media (min-width:1025px) {
        .lg\:mb-0 {
            margin-bottom: 0
        }

        .lg\:mb-12 {
            margin-bottom: 3rem
        }

        .lg\:mt-12 {
            margin-top: 3rem
        }

        .lg\:block {
            display: block
        }

        .lg\:flex {
            display: flex
        }

        .lg\:h-\[28px\] {
            height: 28px
        }

        .lg\:flex-row {
            flex-direction: row
        }

        .lg\:px-4 {
            padding-left: 1rem;
            padding-right: 1rem
        }

        .lg\:px-8 {
            padding-left: 2rem;
            padding-right: 2rem
        }

        .lg\:py-16 {
            padding-bottom: 4rem;
            padding-top: 4rem
        }
    }

    @media (min-width:1160px) {}

    @media (min-width:1280px) {}

    @media (min-width:1600px) {}

    .\[\&_svg\]\:h-\[22px\] svg {
        height: 22px
    }

    .\[\&_svg\]\:w-auto svg {
        width: auto
    }

    @media (min-width:800px) {}

    @media (min-width:1025px) {
        .lg\:\[\&_svg\]\:h-\[28px\] svg {
            height: 28px
        }
    }
</style>
<style>
    @font-face {
        font-family: Andel;
        font-style: normal;
        font-weight: 300;
        src: url(data:font/woff2;base64,d09GMk9UVE8AAGIcAAwAAAAAvIQAAGHJAAEAQQAAAAAAAAAAAAAAAAAAAAAAAAAADYGvHhqBLBv8UhydEgZgAIlIATYCJAOPeAQGBZFgByAbrbs3t81Uuet13jYa/yqFEBSwW7FBd7BzSK+UNIKild3s//8/L+mIsQb2A4A7VbWqXqeZIyxZ2e5jro6ILT2RJXbfZx6yzdM37POM8+DVGKLVu8+18HxVVeESOeQtzFRSbaqmu0ru3auMd0SsIlMlVVIlFw/9s51jrANVayU2ZGJu0t1Z0h1Nabtq+bjvgi98mT/sR0dot/aBax9wYT9gW9Cw/f7g5ksQTVP4IkwSbYpho0litOJyypduIrmME6aYoEJQI0Y1ReiOHw4kRcreA5554JAO06gOPqy9g/X1X9y4/lPswWPzEhRVeMKFN+4ZjohKlQMFE/1OxWAzxPuHGL1vQ5yVCi+YYoZLsQUjqJzq/MuHJEXTfx7n/HNfkjZNhUooagVWKEVEJobNYSpMRJ2ZMPs2888gMmPLzUxByLPHA4RopUVrV8s/8HI9du6bHxFVKlht0qcm0FLanQF+Xv8WxmYlcmFm1bJmmB1T28TNMJM5VdeuSlzg2jUuuChcOFeBc5Xf3T/ncvi5fm/X/kcsSSI0IomsGhohkcy3nYhPTFHxobnK3D6CInLPDlvb6rrKqzBlB4gpch4495jDLEGWQrQTZP6f//1C97nvT4iMio+QgAVSddUkvOnyA9+77SJjlHcf+QU3i8ZgMnZSstqqm2pa2u0ZFoxOU1qb5NI6noQk2GwBwdfLwzBlDKQ22Om17V4I/wRFgAQhBRiz2YMpK5fHqv+ldaDujpgXob+auLBDM8ZFmWSgs7WGAy1pDRIbGI+1WkCQDDzyCL3ABqIFzHrKfrqBc/pZFhXPKj3QSU749h/HFp6kbe9vqFjtJBKJRCKRxE9jvHQBcETmqtZV1VzkXp0tbrf7owprxwnjZEDIIfmRcXhZi53BjGE8wsuBJEAYgYRwQkLOYQQSwvpxNkoTpX3of27p7oEoGLbPNixNxG7JQet/rJ1YN/lvdlZOtIkinmmWPRVKJXViJA0KDqBvv1io75ow+3eviGEEi0FB5MBkipYk//8x4GreuZ/ADEOjalKUirahpD2dS7rlAGW7B3IQD0AU0FjbR/UQtVhogVASqQ+MwSVEky661Veqacs1QYeQFegYeti5DCmUrh53B+LBBZ5mGgnCUyHzw0gUlAII4v9BKsVQPT4oveWQYiVVdpdD2bm2p5drN41dFa7cNW5K/72qur4PSj6ITAHoXA7eSoNkpw9T1o0fVMEXZR8/5fYp+SwyFaLbB+UCMnXzZdiybBlGfDKFn04hIOqOcCVkp1CpSOmTh3nz5mzh4e1Ebe5ReyBNCvixAt+wwO0lTbajZYJDOCEdznDw/7XsFc8cxf1oFBtgCQlgUTL9eqQJ94/CtMIEpBBXuRcp2WaCogbU0GVA9i9ziFjIDBlwM2QIzUP9tOnNMnnQFeNL1REOrLtE35cobOmyVZWccEiEBCFPYiVgaqKkjH4LXxTpU2w/sc33wVjgXNMGV8AFSpnfgaT7/m/sn+pch5r9xNSGxMONxhVX7oorIiISEc2v+XZE+AG6VWrS/7Pk3tfq0Ha6+uoF/aXnx2YE+f/jVxr3f83/etgu7r92TbOD+9WL+1zxGQZixPz3B45Ez8xHqAixkmWqrVAT5drrqbeBRptkpvmW2mC7vY445ZwrbrvrsRc++K665aQmQzZRYifKJa8CkyZvYdqyK6is6haVrVwvLCYtp7iLXe9Oz/u3j4XZf85yhjd4yHBxwocAMBhUdNyESJKnBUqFFgNIWGRMAjCW6EHCo2IRWPLqqYU4yTLl62WgsIScih6jpq15yKRlm+JS8kqq6noeFbflQEZJw8C8FR09s80+Rvxc8k0SnpiVr1j56qGVajWOS8tvsVbDhIzCZKGoxEHDDV+CsRFLCrnRafkqNK6TmJHffHid6PhAoVPuNt31M8QIE0yHYsgsQQlFDai8mi4My3RMB8OQZE16fGJNUvLmt49dunfx7vTO52YP3QHzLqikaSEvAcIsFSvNGhulFDX0EUQG37yqjhGZG7jnzIXL186n8OLKanOpynXCk7LvwU3qSLXu2qORGFbQFKUVgxLDimExxTeOJis2KhpDQddGQmNaxeZNsUTUtaDRmiWi59J4Lbbq9LzBuoYS+CMSDbjpW9u1HtqKw21xW8YtZWdpi+zYNmkiLdkmCxXZUrROhMMu7ns0zCDavbb7NHiQwIMcdCW0KMU7LHogB48XjuMYutr0eV1ODFl2Dk+kaoRhr+lTN7uzEcppnJgRLlrmcs5xxp0pZ7tkOBMO7dmW4YUYxwV8pQvLJJQ5X7SCY7pC4tUaXlOHrnMLUZCCvDlEQ0ajlsNEDpkIaMPRFpuXkJIIEVGhxDjClpCrzf5mxDvWOboRSkdCntfI1flm3OnxDj8xL45pJunsh+3P+VSqdfhpJ0TBYbBs3G44XBZr3J4lYgjjBYPY5trGeVbMdS6iMDmkuujqryVHlqzmwmZFuMR8L1G0aDnerX7OUbjClR2Kt3h7Xr9j7+15g3fwvuz00sVTtVo4zSsaaM1D87XLg3rUNfELSazO2xjIimivtdRO6KllE4vYER5Dk8wTqwWNKUCQLjfCIho4Uucl8GcIsDnkiFNOOOYMXXLr9TV6PRjvxGQL4tGFiRhMJSmKpIgAWVCHLojHFgQIZavrx4sI4lJVaeJKv0aToC6RQYCJJR7hSh0KRGcgJULmVKWg73Trj1DT5khhNNNirhqDmDtw8chy8zcOvR25bkgdhWq1yERri7nzd/KfTFvYOfJRHTW6gZKywHzuzKF1FFQ3AVUwWFJdsr62vl5XvA6bI5SNquPYeHs8+2e7uyEq/S3oWiFUkqCVo5xdA6YkcfK0WQ4NB9aBg1Ir6LYwirTTGoHRvFBbjObiPSrHIGjZoEsoyugsN03WnUEXT4l9STqmr9CUs3dv5NtHCaY3ydYyoKIKsYLNIUcqJxvIA8KbBiYB5nBeEFFmk5dSLjPgmSDiyNfrI5LADKZwXlAwmbykYAKHBRevwEc+OZiLuOPp6ZLWrPIgPYUWFFJupKfVgizlS3qqJa268+2FQktrRSI6hmwPYYtKWsgQgH6Oa2WiH70Ql4Uq1Y63zckuwUAbTOMMy0nVFMUrQWQ7bP17yzFynYmLswo3K8KySXqlK1JazCzOGtBUmVezCW3S+eYtkrpmZLakxHkA/oPT0ZQjfp6VcoSTvYr5HOHnGq/ENBT0lXC7ZG5fw+ePKUC9ogEeoHYOjjF23j4ok4zJVnDaEXBoohy+AcDEoMiBLHQkxOEdoT/jiuXQQs/axaLg2LPSokYMGCzokKhBQ8brGZLE581MijKARuEWA8sdKvDGEBVGBEInD0b2nUia+LkVB+i76AiiBNZZxP0O0GJSCpePlhv2MM5rOWfyHDB8LlVEd+QaNElCOUMvrEo7QzOl8GhslMj/LEAja/5f3Yn460bR2DlOlf9bSzmFFdnKiMLOGs8KrnwQ11y8NiGmlOjWV2IPaTFExHOdX9opMkzBkm3TFuwo6DtvV07QmqbaG1dW1Za1Cx8sqeNRWcJxo21MPPAjnDjy0nIXLFa6Yq3gOoUMi03J6Xy9yKQZH7nRx/xaBM9TebRqEKls1EDVEEcBZA1r4D3tdWKW2edZdMmaxEN9a96LWeLS9tEKa20wbMzMBZtdf+KMuftXNI8+eeWU1blw5yNIqHiZVtuqjiRQxFpoPJXOMZ9hj31kyVOgSIVqdXIroKhiSi2ndW3sUGilmg2j4zMKw2s3jk0KZPW9nwd9+2le/qjX750bo3tZxvH3MP7/xVq1k7+5d8n0A4YFKcp62gkJVavYW3b0tK074OyCBX5RntFlCcfX6hFrYpYH2uZdC79969r5m80xVRH5uhvxpbo6PSJqadqypSvKzp07WXrK4E8ZxSVHmloaDtadb0jxDwhODDNU7W1IzdKpjckyHrXelY7nJtuZ0p6BNxf75/1G4H+l72zvSWOKwphBvRjb3eV09UrdU1m1rTfhsZ3YN36cm5g0c4sVTvSRwpCcB4TSvji9QQC91J8xRHebztCkWgPTHxNSn9NnCQrwxb6MppLzNoOlJ28LGJOA97r3UVc93wo/1WK7fb/i9k+3hi+v0K8pbyYvbGBwa4a0D2RIz+7AW/EGoUrMlTntEc62uW6LGURYv8uVibqIy5qIIjY2Aflt/VDnBZNmLqonkwRtL+Jux+zTCwg48OKRvhM6I10bb5+Rb7mfOhmneykJG7tjHtkJf/QJYZPm+iJFJbj7wx1YuXCWwIde6J3OLKoK1DccPOQPa7gjER6enOnOdPrRmh5MDHzkCSDkTVfX6XPbFnxVVPjZl/nGlk1bNm/eNGXoP1rla0+k+q7Kxou25wu6HfShHCpdF2pamhujPBaHRPn5hp7t1NXR6KIIJoFHO5pNwxgQO06127pDm98OiExPTtRDlMrKc/vP2luPrVqyLG5VcJjBbpRNBO3cyrlO1b9zs+pvGpGyb07aKhRuyJvq6Kgj0oCrQ3WhuaAZU2sBsgo4GUspXj+OtI6RjJamFCkXmxMXB4QleIdG7zuUZAhtMgajGKBIFJBf/PWIHFQ10kTSeh0d2WGZCZbljmiRiaKUjud+urhFUek8eDiHMXzIr3NvJUyPAuEKQVFLgkE0R4ifPI1FXxDh3YHYcCN1hl9OqmugQFhsm9bn+eBxT8+Dm3Hg5Rkc4V9q8bcWlR3Qzxe82W9vPyI0L3k+CDknP4lEN/mb51Aj/zY3qQnE10p4+OzISXZOpkGR/mk5w0kONKeFsXNjjB860QEXyOzgC8jVAhMgU4DXf4Xkr3lNfZ6XnEzVm0BZ4M04tGxRvUDrgBNovAHqn/ETQ6Tq4blPnO0+8cHzRVJKcXbZh0bUXayQm4lmtokG2uF+mjjy7d3OYIbn7E9hPtyNRHESF2HRtsJ825GMkiRdDFQ8gG4JYeex9rIuEqFQP6tsWC3I8sne57/bQjHrGTskeGoV0HEILUGPG/rE5aLQPoPP8TqIrqRaAKLW7JGx92f88MP9+9//6H5yzJgZM0frP1g90i2bbx5DT3kQx1Tpa7t443q7h7OTz2Kn+b6d13WzAX9pt96fGce+13TGfaAzxqRH+EtbWJRTthF0yop7rLQQQ+Su4lcT1rUJ9eohlUeOVG6C7ZFSuBckXrXqB1BWWly8hiUxDJcqtm/ductGcpB49EYQIezkf+4uQb5b2DW10hC/fUgBT3QPfcozc4AOQbebdeiagM3KF++l7Iqys7oYRof/2FN0va4pP41p61YkZ26DjyCqZMkuQ5hTdyHBFgJrIGQEmv1wZyKS1YiZeEju9TlXwABa1tgILQVpfoMu/KwPkjIyF2HhtqLcRvsHJ2dHobCikekMoA1NzE2qVSdrDUc01D0wGcaViK2y+Fvpyhfsl8aCwELwYEeLgBGlF0GLlQOYZjbnbs5ZY0uox+zitM90kZQKh0rzQjEBnjNccpODlgA7BS93wX1C5wClQ4BAlENDHgLYLinYoQ0zpgRb0ap0XhV46++5Q60sKGRZoDm7xjnGGKZwDByQQ6UcU/KrGsBYUSD5RHgFutrUJijMKS0pKiopySnOSM/NztBJVU5HS0o39fSMnF7EwFsJPBvZUgh61ZDjh8orihC59CBk5u3IOQVCPsCS0ux9bmxn5T2UbHxl8WU1pCZGuk68OtO+KDR80RqjVj6x++Dhsz1fL7xnFycync6AvQ/dPfKP0MpzBaDKNmxcDiJt0OZiB6U9zrNqnp110yazng7PJ5Pu+qXjF6sMD9FVU9vaFnHeyysi3Ff0tXXvhzF4Ojv6eDuJMOX5ZYl/C4a6+04VeaDOh0ZQZx7viL9fcSJ8/xVJkmbNkcJ+u7HplWHeKRLj4BIy1Z80ygtQlHrc2vvwbU3PM6FtwRqTN1ZRQ7kRAwLCvbKM7zpR3GhfkXDUEJbq/ECFfAozSvDC6XbuRDHi5CIHQc7JEqQMT1ow0H8//MRwFwonmWd429Dtggqgbwp95jfphixCc6Fju/isB+/hDFzGWRhHcbow9UUiHdIzQFQdToqJTUyKjU0urxC9ytfVLQ+EVrk/B026Y6cg4GvCw4fSA7ZIqgO/tAWH2vWXFRf1gIjoR/FQZjuKNZhRJMJl94TQ81h3SRePms4bQ0kWiyBeMLktO3AjG3799Z/wTTb8jWFiEw54FMjqD3NyAt4eza2ZOmAUKww1A7ksqAI5iHJDftD3nOM2QT5oYYTa1fLbIyN8hjDlErFkw7o4Yz9VGRqpFVqFvMssqQqDrUywJQtqE1IStLnrpY3o7cdCQT7zTLm8AP8ORYCVYhb6FHEZP+lyYgWcqQdWouruliA+oacmzOKrdZfMUxVirXSgur6gxU7KB86jRgkZckRMO8rNXGTUeXBQZGS8vylHnIIiQShCCybIFRDC05lAFRflG0BcINMn2CrVWFwfXqNspadBSdKnKBoGltp3VkuixNIHEhDCvk+OJlRO4Pk3i42HNqzfK/rPX68yhPS1LD64EGi4K6tqe+LED9evvfq6f+HosY5CQQq1H1RIKkMbKPSXIaeW0nttFnHf9cI8kWSEKkKJBeLpkA4U1M7N2IrNM4R2EfaXlAvtD+dd/7K2apcpXq5sllSZbcT7DY3nq4AcB28OSyYIgpIB2cMcDARIRPX5r6YI85nMGdAZYfJbUfAliAMeQVbAB3A24C1IC+wsCIsDIdWcsfICnn8Qq4NOBAJf2Igugk0DjcO2h62BCeAXaHxgOzo1EAAL0BmBQNiBTkdnwc6g6bAbnRMICjQL2wmdj+0IwdgO6AIIQRfCHnQ57A2aD/vRJQOh6Aqoga4EK7oKXYOuRtfCJAgLtBZdN3AAbHAQ3QSHBlofmAxHYQpEAD+wGxsHoow74Jhx5wHR5nsPiIHjPT4IJwbtu0BsoMMHxAecRg/T8Qx6BBLRo3AWPQZkGOfQ497zg86ES2HrINM4F67AMywb1MEoyGFX0VfOnbgWXYMb8LI5N9DNg3zzm6EApsNN4224ZdyHSuPd0ROcJfYHwkfmWujjUNv49GCGuU6g1wd3VurBXeFb/3uD/g0z4SHMAur7r4AGgd6hH9BPQCH87PMI/Yp+Qb8Bs71F6PeFikEC/O3zZNDPDyoJ9Af/RgHPsQlQhc1gNMFm+Sm8wGZVwvAYrNMwD2xpbCls2cA+2CrY8tiq2IoDHDQBW7G1sbWwdbENsPWx9bAN5wFaceFCWAIrtTfV3wG04BbQHxhGGXgPfyBUQC9QY5sCD3pIBlVoCs0hCVJAB91gPKTRcbMBvQM6QF9IBxHoCP06dgrgoD225Q0oh3YYAnY8tIGW0Bo0xhpYB0sNT2wXfy/wwHYNWITtDsyFFh1TsT0eAQoYgB34Fj6AEnpCW9hgrIb55uXQDJbZ3Q1wAvTATnxjJIyAQQEb5iEwDobDKBgKo+2xfnuXvJkhA9HSMZC5CmCTKEd9TfU2w2LXC0mQZ0GVVtf68Misbr54r3a/l70vMZ6VnOBxRgqNho8UVZZ4XGeMgkXipoaxyEGe7soU1TvrZE2L1u3KGdjQbxITh6649p4F5y9dqV7FxnE0r9MJ0uuB6BaZPXfSZPNxYtJqzd3RCGwnLOlwLPZEJDYZY5sHz1w/ufvJ22tnsgsozQe3VfOVrZDSPeZskVR5lDFkrpPaSBNetxiJPD7Uv+tGpuad4ErXO++rueMnn35DC8WMkcaWIslRvpKqS7IsHVNDoix9t7NZ5lhkb4c4xmprnO0VrvicCdOWnEWHcog0EVEnM5VpC5/vqTZqVs859FGOPb5JTmXm0xxsxLH3wu2x27exL259e3fCHtjv7LnmkV/SaeRAkrFyMu4GkWA4Da4GqyHWkA6KwIImGBGnucoLPvPvsDHSmGzMM23DXifcdcF193wqpppuU7MYBhEn4kWfLk85Vu7Tuz2WvnQcK7Api7IlazOH/SkM/+M73uYjzvBwXBkPx9f6Wf8QDi+4/4OY4YQfUWRQQgMAcLCQYcKDEJLIo4o2ksijijaGICFAg4M4r+e9nM63+XUg6ZsSlKUB1ShHTfJEQvwKQcTEVTji70LJLzmVRWnmgyMcsChY+EhTogFMmioYKh4n6cEDcEtfU6/6llRWucpdtzV3/deza3WvvT7drZmy+5tjynMYea7Pqve9K7BE4AHJ2IWHcloeJVNWC0eIfK74zmVkeJpAlytdbzRdlyunNzXzT3ZmSdZgNXPsrhVucLafeYIXepMPXPFbXoQr7kIRJbEkhmHGmQCRB8XgbfC/pTH8HS0Y/Yzs0fORE1IeW4w/x63jMyC4kf30ZLl79iJ/g5t3n779iEnLKek2aNycVdui5qzYciAhp6zhSSs27ErIavrFn/YXgv+Hm/hvE9WJ/zMRJw6fOGbiRML8ZKnvQrl/ZzMzPfUrQv6AV3wU5Ju4UqDylohbIZ/+S4jRVHTE10xptj7dwtZoc252cTQx9VIl0kjUP1l5GhDcYnPdA7DGWFf4hnrzztjQEG/bIuA94csCzKfPYasUwlW7yyDXjCI0Vg161sKMbK79K5q10d22tEe7MC30Os2v6zmhfLG1LKuxQ4YZqg11sFpd6/J/R6H5Xo5bUDZYde6DF8wP6T9/22BaNP5V0/BHO1VefvGK7UfpMfZI8PJIju2WqCc64WxZ25wDBmNwXIhS7bXANcaVqUmOwjZrfcjAIaQ5Mt5z9/x5Aa6MSqqFjTQ7J1Zods0Fy9ar/NZj/TGGHUZhoSkM6c21mKKAJxPSJUbMNKlnxaHTmL5ueUrGNijbctDeeeYelnRL3x9YzupanQ1beFOs2WYoKy0uqlneM77nOwZAw7dDKNumZHGubYqIYn6YgCHYYKb3R17VURuUz4F1bhKxMd3ddv8XGuNNEcRXr8zUBV5HzTjWssxnwWRSNjDfT2mUn5td5FtKl5ch8lDbWokczKYR97Q+4q87pqYRKvO2FTYPRfopF40LCy3AaCpRN+NN9BjTaZ5GNz7VWhSrXlcyJm8Bp044E9b6jJeJZdmpZ3mCs9HStQMiWoYWRf0E7Hg7hPKRfMVLcaVgUO7UT0JrvSuEGUnMZhFTsIGHlvZa3Q3toN376xRrhDIhnEqJY2tWTTZQvt8hURcrICGvrHrxzSHvw08qCiuQ/CP8WrTE1bCEkfzScLjaEvHwBrl+S+b1lRiHH37LUgVyG7z4n/7oPPiL8PKJEizw3GA8jR8O9htT5+xFMmmxYTebMYJb5gLHBod4ZYmPFz81Gw2yju7qMO21hnetY4rjP3yvwWApAA/3ESpqX9IqRGiWHptnUZ1hnk/BbrRACjHfeVU7YO7NIUfQdDWUcLaZUeOkqFKWGTsFWbR2E8pEJZ5yulE0LCrluzeAIWDjhwbJEWmnwpJcic4U8D3XL1aKdPeqJH5mBEWFQkPRJrxeFWZ6BQzYWFrvVabNBpUM2jQMyPso6kX9e/lemNWLSoHILajg4K39kXKjEgvn4qVRTzuASPlQNEt2mroyNK0RRrj38ks3HrHfamn41S7sLkjIgw1/RZMRrY1FgT+OuKExwut6A7BW0ISOcuCN/j9UsTVboTYjOjYFjUFRxljEHbxnBFoU33FW/DTyVJS9F55Ba1ED1j6PrPantL9UGBfmyLJDLmOl4wEeRS72aGCDmjG33Q2XMdXJvd9J0xsuZV+zxyIZlH8/55Jh9XKvkD9sQIDnRy1rk2p0/mVtNZ5NKx5/ZaOzHBNf/z3lEQb9Nj823SOq3p5oYz/akkjPxNZ4cPKvyHG+XOwNjjWbYVqWoNXkOJ08UqlhMgSkISNpth5KxEb62fQJB9MWZgiAP6xgitDkPeuDzRx98zxUAB2GwhH/wl2yhHn3W8xPssKDhG4g1pHZZ153MJLYekcIW29njlBSGucfkEWqh6IcGwfPnYRXj7UJVTxOdAgQ3yoGomMcASsyIVmkp32YtjFt3WthrujQ0W1Hfrgx7ydc1ZEd+QeMeiVnZvzmFPtcx+a90w2+jj/anRgLuhqvd+OOEI+voTFyO3Jw8AJN7I/UFPVvFgwDshivyN4nJArF2vUxGf7eqx04HurzAkdlzQVeFeU9PDu2P862UD1RfakHIXIDLYIeAS7ucHJP6O+t017/RxjuvyjB6olbt361ZXDhsyHEN1IHxSr17onuVko78Ik5Yne8HoLRYl+v40YKXsS4gQajYcBPDfQJhjvZEBvQTGhU9kceJrcGmLqEBKl/ARHNxXTLxaKzdPiuM0ca6peULNttHL4hhQSnDqoeINQAde7l3stX6FIHuKzFqWdXfIuvoapcD4+I16PabKAy/0Pri5admw1K5ldoHYH8yI8RiuSnXdjATrbvsQUfoCg0yxb+DXb5A65E2xyOvcFoyCr0iOXLIwNt5ZiaX1l/7nTrOYMob/WTIXxb9SNntWepnu8HNWz6q4b13d7N9LJW460hoW3DoUPVeN3yDeWvgarWYfueKfBp0IlSIPsWy4CGoPQuLYlmUWpE7pIo2qSZqyqRiqKa0V0wyQoW2oIZk2dZz9OsxGmz0FIHX/CwB8x1i1W4j5W8b/bazDK9EMoHQxh+C2AErjWpsk3WynygqDTLPFoA6TWdvI5OkFACRdz4pfjLzGgc8Znq+kum5EMFt5cBX1tqt1CtU0xbCMX8hqw+/vPAjz8GJKYGssrMQQ/dqBgOL1gLjd1hxQIkDrUvnPsZPMBXoLvWNGIBDlPGwwglYExQsOd1SWsF6jtgKN3QG7IJW4FzVv0zNsE8ZznIA7GvWNgNaYZNbd2U12HNRm2a84W7KYYpgqUhoyU9H7Bp61GzA95eYTxcPr1ltL0FayeYFDrAX0b/w2Tjo2rj7ar7Ab/gANn36dHDxkVlzDRH91H2zaZQ7l0Km3vQsECEmYodW3futJHpuXsEJLzMC4VBOY/pdtHKxbMEyoUXezGKyJyJDEqqvVlTHMOdVhqm6YdQ/7vhkE39EcnIfM1U2VBw6ln5SA6kB3xsHiSTNAk3OlzQ6OegfKXPAWc709sywADir44gm9VGzBtrofPzzxr2Vx39Z5cycYJvvOsLnHYQnz8gg6TK4SB8DnzC6xOxoRApnTlDISvGqiimAzqZF9AqhM+7PeE73fHWd23SLoVN75p7twV+pGT7SxGOMAf3uZSllaQXZ/yzKGbZzogcwg8nAQaGA7gtUWGH+HVudJLXMVkY0uU+YYC90otWNrjcp7WVdZ3BSgizYmROzUrkB1FskcVjHg3hQhZLgKGkjyY6k93HaD45fU7hKf+iA46mCxuHWq7Xa3DcYLQ3aegx+NLqn2rK8yDDn5xklQNfDvKnkm44zLbuVIZ0Xmv1X1OG2WXGl+vzaypUIZe+mehnkCkRoQ13R5vmeP5OZdg6V9h8hplvwenjebvLjVVhWSHhNs+TyztK9n25o1A/o2xYkb0lxx6fXFjXe6ap77Ez3NobPeOAYUH7FewdsSDfzRkPn8apUCkX0QhFSkhxwiuoq8t0iWLb4zIKuxdpJ3/7zzGdcoAC+UBCj/S19EOyrEfaDnqIkn1hXyFSPne7ZhyNa/Mie+YG/FpSgrqTqTnH9Yp8ZD3pTXJtDidlDN7mDw0IPy3Cd8FSXRjyAVoq5OdjsDW13DcZ/gdS/OMLt+PWwQopsK3eqV71bDYuGaQsZ18FcQp8xCjg4hFAFfH0ouxWYCiWUxdRJA9uR8r5kPFEfo4eqe7pW3A0CuB6ESyMlIOgCz4B483BGWkAPfl2xS5wTFCIpy0RCjqS8vmIuw6IEdm0aTW88n/5MGDrFvB/E6ncx0X/VU0QNHhXvHqhPlZ4XRK2ZOPRraiotNctcS7GWWiwwHwOaw2LVC+fw0UbFqtZb1m0A3bUJXHOxChiITaulnu4wtCKIktfR/6OQN9Dzh4jlx7Gn7bIb27IxeDBN9KBm9NVFPvchQG9DOrbcD0uNZpqBxaAFlvztzZnK5SUHDqU0U6xOTJQNUJofAnwpOvkIwW4rz6W+KNBrd2LPVKjy0R5aF1oX/GCmBmxxp1Uz6r59kXu8fNijW87sYG63C/Xjr683hHGiAT31dFO98vVgy/6u1abjzki9esZo6tFXx6M444F9hYv9qwj4NS7U50qxVzX4cWvY671sB0gTAti58QaP36gG1oQNyQnrU4L+PmwcScr5h04rBuSmOjBWQ611NoOHUx6PvIufvQ14t+7yPMIqU0ObGWtpOLbYFhJGeMJqncv/YQXraH7U4DL2fcoytGyC0/M53C0JW+Hs8xD2ihxB7xdpMPLggoCzyIEePprUYYe9DgXZXg7H07p7JXmbK3PbbYTGQAIlP0pF6PPGRaaIUKoC+cIvO3MhoyjOrdz3MzYkNPQbKN4pkj00t37Ewxqx7j5YGVBsL+Nkd3fYnBCdaAF3XCyhWyHNDvwwUZt6sE+nnyvst68zyatR8zwd1huPFru0DzKnopM/e3Xn+D342Tjw2rjrerHQb/hRjQ0Gd3KhBkurkPP+wu3BjcAVPjsPoESlsILZTye1rX54fMDE6Q4Sqqjl27IxusRr3bBA6CWxnqzpp7z0Qq2BP5FIC/e1euRsYSa9YqS6yucaiZPgxdfIr+uG0gqVjjOx3RAHoJ9fAPY9UP5OM+aksDzJg+udX0PVd09qM3rkMXF7bDm89MBVj1e5CPHel2g6LxYAE/3AXW2cS6spHN57cRyPQZ9lMqk+pzmD2Je/8fHUNud6DrtuShdefxqw30bdT3u5kCqF0ZsRDIG+kAUv/9q43gtdm30CLOczdMWxZy7bzwk5U5WggpVilVvAlM7RX71pjKyfuGP5zd/ATnjs8PttE039dxKXDqYGbGmpoe13PDjRRBnY3vc1Gr3u+v1VVPXQlf60xP79uz4pyoryHuMbgdjaWDjKBxrkvIxzTrpTSbGvfjNYPR1mCY5QALfIu/jFtAngZJ5Gzn3wiXWP5qXx6dAKXUpvPzsb80byP45JFZEiLgcjdRIkWhvEe93TDrjSKj/6eHLlkUG2Lwwe0u2PT61u7Nb3dmOGuPx/tZeMmxF+4sETJGOxKuDpoMEdUMS+YcdkV2+NvXiL1Om15tLFnm6uT8SVvpQowKqYtX3B6e2KB93j/KIPt2ikIgm7KBhxjmLoogOl95n3/cdrlOgs8IEbU0yqqfMbkykBxKbAHFsYDKXmy4LMTIQxAxZwahFm1G7mDHIvR2n0Ks1WGt1edS0EMG4vmruJu1w6PEkrbDq91ZICw+7HVmmUtXPBpbhf+8scu+oBVFSHpATOXLBwpTjlvsnqCQ1ubBzDX1nQ1hsxL8w/wVLNY3rltUMmFz8SFXvVmmP0XuupALybdy/Cqj/LfiH+EZT1qzeqLnG5hd83Wzkc69gnBfraAANkHMVA1cm7YeWqlTuqW9Dw8igVJTvtYpGG5cdUSFMaG9cFSNk7cPRUAT0cDG7d2LgdhFDpSLnZ7+XM27YK4vvlpdt35mvNyhrl6ZvzLS/s7XmkEFTQKSsP+FOzcOVtRqRf537b9ShsS1hSH4P5/w0twzaY0fRjf6ejwVZFtPI3OsoEMbGzzCsxBSkOTBipL9nstiu81no/Ot8Rz+vseMNrma5CVBl2jIlxa1rU2D5FNM/CrwVwLA+C6/gCzs5HIZjtHzCoCyUGDXvK+DEbjCN98mKcnQL8rw8i8/fqMOZ8xjZ1/NETbjhriyr2f860hFtkMgV72bFGXuKCooKi8kNoX9yLgGincaxhCQv8YGlkuHj7xAK8Gtnfp/76+U+DCcie/owIyXi0pAgvC8imLYrGKyaeG0DjdXQlvSfLzWayJt2V7LURDpvAkFJ2p2uDLprV3Bniu6Quthtko0tYDSQzGAK+BFYXve6OP2gzsvBlCf9Z2/e6o9608ExfO48x/MPdWL5GpkyoeGXb9/ufvHi29DhIya+M1mygfEw4aYpZ+AGkRBuq9pecNSIfof5DDXvwff9GUl45zYoi0fsf0NtwD41G47LeGaL+US8FOLDyESmrSVQWKEJnhSBSuyU6kJjtlWBWRMxWhbaSPMLDG9qBr1d4TlQ4HjlcUMNeEW3AFlhLNYYyg94Hc1CfZQISKWcslEr3ksX5iNX5ALU1Dj0fmbEOHQ985cryp06M95yTJHlvS/QSpTDmxAyHXXgiyjJhmzuuZAnUxa7I3NkBDfUGQfGVjxy62Zm3lzEHpu8/eWLb2BK1hEXgIpujglOrl+9Ns25zGPon96D7zIeuvR/KYuD+4HF3kJ+j+JTTNE626biU2Dw2KR43sQQJevt6uxmu/osK3k6PsEXWgMarhA4Zmkw9GUZ6rMYxlU94dXqdfX+rYznff3xm7cofgI8idW3xceAFZ3wOW6Uo7xrTZS+8DS2fgE+QyIn69DmgfBMpwMwWtqEllBspNV1keqNtDmVNm1KqDfSplXabHtE9yrzac1Ih5yMaZkZKFUOZtRSOZAeoGRCv8zAytRfOB/AyuSCyaAicByY126ZAeTkmn+M7IO0vohtZZFBJOva20XD0C62nPYQcD+iJoNlx0fShw2oz0TDXE12qBYPYB38sJ92gvvGUZVjoYeatBxXbAXvP6VFoWpJSkBdam1yKwZJqseMa6Bb/N9QfBAwNK+9O1Ag5MHMa5BUklFufMIdkpSZkZRSlHXgo0Fj2WNyS6noy5FhdZklibrawpHR+PgPmtBCtcJ+nkvZihmlfnmvGXltDPt7Ks8sSTqJSfq9QbpsMEtMrLzBGkdlDjTVaSvf8opLizE8lROnuo/fsRMuuU6fPNOdQUaKvJPxplre/kIi8M7v+whl+z3pKtMS66x/G4YJaETnetRWyksE4KFTJ5MzMjuxJRmHjPXWDWG4n3/w6t5lAhkH5XcJZ5bJG6dJDN4w1oXRtqF3JlPAue6K0uN6t7JqiWfMHLtq2V2mzjeAs1EDjry83/fb/zMOTJkyHQ+mzsOGPXB+Kemuy5CtzTKGrTYnf0X4a4zfdGgsWUFYs66GBSO/IHcTYr9gdwoa10VIKuNzYoVW+5Kp5/Y3kFrigzGs0TNidecAWg8Lgz7P4qhvObaUYHYkDxuGlf48GkPUzMdiNxvbRhw2tDUv5GEJClE0UpV9I7lSmmX1bM42AXZVPH+gRUyvlmzTbL1XiKN6EBr6aa6cwJiB7El1q6eHo+x5gzGJZjmbMAPIE+pW8MfI8zphEozk9Qf4evw4/Bllay3yjfGjMFC5M15eAq/7NcZu8fn50Jt5eQV6rbJpTdqmOLtj5qnvDZK6S3NqQgv1uqJDNRdty97vXzvVf6xs06Z8qrjyVqflrbSPXObD2CQvcD7jw/z0MKV1a5iPofJibANW2qtr24wAvhNq2w1a4Ag7vn3kyvRNm3IhQl5+Wd4xe//+pWMNljqPdyLqcvTQ3OQId5vuHZu51DEuLS9vDQg3FZZuqrT/fOxjwiazhvyaVS1p2S5WNEOgSPGy7Iqwc6BSwknRAqFiFC1r1jiVBz6nZcehnVU9BvhktEDe9TDLxKSkukksbGpmbAZm8sdUkR2vQ95xD/TaISCUz0DKBHvGMocJ42UpEuaXHoDTYLnTKF+V7ZD8cTmYFCYNXvH++mPlauwgzWqKgkE4dvIhQVTuvWzK5Iz8BW0y71hawE1Lqc/fp/oEdJ5jG/BWACUZb7uX85yeF6C1vgPbk96BdzLlBWGM1Zc4mNqfbuiF5yDurXdKPT9/jYRFLHJsuXLqKLZt9Zy8PJJ+idBZWEcC1/Fw/f7KI691ukkTfeIXvcCpB/HFA4Im1Vld9E3rcWFO3zLdiy1Ni60jsPlnSckHpfbS0s+37TcaGYyQ3wsrc31L3a0ntqcht52r9e5V5m+D0LLHM9M/T7enZ3ywOdMIIrBW7KJ/decJIXPesNUP+Xnq9M+zD/qMHO3gMGrU2w9/JGbOMjsRJT94dQ+r0EcdlRa9trSyzXb75sl7310JWH5c71UWvuxbM2nba4QsItLdusnBb4TtrRa/r5L1bxKlx/POhznbprv7DmdIbldVnO6iHEztifhh82uMrCOkA/qp/psEaiVhcJuQKQ3NueF1RqdSvdy3aLGd0QQPYfhswym8R67IzTeZbVvz8dpP1uqLwvpkRr9N0FzCtG5rKzx52uhQSkv9ckPsk6a1keMCg9xtQa3Ecrt36958W/EnhcSqU5EtOC9xjSXu20+aX9nVWbu4UDYUlG2ost/uaCT868ZVk2+IYfNpRiiwxWRofmnfdrrZfvjAhtwio1F5Zk3qrpX22T5BjF9oZDHSkF5OROvqWWb46iVLAuxJqbsKs8tHaA7GL/AMDkHj8lUYVgEAOwfe3Plt55mMpCN6m/Lu8oi9IXaG5S5kWpJhBMoAcNvSEhcvSkMKOJonGIMTxtNSFu8bxpVRek9Ot1pR2UBK6GpYd24WIt5SJu6bzDw8U6xQ9Wa4vnWGMf0qOlyBXhT2+XyWC1ymxpErwbflhhjyhQ9c6FJVgcTBvE/s6nrtkUsVPVRy2eorozQ5KSM9Rachxr2KFEeyJKNx60y5JPnTpD9kWGWvotnI3FdX/KuFje0JQEyhncUj5b0yOmYZRW/DnmVkHcKgph4bBWowWsO9llDwNsS1at4nZreYYfT3334mxJmNUJlG55fEKUU++xVGgjaBcKESBn/9xv45Ne9jc28Uzc8EkyZWDJZdNZv8U5XKH5vWEXc3Mc7Up/ywX32asRGyrG0IlZPAhZYKPf4Rd6rUyzrkxIx1UYUSMSOZkaZNvskSugdgSC5XQ8qsyEUTr86wu4WMmoU6tAuu0rt2fpv1IgV+lmFUmzr5FdhX7mK9rP7w45zul0U+KwMTjKZ4n8pF9uHX1nBsyZX2E01HjcAj7auu2H98MjSbzry/R3zGOG/KfN+O/s1o0Hjci13lnfAt0N5cFu+9es1nn76rhyof5u/9aI/9q7ZmgibNd+78lmMdBQUffrhDr1M+X3ukJMk+yTeQoUmVnJtMuDAoPYHsiExwdBlt3iGzO6gTXz63kR/IgMMLniATTr9uy6ewB6mJKNpaw7GOSECmvzlIPaSgCBSmfLZ2JIWKhHpmQBnniS6V3ISpxru1GnXoC7T7FyYTLnD7lyr7A6qMFmhDs4tfb9Xi+vWezd21Vr6lZSoylQovVZTRvFprdxEraz2RjffF1ivRTYaMNHmGOSUHT6IMfLjpsBhrdnkN1MHoTcFCS64MfT537+rdq/+Zn7By+xI7C+9gJK1IApRQUGEP+M9zk65F3xlKmCQDfoIMm/iAEI2w+VNtYLgGYEIQdfucEWwymSgVBx100R9cyGqxX+0pv37CmFpn6ou52w11dZnk4NlKiATtan8K6FQcGI51Qw7DQMRwNF3iY+7N/OHHUfV4NL4+eszMTrWfaL3tF/v72z1cHH0WO3Yvnf265VyhHYahdE5vSpLM+REbb0dp0Blr2W5zmT8o00y7y7zd3KJaydon8YgdM4aGKy07T/ow3rRTVMHDO85K6l6laDppBqO5LpSbFyx1SbdFHvL3wu1mwRHNYiTT2eWexOHKs1ESjdhX931Co2OihmlDV3VUQq2lltOQZrx3IIvFj2yJZsfKJUglDY+J+oRHX8mSaNTuOMtnKkQTklQDROxW01HxspynPiRhW3oWzQspWb2diBoudKZChIRH7ZLFW3l0R9RWGtYE/T84Kqln8SkFiy3nxIoVXw5zTaelDmnG1PvolFnvd1n1rLqmgNKoNdYuX58yo1VPBobqtMhBril/BGdDEFaLpbe0mElMSVRyilpYM3u1vjyhqqYIvXstvUaXW/Xaiz1KLSctxxx2vWKCUpC4Kwt5xXFomhlE1AwgoMNdjuYURI8tBzs6xodxZpTA8JA7c0aiUVdMvAqExuq7XLHKw/gaof+jTKUL8vQHzcM4BpseZ8Z+hcMPndEsszRu+9w8FkZI+CBylw7pZjHRgVst19PaKSKxpo2NlhbdqwbafvJ/ZnQswRSEc9xxyiiS+bx8wDbW1G81u8tBCGnp6DN08WKr7LZHzzHP4gfHTPIoTOjFPeBz02buXnybMBomNFlpMT2rKtZkKPN/PGlqTJ7nWvVJeqsVQlqmGqu5zGy2rN0Jb5uVJzWLoYxpsSbLszhVKUUoV/llCt+B3h3VzJwSK8dxCrTTY27icUntZa5XvVj0GDVosojRNTt0CdKQOu0Yb2Y7vlnVMV6VG7OlRlZ7kb3KhKY+QjPGaKoqJBUUjKL0FCDZUvHPZBYn2ShNcId1RMKY6xKckkai6MYw4SQwxTIKMUSS4Wkycij+5RulJ0iTBi5k7QOk0HWIJ8S6JMFLaORY3J7ncoKTtQnNBw0tbhfLkySjEsIdmRGdBKWkIRPVMGFnBE0PQHdGk3tIhqd6lI/2jVR5BT81KZPvOey8qUJ9paTBdbgOaUa07jyFqTBYe8n8JAAnVX7oEW0AWhJBIRZnwOtjdVh3asuDIV8VajfBVyuAqWgT/j5cDej6zrEghw5oEsewYDUP++KtxxGd5e/u+2Os46yERl4WluEyZg+wBbxsMnFOl4aMJuR4LDl5s+TkRaNFGX3fvLQdyMlEDe/kFJFTtRF3nI1vsf/6EMagQH8Krb9aZ6fe73vQZaKhdq29kJs1wNr9363N/1NpngZBCA4z0+fIpSsjEPHkF9JPQ00tD20/ejROGDN38Xjv8pCOxfquDdKEqGl+w2zDHy0ksxOPDty/o/9Pyjfjpbv2aE7UkFzvPNHZ1JMy0yMy/PUl+vot6aVSUF129Wnb/1T2Wxvk9QW1t+/0nX911iA1NWbBEMdML7u677zZJVNvOv5KbLCma/+AoaAFVnuJegCCLRGDe0411Nlm0KfapaILDTdtXzm1TDumTzgujahaWtFpu9lz8DlhvnwgoVy/pLyV6FzLsNZsnB063PdwRGOCMTtrud9C25Qr3t/E6L9pzaMZdcmuNkfvZSMZm996LEV3V1LeuxhBhq2JfrDvZWdcbUS5wXFHNOcD/o1dtquXL/2wUn8RK12d3x7qZXOZ5zWyUlepUTWrNEqCG1wsupAOZdIn505nqokCdtMkT/+NJaTAASGQQOMlCIIDHV5fDyaZFHtIklCXSPmqwBJPO9vcNpatZ6jfjSObjxuLjp8yWpWJE4NSvO0jZt/5/fud479M1K9MKjfU4XQML4Qsfp4l/Mza//JLo2X7kWyu/88UWCYP/40h3V4QJPTSJe3Z4EtdGUxot2lJTAb2aj+dcT0dpWrZ6WeDbXkHjpyy1a48+o4+ltvtMaqRi3JVSXZiQkZWrOEhq7m/zE8QbttCbdcquWKyYnKpFAeqNt48upma7SM2c+n9MRoNN26mo/mKyoIG84CMvzP722/v3uneZt0dP372rPF6/ZCrTW29V1t8F7r4+9M1sKVXVy3lRW6T+j+0xXKg0qhqOnP/0mbUm6JNIUWoY5I0DCB24uIXGYgCNEt9lUSkn46e+9r23L9j+rRA16E69zoHX8nfPfxIGuMYs7f4UcXRvL3lepOyfH7MhgT7CtcigidNUMa5LdUNjceXejjHz2LDXnpcusR/7esal9VR2b00zvy5LJ43elJUrWkOwnft+7v3vv9h1t0xY2fO6mB3Z/5gDLbjk0RjXxUMoi0e64dfFv0vdnHy8XFx8W2/3tvW2WuQwAdKLV8rU45QtEOJS+2HMSh1XAOVj+08o1NRofyB79ACf37VC1W2KkQ1cApU53xULVB5llqD7PQscOST0Gf3YmndyJ+Jp93Ul8/F4zBQKWegP5ZQmdlrOMzNBNYsRj6LbKG+ndxnVW49zpNZK3YYFSsGYS+Wjd8Zd9YaO/gc8nMzEfUk2fVetnxeNkptPxj00ibDa0XAbhFYlO3Jlt6MSOG7B40yNfBphWHusgc9oyzXHCE+8spnaWT4WHyBEOC+Biqflf+UypYqj/5K3zwPExavl0aXeKSQwLuEFRIofwo08j/6xLHlav/RwdbuNPVPk+bp8j0yb356+05F3+fw//UTD/5dpKChu3z+97/Xffr3fw+95Mz//Ol3kgEzApapBaQ5nYQ80zCCLdEtYwKDS8Hve/05+vcZv988jWd92/+8x0oWs6JVWa1FsJLNL2ydJ7GpMH7soYnAGVqQsGg4RN4/3eG/tkmzlt05VPWENdv2FdWC0q2fnJNmFq9YLbh845is4lqRcSm5xUlDzmo6roSRQFn+0pUblquaWVS9cVwSvr2hr0FGGGsOhFNQXlVLVtuAJbKopoNlcE0yFbLiG8skfBRPkKdRsEtrew6dOHP3XMgrbzx1x9YesdGEuUDOM07yCys8fZuefAVaIkGKDBt8IKWspQ9DUXhOahniiAxhoK6XeKbsk/LD39pxijYFo0Gnb9wlY1EbDwypL0CFVX3CQ9XSc9dkZO9es/8DI9VVOimXtEl5JV/s2m0ry82/C1qrPAYlIbPBIrgZTxxqV/iWqwz3hsQC1Ggq1TbM32HZWDtn0QRuyITY+ku4IPWnv0v8G4we5YLv1OqRdi4n/0OkQNrRFtgfj31x1aB17HdCRoF7cebRI7a6+gPdLXXZ0XV6u3J4WfA+D/sYj/B5XmejbqUb17Kkm+mlq2JtPh5xrot9DpyM1kVvDzdM2fhLMQ5unL9RaQhGuEOr/ILgIuxvD6LbVSWfuy8YQj/uJ3KCNhWJIU/3NeDXX38m+r7WkopTxlinbkK4dWjVBKyNrNgjbEfyodZqvCpTSgjvUgQf9nbFoscwSFZ5evtykXmoGtvkb6nK0JwsWrP3rfzR9xVSYE4pVOuBoUpmt0WdGAs+ihgw4HBgB2ZUFweDRlJQMM8lzG/f/kwUBLQhYoegrKh4J6RNvKzIm7DC2srO1qmoPbhyiwjw/nv/dAc3RybR86t5D41Tf/OJ7iAoGZ5q6+w85cuGbLDEx9tQNWdkq69p1MGFJzG04OCbshJSJPpRaDtAd8SFQLHagMZM7EBZHZiQjXCC4QzKjBeiN3CpIRa5Q50smIoBsxg5IfSU9UBXrSo8hr97Y/jdEqP9Xmj4aCMddbRHhUYd6VBhwL7FEAhtMuShuh+orDztsrh2Jyrs/D6y82SYU+XoWJpRuBDFTkJK8N/GmTaXla+tlnbtO7TjiL3r3PIg4YVZw32IOEVZE+rfrPJFwVwjpMt/PaNB5ENfBQotGCNAlUWROO1YJMQqCtHSWBShV5+/bEHrPnC8/ZrtldcDJiS4VySvGyAhyf52It95bqD/BCNMXhsm9clkscdpzoKIGSxPWrltT5IRpqw/cmZLlZ0iP/7t5ZEl90YdMNSpJC4AofNab+gDg9LiDhPXguR9DSsgBlUtd/WHW9YaX2z7/PMdO78j4B++8vy3JB+3uCBxBAZDUYGeHJFlyxdyAvU3oCN6DB6RK4rLr2NaefXqGvuz7tZ7gjAvNQ8Uf0TcjcJSjQDvxAN4/2w9w2ul0ShGPbx7pIQj+sABSMZC8haSpzKqoT5BJhHf8mRXaQsqQhqtxSWmzFmR/q0JMtvTlsapQgNtB5BDIpWkPiGr+X+D7lVb7+PyfZs27dbblG3ZOZ+utou40+3ZXfafH9Q/Gw8iMsSQZtnc8Rj6y1Ue7s/fEz6KCDYL2JPO8EBa4Ns7Wf+Q10lA0NmLXRfOtjU3RIu90CFXohg4Ip+jcQDD5c8UbhNQHdNWuv/LHUIbKwBWSg/U2qjIdinIsZGnZEA5F8UYqqVyoQ1GctKwF8RlsVM+ipzsdJGnLZGXDpXCyI8fbdQ+xoEJS0C4u2kp0CMqzWCCPniLNTC9wFd6HJGW4TwJwvyr7ckrK9aPb3uz1V5TUn9zqxEl+36yMW11wqYni+2hmcHzPzWE1tGK1AI+QS4WfwSRJUt2GyWiGC+iHooFFq5ultOcwFmsMrg4WA7bUFHLoHB4XMBemcxhNz/N/deum1/ZyErVr7+GJcqocY2Q+usHv30V97rzpTn7QFQf+xO364lLjFmZcLhS8H1vbUJMmxQ/daKLextBxdSGkZiPpaeq8bJRFRmjhGbGL1+WebROPx65QnGrCrqqC+3DXXs+LEjDuBXB69d/+sUGXS3dcmhaCp7GS8QtzmPl4o6V0a5IFqVl2cVpYro71MvtBGtjmFQri5wa1+/EQpn7udWY+z+EBnJyZPTrXCg7jHht5169UckV8nHJPdINn5u3I7cRRUMByiKEaL54FTL3vw3wfyUgYut8ioWdvL8ngM60vpWIScnNVpIwe/0Yz/+KEWp52KUI+rCFEeODfka0JmB+H1cG3vCuKU/RRdu5c00tkWd9/aOi/MWimHwQIx2YjHmiOD0tA4QZLgtLIu1mGOuiZk6ysRWqkeQT3MLOyu66moSTw18JS1pnSoNLkPY3ACip5QogzTnkMiP+ibciI+vqAEVEExRli2wY1AeD8gZB+rnwzmC/CM1bLv6E1VqNZYoI5QUimKtZVEZFrK2lWhTWiPqaK/lGqByzQehRynuC81lloisUQn3jzQbDxHI5w1falPH+hvW2tMI1pWLusuB3akzXunzpZtVdO0FwalUcbb4zm2s3qjAvAUscgEZHhFqQA4e9mmm8Zd7tk42vkBkR58N4asGd56EbBggYVWvtCxrrz3WdF+l5+bm6OAIZ959bo5Bo44UwjyGku2UhnDj7MJZq2tSI/Fs/A5PuE1xX6Z1K+a5RPOq5cFvcJ7CYel6om4Z+WpTL/+Gjr6StIObnZAuzGFVC3Qo4P4j/aweR+AQOgi6kdxVur6sa9Y2klvbRiNgVIekioyi7VOjhsnijML+keP3erC8EQR+SNcwk8VZNww0b0YQeMWAhVL6Tk1UMaBbtsmKtKrRmF/dadYGuanHxtLseI6TiKMvhhmq2kQi6vEsRhLIB29McKLz1JVW5HwsDPoSOgMfgGSxD0qdyRVj7iqklYEqAABrLmLyMK56E3ol1iJ4fEiC90zM11IuV6S310Hvqq/c3Tp9glj7Hcn2lXfoet/S7nulVPuqffdd+tvyKBBLBGhys7KFiYS8UC/usGPqFLuu3uj1wZa9wfZ6V4BBAcm50xbb8tHs6pTvyL6WdJx6AP39oCiKLIm725xog7X19Cqj1/lgWS7//z2m0/vFg1+j+28FeadAfBjLu23XmPDzL9SxRc1T7GA3zPo6W0z6ejvM+gQOXfQp6rvuUDNz2iYzc26uYePD8u42EqT1SyRFnXFHpsVfe+hqrjyqX52kYNEtENDwufEjW8H+fPQU1nTxlarVqsyE7/evpBDAArdsPw3XbB0/oHr+CjqsQdgkyMCJOksbF0xMRZi14jDQ9AXFWADyAllofhy6zLRR7rHtw8TGi9Z/SP3ZG9yJLjiZdjdgkXHQnUKix9/PDd+Xz/50fUpqgDmkaPkJz2z8HgwmwsO6fY3goT3uGuyOLbgH5XITyj7+p4lAirQ6SOZ8/IrLubatCcZo99kaKveo/+zHmF3hMX2HhLPuOWii2Ks8pzlxTQ5kwAa/2RpBHHoM2sl8/EUhsdQQqDCEBgzPAVZQTa9B0BQiCDN4D3c8Ww/xdvpWKCWQA3Y31n12i3g+NP5a+GrzpD2OPOCwUZZUtUq7vFjEBJiRs+IYasWZoYcgcbzLEynz8SM5SSaKUWtNw5LVpw8Z6p1hy+xA2lXPZ2saoIVsVgCYQw7SSchR/fEpda2ooyYrE1jd5Wi4+9FBTFcYt2XXhWuXD52/eQlegBaPkUkjhxZRXSZXVd6hk+aq1G0bGp2YXdq4rJ6b/N+/3dCtmE2yhtPV4G5Ud94NdJA0QyvL8mYD/7+FhK2AbdztIu1LyeZqgd4UtXGwlhCaope9hs5/SosIxMRdAptqMOP6j+xc4AAfhEByGIwADAigkIQ0ZyEIO8lCAIpShAlWoQR0a0IQWtKEDXejBAIYwgjFgcApOwxk4C+fgPFyAi3AJLsMVz/WReRfJpJzISn/CYvdvgg/Pt5JLHEsHKlNRlmvuiUf3Nc4HPDlbQiMZiWQSxYMNbj8CfB9xDWiwKxUlcMlR/0nkAJNICm0mJlpSiswKK2kEgq2amjRDT5sQxSeQ1V6GMJqk1jcwsY3DMpfzuWeGCji8A2mwcSjbOqrjpKQORHqYl4GlK37qEJNOhAFD52lYDKcuzPjB8311H0H9END0ALQEYTWwGtqnYY7tg8bmQbiMQGAnrRyJwDLK8nGbfQamaa0GxkGy75EiByh4WXJdFxmKktjKlVml/szJne8FV5nQJNq6h6D9A7mFId/LRwOuuOtvcPBBMQva4vM0zVCSj3rTizbLp3vYxHy98Xa7QYpNNgv6dP7JWdTEwKkaJcyi6c+SRYyTAnY5EjWohoadRoDgKjKgl3AeIyyek3Zoq6rui0Fo1lODEbRCx9bqWPx8dgriRU+bY8UzBt504tplWZTDZuTrk1ACLXA55RTD21lcE+OcxWFXWIbSL3P1pduu7DwAtxbigsuSWABtuNQdOgyLDAScoPkf6m7Tlu9DqbnnfCi/a0rl6pA9Fd6A5fokUB95PQXiTZ9K+ZpB18My113zbiQq6kqL4vVTAHjQjMmrY+Snm/4+oT6HQ+vasdQOjwUEAXZPYbJIR7a+c9ybo4hZBfnR7tMiBYUMgebUxjWvRV/zvfP+B0OoumVFj4cCtb4C9UE424TGRjxcxMn54l3l3WNzUcnIJ9mF6jbFhnLPd+ZDDe2/c8kfaRfUGbLGNzHULS3PONVGchJgByK1LEV4KJ5Ao1iSF7xWVBmmtghSJZcJxMpMBT/eW0igfQdM7KfchEYdFHSZu3DNZ76LX4N9Sp3/HNyUjGFX7QpmQqdiILCSyDDZuCyXY73bxTc5daLiw/Wvf8icY/Mrw0QqMAXsPcg8MTVEBQySQRaZK/MNjO1cBwp/UDXZLi7L+EUMyOqQu2617LknRJSBFGIVkNBaqDNBhrANzoVqEGb34ZBSP1y3hY0cFQI1fNJnYWU5NVCDIlVHiwrscw6DyYmEV4XvwKGkRTIImuYYQROmk1sUqD/hLlYcp2f5oCnqsQziajwfF6jQyMeH5l4fCuURs1Yg1xNsBppZvDjWNhO8Gcp0syCkyGeo6TX86FmFezL3CddDdZ+CHCBN3bkE8bM/ukVQVQqaIMYtlX5dU4fT4MPlhm8IFKnb9zz6gPqNWC84s3wqjwNoMlJrsOmDh/UjmFgcU/rRkxuMQ9PZARlOVVu+pzjkFsi32WJSym9aSbLQr4PWDoMWvHP7ySe04FRaSc4lnyW77U5JLDrLMV5B98AWZHmWH56uOYSN2bpuAjsGTSwMn5FJvupTaEnfq4kkpbOiZnNHbua20TU9uFNZZv1xAUjzZD9CMVE0M+dzWGbaIlYrff9TzYCAZsKtNnLPptRvYUprE+rLHNxYx8JTgLlJ51q6IuSW2nDIfNm7hGTG42M0tOhPTgZ4GnP4Im+Qtx8dFnqhl0GqYgENGMEZPDftD3gIeI41BNeoUQ4B2CAGkiDDlwd1oBAaQ5nS1teQdeaGimQ/UhjrAaC56wGgxSsDQCsniAXO6PsRgB4zgNvY1wCg/Rn/KujQcioCgI6uuV0AmmZLthaCXrKbI3ly/P+vFAgCaISJmKWzYE47B3AkTy4NSoFEAE0wEbNf+zjEAUF3bgMQ/Ze6tjsV8SO2KIDAfSfHKVHITZ978u7QWH6tk/E4URuCVXFD1+LmGspV91OuqZHedSN9xiEj9TKol7pzUhd8Jkv/0JLRIjMWC0ugsYQ/NsfHBQ7fPdW7zMknJfBzTllVPcAM7uALlnphoPrI/Qs0x7+42VzEYhjCqQMP8AOJKnNXowAqUIMWspQCn0MiyvihuvpG3tYSwgiBBoDX92fOFgkNh2g/tw2fEY+0KZ/ESRnFZMjLkn6lQX22Xiyf/FTpAxpq72+6hxwe1INsoRPOuTJ0i/VmmnkFH3K2/8PwX38BQQGEQGI3LIUXORiFty9O4MGPhEzUkIp1hFTvaFFWFkRZVmuMxRtktanIqRP9uuEdrW3TWPTGEQAGc7h/EW+QY82bGolVVzKdW8crhqy0fmbrMZphnfe2H3gPpnia4kNYABCX9CoBhggp4RAzKR6pKbp95Hxd4SIaqkVpRnOpsy4Dt+vDsWQm37E3XENn0LyEHwAmvfAuv8T3+vdKwIyg95oDsUVCw+nayE13FsUHxKTkFBKlyJiWB6SEVHZRn62x3BqbJnUa6u43Gf1lDoWMShexE6a1tFDVNkATAbawRfSwCMCyhB+TC/P78spA5XRRj/pVtCAThUdF/cYttZGlQFlWHzUC6xGRdawbi0HbyjrEltwWHhv7O65osNv3XUOHiPfe7FK7He2dAfpm/El0+WmRj3rfDG/x109ggUViTBeGse4QUbAIuPCqAm4BG8Ka4RsxG7+aCx2bQyNSlBWlFtFclsKqSUXIDaV9Hztu+hZfmSab4D8+tuVtsg+AxFOZ/Do9PECzXFDNlPM6ttAhoeGkKNz4EJOSpyISVzPOSJ6SqvLTsv3ofNydRJf4P+iUHGj4+1fvoPatKYDGPNB0HnksXJIMPl+LitnRcvB51H8AmvQBCm6aBC28ougHuhW6OCINOu+slVITSSu5y9oFo3wBpK1OabaknR8NoMFkB416u2CQtcbRa2hXC2o2gFrswCIttl1m3/+hDGlPANXD3FUY3jEIQOZKDQp9OgroFimhaBDtD7Y1z149X4cU62jZdR51FkCt4tZqochdlQ5FBiELpT3SIE9zIotOhcSZb1wxtCCO/V4yQL38VDncnNd61DsVQk9t4wTqqG0/T6KrELHt+os6Dl4NnfN3sSxFtJpA0VJZnlMbgAozUNiHUTeIYMY62yqgYIVNVlEV0HwEU0ZxLDezuO8j14Oo3uFSr18vaPG4O4wgDMOIF8MwOewNI/+maQAqmZvWSmYlGac0F0Clmmnbp8r1EjS8DErIyVy+FyqIJXE8w/MBlONOfcTXc9+jqiG4KVucn71PqFBZdSqkPky++Qz1ci0MZhWHl9jpDaChhIRqGbG6trJQHywNsoQSmsLNON26D+XrMOfcbWWlApFTyiuPwTTPgwrDExVnmlgDSK2XDjslNnqJzDebs5frAaQW32bduxxVbGWe39F775FOug1PAKk/eZYCgoSAFjX1deg+eas8rPatWe3pK72Zvvn0u50BGRTBhyyBW8F5IGQzxFtUazLSaMqx+kErRCo0HQpJooRd31xnRI0ulO+AwQGgyUWSMiFVGx0nvU6Njssg7noNCM7S6fQ6cXod4m4VAHImHUilePt9EXKoD4ZgTv0AVHvZ+WEYMYgVBNf7Yf0M5ZsN/u+Ldeojvnq62wRAcGa7JrrlE/ZqMwcBBfN+nV0AgTnd8x1E/jFYyUvX/6AJRU98lwz0MOEG85GS75IR/THaZUd4bybjUtt9yRiegCuAW4D7gKeAV4B/l+UjeP7yaqAZgOYEaH6gRYGWBloRaHWgdfHzGwNtArQp0NZAO3J/Rrtz/Y20L9DBgv1tkfe++l2JRNKRnG2kaHES5ZZP4l+/5IdSlFhKGZ/heN3fw/+nBOnoUOEJYbdgBtB0GU/QdJGEfzJwnukFn2Fp5DN43/UFlPAMuVZoXSkG/RH1llzVkQIvNaXD6IZxrNzZc2gW7NqYBuEgVlpBwD8ZuIPdKQTMTYYImMXbEtnKonAIweVBBT85rPgkiFx4EUWlLK7EFqZOW1q6Msosq+xyyi2/0sowQnLmQItGQIXGpyoiR7riE4EBo9ZSW0CFvgT9DaY2udP15ukGK2RGF1QyeegZb587LTADA0ElTmLB8LuCAWHtA8VJFyTfcBH+o9QpCmivFIRKi6OsSSlUta6ya0+Une1Sl7vS9UdHIkZjhJmA2RTMaJ5lTFbYzN1Wu1js7W40zAGHhDvpLLvznolV5ad6/pCI9o+b7m4Fhq+y+0Dv9YrQ50L6fs5KOCJSg6tra8e70EUx7VvW2LMneBmw5eTHhmdZlCSeEtVSop3OBhlrptVOueKxM//TKoRV1QuEqgr78HM0MqT0G/ridR/MiFPm3mmK5DrF0EbJplEiytaoqpkOq/mPEGqdDlf7svCFc51ieJxLWbfy0kpoLWIchpHP8TiUk6PO2eFydVS5OSx3R8ojUrKNQl11xLp72SzTUbTJo9mlR3PM0n9DlCyQDqClxiEqSoBgOlCDx0hEQCo+c4DteowVT4vo5m2MniOzAMGyyNewLUbpuokyXsWfOSwVuMxNvH6iqoRtCiNMYjLFLGFZzEztWmovYDK5M1dVIbfk4DlqMlekTxEyRtxRHTY0wTraajiO8Rzv+I6uCMcnSeSbQ6RRqsTICajlnL3RpfSKPAjXfSlvoQYyk1zTMHEcZlEyWjZsc6Hiyg/Hn8SnR0INZw5tvPwjCRIpJUknyteASkNRcAoLSZF0iUxVSjSmTuekUU5SJPW5Vjs9UoseA8bSd4cYTsa0zBY+8g2QtIxaf2VBPSEhYmHI/NoctHmz0jL6hBQqIgsEIk0sBDh4BBT4o1RApjHK2HikybeMLVDarE9GG+dtyTbZJdJue1R7CKXTSeellcRkdFsosjCeGN31QFl5/LEIVV6zeuMjd5985+GH+H2hfqrm6Q8x2DMgJbSJRFjLiTCZSmiskU1F8YWEKy6oR0MiHe8cI6+CSYOSFym6bMagosuJKdZxTOFYUkWpbWGMKl5vaBKMEkqLYIktYowrqZzANE5SyVFKyeFACHoFtQ6Zq15ODUTm2h+dKoyjq8KxVexV00sPK9HRufJydPXzu0avV80APax0ZXyYOiY2cpzYRh25a47UZcetG14013VU3X5HOKoOaxm1CnxVBwAc6BvKX1GTEQ0thsMDVGgd/zSY02JgXE4qia2JLquFCS5VNNBVY0WVYoRhxIQRIwwjDCMOqOHgET7VtiSJx7RkklikiChT0TobyAdlqnfYcXJhTqLKWTIkluRk8JwkAxVSqosjHvpilDILs4hS/gBH+KxJ2PfnEUZuuIiIiL1YiVVMFg0KlJLiQEJCJSloSeFKCk5CQKhelzAeRswX8kaaSGGSKDFS1rDYWSZVmm8Z4oQTn55UYaPN+JMFPDxCpigjxQlISu/i6xkRFRJqNJm2POJRpTDjUwFcChKD7UOa3zditjA/dY38YqL5ktkLCnFJuC4234T5ELa6l1DxEmodtTSVjQt6CKfUsdRSyTWNUYZqRkCLDi06qepYqgrGQaravZSVULVyrlSU8E+UCMS3NzziH5MfjTo8uz1Z2CXJ0VCzerBfNevyE3OK6ccijuRPVwRdES04TiGMDE/OS7BIyXIVaq69CoOMMbKH54/PW4goKfIUaaGDngYbC3U/R6/OR6hoqfLVO/112VEvQ4xjYM/Un5yvGmKkKVCiXCe9DTXeyB6vPzk/VrHS1VSqpc76GGaCD/akvdhfmLhvb1V7fY200kVfw00k9tS9OEC4+F/Ky9hYa131Kygm2AP4JxfIJkGWOppoo5v+RpoM9iz++QaJkChbXQ001VZ3A4wyxVSYRnQ6myivIK0cJao1W26d9qX72u+IQcMuGnPTPU+mmS3T7BuffCs/6xwABsmUdSTe69McBYcTL2IyMRJpY87DcTtXolK9VsutsUmn7mvvL4zU5w5Bv9POG3HDHY9Mx1dPQTP3oXyv8wAEc0QMIl6n5D9+47wcFBKlyJCnRKX62PqKxs0vtyZuehcv85267XVIv9POG3Ej3vmIDfOPTHvlg1k/yt+6AIV4YL//vi9YAh4ZA48TD34kUfZDpwtRVNS0shSIIMtaG68Pf7WgrlvDxtbO3sHRyeP59c9z64arbrjniVe+92v54+aFtXh0/gqto4iRchy+6ptJjCJ65Ij/l6MiUb9GEQMoCPgsZZYmS5tg2h0PRD5OeBjI8CxhIWYoDgEguk8XUZJkHYvcAbY+orUhxozPd45l1tlmn2POueaxV976qrqVIPg4JXJrXa8oALwLHnpfaVPCUpCzTTxvUj21B/jn5stQ0+BLUZOsChOSFUG8QvjKfM37bIonogYIZUEYfbQqtRPdt1AfE/c0NjEy0hQT8mUpGdEYJmlokrdXHftuw7BJznFBnpi0OAFI4IfIEODstJvBeycFMWkKbKyEV6atZ16jCGATc7ZpnwDM+310nOjTPTqaABY0fvJEo/pUNN72MofwdxA9oBPg607/EqtNERHhu4VzoTqjto2EPu/ffTYe09+6PvryKtJX2d6o6JjY+ISu9v/o9hAj8cQoxuoV4KxQlRJMFa8ivuidM/OkC2DXE4IEjT3BoPMONp1zFaw55wxYsNOwYhpTyH/TaIx6FbMxjiWJuP1SIqTyF5YlZqzYceLGi58gYZK4nvxAZlZ2Tm5efsc70clOdTpGfQy3+kjUUjhsZb0MMsok08wyzyLLrLLOJtvscsAxZ1xyw11c9hiZ44qMmQWuqFhZ4oqOnRWumDiJN7nYuNngiouXLa74+OFwJSQIjysxYQSUBEr9GcaPRgtKB8oBlB5lQMO2SJmwNiRibUzC2pSMtTkFa0sq1rZ0rO0ZWEc42GRfX/LyCwqLiktKy8orwADZ0wtLr4SXhlXy8h3f8qT7nTxXC2E22nvPLN3h1oKhXvQKtC2eAZsi0OAwvOHVU58HAkDIxt7YXBtPvNoVH0bIl06SLPeXyBStqcQcTcKeJ9MBloSYud1PjqDqP67wfAorqriSOuvUrVe/YaOO9wSVaLIKobWYkJV7fa99IQlEi6uYkDsSf7LvtyQBLUHjRlsh9F9Y9hxzyjmXXHPLPY88SwxgzTsbh4VH1BlyAwmmUoZLIg+gKyIoB2ngguHv7BAXe6SkkjcvjEGHMEkO40ZCHEIim7AtgJrrpuhg9hyAzcVxjPF/xYFjU5zelHo/1FdTabT/v9L/tw4/J7afy4OZANDnOwTwPtd4ocrfTK1uGT+zC9BPGkEc7QXugzbEepvsb0m1rdn84TquzM2xy714+JChs2d3Bc/XUjt99q6hgwQisMQWe1yhAHosAS1zpCGUkFdZKzWRmCCMGJqyw8QJ76hhmo/9nyTen2MgaAO4Gva4zEZbHGzoFej0f+w4Zh9wkncAL575k3cVLfQA3+aSJag/+ZOskrLwfBOetnD6uz4aKomzF4by4f8uhWt+reXw3+1/8iWmaYkOB65MNvP9Hkxicl2at6bpTttw+8r3MxBE/fbkWVe5GFBrLDXTYJkQhl59wIpsMGsfBOgDmNG8OPESTw3sMQCi7eLa7u4h6oS9BeyjZcL3Yt9oR3AJVfbO13TO5/BcuRpWWkJ1tXeiPqlLKq7mVqctvMSb2mpb1pGQNnYFf1+J5uv/uxEghFWcBEkyZMpXqFiJJlpqp0JP/fQ3pJQWltqatva2w8l3SsZ5VlhpXY1t8wccdtIpF9x2x10PVXnjk89++OkPlTVeeavbXkw1Nbarpi50odddrEerOtOHqk1pcb69a2EnK2m2+ysqpOBC+yiAUaCkJd6MfjhNfLjx5CVKuAh2TvLUUaCWBmrXqr7O2uuokwGKPDfWSKNNNMYEk0y31HyLLLbDZlttM9t5V1102U1XGuuG//zlH//6pdL/JOOG04+iNp7B1H8WZnA0k9E0zuZwMZevZdwt4G0JP8t5WCjIaoFWCbaWxRo1bBBqvVh7RNvFZosYu0XaJMxO8fZLdNAhyY5IdUyKo9Icl+6ELKflOCvbGbnOqee6mi6p65qGbil1T2MPNHJfU4+08FRzTzTzWBuvtPZSKy/08FFX73Twt+4+6OKtbt7r7auBfhtkaACGl8CwIJR5pq3Xve1N7/qU2aS73ethT3vW4+5U2ZPu90hf3/XyRR/fDFbdYxWUXW555TTRzUrrrl23fqM69RpU7WCpkhfMatOf9/2PtViv38FNaqLto6vSWGvN18mCbfIRwN0OuxFwv9xKQDjC4HE1tU4mDPT7HtTupSy23Gj2EH34DNHyr1C+k6LR7RPlx5QKnoKyw8O/zmOI6EP2QnnQFQ/4buygkecuUw0UT7SLerJJyTwgbDCemXk/hfLzwrR3pz9ZjsgB4coLRHsmD12VcrINbzGl0eWrFWjlSpHbD1fNO03v63b6i8N4v/dI2CpIlx4v/UqXs0XPL+xdOlRmEBtnkv0gCKSjq2fauUfsI1Hq4Y53n/RCjq8UROBVrU5XdX7NVxueagKSHe8eNjelIbhrANXl5aXU+2mxE/3YwBWPYWuiYl/jFyw1jPy26pSC9XYLeiKV2LZoD3eobivFTbMgDW4HBvXEOWV48Z5MWOFafRET8SK9eR5nlUyXZpcDd3PgvmO8ppPYwWAohgKwQxFYIVNNN7slFs8ytqhx9T0WihhH9JLUIzfnOpnIqYW1Q2ImLJWIqkiXVoqoXHSrcPwYri0X+eu0OY6b0wdXGT4hS/4ewydeyKdW97OiTx5XX+T6Kgg833bZdJMPsnFINzm6+UXQpAkJfemSM7J3FFrbvQv1XpYozd2po3I6xlqbjh0JpXHqfN35Ak/VetyW+BqiLiJEcMgI/OqF5crvuGFtUOKZtS5qZWrB9pVIkAJ1IRo0EOUPn06Ss40KoCAlv+LWFw0xbqt3GiLbzO2Edpu+TX+kVs020dvMsCTeJxem4JwTeUsVOW/Rk7Dt48oIUjEb8OegP8rrOq339GyHKHq7pdh69AIFsym8SpRGs+0wGHypydTjJnspKCFqKqlhO3CIW0gNZmPn6R7hucu+V+I3JHxxYs4GTefLcZZI6lJLLzVaehoCRc0rRMtrtXKXHqD6DvgzmLj8cPW5BKHqnUjeC38coZy63eVPuZwOSN58FFS/RsvVtVUNb8SIs9UpsiohjylMNVN94isX6D+OWeNuf9utu9Ac731yE97W5IXT30SNtuHh4ql0qm9UK48E6mGzAfAo5UQgfmY9fRcmbFgPzBfk55jjJHjqGzINEMy+2kIDitcA+WLIRzsp+VW0tXFKfvxq+oqcGrVlrY+9jEMzKoBtuZLOT8zXoJ/RzVzxc2pcT5w8+QXSLKJfwXwz9Yv0N4ZfxfXm5pTIr+Z9i3JqyK/txa3CryfNVgwGrmwJBMgPTzIfP73n0Eum/+34v6NvOvlUffz46c+l3vnnF6c2/2yf9B/N72956HD4X25km1IiOKRgpaT+xqv03j9ZlYk+mc97aiWmQbjtFCwxr4HPPi51gTpYcrD8q23YqUaOHTCP7wdlkjHZCjjtCHBoonhUjgGYVVc0EoFgrQsN6js3o3HFqrpa0LN2sYRb7Njv05h9jQwDhj/r6ZC6bNAQjBkkSQPpkTh0GaxzxOglntLcYRL0EH3gKNKEEJduC6EdiMDErdqYdNBHgM6lWRQdJu+olESLQ0hZ0PMmuGEKvXMkGsw5QM+iokOGdBFlJECTQJFcdNDHjwpTfjBvCI0dm2SkpSW0Wwy9HlNbXAzJTyofZ7dP/jjcra9eJif+e5OdDRMe8oWGPOJ2oslLB4cB9mqlpH4eVyVZYxXP76m+ME29Xjs7vZYUNO3zNxm8XooIAAAA)format("woff2")
    }

    @font-face {
        font-family: Andel;
        font-style: italic;
        font-weight: 300;
        src: url(data:font/woff2;base64,d09GMk9UVE8AAGiIAAwAAAAAxZwAAGg1AAEAQQAAAAAAAAAAAAAAAAAAAAAAAAAADYG6WBqBGhuBgwAcnQgGYACJSAE2AiQDj3gEBgWSLgcgG8fEF6Kb90LadBsSJE+vzu7kyxJ2C7/dzr8cc0t2BEUru9n//+chChmz2btEAljw1X4BkkqLMSp6PqZt7cfAzrn3kVNTndNz/IxFs21zO10oD3D1AEMAAADADZDX8wTnfah/3jVHlWN88NLd4FVQrnoAAewFYh2HlnS33iRAAiR4UkVDgC+wsm3TmubP7+0/o3p7YvQei8ZAeveHBgAAuHYAAAAwAABgOoB3F1ANy1lQqqBcF1SAAOhcSK9qRGdQ5WwoiRBzIMGNy9/761tcK67gkU9bjM94Qze4q4AEeAAne1TssNTIfZuevxNCQQKEAgvIIUnRPJ7W9jNv4/Zqr4kDDiSiRVKbSBMLMJBKoxCjMT5GY5IWRjVGFfVRgX8e1gH9uW8WchITiLRO67QVCeA3m+REzQB/rn8T0uTW2FQN5eUhLei2Fn1RB6g6oYM6qyO7jv1OqB+u4X+b/8f7KuPr9XdmzHWpq8aowESHjVETAx0uMKi+H///LavXuQPYMQrjv3+Fe5rAISXGIRyB1LMDgB74/b7Nt7W3gtxFVEKhibekiR4JnRAt64Hv+z138u69d1/5kiRJkiRJ/SMZzNhUKz/Znt5Fg/KjNtm50uzr4n4OWBKS8EcBNAhuuKKpPLLW3qTmM3l3az+6r5MZKUN+P4Q3+DeAXf/rf6pf6semvSXwrBQgkGQC1XJAJkzSAJDCKAdZYcDz3LOdFsC/SZsqi1D/kHFJ5IeO5UCYrqXaAbgNQBO2Vf979R/N3KqjKv/NLZdeHV0TlCMDhmREKUYOACkyKkr4WgFAcwBYiYElhQ3hnlXvEbzE2J67B74N96ylUyndQs7wFQxdqD6xfaS4oNoYGaFoqL5s+gkLKYS1uq//xXh3UMhga/zdDQYgzsSmzWAKpmaoxmizBVv16n9q//fBTLb67Ner8tazTvWZBbpZzhIF0AixZSIZSDJgCBzamBJbkm2ZYqQYMQ4gLI5So1z/i6bW7t31VJVeVR/20ZQkO0yGEJgpRIbYATmAcpBAMsoh4j+TP96+AIAY+386y3b9JF+AUCEsGjmEVEUzgpX/yFrSktYL7KfdIx3BSJZ9s3gUIvIBOYBQJVVKhrK6MtR0KZpryqTM36sr2/cFuyNndFFOWRdyVbpr+IIbI3F7s+Li55zErmdWu1ugzyXhHIvaVUhtSJI4e/jgwOe4IC4hLmodwTk3nYuqPXd2ZfetO/Pw/1fTufbHOv9ZUcARR75tVtbYROFQqQdS2AkkgR3U6hYaaWWgPE+/7Jdl5pDSEF+BQo8QZvpV1695XHITuok2hSkUwoDDYixCwYaoSGqlXrdeoOTC8/9Xqjn/dh8a0Gqojlno3+6v64K1eZSGrZhYi6FuQgUrAFYAC/9fe51+e2f2JKEphKpVOKIMRqe1B90hTJWl288Kh4wEiZClKoicin/K2MVyIhdS6CDbdIS8ShQwiEXS2qBSHv8n4v967v2sqhu2jFJGHTWEGGKIIYRLCDXWMh6zn/3eED2A63EobTSJlB5teBj93DFxCHhN89T+Xw6h9f+3vzfd8mIZfy/nyWY2/VCfvfijtGP8NurG/NSmBIlo/FuB24VBgKemZcaaI2/dhesrwVBpxitQZLLZFllhjW1q7XXISWdddtN9j7zwVbOOADdGKerHTZQ8dT4FFlViwxrV2DIraWpzGmw8ZittJUieNnOOvAWLhVcbkI0JT9TDHsG4jGq0E7LIRS9pyUtZ+go3eXPXu+FNjbXFrY87wWQzzznfQkssN2J/R5P6f6mC6UHHETlqfAgAgkCNBRdR0hRp08ME08yywDKrsBEiR48ND35iZClR468TAqMltAoajohwxZMAMOQYcBAiSYEWfYwzwwpcZBhw4gcjQxGScSGMiFFJl6tYFz0NllKr35JNu2XKUaBCix4jpi1KOh6ElbCqWPGTpsy34IjkGbLnK1qmcl2NtRQ3dXDBMlWbXATaiaZa4Mhp51x0xY3G2r7Mm37ocqsj5Q4dLmJccMcfBBodVjyESVGmjR6GmWKOVQRocBJhh0NZb7J01sNgpeq0GzBpxQ77HXXSWVfkKQurkuYPe/n0zWbTThhMpd0a7ehxQE9/vGajdybXTaqL6hgCiXewQ3U6qNDVafQzOQ1soU59okMVni+I1q9XONuinUXZ5xfnn+b5Kzmnxp8ftXPnFOliaMYBQ3XaSCKv5+cGH576iZ66RJcyPKP/IM/GKgNanRJWf/YML1FFL23FtG6uVWHWYmGNAusXhFi/HForI7xhHvGGf2O8CXWMZXgTE3hHyryj+Y3eDYY7eheZjAqXD4HcB/gIbX5UBpATQdY8QoiGIJ0RZyjHOOKICVTNQIkhR6bGEwxY7Q6FOB/fQ6NoBJ5OkpukIb1+eck/2OSZY5xhZ8n2Ksos9h6MSBJK5JCSwaZinWNMnIhldlw5jVBeORPbXPa7KyVQ5JSwKHAHyyH+WzSHLgIHFWblEFH5SmrCojVvucrtRfvYPldhX5DMUeOO3PVs1/39aAImzyTslfXf+p85vnmOZ8x8TaZN6lVoVuB7rdZHI6u212p2Ae9AeeHDrIZ2JKD3Krycew+TyBohu2C4noW0AJ6JaLzxDiG4NopOFpqjdwzwO3LwO16gdwTQO57jd+TI70RtAtEoCMuGFljEklInQ3MEMMAAORighUwT6TIVHILEIoDp51tvLz2f59/8kqyCiQBeAfwxTUlhipiYzfuji+shJJziNo3HPJI0AQulPmIZ3dmmz2aonBJN6ol63wCTFb1iaaJNwdqT7uQk9MqFZUjweIMCT6SrpqJO/1VMgxE6mVeXqJSFC3M2PVgzZOlZ2I8sToNhikH5gmCXLXvAPPpYg5c6TeisYhg5YMpozuoj931WbeB3NNN9zfYibAWrIn9ynhs3kRcukPwywLwqFjm3+QW/NFZ01ZRArLFHcaD9RY540S+i0LJNBiJIPJYtZb5AHg0of5FjQL2IAgMKMPC2mHPxQrxkVkyUhHvV0tb8ssCroA+ElhleVX2itWzxKq1p7o9ekwwEiga2x8BxK61Y9Q7Ajl91QaftM1rIviRta2wOZPFVTxuyxgPaAZPC4SQ6oC118sd6VUSmy/wsVu60JHIaaW94RVOFRmHTw0rRq20pmNLF4JomLx3YVhRhn6DKy/NJFRJ70mWebGL8hBd1C9B8Fqp5vUXTahfd3930AsvBp7OH8eo0VrfWfCwXg8Lnu+HzPaC+cWC2u74og2/QpgQvQzLltECFbEexgXkkYOnVdnYOCCqOLBRhJCOWhxGthVQjywB79lGrQ+KJHRb13oASwY+ZegxkjhXIpvuGTI52BFfuKgIpI0pwfVGHLYHRoYZQfMjTyPzkxwL7UROBmqcec+iHcIyYHYL6auSeHRzmjFwKTSzof7lSmiekDh2yUSmwN3anxBiFFFytvRSpvyzUt4bA1DvUuSsocp5+VWQdON0FVz3h+T6JT+XhP/qHOJyTctwnfppHe+DjPo3LvPwru+7X93Zfc0SrvY4buDXQtDFi3HDHhxBIglSYAiJLyatVGKRRm0Fjluw6ZMCYhSsF579QrFGCXK4QwiSTpctUqUEDTbaZNE22XCVKh7fXxMKM22nXOVt8XgueZMoZZp1/qVW2OMl1wpLIsCU5kSc+Bb7okKPBiBs/UZJkpvX+o51uhphlhU34wAoQI32twCJolRKPvqnR93qBjUqp1aDZqAWr/n/VcJzocchxV92Sq1CjXv2mxSX9G+kSI06y3AsMDI1MmzN/4eKV6tbfSBMxmm09QeLkqdNnDs6Tv0iJshUiaunimZg/Ky5jAMNZzAgwmUFRKIOWIlEC4wongyMLHV8pFLswhODkQkbISDlzuhGEkSxjQ2BG7d+RAlRt+4hvRCIkUd4QY7rY1dHiurY+lc+nfflae591miMJFZlKbHaAr6Oq/Zz64sUrfde64+siSpRuXK521aeE+AckhUdqylo728pbWIbotwz1sZ6e7tbR3q4YtTog/oLdmPzaUXm5Twam8usYiE0dYwY+VGLfnBfa9+8QuhC1KyG5uS8Iu79oGu9mPd+3EX3+yUkfhJSJm2qPYf3Xk/TXToW9lUE6to8bPs4+jyzbDVwXw6xM9Km/2rA/H+PS3x+PFhLdaxP+WqrJuWdc/DNokP66MEyKPmcyxs38gMHsoMu+aPhotW0yMKH/Tmle6X49K+QLL8EUMV8ma3dpU1VQ7TZoVqvZ6vskLQbL+Eb5tnHXub/oN9vDl2fuTt2RxqLEgRooL0GoqTTNbJRcOr+I5NGZ2SSTcks0yDQabzZcgpcs9V8izXXLaxbL4i/oTq8/iPJa/Iauz4JthLw13zh1nMHty1NrBZfhE4JLdpGi7d2xalWCT4ybk/pYjU4Z50YGmnri5+SnZ8auSqq1iRUT6JqmKzgnnIyi/CVD1zfRoiv9Wp2covQ7tL31ijIBDOERiKdSEfDLHYFzcONaOMOPCok1EvLRbcgSOiTkvvDPIRD+b1kZYOf4OaFw/XJ+6srPA1uygxPF6KPNesAGFGhl94oaYYFp1wVDRu+H35OJ+aMfqN3gDLRBjdibvid1u6H0/8nhByyKNm5LWofbO373/5anna49P3Px/rzf8PLDSqpYaGlBLaMLY91jQ22hnnauHo5bhF7GQWxhC8Ho72cHF2mCMD6USOYdrThULvvawny91IG2XqFV9VqWDZ+d7OoO3aD89tTcdYnRtcLebXtcfTyKEf4dZNX5eaoCA1M/ZFy7y21xCtrBcXT0A7SHF2ebq5okD7S5iQyKAagpeV/bQJ9bUn/AFk8FmYGvB3zVQ3kZ+2vZu0eR4Uxl2f05fL2MyN+ev3ergzXces7tH/qLc81VjWzFRdI3coX7Ur16yPD1bGb4PSazCvYW5qsqjFzWzUZrkWw/Fx9+MaxF0NLuvxd/VqTYX5mTXcKWTJB5WQn5wTJDW7QR6MFs1HICdp2H1pTMJAkAsaE7MJ5VTIN505JxsFFbyciY31jWB/nGxPgUXcJDcMKDgwy6Kg9wUGDeEas9I8Ms8LWnwZBkdfbN7/TYYBPi/cjC3VJfDM+FZQxqBUxBZ0ubHAMt7HgKbQFZyNR38RvDCWRwt5WCuIclvFMIqEDPc0C+3Rn567g9ydvTWPSWbvoK0CNNgJTyirLbkK9PStalxitQbg9ixKn1ML7LmWNtrP8JLKsaD/zdAbwfQYqTjTGRqlh7reNPsa3dGgVEoqoihog7Uu0OfoZ3EAOVWH4WaYouHiA8HKV8nRBTo+A/xoRZHEdjLjSeWpAeuAX9AYQ2ltoW8KtXnwHlsuX3RXhATeYRCNYquBxm1+dmT850ejo/wAT3tgXFMEaYmolQx8DRG0WA3SlNbxXb7z27HxzH3thXW9eyDxwQNFVpAeJgwFT4MYXwbCpwT8ZQ+BV5gg1FfWLEyuM2liGBscnYB0ONCQk6XYIUycFefCxklxGFxEJobN/HTil2F2+Avm3dbziFHlJhSEnCSCkl8WhvECGDPZBQwqb/b2O0smxLpJWrfwYE+D9eQgDQ58PFhA3sQlxBZtyH5hdhMVcyc4EEA3xLXBC1DGcsjcrSqCX1QPwVvqXyOZ5yfCgX1+mPSKqdXcxaX3abT1RdLtwq6sdhrim5uhHzEq9DDkXjReiydgF5JW591xfBNkLcnm+d6GfDvzoDMPdbf0igtwCROGaDJIoPQNYehMr73QY7V5gqkQjGYJ4M/B43NNt6J+mmz6isVR3rLR+RzNrRCJYyatf5/GO0wZjVJJ8dGbtwlJGd8e4SxIYyo8mkNSYlpegSJa2yVV8DOE9NFzNCwiksTSSAD+FnUxoco3aOZGsekFCAGgA58AYd0Bpahhp4aTYIGMR4J4ar5eRLuJqdBNDZ2wEihWK6Vdph+6Wi6ADcTdnbwsKsKlhzGvsdZXKULYdcWS6+Cwp/g2QKFQoCIpHr9Pqy8tQSbXJqerLkqmlE+Ls2uH2hg8SmqURNxAaWr1gO8hdbtcNiugV17ARTCWT378EANbWoYmep/KR94XwJI3vj+SXIdtYjScjJDLSVR6fl7c9i0lU/o7kjk/zDRZ60hb06KfDBvGGjMV+fWs5ATJMuqE0Xbz89vlnBtFffEPlg22+GFikJBYy/VlpwuKr0mGHZBfl4zdCVoyyNxuVsTUiLTrltI6fEePzoZuiDR6JrI44yXIFNmxqbAI3OrXrMgUfZv96OOfcJA586+zmwXfd3EquZKxcpFZdQnXI9J7alSMlN0KjlwdrDhjQGk9AHcARiKG449q5MT9+5PUsq1AOiaaENwDQZVqLcjmVwkOIUdkVoBIJRL0iAE0Rg3MC5ZXkGg+rj+pGlDqgCLzIUscRkQPx/W7Ipar3XqF2ZVUF/ipMRtNtPrwFKQg1yBSZapSBJjqEMCYMb7ojkH0cyLBkhKMdFk2SsdA82VUjbKhM1sQmJMbGJphrJHJK1YbPWMDJpU3aSKqc8qb6yzFhXlmVIOqjEe8IGGVLKTUZDZaVOf3skYGqCAsfi++gDbC0vrykCnBptuTMmae6NBHOPH2iuuAHQHaVrB1mEY90I/VKez/xqb7KHQpCztrCXsLPLl7wDIEopdJbiImrwzOlse9RgNgIYROKNFfsOlrHRWenfUUtajNhTYgoURBxFD5ofRobHZWRoVS5DapnUO5h3sRud6F7WRqR52PAWqRXxUDObw0v2QLF6S+RAeFIRFcO0CUf8Dkor9+8rVdD0/Pd6q86unjnMS3dIMULCHoHcSq1TLj9NIMIol1XHpfcSKivhZL0OSemdgKnioHjNWAuryR7QVnKeRYjLFNpl7ie60E5iEIivOLaRZMPGTU1jmL+aFVRAgZqcuC2ezNy9l2JrUnlsbHJybFy51GhY77onchqCVziZVbclUUghoincY/z8O3z+e/+FNcYjppJNRRn50iaUIpGXC4MgiiiM6Ybl75KWFGZXAeikERzFzJshdXK0WS3lJiXFSVSM1BKNsKBskjKaUhLCHUx6KQqOYgDEOfBegMAcVMMHQM1oc+EHQH1gWbYItAfem9wivkd+N7ByroYPBqyB/wfk4cDeaIvBfvhYwCZQxQE7+EzAHj4HGuHz4EC01eAQfHHAAb4CHOGrwAm+5sCCuDgHqjpwGLgGjsBblEdH2xlYqDwBFgE3WFfVPVD1gCd8FziJvAO8Hd6mfCvwQt4Cb1a+Cb4feFc9BT8ITg+t8QN8Ah1J5jj4sOwXcA7TlM/DjxUHwI+DC+ATcii4CJ90uTS0s4GrgSUpDgvPB67DyxCR2S7zOS49wQ34hcBNyuvgNvyqsld460Af5bcDfcFSuAPfrXo32gPQBL9/oB/8cfj6w58GBsCfH6gAkeHbA0iJaNAJ/D14OLRPgWXgCVgOYsBmEBt+GYiHf4jyKfzjYEUmAfylaiJ4Bv8Bng+t/QNJqv47GBS8QgJ4jUx2dwiyALxBNhCA4idgiYAYIDsiOyA7Izvlml0DW28Xo83AthuB3ZBjUvWwwH7IkRuBAwYYDdYE1rtsgScdyIA0SqOAEkBgBJjBRMiFfKUYOQHQIIfuSmEwFCRDIA4CHrJgrkswcuIABcG4QBGEAAfjqxaD9IACY5FTIj0pw4ORYIySQc4CqTAKUkAC22AHbFDqkLOBqbsJck6wFjkP/BcY3kgP5PwfAwtKkSt+qhsQBPIgDXbBVlgFm2AYbKyajdwFcpC7vzcTzIhyUlAOpsAcmA5ln/upwSwwG3ny+0EQQDwZJQ0j1tx011u8kebbaZ+f9S+uoaU2q94mm22+zaCEqbMWKhPR37FEOZ6TuOFLX9FmrndbOzzDhb04L5ol8OJu+KVf0c24peO0SWrmKS9ywcvdQduBojVoKSBKkS6jbY1bhUlR4tAVpUK6Qt3cKT8a61dpt9YSpMkRWiZi5HGnmOv8511y0zG2MGjSwe2D9sSKO1gd3K/3nXpMOImQbw/kH0CHFS8YeUj+KvAqQydlbYHOQHFV2iy2AP4DKFdpq3WLVUSaHAX6LXFCyYa/Q0c1tESoFC91kfpLLqlEuiHdl15JUxehkloiy09G4VLIopBq6lGfpqQVLNIFyz0L7Ww3m2122FnX3WNuzgg1/CjikznZCj+qWBJJLtX8N6vNezPfLDbfW8faH+zd7P3sDUqiVMqmQupFSRSifMqvz3fwdGjWDd2pRzRLb2qx1mq7Ruk03BjnhPPBBRFJGrJTiI60QFskJi3B5KUYVeh/q+M7eAk+bettS1vGnE7QEPTGYw5m1vCM1p5MvNqUHdkZq7EV++YaaULK5AdvMI9lrGULuznAMc5ymd/8Tn8FaMAGwAOQAWgBrABegCicnJaVV1RWVYcBE2at4pDQsHALiMP5CqTvUlwpBu/0RV/zdD/txd7oEU+EC7Up1MN0sIV4vInmTYuIhfhMZ9Jr0zLxkz65kz/l0l4uM8zoMFbYhjzM01mVQ+UIs8JcM/2YkcVbaoVeRstEmSzF+kb9arexlzSs38JJvCl4zAZd3ZFxoaOPY9wojN0wztO4e27INM63Sa3biq/ZUq3IfguvaI/vg31rd+3k0eP7u6I7rEf9EB7Z83yB8fSd/ZN9us74dbRwKQy4zFfiWl7sS3NFr9adRMG3/57fsjt4l5+2WCr2FZuf3LN6NO+j788fcOj+TpK+vtcP+8o/yWayut/2h+EThBFHGnlUQEcnejGEcTAwh3WwwYcYBsBAEEQcOZRA4ldQ1BVtBUlBV3AUAoWzQq5QKrSKIKFFIRoxik1c4pewxCUnZfnvnPDdsOaNoWCKQyqlxf6pdeAl6d8N7AfMvVW47j+R5i5esRStRdn+OVB6qdxOvD+c/ErobfDyq5uAzqgHElQcBj78SwtzFVZo/mCidms6+WoPOlrZT4kyCUywV9urMhojpkphVMYOnZyTXFTHkl+un89hu0OdbYXkzoD84THIIPnfClxtMtUwuLfaUz827tVo4lrZcwBnWyYU0ai1VlQK6xWbMWkPHTpIctRsvRhOKwLQIFihGTyfG8tbA16ILw8Dv85Fy4Y9I3zHu3zF2/9lLcYosemJ4ZkbqucT7gvzMrZPBBxScAH7AZLPTjvrvI014wft4+F5dl/UbSpgBWboAawQOsQ3dgQ7BIX65fBUu6/qxQlMmvmba4O5XG16ybwAsvsszjAO0U1U3wDrgaGwIRP6apb20xhcM3T64ERFq8m6ShT1plznCQtSO0Hh98FkP53K1T2MDqaVmIj3gskQzd4uXlHSS1gwdT20eUUVrhdLnDliliJ0PayX2CHp+MxnV1KBIdIplSTfUq6hZG4wzcf803tUoIouq/P5tHOpwHqAukuY3ldYo4UivSvz37ECMajRs3z8HFXpjZHFVGhCx4S7auze7+X36yW8FfRrYJjwdabwLRd8H0wMX+Wv/0Mw0EXJXyObFNugiVme+FcxjRsfpaMcuVHTSX0eaVOGJMXmIPcfQOW/wUexIjSCx61vmiAuiYnQM0jNlIkg34csH7SFf25IenQEKxY53y1eB04hZ5Tw2LMHSW17EHDv8a0emCTmK4fZKu4oVrh24MnJDyk+CSBWGuu7b8Uqlg6JEbyXHxHeHH3xaGZ5LRqBCy4AVmWHz/OWAXMykt4aad29As0jqZ5rB+rhNRE3dMOCbDyktPoZpE824Rk760rAcuwS1JMY8x+msUeriphCKcxCpG6lrY+dKrMpYkpfun9fSQP2yGyVHZM/HdplfecxSw7rysWSRUhxjKNxo82CASPJMJROyc+bGd9sSydF3Hv53iDESbvCVq4P9p5Hgb8n6qwUz83tYAq8oA6jd+HLvz1JOsodZ1B9eFuLUE2e4DWXoEecp3DhdSEcvf0XjsOc91PC7/A2KPNI1NrwbULqU8W9FsAKdMiiVc4pvvkwMjOaHLgN6sNRWB/a/YOel7yuYnpeTXobh4QheturnCA1Ki0/9u16SRFJyUBr89YCBjO43MsWeWV4pK/cQ3uoOIv5XYi/2Li1Sr791uwjA9vCp1yV68KATq9GMLM79Gy+XhnM7RJEheALoGYfp9S9JuN4MdOnBFWe1qHF1FwKawOcam/0ah3ko02GnAtsN+d0wZN4jolN+YQtYb6VJEw2eawtXy4zn2G35tsYtGJFnxsrReiWjRwAJ0vfWkh+IiMfhhv1fPviHvhcZO+HAXmFik+sZU/azGnVJCGHyuPT8YySLuXjWJVZCVdqao93La73V6wYL5eN6lLb1aqY2IKmw6cx2LPzjm8uIhcwHrbiVPqBQjyiC9aUewvXQ+h72Cn4erDTAhuVnmXGxpDOgIF1A6wvZUgr7KTEx0GRdTyziF7Yr6dwen0GQbFCDNxPMARwwmNaFLiS48RPcUEQq4B8OEtdqlq8IBRkIFr8mS3h6K24jvt8nhCgH+Og2AI4HzMmNKWqrsUXCuPt1TDTYGtqD5fUsBnDpPepkVvjl8We/SCkfdSu9HDmdyXz6uoOVT889dNHepuhL0m+7jgtQ82tVXgt9nTpYc8UYdxtpsN2msIY3En5tj2wqqHravH59QvQRpglfWJos3aN2srpAjKYra7ut7LP+UzEk83WqT+OweAAAemWZ1c5U/oc2AcjbLawXEcKixZJf0VCtq+Tik9iUZU/oCPQ70HQrjImSIv4JknmUiHwWgB0Bb824mV8k7tvdEKEvoVld30OnozxMc+UH+j8AMrblOyM9/bt2xHyLMYaDAn+uSVuSqzWlDCp8+YfwAe7QNEr8HjX4RjBNCZEHrPdpVwzGXk/djb/ply/yBjrqlwRkI8T+dXFQxOjiz0hk1vqgJPwF5mdC+aCHZ9ELo43tWsDhQN4fNkJ5T8NAH+1kugbEOCqSm+K7IajDtfx4ZZbowyEx8/9WQ3nZvdtm0I5zO1RDXwTZ4sm0xNFsbHGdH7qAyuSA0EyFezzr6dlvAXFCgrtX3yi7ZKaKvz7P2jXmFF+NNWfg1J/MZTZ79XsAIVTPRzPcozX4cQ+pbzCw7W7RQROSGNFOt9HMSd9pniCa4jnTTmpLMfvERC+w9qsDE7BdLJq5XOq8CYrHPvqco0U5uoJfBuax9FB59bUA1K7uNU4HhJME3CceUsVGj8uAfRL+hDNe11ectrVu1XGji3XvNwd2tuUuRL6ccwh5CVASbfqcxT211/G7tD8QoVaK+oNGlGPADEDlC0JunuxQFy3uAcaMJn26GCrlA5YT+pMs/FefxBYuul9f4rvt2wi3K2mGHT/mwDmOAM0QslbehH62Hg4vjENul7gl33ruxBvqOnWZIuIYF973UhnmUFNafj6cHd/dg3N94Q7I3voAg6WikcW/QZlSN9LKz6ioDDeYrGSTc8/2s3gcAz4eP/xKLG3YYhXeuxInJcsPA2f0ezZ48RY5M9xu6UJz9CBmvBwQoc9Q4C6lqU9hv6PpcerumlzNSfhUnoj0m/NUO2+2t+qj1hnIqPS+P6ab+NkvD+D+6sAauaOxF7Ax1lsF+0d4AVGxrG+YEANFIjwAeyU7/xuK43vcGprfrfgTnG+tW7VTcETWNSm5uwP3v5pboI+sSjJeuh+sjhObbDrRtqRTllhz29WwB4BQO+fJ8PGwLTp1YGkdg2vAMr4XskDjnwUTLLAiLLN//63tX0JKTrYjYCkBUySghR2/lie6/QRYkzxQxddxdqBk+1VFfevhFUWk1OG8YwEATzow9U7FqO/+LW+dlRXgFd8m9jXeX5r0ab+GrLIh6R2VKjbvKFbo9MTBJUL/Dr3l3qEgkf0mtIQ3WQLu72q5j0/oPNKEpmsrtp/yKRkqNXOzqqc6qjx0vK8wjLlQeJP021NkTumFDcs3Dxxeor5sBEKskArjSvIIyZoausTHAFY49zhTiHOnBqpXwDTrgI53dc4tnN6aPYSgB0zXaqyv/4w9tCome6Ddjd1bJkj+1P7YWZvakx5/RzY2lm78W9k+kJ79du0rYHayA0ChyyiaK93knIpaH+jtIuPx8EE/hae9tM34+CFOASMbssbPkhViToMnsakLvYv86mAXH9xDZq+8cWKc/H1wLzYb6OQzFKxXhCNI5sNMROo5OtReBGdgvd8mQiP8YimfHPUOIcnBCbEzMkipsGX/HU9ich071pWJhjdUrpAtGNIqagw3oae9yUxumfBVreJjafdQfg0Uv8NSglkPfay/IWnXccjT2b/UymQzdy5gbkSMnoynU1Evydpl0qX5CdcPo83OikyPa8B+YJV7/EqST0LV3AauECBw4VyQqnBfsxESpKIfgP8VXZWS+toZFP20aaij/5wu0w5eaoyZpkP+uNEpG0jGiUSPc7O4EpV/VrxhFTV1Q4c+k4F/+9I7rjeP+fqp4hgfghswuj1kat92MWLIhtWyV6HOBs1m3u1GbvKceyWV/dfmr8tn3w5/NegtESS2Gfthrf3XfSTT78a/vNgRu3jqJcJhrySEtVn7dt97eLK/Yrdtbg8oRKo4UxvvG8s0/eFk464PlnxWSfl+jnfaN5k49kXRge3ur3ZgzUyUBl5ZWTYRrlXyiVa0MEeZHCRfku1/OC1xTt6dh1dDnOeWHteCP4/bINmvcRwO10Gnt9Jvj7UWJOc1OOcevCzmYAlnCGa5cSOa9/VTmvdaUj7OOTSWDwJ2mYdPuyM/tpJi8ViLDgWWVK6KVh67jAkL3MNG2VfBG74ic7ZwC1mNGi+GYOvYjppt3XS11rDMBIM8TA4yW0x7UhAWQRr4N4QfPU8abtpMHVSbgO7s7q0jWwtQm4522p7d05yHeNdHpMBj21ralEB0wQa+LICi9xyA/IrNAx3cEQK4w+Eh6mI7kcI8WXq8K4dCecz7JQ20rlmoAldsSHOQWzezVSoR1mWVgOX8V4iHl3w/XjkFsqiyQFKNDv/mCuOAiD/81HiaJPrmKbUHRPi5J2l2t/jvpHZitnMedyvLSPjlzgfOrVxSIbsvbTGpzTCkiKci+G6++eloWJiexFKUpnk+UpH244LQno/DdWP+wOx66u2yX4WK+7XAKQhTS59S38RVmcUHnJoZcK5XHIFeva6sUh2l36BOV4pERajn5p0ml3Hg09D7ombdK0MYqyBlVNRk5jnkbYTHa1gBziW4dqQkcQL26xPKsLjkDy0p4mLJzhI7hVPjV9U7Y3p/jWotEa70BHR/S+riG9oW0RiH2PZdIEWUk4irHVDA55OS67Hz/BziZdS2mcMAaCp/XNwLgvch4KGRSP1khfyvFsEcTr3BGGSLuN4QbIK610Z1liuSP8Ijh8GribRGigkfQEQ+cuJLXTSxw12bFVtbnm9Ei/gl1Np769Xus6kUZO/bZw0k+7i/HYVp3zknaqprpja8DgxBwb3HistOWKdgZKTtIxdOxEDGze/o13WitOQDrHXpTFvErTOonyas/TXh+NMG4illJyEGcOQgjjhO0q7CJyQE6tmA7eZNOpuxlWvWGEkHlYMZ3ld4uT4/3JYnos6wcU+pa/C/hNwFc/TN9h8dYi9uGdusZzDPsLhtmmUum3zNMx8hTOUWD4SzsVr3hSi4kur0pb6YAr4XlrzpOKxl+5FAdWPvLJU2xOVEJ7p3Xmu9Ne7XjHnYVeo7vGKIrMe91r2dqGUNbMBmcUk4pG0FyFlCzdxoVxXTEUGOMw4fCq9MBvLMb14lMchurMqKqYSIuMJB+/gZI9lEZgbxytUz+il+Lcy3R/Nt4PegHr9YqS3cyuB42NLLMbKsbhVSC0bDGVXKhBcz1cDC4lbjEYPzXjkoVb7GuAkjs01eChknz+ezaXZMwrRc8EZ9RE8oeVdYZs8eRVAof1o/+iJO3BOqVrp12L9uAJoWIJxf0bBTReFIzc8nfL5KDSe37GNTuFFKEu50XVW1ega8bn3EuzTON4V3zU7l9+Sl1YczDewGYPEr0vcopPTCjpNB9gFPBNAulsY5k+MP/9ebLrWCpZ3gGCuYjYDD/0EUOHmEasGnmFuCY+9WAi/A59Oo9dcUMQ0ynQirxrNrUDRPj4WmnTgDGIptXCIMEBlsiMwz2Bz9NerHEv/8LgQvNBtRth8OtKlgttFXHlY12kX9sC1JObza7UwvZ/Au1ajxXbwUmmqWZzd4mW1kJ4tcWqAmHy1A7EguowGOaIbeIzXWifE6MbvJKa7+a4B2yds36pjhcWlJaXe6OWSDxMrKPAOJiZH0yv70IpyhO18un/mvOrtwAvtieo2qLjPFNQao5TvvOrbcn8RBcjJwIDxdRKNPXbt4yBtg3Dvn9zr4ctgo7esZsMYASnw6oV/I60GfO2HB5ObryILaGh7X2GAxxu9fT1Nx6139jecKL70mpk6wQrIo7+3oQ7vW8MjpmsPIjtVXDmsiA9bsLWUNI5DoFECCktjCWhfwvfAZ7XZB5G/sAHreCiQpGfYGySQfkVHfE3V2GFwlypAIdgOuCRX9gDxi6tohrTUK2Hnqt1gnH5GMSbHK0fFa5wRqJXwRtzIw+XN7SA9/OEstAcDT0otm3mk5KjeJAsIEwLzxS5iopPiOnH2nDAg1h1aBisIYGAKUfFPwDX4FaAzEv03fIBuoUJ4AHp43aW7qdd610DDYvHlDJTPRB7ePw3VaWhobAef+oHK2DzN/U8H9uIcdN0Vj7zOp/VTnIau85Yq7scy9HFfhDhg+6a8+wCPXRjbSjRvf1sHWImY31fREbQxVBvxBT7l97gYjWbn6jwswXB1DHIteuNd/q/aiEIzGtx9NxM9Zg1SwJptd/KhzTUI2g54z45zgin3+pM9xIEN4rUvjGMhOTqdGNJQlT1D7B7acMwKku8NTTgWfSEkuoVZ8Xfkb+t2OP0Uk8H2fEcUlNUCsJHaXaGuFrZaTvVQuI3OEQ/bCfY7gZ1aOXWwKHpYR4xo1MOCXkv8kWQqQWO61Jzbh73HKdwhw0I4SHsUV2aoTUH7ag4SaHV6H6kTIuXFwGaa3DkIbVo74UEdspFMQEIpOYz8KZAonfdXSwaEy6yjKQs7Jl4H16WwBxgJfD19MzRcCe88rS5KW5xiyoS5pnw9CjBPATrzeYh1+Y1o6EAiawvQ82k2vU1Hu8fatbR7TU1FebUSI7ytFSU8tjaiMNQX+zKDbY+dVA93StKFKP3Xk7VD06ZTMhAfTHQn0DVKEAr5tDc5jenCKwTCDRy5H4al/Bx9NgNx6Oh3ra2oqKg+j91qGDHxuhEx5ePrHI5NcnVhC53HOQfTHj/YKLhWoAYT76the+Rk4BveLy9rVWYtkNYzHBJXy2Jsj2LFM8AkrIDUnu07/XeL5zfl1epHvlXi7oiPTCjBNp9lxLXb6M9tAP+Yzm8/soqL4Hn39nHhd2ErV08rihEe5DadnUykXfKvgSm2Dp+JfxqwL78RRrx0861G0FcpA355sXqtNwFY23GNEKbV3uTjvRQBEwOnx+h6ROo/w2sEWI0xXGNeNgCSIZxHHuvthBbZtRSe+qtwxY8vZxmKWwtrgCX/OFL7fC0YqNwYxBDC2MjZpSQ/L8CvLrMf1PTm8GFoCrIwA1g0IAghZcJPNdTaQDBCAEMjZpeCvJKDZzcrPrpn2XoBTbXxGbRhwyuG7XQtIKcYJWAMaHN/QT9UXVhQxhb3EXeKJsdfDkmu+3tDYS8PunMubTCgzNpb1j74Vm/iQW1/bHyhblE+YsrJPcoW2b3FadrCQLlalLtg5LG+IkTisl29neVx3sTX6P3RmYCg//l1I8a2kOH39B7xObnJrMCHLNbXFXbJl8s1b7lwXAOvtin16NRaJ2uDPF+8GlJbv/wwzVq5W0JhQSZz+xB3aVlOh/zl6tucsZVdB1FWONY/Lp+KrbiI4xOFAnKn7oo3Z60W0KkthHpFbAtBoNNprYS1GmE5LDSY6zM0lECvjGnFwxSGBBOEkQ3f8Ez3WaUzeghXq3Ra9rC0OxOjVcFzg/kpcM4w4W8WX2cMEsNDlzc180djq3cCV9E7GjlLi53S5afN/EFqLxzm7KcAj7zHqQoPv22r8QEspZXCnEfXIlH6XpDbA+vMiqS6qoIx8YACWVYSzNYlWafZRXm2sjp0knX0EdQyx1RQVGFAims7ayNitQcfN6damWTSKGKkOFzEVrQmibIal+8Iu2aE1AcATnkWMw1kpspBrVRWRjVyRUgD4GnWGw7V1D2nL1OSkSZwzY9HpHovivDzAyD8CldZ2ASpJ9pGehgL72uOcL5tWHpslkr0CPkJCCkPIgR5lihiw/lp25+w1FP5YweRnkP46kEUfolQG2BDFWI9ICyyxrQd5ULpdQJOMkWlhH580qsLWW2EWo5qkMtlMt3UibB3Wlnh/CJkXeYpl488+XebzS9A4D5+OT64js08odkUeST4kLXk/cTbib33/Hh5EauxIMgx3cMB2VpRsaNcXlK+/1AF2yuAgDC8IMnVLX1X7qiezn6+vFc5AX1J0hRC5FZtcl6S3D1p10UDSeMQwHmU+hKxyOvH6n8dyn/qP/BXc/+gUiXr/mbq/bh0bRI9KVw1H+1KtKylRPeY2pNb8Aec1OaZoMXqZSwlYcRlfdDuOWpFl/sJzalc60HCPt0qbOBYMZsS88fjDuiNdIdtl55d9F0xqKw8HzS4oXZDoTUCMVxLR78zp4Y/U9NYGh1jR47S8RHbwneFv5ZKx9qTc5RdFlz7mFi6p7+otp0tmyd9NrpmquWARl7u5Gbvccs04Tad1XiwKb/pNerWrTOEt+qXIzuvcLBeMppiP4DhcSLQrmKdLIOMLlHHunm0uyB2YV2Fg2CW5vIlxNNYbClErX7qIFe5e5ypPJW53UhOXePmOvnu/Di3P8JIbLgJEmlre/PBlmpHuK14W9/TOSYfqU7UlrClw2RlVkyFmywjzEvzm5BfaSnfKTRT1w0SXqKbOE680becvC9f6ozR1LClM2R7zMYyZ7lqsyjBHcByBUcwSnN7Epqw4sROYbQ2zo3IcPOrIvIiXiCFLhxE4vAH4WQd60KosB68leACHedMyFaZQnUPd3EVOV+XjCepdWI5T5eONZiotAcfREbzSbdTJ3mLpNM0wcHVOl5NqGqpqE1O0VOcRVN1YQ+SzXwfA/fAvIsHvdc4hx7MIa/MKM5kDWdQvSmU58CDHNl7V71gkTtlQM360Fz3TZZVnVDXUFlZX5dQFamJi9co1MmEe4DUzFVZVQn19cFSVFQ8fj9mn9xoi3okJGbGa2AlMu8z8PqfkVqjgwIDssQpMSQLL78G2KaU0EuoVr+aSE9XnEGpgfM7gRsVzvASuF7fBOx3pY2hJhmW6kCzmPpYxdBqd/M+pNzet3e/rK0cMCu+S61kWm7vsIig90qE1lkY/S6yuiWjd1sSkX5dEJkiItYw/Fq//ci8qfxQNakXURlD9vF32HIi04t1xIjwGoRvGCLExEPZ5qkKtjaPpnKWsEpxrcotmiM76T4+OVRnMc0qBTeqhBbfFjKdqm70Dw8WshSal5Ma7buuy+hJbh6+xcbqrsWbtpflniIGBYYgVchePYUhYNOcjH5iDjMjWdNFk5ygPr5LrNnpsGkMztn1gRHGkOK1fgqXGqu7F2/YXCHgMicUMUBjN7ZKCSVH8r4ovEm/WJLAxmvfaREOUd5h7GSCZ8MG2a9Off/Gl1Y8mpts6G9h6VXDEfMyAXczf34Yc+ZjZ5Y4Z5H+fROn5uZPznR4Oa6wdVrL+NJ6q4jAgcmzMxOLM12+9r+GO61jkjf9JlIhWeHxnrIr7cCBzBN0W5OPVu00yY+Pdz/WM6KaCnGpuLW6V95Qum178YkfD8vov31auWWM30fDmSSteUURbmmIJh+2TGAxQxlAc/nqD592tNNXh/gTNOv9pBRszv39fin8IYUIYXAFuR1V5HesTg2hZTCFuTq9u1YcPeRHfvijTV4qJ7xPEU3OxVBkUPptg48TTmZ2qsXwDyKQvyzq7YAisgUs7qeMbAXLW0fwX418NCDLoCii35srI4VvY+9rPJLdfgZvO1/xyD1vrRFKtxUv1cAgkdNhIMl6m9lC/p5f/QP8YUtUDVgrWjR7U0lzTPrKQ2HP+EdCD+Ye1lmvCvM44i1TRFsS6UT80Z6gQgFbEKBk8jDigs9FxtGx0KoFX/5jWL98BerT+ZXvMbxObUY7ZdT+qh8PP148RiIK+gPPyWXz1ScG2chvirmzX9ek6TRWbBCGDPmm3VK9fo8THLKBlfOtkkaROOVZmohjpqRHX0Qp6v2WWdr8ODTQF021M7Y429GA9MINf2EtKMtZKgk55HfHxKx+0/xfDrnMqZslMtIPuNU6VxPe0Oz5/OxaiziKng8zi8J/ozjzci+RZnduSJHNAjG3Z43cUea415xRlCnIxiW0MQOzrdHKoGsriVhRxDNre9SPYFnVXt43D5+3F+42WFkrZ1hW5ZiPvBchyld5i/FpTLyOn51vIezLLY9/BNt7xOmbzEJYIBtW2GzIRsEnyDI5rXRri3XndSojIXS94cxNfj0KG53OmdlzO3z38bNOrQPPNRNpxGtUGK0w1+WZu+rI1iWmu45bYRGPMrU5pUUOqUwTfGSF7TCb51NpDH2zACeFpCIVITistMSuWpKXszpr9+4SVprllBoCUsyYt5vNOWgzBrONrNRizpkD66zoaakQGkWs8m6OZlfd7jwLmbE65qAi5mASim0MNDAbqd1l6aRvdNVOkUWH4JQEuGAn3jATilhs08rEM3+e/Id8MwhgxvVMzCxiXgA/tcZi6tZfCDObPPomcXZ7N0FfruNjRP4a0fo3A/AaXsez46WqPSa3mDcegPG0Fdh+0cRTazoDHsGKKgqrcrbnnPIrqyLE9AyRyEOu1c7P+Bbk9TF6rRMXWNEKa2unOHUzf80ksjDMd7qG8oXSRBbyxf434EwxcM48dXNAp34urn2b3wF+xqPUx9p5i3HXaxhd7N4YzC3IFRP+ljnpPmbmbGwjMhSKgm+z9yaLU+S9GGrmOuezdC3/M9JoyKFFzMpTzCtLqFfKpjDejU52o4vAy5uarYyjOy4LMVte7L2JpLmNY2fkRHl8brSywqZbwnM0tn4Lw8yLGtA4Nv+N/KCkRqxjX6fsXWt2cp7Ic9wJh4TwwrKsRXSzC93s3NgscpAi1qq3qWySyI3e68heCzbavLFkFD/kbCLd2EoEc/ANC5sBRkXZ704sK5D4DvRyWE4sbLi8jGF7gY0iB31FsHwPDFOuIJb+9gJJ70KTw/H5NVxWBuN+QAM14oxrDAgzlgPfE8sLIFUJYo5lnWmTMho1oUE67UmGUX0xtqMAYqUg5YgBHF5RBrPKNqa7euGXBokpyJZHLnr7tCnMPm8lzIGpPHyjxRCNGxN612kf9lX9PYAUuBa7JmxMPZiBCQzfrGE0sizUTEJ4+EYNsMJM9EUeiYkjmFeS1cp8xDdAWlF3Iz/0Grc5b53Z4MYLfh/2dIaUsrQZdZ7StQldhZUnBMfYWgFrHHQ2wy+28J/sNkXkdv4cxvPn+bRz2/FzDI+fMG7jOBHTcP6vP3s5nRdEMODHg6txC9tZyw13zyKUOlS+cxkOFALTpMtM50wHmVZKoIQZ7e8gbceR2jM9pXGiiJ1EzV7s/rHtxHmR7d+FkN6RCJII/m4wUB98bBgeZnmFjbGjMmhH4EwaahH1ULC2UOM/rPX3Tt94evn681vT9u5V3TVKOWRf7khy9UvO6//38wLzXMhzfBPBelse+brrt0v/aJtHXviQoCEVZVPLgxvUyqSthLandXERWkrIkcphzBdfl85fVNq1E98op0wXuWpc1/k79yf+2Fn4OY8v4NCXWBcIcIG86zzhCXyxI+9Gh/1UJ+OTLmzYLl0N6bBpW2O96vKn7bOKLObPikhYhwrCT3pr+gDbryTGP2cSmFpQggalqRUlW8+1lLvINExuP8chGJ9NEj/sog9siGVNR9hv+P7/rU45XwlUXvuQSxHt0U6qDvbqpQ2aHLzqq4y1JW0Hn8TckAn3YvavMxe3RlWxR0cWFm6o7riN/bpPCThEAg6GN46qzg01X3v+JGKZR1k6T656vLPrU323BaFK4zp8PFQNGHCjP6y03kviq4L6x1QvH08+UCt6SJDobddaIRUeUM6MFM7Vg3+OnpdVGoOAHGmFvf/LALLBQBACwAZ9ZvmDTfpbA0FkkcGAAtTeaKtCPcpsEzGzR0XSSD/cE8wP3zI0trEjuVbLPTQ2cmnnrb9bnu354/abIcV1TLIchxcG0j8/h0kgtvs4RiK5fRlQm/Q3D+TCqv8ltO8PoAD9fmJCvu/NjZD79CGkUDlr9eVq7nR72yYaCUC6Ckx1bar9i3vclPLcoUE+x07ppvJkTeQ/1PAyD5XlABVxSAD5CK9ip+ygh7HOm4LbOwmIbLPuvE0iNJ5XZSc9iBUPi+Wyi4KMJdPFEtlOz+CihKnQFwOF5guUuxB4PAcdmTA0NLE42zGy1slmtcUUE3WVWGB7KDJbsiRdV6U/h6+Rx+5l4OZSLetNeuTufSCMgy1TbTcFI9gVQeiJi2gw2H/7IxcBVtqw4uRPbq/rZ32UJmJv7/Ss9Xf7NwWS4ue0Lf+Hfr9h32HTg7/91f/c5K06OS5t5GQRm3mRnMMdu3hnc02PvLEyyXtZmAB1qGKtU4gwHr73WmWJctlNd/HyLXjTqSI4I0TorEN8iXhlS2vsJsGDyktWH+RX4/6fb0c+/LfDyDO0DVA9I33EHdBvPre2hYdi1Xgn7bHjHX1t+gDhsV0oeOOPQo1xK9tYw42sQciRwX+8wDjEAlOkyyynTEcTSSUL2sDmDFrPDJ3fqW8xkXbvaTt5XtTkBEYnIMO3CH3SyBAaQ4cH3KbVFKrje6HG00sAZqRqruphUYqFw1AGTAS5SQuyLBIlX54NksXG7kdBppYDo9cjN09aN+RxIWTpSPirdTPKFtuxEB+iQ3LDwD6qvMORz18OfARZRtt3Am9XyQugpGxarfB/nrCMmHuRrR8XkF8GB4scwcBbcrQunfRCohcsBYGt/DQYLHICOMthhe1LRYuSzZyZPRTk9Je/NiXy2l6QXyui21x1LsjKZod5afkTCKFyUgbIDi8HLAZI2gPKpC1qMsrAArhczvQ/lydRrq1HR4W118WWNx6l2fUBJuCPr7ENz/Wfu5/+Mcg19eb6em7dUFNMuXrD4YIl9ge+/V+o618vth123zUKXv/21UOvfxfcrZQaVa4/vGPRNEwfGtPihxI5m+PRKmtlQ9qspeC8j+eEeTABCVv/JWzUlm9p0pkGz7vQaqdaREvw9b1hN+FmXuf4gV+OuWvnKi6AiQxXPPBFjwQ9FvxEyNBkkG3SVBkXzBgoUGWAgJQmHfqNWrbbERnOuuSqXEMWujBprllz5StXva5HeCprs+ettZJAO8EIHudrFzEpv3nhVdaxvk1vddypZpl9ni1u7nGeyMh1gFygwkWAAg3BwMhQoceBjzQNJplhCQEqDNjAqNDCEf5L5dm7FB0VKtNVjd5qDRKW1mTQlAVrtjnsuPOuylelTpM23UaMmTLnrn+CzE695JgkRcrc806bPknKtBmz5R7bYyL7ikLsHRbOXQ97dTX2BbsARfxQyv9lQpjt+4Pw8BN02/HZH2xWalJ97osH8fN3zUxMzy9OVhheDIpmfgnj5+gVeKRctT5Fr1Wkajh8lfsXesu49nulecb9ZayQz7sE08R0mRS/KylVxZhLThxYMFSOdyr5AikYnL8u4Du9VsxER+x4Gucl9Z7SXPhcIx4scvvNjBDGjm9AjdztJTok131V6hqZVWz7fXgwGSEmJUUd/tM6xMdWniW3136w4z2dyxjKcJbQBAZTKKH5TnXnOXaNvxK+pFkuBCzM+b4eO+lMan+J22zeV3voGLtjBq8DqBptT3AQYZ79OfFf7414i9GNXG+RlvoNL+senJ0crYx1I5tbOkra5ML66BAfn2h7H8Yyti3wINSli3oJW5VgL8iV0VNt51RSbeSorDoIgwVKsDyWR1J0vYFM5JpqnwXo2fVEsuB5F95PZIMX9nyGb57Frk6oOjYACgQeNknIi0oPVizVx+jjtMDrq3Y/hlBCNOBwQygkUEH381M/330n8MpERfCTEPn1bFxlqe6gDW/TgCNAZkeKbTpTXdPN6toSMWzkRhYzvB6OCrEpVFP7fHS2e0UpVd1WLZt0GLB9UJC/Ny+fjcgQeH9xi94/T85Pz05fUT1YP/qzgxHsqcqOT870dwe7OXl52HkGNQ/m9XXq2I+DcxnIHsoO0tCOTkD/HeddT/4GKRSKbC5y4fOhIMC1f5WwCRUCRjKo2PUMm9tn1TWq8cLtdk560XssZOXX3QWp8TQm1blbUUsXMcu2Dfm+5MhzDtVld9h7/eFFvxup1yMX3D/e+YOO3itqhwPudERr++uvoNoCYXoAOoXBTXfEspvLJ2aknnjqLwEsxoV0A4of8BcH06+DKUVGXrg4uwfP8hOYdLGQxrAlw0gWczEKyqfAOIM5bqNeEA90WA9/A1b3FNRg2VNE1/YT8XPyu1vTNweiu5fXs/4IdmMkk1jOzJdfEf2B+XTXsFv2jc2ij0VD39vAgz4punbgpUQ1QciEM0U1XwoC0mPQx3fK5w3fLd6UN5Vu3VLIloySeem6vAwZKWYrxu1qdf+5q6prvtcE2sGVwzJ6w1QDRDeZgvy0F80ubh9FbBRQZwzNcyIPivH4etuVrl+wTYZ/QWk0K9hIhtVNbuqWCf/hMbf3JUytPcYkywQaMVAUqcyEpovu6RFaNGA73sb2CBYPBURwkBef2MAlChVgPwbOSJQqe6SBQG9kDkqz9gQbSimJqUZoQuGlUwFmXwqQdojB8LbKSm1ZQvywcSJtMi6BTogLbxFaIK06D9y1maxu7y3olb+9m/Fu5YZBDK8V0j3vw8asItFD1yKuyFQDYwhCTCL7PRSk3NgdWxPYuSdAfSqN/rPhvJApweWsYwi1Ar10RJM/7mobNWolfI0YIA1PH1hFACy6RS7wIQbrEvBNNegGdXEfQVepbYwCqNlIDQ5rCw4g2eEWSa8J7+hTXViQSCZgPLf2GE9vc6k3BR0ZyCq2YwbLnLLHZ1elGop8VqGxNByw4iQ56udkspHrdXT7Ce9GF+6W+GJELixlIDldNDpkUCPwFF1zku06CuRWZCFGolTFj7EHtNbQxHhQRJ7kmfV5ZMqSEVkL/PZWvMn/4BH+uRHA2IkxP47+E5iHz4YLKQAlOvtEPwHmGAXdQCdXAW7s6HkdtAZ2cBHRCeCTl21DVtMBLIRFMFivqzQZRsY4L8WYmJDKVPArcjTiisA0a91vo5OSB1xnz9xrvya/6XR3+rJWQLUgJx9lx/28nBF/my9ngbU9sqxAKANUmARdzMsdr3oiqc25VekE8wfe2NcBNkIC7UNpSuyiOns9arIURqcP3LL3rCYNI9d5Dyap64ENeFaAhY9iEmvCvFa1viEKaEtnyTtD1/htGRPDd2g0KqjrDcOLxWx+A0mlE2NIl02ZEYFyz8zGnnw2v5ak0YmRJCSrwe2MDD0ss2daMp/aAL65asBxcJcVVYMOWLqevDm27eObF1767xqmQVcRHThijFjOknoQWd6IZ29ExiMSCph8W5P6XaeUITSyoKRbQvkaYFBIGjY8t+u8YwmUseFQTu//va/9GUAxZnKZWIg4UvjlIxl76jWhoVEx4aExtS3Shb7+iSmfvg223j4OUl/DvDZXGmq1uhsyRkdjqdcQ4e8KLRugXUK/Kg7hcV4u6TRDlFfLMzSHDIfeWIDwwEI8RLEluSJWIj4hNyFYk7msg4DrzaNbG8IZxnQplAJUM+uNZ74GWFOF0Ior3cGCA7TWc9YAJaIGeQKRTJPk0cJ2ToBFGZUaw/LCKyUMykNPVzgNOJpuyBipcY2g+X+Gfvzr3dizH6Ooq3No2L/D3TMg0F3Kvi4r0vxHTv249rqArWe0ElNL9rZbdUdUCNXgUV/KKpJqasorqovGXOGRyS4PMNGtdUHBQ8/j7o2S7uuq2JwU3Xfm3OzQbRZg/bJqrUpv37s+L93WU+/umfsplfQqoWeIHIxS/cOJMxMdUG8wB6Rk7aUEM1p3AzKFUsAsqbnT+nEsnA2IzuV+MwmSnEyHImmdqVIq53sEWoGa7ArEIDLSYxZSWol+/kbU0jby/XwliDrzmcL2LGMICEpLkQHX0D/H8mwpOSiwEEWLbAAjd6TI2dLi4/y6Q1WGk2b5Z1RxkUJ4KEyCIsvtwBYF91ouQpmfm77Fii/ppiO1PehgS/EeoZUDxBCNlJl8F1dLhHzJKdfCRpzrFAxDuZcHlzwVFPiWf8iYrrN2NBrWs+6pXFKgh4MJLIVIoigtNEgaacnrplvwppLN3CEhPVkABBr702t/KG8qGRKnYGEXwZIhcpb1oFhjqpLU/haBjtdI71AOpYtRQPZWQfkiQHsCGGzQVkmCbihaiGKJ0gXWZn0I6XqomwICkPhyEvpoIrjhzUNyFpAVr4nkI05KNEIaJVPKliPlKZJKzJHmWS6ttEnaYp/U6K70wEvpte/ST78SzdEeMcgB6UqwZ9wNybOm0qiaxwJl7SmAyMX5HDntl5vXN/hbvrnc0KEBQFcXKopHzRN38j86EPyz9jXo/7OXs+GBv/tPklP+8GwjZ//12ZPcpL9HaHP+XTlps5aTDolpPISEHoqUPhrPAEPGEEtOS0DBCEfJ+AupmND982lyo3Em0HHnXdfkmXe+aV3uvPWbXd1k8fToWHPmLUjPEvmvq0miZGkyFZqi3CIr/3/WAyAAcP7jENTkx6Axk69n8bTsufMXiuBQAg3uch7oW5iNrTdX7WSgNdYeBRoA7rUfTu39IWAPHLHZo0MBj3qD+ssJnhrW8xmRHNembl8/IUc90v9bvP7j9fGikxygtTyDaac0D7kh+w6YZIzm9la6W24yTA3bKArvqoM39EF9O4nQzC3OnlifeS3OnYVtF6YAP/zQpiinEwnEiqSAXAwNu9gpwmmPbf4gEs2jX4+FqVwifPp+ct/9/Ea1kE3PqUGy4CayCl1yVYpvjW/qRxFOYa2MBTMfEq2karqrFFcsGejpey+U3ahZejIpr8fJ/zxyMUbTIa1eDDG30KMqmE6ST6OMTmmU+pNA/005jXj+GvvxlP81ZTdLlDidMsX3tP/U1ExeEQTCKS6oeNLhpkI9o9RI3Bt/WEKCgatGetCJpnd/k/Zbq6/jAhZQWXoU0lwSOEWBlN2WcqDWwYLKj4AOZ1rMAhKSDiluPKlDdRhg8JABaADeCi23x03fOhmdU+WVfz3rX+Z/M2ucFu+aWn+3stz3uyG04fRhSMdtPMZvklY+3iRTzTDb3EMXWXI7K6/1e9ucTyiO4v+/SVs4i2CRLl8/x4NAHYl6Ag04e17VvtfSyNAhFpognGoAtW9fHV49cw0M7KGzb37xGrlDdejpvw+cdU+q9uXUEah/TQ009pDa9/Y1stY+06h5nYSdVcdcPaedl5pq5ORQK2MtfJixYfkumhWr5BSUVNR84iNDFAqFQqFQKBRq4D9oM93h8GdTP1817/ly3z/kX//5Xxu6dh06denRq0+/AYOGjBg1ZtyESVOmMTCxzJgzb8GiJRZWNjA7BycXNw+k2E6zgj8ImqvMM7/rzK8Ho/k/qV7bxH1PoPRKouX4oTzrjSQaja9XSpWZj2zo9Pm5TzLm2f/c+txr7G4hu9Gsq1G/crXIAg9LzwxQlnJE9u4PQK2+Jcr3QLST2uITpfYRJIjwOV13QtW/sytOaZsOL+4XswigimHs8u2W6lBWK6k4JRXtOi5znxNUHdPRyPm4VlstOcFqK676oZvFBUiAZCz7S3zkz8qHH7pByAKRoYtNbwrDvVIDqNleU9v+krWE3UA45Zd0D/eFFYVwwMyXrq/yvegicw+l/2lQaoTW9ofq+pJjtT0PHCdneL/XTrKt/URlomMdtMOBLhkzrjY1d73E38iFLJpZ1T220exYO6nprf/+otJEf+rekXL31uP4GKFyvMX7grvR2A/opuBEMpV42t8yqUQjmjELq5zdVLTfaDyFhKHDQWgvpOwkq4pjCieHVThTHoRvYbO/Oisfy3vwb7b4n++2rQD9kv7s3bevOMdTOG0ZOgRKUHlsL64mngrlVbXOqKaLVaSQzM+4MJVGoc5sXN1NoFIiBYFrJp1gHLKJh9FaJHtP6po0DVj6Rp/VxKgKy4BrSP7N1eZAYnCtbnteySLDSRY+A4n+/HfhDxb0n2sl6rIi0xU0dWWJKqxLbQwtLkW1+vwVskQK07P/uYGW/3+xgs68QycmNFUOzsk5xpsDSUq4QTDrTwaRA2xUUzg6Gri87WspcoWoFSXHHnT64u9tBrfjnHl+4Hz3JkDYnVJJ3t8Vlphjo7THVW1jYzf9K/vAuTNMpTHHDcOe8tHFIGj/eTBiHO0GUmqvEKaAf6SiecA1yCvlfiB/HVNKfkSUVgZGi0HbkiBlxniio0k5IkC1OpBGgbI1FZf26c1D33miWtsoGmwnhd1NCnDsxfncV6c8YaJgr6n0/Pz1SQFWiUyIcMu4CCJ2uYW1stlFHFQa/VSne8Lwg5ufKUZz+cTlj/QdIfuk2K3iqytsSk+mpR9hkl4bmg00wQG4O4bbLqBHuylYBQnU8+i+A+66tqM1YWrX067QBv3rIC1YdHs+q1WUmORCNzmPVgj7Zu1kjr2U2iG7OxN+xYlve6N6TjokqX1WuJynftvAHuniIo98R4YKlYu29Y1/yDc2iUIbS30GB5Q3maot8yY7eRV7OWn8sUsYKmfCql9qbnwzUVj3pj/5PaLcUsuITGh81NUbV8H9WAeumS1wtpXUPqJjU4nC/Qv9tlX1ZtilHLk5GtSx/zEUNhOsczHK9RNctW3Le5Z2lpKqebCh/NrcJx9T8LNvxjLNTyxZcuHzhQKC7S0OAmlmWhtVDQQft662AIy9WQnUHNY3+r2aqiZUbWbH35rpDQz+ESi0xAKr0DgysfcXFXtOU/So+PSoGU7rSq827ItG4NHN10wTnavzVOaaay1Adx7f1TOrljhdASdZd8ZnphSzZ3MpyGOY0t4ctSANlJW+eyqLRQOruqnYb65ck13N6dJfNShFhriFNA+07u1SFkor3lElRSIYe7+shnVDoP2/vwm1Q+smosEcJpwU9mRRUNjKiteIDIvjNtXbNzW1CoM2qX5D0tcT40oR/3P69uZpf01DOR5+E3f6DCkLUCQqdINqoD3QQeg4dBa6DN2EmqAn0CvoA/QNwEYA25AGQ81QBwzuWBJKBnQs2XPlLVCo3iILGO9S+vvVLwrwzhcAv3Rqj0YRAODqNTG6zegdJ/lGBZaUkkkxDQymsDWevZ+9ejLIbScg4yXWEyCW7axlGz+ZXaqCCUxz51OiyAzX/seT6T7AWuRT27xBILkE3CkZ+tI89G3u6Ia0bYBm9RU3d7xkux6GxHqWyKYf7r5pLjoamwHQm62dlyxIKBnQDU0bm9kD4Xdw/Udw01eo1xIwKxmMa8dboNBDb5YwmyFyGQ+DjZBmglzFpigzb73E9Z9/63sYwhUx4AEl9LDCjSDiyEp5TFP6Ml1rLXf5ylHBRBL/QEOqsv9iaVHrADVLJAVK6/V0Z9Na1DrY5bjYJfe8xu8H/8D+1BAAhgOjoOK+vBZmBl8zYNKXqCFfVuoYo9nNa8IuSS4PVNHGEHNscZbnlD8cqmhLVDq5VjzG60pvIl9BlqepwCQzxz3oWS/P3AS876fMtR79nSZ/KZA/CwqgECTaIiy0Ige0MMMJfxQ9cDQkfaaIUncq3eeMUZaertujXAGMtwI9nLOxwDsVCCV75tryn66ueXqsEb12vGHq6i0NNdlhByEARhqcCvuh+UaDQcMAdCCBAa6IjTLSl7xXyVkJbgmaOLIoo/mVPsCJ/W5bdzjiji/BRBJPajubrFDlVqtm6/R+MJqa1jxY9xYL55W92+t9zG/0Zd/3K9DF75EBKgYBXArFeA+TYWfwpzNSDDXDCDu8PWEp9x/5kURQXTHaYzjmMFuc8cSfUKIf2CnR0smlWJVn9ZhW0D1zEFBzexw+C1vWpu2PXc/pPPJeWWd/NWX8MyAQBBknUwcbIQSEvHNahlmczk9ZURNJX1eMboyjHkvCHle8U4FEeIg9B4ix05D8QKznkonkM6Wq9ka29l4vKlxeJ4a5ijiZn+WZq5nPdg433OY8z3UcfuYfb3TtOhpJQAvpwYEjp9SZuHDlFu5HSOJZNaNMKKOJvkzNuoyt5Y7oOxJ7vAmU68LgrPjRSSVbhVY+Wpu+zaGlrca/eMLcrrGNVbXUYNNXcgGAMwMAdnY1NRF3GNYy0ZHfXBvsN97z/Tphf24PHL3lHGw/AFx6gc7e7iarAGCvehaaLL506sapjkKMAYr+Qj08OvQRAHICgO2LJv8BgHqsPM/1s2l4TT4nqrRy4d2JR54Nt67l6M7K60HX5fRQGYhvZIdDjnkXwL6a5igAKGYiy09GeQMAXNytTbfQiDFT5K1ff1kIM0RjYILyIgA43UCSBE6Lst7wHJpxsaVX7VLvoVMBqSDXqBSY1t+aF7YAAI7FHiQmK61YVq31syl73XAmW8QEh7I1DwB2rNe754jgcHaxrGTm6jsRVG0ji/FZdI8p5wLAYU0d7M5jqxLzEAsQ8UijLIh6jsKdaJB7dlWeNjrygHJgFfCSplxoOuqr4BhACioMoZaVQ1RpiDFameLpDy6zYmH1Hpncauc+7r4AgFXyRtejg1n1gobOsmfgbgg/TlaLxrc0f1zvYJ+WhK0iNlxuGdvpcLlcPl6Ub1dhR5aHPQOAE253YQumND9gemycyrvsXF6kYCfheE8qrO++wekLrPJTXrDIlTdMnUI7ZdabbFh2VBKESZRtVy0sZ3GTkTuoO3XvYctMD93yFr6qbi2WN+Vh8pQfjhgKX6xxUZwevJvUqrMA9MhzeKzK7Ws37LRF98HwoI9+DnHUuJ23loa22XlP+l6UC48M1hhBXbdqoFeJaFzIo+8LpDClr/Z63nO1uwYADiL8gykq38ZXV0/hkgRJyY3LQ61Lv51mWHQe3js4eXa8dDHvrHTxxIbVs/PS7R6ilwqwrPQK6nC5KacxSMW6/nudDVNm7cABPWGbMKruoQ22TG4Pnd6jjWdjSo57HMqQWeKKENnFLGcKlBovcDm7MT2jP2yXRWme8hUAluDfTwsjZtcCQN/9grkg2m1nKowRVnZ6y6H7OS/VaYNJnzL4Fs3vEQA8ADUk34grie1xg+RPqdn8cjoA1wHcBRIZH1LtQN+DHwmgE+AGALgZAG4DcCeAewDcD+D+AA8FeDTAYwCeBPAMgOcBvATgVQCvBngjwJsA3gHwTjfftwuMHPKojhYnQdLc8siv4PoWXWJDP+HoP9f8SpvW/3U10FiM5lsNSpAsTabsIQXCSodXaTHaHWP7Kpvq5FBVU7Pm00AVO9tHq47Edb9uGg8H9nNEoVVi7GIksZ4BIosJVyy109SXtNGIJl0+cm2QLdmvetcQNOtmnnLb+5rW9g60j049ahYO9d3MY10exIVoDsUaexRfWpgK671lHKWq1geL5FcopFdkUcWW1KCGNqzkUkotrbGNa3zpTSijzLLKrqBCBJ06JsCDUhDllpIsvw6VEiExShqAXEUYJSYTW2AhuUqbKdVrYOJUxzJ1WRMzT7zkpLlLeASTwTPLHLwQ9Pl2AJwrW/MVwkYf07n5z0ZKmnV5gzANaRRRKZUiGBJ0IVtw9lwheRFCMywDsIKTvCvVUqm3j50DcHNx2FGuzuiwlS7kIL3JmAoQTE0FAP6o5HIOWr/zVfiaayerYyyoIbornh4hCPLmHpgUyLXRt8B7hAREdFz0lyRFmnQTlatQ5YxrHv3dE4j0uiSEvU7PVtizeA2Y5G1FTFW9eB9RQf+hMYIXxGVs32Kn9aAeYFZGUcMUpOS/wJRSGqqxjUeL5DK2v59BUGYVXFndss7WocrmgRAh7z9GIEkTEUnvKoTpF1wGBZVhwaQtBBkVmHFBZ1KwJRR8iYWsIQOp34h8RezlP18MU7MmI8CToCARzlenfhqkaISYEEBy3lEaPi1HuKJJIX78FCGnoWPFblr0EdcSsVJlP5PfykVlcaIVc0QlMDFm9A/UFlk+1YyutM3jpwxtsZ3aZXfR7iPqctg0C4YCMEwUE2IKmihTxIiQahRkd3VYOyr0khfdUhSy3ArzQgcWuSUZJSUZGIA0+lkd2cbUwJiYRkLRJjnafIYrk5k62sRMFNkYTM+fEXoMCWlZoFgidMLClPNM1vymz/EXQCBQCE4fsYTieEGJX4gkhE/tnwklGUxsiBEkRiJssjelxsghSzk5BeUjlSmmh5Yx+WMRywAFz7BZLjWoB8ieDypmVq0nWu8xwTl+gOIlUA0ECg4JAYXGYFkTxEYAVFHVokhlQIWfVKrHB93VaKC2G4vu9iw87F10t++Bh/0al3YUK9MZl6YqnknlHsdDQg9UHni8VCF9npvX3nP2wS86v7Uz9T//vKMOncx0IQF3sY18nAGcJcclapnFqSj5M2ZEMipzu4puKQfmotq0y1QML2mNdsVW4V3cwKd86Y36JRn0qCyjZ1N0+lrQ8RMh+wirzOhbahe2pRWBpQ+CxEnOgSJ21YcBQwajYeVVyMotXKvolnW+DlXAo7aaKmQVd6t1nW5Zl+pQhT2qaqsipAtFQNcKTX2FuGuFSbc6Wt9SiLr3Gg4WyUleTYDzshryRAGAfde8aRBpqfTv30Y0Ru8N1oitbimp7kc5wqbmreUW4SBksvNoulVuzZIrI5RUlJQIJUKJQmOwBLgIJTyJLRyjoYiJmGhTbIddNNvrpsIxp2jkOYk1jdEgYmFOEq8oGqImxW/KgyANCiKKOiO/JoZdJUJhvk6LfDgNEZpqTUhIGGGsxCstd+xBgMNg3mQiCwNMmEDPs8HVsF5kEEZmjA94M82n2gCFLfYFqsQi4ZP0iFGt9k2pW/vwCQvflIQu7erraBM2fFEThEsbipCIuEl41eERaQpXVs4wQGKfCBEuFbLGiQsXYIyjxWFxuHC+YuAFEzryzmHXx6A2hNSACIs/woIniqK8GeEh/U1NmY2mLmxKMnqExCTEJAS0BLSkBLQEtOFKOobFTI46I4fg/V0/hs5e2OW5g/95HVvuAvUUZ1jJ3Jto1okMEhVb6/j8xd6gexNcS++wx/eZsuOhu17iJRsr1yTl2v6chr83Y89TkN4SDDdO3uf6VTovO73h57px4KWHPqIbzVfHyzfFHAf9qQ4x//S/Fnx5kGSk9MudqeZq+7Mevs+CEx8h+hlolAkKTTPPR38CxPdacuYrVH8xBhktQ5Hp5qM/GeLvrbjwE2aAwVJkKpZbT/15Ed9nzZW/cJGGSJWlxEwL0Z8i8U9tuAkQIUqsodJkK1VmkcXfLMlvD52kmCCfkL5CxUqVu7d0V6tZp36jpi1at7vt+HTMwb5073X+vY8DBAIcFJjL+PsDYQ4pWqx4iZKlSpfpsu3D73FxXHkLFC5Wskz5Ss9W/3BsA6cR2vUaNmneqm2Hy+cvs9g4t/P3fVwgMNDgo8SMt4n/xbcsXEVQp8uYJXuuvAUuh7/V5ufGSl7O/NRAlJuvVLVG7XoNmzS/vPo1e5C77dC5W88+5//7eGBgLiP9/vzAwwBcxCjRY8VNkPiy7N/ij/OUadJnypojd/hqkhln53xW2cAugGXWWG+rHgccdfrKxX97zmW4qckTr3zwTfO8w43YL1vq7wXn8wspafORzVRnr5xfSI7Nh5v1UoRExI/zCynAsRzD0ZuXYPOSbF7SzUG1ofOC1KciJCfCxUBiD422OaBwvACAeLchT4HCt0VI2aLLpii/vYiVNtqhwUEnXXTTM+9806qznUgFTqWUs84zLADaZU/8iDy1kFg0MLEymw2dchHLPMKhRjDCQUagUYV/4SKwikd4RDh5+KFoHKyUyeowhqsqQaYCBsYz4l8ULSKH1mL9bAQS8Y+mZfGFSziGZuVYI0tQTuRbFLMk3VlYhdzF5jpwSM7a61c1gNOJdGUscnsA2ghpXnov5QDktIY8OP0BAtBbL8BSEGYTOO1sscAvugVa35D+7qpTlP8DFA+gj9C32d4go+khDqK7i3K5x29lO4gw/O1XQ6aJ/Bg3W1HFlVTartZab+PjZN4Idt4acO4iRHQIFh8LlM1edxwQr90S7oEPjWVPa2aA2IyK49QFAwarUFXk2tD6yHmhitmKHZxy6t+V4Ux66OQ3sEwi7N6zSKn8jXV94pyTJE2WPEUuuRYa10MfSJEyVeo0adOlj80uY1QW8f7i+yeWb5IyCyyxXKW1Nqqy48Dlg9jnsJPOu+q2B6jcE0VA5ZE4IirPnCOh8koSGZV30mPLfJ8OSFaHyjd5gsovRZ+g8s+lT1AF5Nr3j4kAE3+J+aGlgPGAyQCTwxRfbP7oqZB2xUGqjotUEw+pNj5SXQKkhkRIuxMjHSVT42C7tdRaW+39X0d/+tu/OusiAGiLdypDI1owUtIjfOqhF7wa9Ep/iKh24ChbOyCeDAJ7Uxooa2KADAUgwVJo0yeONQ8AAKHqiztZquferZxjEPqyUaDhwiJUFTZ0gp6KuHvejhaxzRXCnvFrhwZA8hcU2XLKLa/81seM1cxH97gXMhaF0ky8hpAdhLas7QMOhiTNWFQOQvcn6Igq2/oWAL4tNg6yDB2qLaQIfmPdmTJV6jS555FnXnlnCYPdUlyw1aNQHpCgEqEJwFdKVB2iiyGCPuoD2O0DphR9e34EeIgIdAw1vXPExJF5e/GV9Zsfhb4lc88JkM2BGkILtwWwWSrDWxL9+/bDjWDS/z/wv4eBtuWXjn1gGQDA30wGwKyZ4cBQnziYXY3eYB+AYsEYvqT7to/bFDvVONSDTaliF437XFn4jqY4SkIpF9EyumrOLv6rjFrtPQ6Nw+JwOQKOC8eL48MJ7uGe6Z2+Ps5yJDlyHQWO1jEb44M7j3DL3Ca3w6VxWVwJVz/N03F8/2tJADrXywVAymxHOPhG1eoc6WGvofPXf3noAaoFLCXihKHWDVfMVBwKh8HhhD13mN+nrd08loyRAYkNd9uKbsRvr3jfnBy+6zvovKd1rZ8ydn6tKW9uaMSDl5+8k0uQ8eXBseK9YqwYGPv/+GFiQDAlhTVf+AYA4Pnfo2P1RR88v0uVfDpiAI//e5LZRjAyGQIoBFDRhUmTF7xkQD4FAKLtzzl0IUNf5HuA/Ox+dkvuTRAKko3pu7DfUrFfwvOliqugIU1tbaa+L7nhDaqsJ0opsqEHuU+g+dHr6LkuoMnI6e36Xzsr9pz48hcoVJg+4iVKMsQoY+TKU6zElEbd+hxdRR/0EbDwmMldabMtdpSWc9gxZz4uOHTvvX/gidc++K3Z/zp04Yhu9FZL+6X4Jjej35uZM0uZrH3VkmwRXa+nB9I21GQ/gxf6Vfem1rte9emoz80QkOJexj12lW6M6Jjy5MKNO329RerbP7dYAyoXY4KxxktXKsErs800y/xr9nkWWGqDVdZaZ4/al5r/dVe45IYrrrnjem1u++qjz774o8k/InOwyojNpbCYWgWNZZSWMLCSof+Y28jYambWs7CJiTVsbGWtip3tbG3jaBcHO/lo5GUfV3W87eehhrO9/BwS4Iijujuuh5OCnBDslBCnhTunpwsinNfLRdFu6eeqKDfFuWughwZ7bJBHhnpquBeSPTfMM6neSfHWaG/k+CXTd+N8ku2nDN9k+aFAq4n+mmRqANM7AtOiwQgvuw/ifcWylar2o8+h+QuFFSvSdr6iBQor0i5fi0JtJut86Qzpr59f6oRu5enFqmLEaraFmM0011j/1V3XvnKiIf91eOjFGwX+jVpKovHpa86bJ9v5v9axzOT7AoA6Kp4eAurPDw7AfPoHSzOtGfuDk0Rc+Lc76vKD7HLf1+SLL5F/jvnmb/LfDQMxcBu/43PCuc/ljxz9Xh4Wkla3Tv6bkDB7DnOfMSAK1u2om9f6P/T+C8LG8ZvLOV+LU3J07PJwSXY/gRj2ubht5L8V5vlbAw/vfBHHIy7lsFSTozm4TI6CLJzE1Sr8xJp5ku9oYGeq/B1XMdzVNTzybww3t5J9P7ljdavisZxw1aYNydGd5BYI3gwGiyaw3xZ+FPca1rpyjlXRUtNnn0Pbku/Va6mnrCYoSJa1p2Tx2OVx3MsTsMCp0WukhviIinnUwf5ovkrvmKL8D9UpvTrBZFZov1mCqIORCznbk7iA9ceGMdlT49glfV//Xs2Cgj+pM1meqtdHrx3Tf2kGsGDLmQ9PpXx/L3sTRJZu7AKIJoR8DdwXyGCZ3EaVuASuy5bafoqcyWt7qf58WNxXr/zttPSo0qhb/w7bzsCEV+GZCBM6MUv4kmnhW9IJlCdXL6GS9TdMoaFKzTXHMAPlGyXPArnXlri3nrloEXizcHgl9Oay/ttv9b8FeoQCqzBdbYm6Lrar/bQVg8uXFJY/XC1/5rm2M7p68KgEZuwuLuvi1K73ZZsMrZ+Awp80pfC7fsp+fiV78hSN6L1A6T5dqPYJGjJoAUn3YexrVYfS3NCM0jZaDGfpdJzHxLkjzhlmr8MqdUHlLhOsWm9UshPqu/yNFoMc5H5fig1bKtupGCz6de8dghnFZTkiczw0mIe87sgK9RlghwT51kYCRfPcXM4Q3fInv8fpNvASd78rq/Eh+9u0XraQpT7350KFX+cUlnyphdfGuc7pZxSUDQcalTqkoxyvym2btDJehzWdvoMTdGBKQmVaHawkzrusuzKJF1CQ7jIvcavlrl0C2pCdQVYLj0OZDrRAC2Y9nB3LkXo/OPhUv57X/ISNQy9pJi/f0v0mpQ6zfFgrd+5eS69TQq+oPh3874deoIvpUA06Yi0EnV9hlI7+OKSAlQY6vwANoUUu2s+AfoC+4f1j2ooNDqjxVWW3ZElbTG6a7GpL+0tFx0Nme01pUtx9WVe7bH0Bulxau/v7J/nBXPUurUfBb+MHlNM84+698/PI3muCaGRjADApY0e1Eo+ELADEPHmffBEISTYCxTilQFMWpTOm4ZECS1FOLtdWRRCEpE1lRX7iYvLm5owAkuWhpX61FgU3EAKQ07aoE5Dl555A8Bu0ChTfLyhL6wWGaMNAgWX+FSpw5F95gpD2q5YVsSBm9rWElZAg7c0XR5ATbbxyZQWDH62/AQRQ/yi3Ef34wWPfDZe/jv93nm99LZr5fPHvv+7b//dj8JN8qjA29DepfZ7w+PefxgXlTPCcJFrN+2U1+Q//YTVBpzS/4BtrzUfjYXRwV7gHLM3v2UArkRKc+/U5Py0lXlpAuX0QVMh2FBvg9UiApVeb0FkFhNl21CIGMLaNeuOhnTukGpdsA9izj1rDdRJPa4/jcK9DD3JdwY+5/x4DwV1AtjSgC5AL247G7Wj0mpvWMmISbFEfsI00buTKjpUg9oghuzZiTDbYRwDJRtdeVUH2Ds4JjMimO4HJbZx7R+ZDS6SAkgOYnBhokSRdaHEToEOgQDY22McPDio/UJ4QnVn7ZHjSwm4kBOcJdBIHWThDTRHpC+jzMdPCv55v2g8PyoX4kedC2aRoBs/9mMdsw0U+0MMGz+MYOlrN+/GsGtkYmqj/Tp3kG+hit2ltt5aQoffl9tfzosZHBgAA)format("woff2")
    }

    @font-face {
        font-family: Andel;
        font-style: normal;
        font-weight: 400;
        src: url(data:font/woff2;base64,d09GMk9UVE8AAF48AAwAAAAAtggAAF3sAAEAQQAAAAAAAAAAAAAAAAAAAAAAAAAADYGjZBqBLBv7IBydEgZgAIlIATYCJAOPeAQGBZFSByAbM7UncJtTfFRd581QZZyqNC/gzmdaoDcrYIj1vjaCohW/7P//T0kqclQaJG3HgPvnshPlkFBUFHooQ9Z+zA4DjZFBOAuZMAS5ceFmxQpK8tgLvcLBH4gdvp5C7lBVIV/oG8ymUjSuzNDkoT+qmi48veW/82ocE93duD50U4lKVKLK9e5viTbkZbdImRhiYoLwziBpkanEStRlRUFMmIIV90FcQex/vPEHY2D4RY2ParI2vbTaexYURZ7gO4MwQ5IOJgovUSGJ77XGhmrBIUnR9J/n19a57/8/82eaYYYScIgaaogeKasQMRoljMYozFgXszG6MBqLKGvDQJZF1AE+v6Xa78/uzp0tKaVU2gAJgMEggOF0ingb5lfPW+nO9mfmiCBIEDhEYu0Aza1bJNEjtpErYhXURo7RY0QtGFGDHunEEYJJldkvoghm87w82ogVGA2KMbxufvBPVIfltvNVfRIffTMNVQ0exB8WRDyl11dBPIVQGqDQug/xe+f3JTPze+fvXZ1sN/n3PaQJBEmAQCCiqCSIaetbKg4tdUW8VIKWBrOgSaCEFNdy5nLm0fwGCL9aGzL9zU73RRG1Zk0bodITrdDg3wB1+ef3k90/GIPlV4yC4YPN0rs7/z+t2fd3N1WVc2sOq6x0nVtvtEcViSLqjbUhoZEYsc0QUWJYow0NhMasIU5EIUaIjEl8/77Kf52/TK263NSUFz3pPlezIWUNyFj3IPECxuMtmuoXp1N2QvUkXyYdzw6EeVdBAOjTfqOE3bt9x4a4pG6hEAolA6RtoLBJXwIl5W7ezEx4N9g24FOxcFP3AmTqzUC0xWp/7U4Y8wRFgAT+b63M9k9VLaoAK+og+NnQ2DA4QLVT1Qs9v3uGX15vzwRmwxPuMHQAUEUCyp0AdfgASAGryNOR6vwZecKcM+jkWW5bx9LcTPmiscq/u02M0DQZoqHck7D509wvJHIS7aT8d+92+4aZtfNtiFvyaNoIldKhe2xE5lPnu94BzpMhRUqVM7n0Ce8bd/i/cMLkcXI9nCanQhonSJF+suxZxj+MnEnh9JsOpyDSEP4p2Askfc2cMcM42NmSLSGETtQTDGAAtFbQWkEHYJkNX3A8T783Z7N7Qu9CMV8hHFbuPB7l59J6mqbUT+/CBSNBKGYVE0mXEu3q+CgJDzxn0/0dBCOfyvA4caOBrAN7PQ+oRQkkOC0KMBBLNDDLwqlyHbORUhRAEwCIrO/U+TvsTgl1oIyldqNiGkMDHEYKcCEK/P93lfz7nVMXiwZoJpumABsshr3o/Gwr8LrOQtUNFtCcgCTYGN93uHTfFwr3hZJNWSlhh5Ey/JIYhUPanjx1eH9EOEX/YFj82BBVSTtE6jDm6rDIKxs3HLlKBWQo5qxN0+vffsP/z8xxSQDehaRBwsUGa60VK1YOIiIhhGw/2e8chB/QdR81nZjiMPw4Q18D6NoHJ/L9pxZH8dcfb3+bPxD6//3rL/+vNj4p/tv9h66ATj4+vF/4/pdvIgrtf0hwZFTsufLiL0SUeM111FO6IUYbZ4ZZFlhunS12OeiMy26665EX3qrwzt/qNJBAStJlk0tusfLMt8DCiimxzDSVVdXiGptoMXbS1Bly5u9eT3tVSZ/63o8amMAUzDC4cRnX4Yz3BE/oxE3KZEzWFEz51Ix+RmdmOIONfLRjHNt45s7cmydTMu/m7/k2dWNFkc4mJgggpkqbBWHEkICcdAqpREcL48zCRogGHSasOHARJA7BFiVI9hgg8KM/0Frbbz//6Cvf/tEvP/AjP+EzX/+mX//Iz/zqC1/1+Ds//Jnf+vJTP/h9tGg7cwaLV11n460WvLhlzrANm5t4lrkXGrGt1dfZMdPnvokJJaJCnxm+hBBHKrkYKWM9/zHBPChSDPhIkWOXoWvUODax7dJQk82zxA1OuKJCu2lL9pFz84FjV93x2CtHONZyZ7nAVa7zUo951qiFlltrs10OmnDelI+Lo5uijoWLOGmKVNFjmcEmpqSDs1esrawwlvlCcYlHlwcH604KWItc5uKF8d95BKvCmxZUeMOqQNlcKC5xM4I1tE0c/ybNDbctqa2xDbjanvm3o5+rMo0nANsF6M7c3N3b1dN3w7uRrWW3UHCYIoayy8K2t1Aii/LASqUepJz/AGwteGSJGJFsIV6xP2b/gOOusgetMUAtx2M8IxXAZFnS4PnqFs7FLDnttrfoKNA9D9Nk86/NiwXoxTwigBOOy2xyXNJL7bIAlksl9pcbhtdiXK5/1bUjVMyUr73CEm9j8XYF77D9d9WEIEgD3hTQotHmy2ZT+20KdNHoGpIg4pofkRoyo4h+tiVf7eMA76RndQvQDoVk3JSaIDZcnO3TL+JFyU+NesYp6qs+HfTtFZEDsCMbdFsoYwNHyBA5yoUtJFf2YmwmlU4FldRFTdafoefm3GJu6HP6fwFa6pZidtYclVZaS1VSSe/Sp/WkdxnIQF7TXxf41VgIpZKEb7TP7U/mc5FKykSvqNKEVhitUOm1ROkU9UQrVe0QLUFRppU1AZfIYBqS74oeZko1f2Wajq3ZtFOgSIkyNapeyTjhWKLOHSUKXS5hCGn4TMzEks844DPhiBl3RZoE16gsuaPklEeLWX4mXFO4clcAseSAAw6EI8BqTLghADdEPr260RPH4/zLplMFUKUaUQEKiKiBJ/PrygaIbhG6IXXIjYWMmeggd156vIGvFAJGKSrHmquHBGyHg8jEPqyWRuTQG1KftbW5tbXejpxYCv5XIXhFKKh+ccCclxZISWWl35e4JaYyEBf0CmEzwhMonDFtgvN2XbUl1xihkLCCIwshgRaC4KhtK6iZ30BV+prMiWtI5FBZECt0S+MJcb5JChCiYpMc23RCp/qMbX5ROW/hAxUBGg2WRekEnKXpAGQTseQ8nmRfgUSDGZAJuAEBg/jrHOMEp8OMy77hUS6u9KogStjBYGVEWTtoVkuUmtr7I6/IHkHtaP/k2A2vWTNQdD/2WImLcV565Jl2G83h7J41WHNtkhKHTUmT6Ohk89bv67MKOnBxDVm45sTLiFMLURYlGdM3qTT8hXgZoKRgfjX2S5KMTyCx0Mrzk2SS8GTrePJJoM/U53q+A+unotrNqrLhlq5LGuq+q3n4bB++GGgNTIpFknl+lYRgzhK8+bwAM+oSXWMOHRriVnSL1hAFY4ULEKMzHSoSf0d8PBuqI/amp9JJLSZQpIILW7EBdqYMCVuwCF/KJqmsdxMW0MEUEY4JWO4gB+9kKWaBRnF/wtB9F0kTfR5HbPpOAhpRHx9W3N/N0UEqGK6vOGrJRUleRzljJIbox6QiZUOug6ukmLPplUrBjaEZJdyRNhd583FznWWZe1h5Eqfpb7od9jnrhgqk3rLIYutoOV3WfH0f7fhN4hSoLaROXSFORYU8HZEqFSXkz2l4UPd83OJhh1/x6kc946/G0+//7H1UDKb5QvVC/e9n/fQvfOOpPbvNApay7GnXqzpMDrHt1UauPZrVN7A4k8ta9rOKEBk6bLjpSxjbEqs+1Ki1SJOVInIVCQwYVRDItq7adM8D9/Ds/bzCei3yVRQ2RqevsIrWxYU0Hz9xIEPh1oNtV6/VsF3ypEAausbKApRuLFGnwailf/YyBmZ2YTFZUFlLz0/qtqLyqUadRvUXRL6x1jR29ql29Jlwz46KD85o1HZWyMMq8jXRqrzZgfeOzY7fms63pdXIORRnuqwmTU5+SV5evrmnp7Ohm/BC3LD01uGRwebB/sGi5OT0wnTimxaYixE69/OASUFnXUmZofhwedtmMj2Q+4Wfe4r7oGn3wcOqhavqJ8CsrzrY3NTX5FaVeGDpiftVpAPfb/v64qLM4vlCqW1exDdvEG1qZANPaED3b2mxkPHwjALNDcTmAUsX7LG1vb3ejRk9o6o9B1uvP5/qk9Yn30bMz1sxzJBI0zohDNm0vOTGJAJ8L27HjP70GFVbn+TPCLTY8XOWrA1WspOcGOtZ5CGRQwSQEHyP0gBwcO+86pc0SK6rFYlflDKWyHy6kUkV1aCQiVyAr/98fJbgKi8pPQMbI3GaBUXAbzKTA4M+z46epCyC/kyuV6RV5wNxeEfHTI/cWCC0R+JHzX0He3LlNGFS3wXtg0QQT56jjlFlZabyd4zx7XNrBRoMIGEMd3gASWMyxKohaUIPbTL5gjezUWwa2LPb0g9WzcW1a/PAwCnV7gGn03onFhcZ5NbC8u5R84C0tkOvycrTZmYTYmggOtLdO1my8nfPbKs0qh4uWZdfULJvX4XcTXihrnmTRdr5S/dp8f3fOAh2slw+xRKW6rgPG1r2tUllfbqUlOy88NSsug4taSvMsA5UjEuXdp5ZELE5k9sVyadaAQfsqd8pOUK3Z2qe/Bjr87tFLEWclad+QbxOHJoqUMmGcjpOB20/eQSiYbx9JdIlE90LptoXHkUTed0FiVh747bdDS2G5o+xOe/ndOk5ayDWHuYCFk9/foZ2iWIv5I4auv9xLufWBW1sNf9I/IJnsFYS0J5wXmqTAcNAmy07jR7NhJPJ4iMByGOHfpV1ZuBkUkGHpyWIZx2zqWQ7/0Q61eg4dKXeOkNOqFFh3quWS8ygEAHI/J7wQPihBEnwJpYphAz4unOGyWonWJPdQfglL7LDV6JReiozpcnpVBjt2mM53Ud6145ozyQCfAYwMLCECvixOTrJ8cmQHThTc+/czJ2FsyHfZAYFue40PXcE4h1H+GM69DZbe7utR9+hERl3Y8EGMZBdx2EJkQ3SjuLkwTnqBGKbKy3SvbwYgS4H2vwQ3RnXP3vyafXBdVP2o4lvJOXExRJ/KfbEiGga8B0p4qqQp8dgY/7OQpC5Lu9mB6m87hCM+iZieIZrv3cTGYMmMAT7Gzu/G4Y2zOcM8zAj6kpsd2GCB07QEYWtNlj4/dBFxqTaNIdPwO8JVVKH1eZh6AH6+oYrP1WRNnxJYUZEeEH/cVkvaW3p7CxoybfDRLEGG9SVXee/n5+MeiciJrQGGn9qIPaFuz9SWjIot8fnYk01dCGKcDoRc4lo0Be27drXTF6o3LCucj2LYvSDgEmYgiHOAr6p5okdqDS8s+AWYQHsMjcfHPz5pwfebya7eXyU6nLthr2P5yNQP6JILdRsXtB16pLqfJfvSY6wllhKTQgFXV5YleDvHZvqEo3nZywVv0kgNvb0DEz1YaCxOXsPGkkb4Wnr0OY+Cawdd18eypxPXUh8+9HQGBAWH6Z3Dy5CdyITbI+59CZENsUvt7Qf3QURfS+kPFBhflOUkaCtzIzUbFyXT76kXQVOVjtQcjL7sMzIzRuwH5mWbt0o+bSJR8jrWb5Hp6JIijDSfk17PxHuAF0BHjiCTxEfdeoPSUVP93sa8EulyPN5Bbd48wlEM7pWMQEVE/EoCbWYf6tNV3gUop3IV5u2YGc64MBoQk8cmjGdTwT46JafLyVPfjyf6Nox6XH7UFqaeyg0laSSteX6OWc4AQY0WrCUAiCNkGs4GCFs5WIIhMMpejeuUdE85MmqOPr773PulCsVuTciTnBWEAJBKJnk0tghguwHd8ytz7G+yonckMiyO486xMrHWnVl04UH1sYNG47Ip9S7JSU7yqWoUQCQNGIqGPMY6NZmLsXT2HMATJ5K051ImICpZwIpGi3mjw9b535VAZF2ik6pS7OSYuSGwo49N223pMsbw/39Y0JdsgnTUStyrOooZ5XPbBx/HuoXPeoGOr7QbPBjbHUDU3Aumic6olGpngCSYyCjJzcVWjuaWzo6ilp02uJCnayZWAXRZUgA/GjvDxq6Jb7TyqPrWGhDzY61z+X+PEOE0UkFw9TjNP2E6PfQjati0byGu8ZASCEwMz1Xmy++69yZH/GGSAucimE71HMxkWJvzxEoQ6EuBRMbXe0INynLxUyv6iHRcepMGQIf/6jocMYUjySd/A4jk1XOC5ubLU3S/r5V5jROPzgbNwhttq6zX8B+YSEJYgN5pidoc0h+XgPNpE4LGsRR8NlL31fhVRwQGpIwcUbWjxRklKVJ2jQCDdCaAB+PeP/XoyxE8zTfiyLFvYIXlf4UfPPawcPf1lTg9Nz4jeu276qU/cRzGy/9SexEZvcWPo26UXB3b/95G0ntcsrvAAHJPi4Tdv1qrIGjuv0BwWwqRAup0Mtwta33/LhoS0Hqfpmt94nuBn5GTzgiyx5OvSsOS+34Rw4jzhfYUlNYuq+DGfK2wfUD7LrUtj5TS2bMh8sSmvYgygRqUCD8rWtGT5xMGgkLT04OF4vBL1mdr16bXVL3Dc+l9YjTcpyKmu/ofq9mB9u68mRt0vgXsEb6F9T47NAcb+khl9kfoObQU76COEZu6Ee3Yyd/ByH8iSOgJ5pqrOJniOV6hWX9mhoxn1rmFdE8VhxGxSEVFR5Cfq6MFWlSw62SbijOZjFPIXXTXBfD8e/9sDlUi3JXpPtGMx0odvWdFn4oNdqgJgasAqkluKD3tbMFnC/8lzFWrrlhDtdWse7bWgv+LLZJHPqhzvok2NHVa6QLLRfTMFHIT2I7Dj0LffqdgN+ZI4JvcRniInOdpWlNrXGP2D1h/AKuP3NaSJTtFWy79M09m4r7NtLHagNFBhXalNmZWE7oe3jjVcUTLGgOIVZzH3I0u9BfswWFevu2cdEdzEaNNn15FlAjGivtSCdaiJ4ABO6wHz0RDgxzCXoKHI6xCDwC741xFLspCqpte8F67K3o6eCdfQw9Az0NjsdcHif3M2P4BFqJnoOen/E88EMviGHKyYvgFHoxnI65Ac6il2a/Ar0M/NErISD9cghEr82r0au8Zi+BoEA7F+McmPP1PHoTXBjmvhhZ5jIsfUKAwR3qytX9du/bINzHO+AKki7vjHl8RKD3LkYkXHXyQbg2dHZjRAW6tBgxATfjI7mFPiouH4PbPv4mwx0+Me4O3Q73Q166aaC74WE+G5qf7EafDy3gEfpieBw9SZ6ir+yWgZ4vtEbfCm2SZfDs53fgefQWCtH3Ftrm5EehHfpJaI9+trAcOvDx5CWkwCv0O3g99G9YkRTBSp3GdkgN9GWQxl9GMfrrYBV0kX8sdFXy3/9A6dDPDd0Cg9MjoALbgErsAOiFHQJV2DEpbE4AazTMDTsXdk7sfIHdV3tv4MDA/h18amTABpvHDnStBWhAlW4UMAmYdEZT5BjbCuzawNNq0rLQG/qyiKc20sKdiF1ngHEBg2FCLnyiISYainsHYTfg+n3DBfSHgbeg3wJZMEAmpV322BJX7GZpDC5984CN2C2tGf0gAbvVcUCSnozd+UJwIzUm2bDPzrEOtkEf2JqMwh5tdB5zGsy+/M4NmAfTLMhMmJPpAXP5bi6N+djzT8MQDERFzYaeEy9mcVropLccf1rvdo0jxsgrZblVtKyRVmOHpclaoMe97X3f+jX6oQxjvEc8slGMdjaNddxzf55N8Xyf35lgYgdKnRFzUqhjGwq0uJ/GsXJrx8knb6TViO+5aOiiVxe9/7RNvmDRT4u2xR2M+z3uUtxd2Ghuuio86iMyTpbwA/gx/Ax+Ab+UX8VvkmflDbiD30c8oJJUU9VdGCgMFyYJjwuzhQ+Er4UlkAY+qqMzjr1jR9GtNjzxQcElDc/CxIsWWGm9nY44q9z+V1jzvodOlHjgvx741wMZDxQ/MOSB4w9cfeAP9F+9f3qNvVZeG6+Ltw52ehe965506pVCrXDQWbYiw2ySo0igzbRvrYiUuiyzixgrYZLCik+Tro3J02UpW1V5wjBOA6IWgzhGQlTHyQhEKmDs5YMZZTl7uczETM/CrM6GpPOnHmpfyVVT+hqr1VKVvlwVq3YdbXTR4kp8FAfiUzkqVJXqtSSBlDLJq6GX0lq6lypSTzo60Wq3ecE8K2y0xxFnvesD/xbyudySF5VUy2uiVKWrQOWrUmT1GMpa2VQCJVUGyplklGgooYJFNPAf48ywCBsMGRoM2PAQJA4BpECNFjSf/NdxiEP4YEhQQh1dTLDCARJEIQ6pUCMHRaiCHiOYBRs2bCCHAlruSjdXdHe30kFXcIdWz7b2sVXGtYQd+xK/3/v8hs/7qm8dsf5X+PPBk4ePPxucckcJoxhPOTNZxlrWE+EUl7hKlKng2eAX3h2+w23hTkiG++y6zpyaM3G+q29pV3rRG7SJOErQbK/eoXMPbuPDKT+dZ6uvInukSnat6UW9prVNdL4vSJkeb+XdcE1361K5kV2zTeJSld4o4kgqpXTzP8Gf+G0WzcZxTXYac/RWcAoJ9OD98t83WKX40r/8aPlbtpfJcl//0PRQi5L6X9sqqipSbXXUU6j5Ar9P+nvyP5L/Lfl/k/+VHE2um5yW3CI5O7lI3VHdXd1bPVg9Uj1ePU39mPpp9fPqV9Rz1O+oP1B/qv5c/a16oXqZ+kf1KvUv6s3JO5LLkw8n/558Ovk6HG9i7JtQ6t5I33cWP32Uh6nxyUG5xQ8HlN4Pqe+VW2AG4ENsp6eFpRsf7/+Pjk3t7++MnVr/+H3Etdg+Tb3dkN3HK4Vus6F5MB/6D9YlxEQgT4Y7ByWSv5db9nd4YbmOgBb3LRDCL/Ffq/sL0A7ETktwxx7HpOmHbqfkr+v097ko78yNFmhnlvI9LGLsAbOaPWWe9D/bNm+Hj/710gl8OPV322IBs3+x5czuhLvelVdeYPsocEICf+IUwEeHnfZoJ8SjxwD8Q2JQcFY4g0QZiirphuPQjFR17ZdIf7+EiEu5oEXT+NzGW6QcexIc1UV7Q7vbDvpTMBIXKYIQZboCo2BNEsQzyLhPRVrwpf356v0/DnT+z7WQb5HSku69yjYQ3llIODfS44QbaAMnLsWjUj7hUSdPxEDGDk/E4XjC1rUDDqWamPQJXOUGUgkms2z3p+Ee18fQnnZjhuHoNFQpIa1EuhKg2acbDu62Tiva37/YNdhTr8Tkwcsj7yODyA4odzvjhHtUVZbMhjnleB54vgvip+w3OD8pOgL93EvxJzCBO9W8g0q8rnZC6d+Y+xPp+oF/Yz5zBvR0BWDdi+leL3dnE+H9yFFUJ7gx3+qVKNgY8jok8bhniby3FHjUEXE0IyZVEYQ0+9FczmjoiGZTl2W73NYTOOITduuuw8odYYqB8QoxxrzapqZ7ULg6Q7tTBvO6d8BhLsVvDT78p4jMmMucNYVl8Cn6DjMzCX/8e8iH6DDnr4nxpbdvtPfq30PMGhDtc5hn4yErNodqqg7nOnif+m4EfgGvvNw3bHzcjEDcx8cw69lA44tSfQfnJUZFsL798uUI89jpD7HWgpEdUMuaCug/LUY3C7GheheUPxbrLdTgMR4JgiWv8JrANdn/VK8VpvhaACX9sXa2FBFd8bONE7tcbJ2AiEvxi4CIZWC1w0U7NAuZE1tsgkxSimXavBwkDMjGjHc5hECGhI5PekEuJBZswCoXexVZHTlsyOA5VTSJ66AqFnOcWS5nAPQ2DjsMq62voJmK7vksUeV8xAkbWN59Ph5KaY7lxth5/K13sGziDIdrsbvj5oPtAJKYCOaRTayMbagTGH339b4L4jtMzU8qLtl7qFxupZ6va9nULp3euhPQaNjVkqcP+wvQOsRk6QMZG/CldgCG3fMkOLyL8q9C92DkNvcqLqgq3WNk3PigRRCNWcalJNm9A/CK/UCL+aI0mWZx6Ct0S3xo/RqZ7E768jAzzDI9Bj3fFoujg2p9pfF1EHn1exUdSZt3tg2/9khM/nXmqYvSdAQw9A+PC8R1cZOhHo0hzOC+fqxyVZ/M+04h+q3X31pIwBYOmYGJ1Q1ZBPdtmlgfa1nhmkAmDWlBj0hhPLhQgIxyarGfc/aeIybNCHTtinmkksA0ZoBFIvKjtn1HVJAkscFQQGNAwQUTCOeMhNGdblj6r/9eimWADYhS4Jw8D0uYNT9NdpRRnN/oleTm9vZnkKj/OpXYGQN4e2JUSMnM4xdgkczQpZyDxYmAWTCs6Dlh/AeUADqSE6bD+JxOCqzoiuCH5RlbizYUrVncRn1pse5t+/lk9i3s8s7qmlZyVD0xKX+TUcpvPV3jFuUw/pjGwQyM+J8p3+K7wGf093AP7tsc8nVF1+4BXWyfkgf2GGC+mDl/ww6I7EukRbg5j0PcAVuJOO4Qt+HOPwQZiOVbKMFygXWCibcu9YaJNvpJ4K5Y/iS7sB004I+cwI98DDHmeufjX3wvj4G6aqnxSurTpvFfvIIw+/BOJWAJyS5sutfPpRGeAdZZSU7Q0qnqBP2xmPbHr4Js1Ei/2P5fiuUBK2u1/f+FIydxB6ADBKES1fF+dTvgFP1XIklvIWCqy4OYgZrWQjQN1mrbNIfI3AsiBJS6ePE+WonY0u29V87gYpJ3xbblmD1wi7wNqB6MzIpZ5Q9owWluxhSAs1dtAuVfQe0ALHihyXK/AHaQL3R/hU7kQdnXSFs3O3jOTuNqus/N8PPMGH7PySPSC9MS66G08+jxlQSUebeBgihhA9e1u19CNro9WdhVgDR2rZIf6edzhi32m2gise/U2scdOP75GJtK34aHO2/zAxtubw8HQGMPfT2Eph82xvbGaantD4mxRLB6zfsIZSx41IDZUAsxWIfHIlkyn9upwXZBQP6/mc94yAHrAA04Bz3Pibtw/2XlYCjtjC/TX8O9k1zpUsWVP8tjkkGpflIxIASQ05MWQamdcY7y1P6ddDx0YbgHLKc1XaltZxQwQKcPXtEHGSccr2RZSl1vPN59Dplil7/+AcCVwZpu7bIMNx5wQzsAt1EO/AfC6qcRMIaN6z23ejwaV4eybZ4N32Azlea1UCWDchMiI5BKtDREuybshHkTbsG6CILj3gJYI3DnbOpLLzcjwBQVdT3MhDm7nbN79Z+ZRqwtTAUsZn52hraJjVonemaQQ8OXrfkgkaS6hJBM0u2Fv4N08cia2VJSNHBryEMJwAGXtYucU4NGLO37SeIzCsyUbxrr30z4b30xe/e23btUgB85dD7imA5qGuZX/TH3l8Prl68cKWRArdzC96P+YoiVH/1FdVlxaeTdzUCcLbJJXdFpDOqDsKadz6eX4HDGnpwUEVes6CsY6xF7Ngm2T5Fxn4nZWHburQlzV+v/zNMbrWmW9xYbJAu/agiikpld8UWgb4zV0Otjr6LZvLHtGkv5bWEWte1048vzhbf/++warlzRpoP/Fa6+vEFKG8R1VMDu3969rqy2rKbsfz4q0O3LluhMKMGk0BXQOnCDOyB35upHOcgQk5K1H5BmHau4eq26iEHk2e3eifovAtyZMAt5I+ZbH7HY0dDWAPUyNiW5LSVTpD5AO1VxQPGOu9PQy8CV3bUs973PgfCYwONOfAAfOQaG621yCU5wrF+DyPI+fglbD/UAzHVD73fcfjTjYNJqiH68Yq3vKMWHsSlIE4aPGRs/CUsjwuz4ebr8UGQ81PMWtu7a00Qmp65JzlR16k+43NS4p7pJ3q2eW122uUyaWFg/TAi3o7mBzx5MhN7me4wOud+uDlkFk30HEX+GLbGkh7wZ8O6OaOQLb4O1z/LA5MEucMM+NhuD6Lxz4ieIgMHoiPrBIYh89mrqjEd21bP2dUxRkDYgh8ALxAMkVlBAgdcNx1Re0JnuCW+aBrd+xcDywbPwOjp+dfw7lher+mCOm3kVvL6M7b33Ybi79yp8ia+9rDbfoKtXvuPP2ogld3kxRQ2sqfAaqY/BAxHN8e3OALwU8ykAiMEUDu0/eWFgkLeP5cnyWDTL9kb2g+mJSzHa/WWZuVVL5EVFp3rvaKweotxXrd4KV90n1yiP6PtIFk5vpp2SB1lG7JwpNuYmmEr2HCqTc88oQLPKPlT+Q/ZQPEtwHGoki48w7N62x/sIb8AjmBjtrrvioYndGM9sXIEcEaK25ApWCVRluvoaCNXZGvizXQimGzyzLVbdq2mPObGHZi2s4y5n/VpGwrDcxMprXrSqEbEHDMlYdJxsfuvlORsE2jSDsy8jb6q0vlxzdb6M4/0ai1In13GnlI/+kFInIQr8cryyyf7JIT0rpQ4hWr9c8k0Fa7BeXd66p2b/r0lvRbinBhuDYNdUWZthBZecKgIRv1mtTvVb/RwaUO++0apK8P9dOjW4WRCY5/sHnVmHmcFkx/06QYywF/Kt6jgtN9G0as8lGSo/WItvtnN3HfD98YC3ampGgNTkTtCplK6o7XWywj7IY3zl6SB3NwJdg9yis7zZLMrMxBwv6sLimiLWeuR6HHOsAzybaquYfCFwNDq8B65fQy2XVDu/3YxZvRnSF+LJLciIqYmWSCJobxiiTWvwQCrp5jmcNXNVTPvJXjEdRgL4uxfy/hlnM0YIY993XnZ0Q1k7oZ7bxaML1w6OMIEqeHUSYXHjx++vNRLosVN8nX8wLUVVKz8vJeJ3QlJGkM6F2h6+hs/sdm4VNMwd7JFKDg11X/1B4kx8Gi4fXT23ihSO3hv6SEoKXIiDmKbeOLyrtK+d1SEzUEPOZcdyauik6r7i4ug7lXjkzteqw/NxMdxPjvFuhvE225LMrgfswLX76r0/zqwgnKoJc7IUhc6vocdB8OJftxsf9MFcN2N84UJJsCvTfAw1k9Efk2vZ5ac2Y+oukJHbBhKAkfjZJ2C2G5kIrE0JtmVD+Z7/8SwHePOgTU2ehulqecF46dSWnM9fwQvvX9hUk4BsxMUs72FnTehHBs7me/346yJo+1F8UiXZYz7D3Yg+wKIBmRo8tfIxSP22j7wDACH4z07MwidepkyCyHa1yGxL+cNqDi4gadOqUlaHzJXJYz9RgKON7+yurTv8P/6jwWOMUCdoT0/sSfbaW58+ONqxzl0LYnesifH7tMgsD44u29TtHfVl897HntunB8pvD7dcb5x7iffck6nwQ4qX/UcjcVAH+euKW8wo9XtCUZ7ySh+B/hx+y4Tpi/KQVGNqvOopWHFuHTk37/gRoBKwPZP1OvEg3O3+OAkZAQ7yYZI9om6Ne00lsly9uCyRZ4+0maSfowkfElti64sQvjzaB7/4yJU1ZnmIdvOG1pYjOnoYjdiW633NvMcziqlwcbRN7d49Xj1JV0bSHZHiIYkUNjGDHeKaBAcJ4DFB3IIzCx3C72EjoG8Y9KAPP4ePHKs0qhhmwBxcsuGm2QNwnQOqWVtOPuKbC7caBmTaRFv/ODgNJn0CcFMHGrVkQFR6mQrnXEiPq7fRJxOJQxDd9H4cRnnN7lu+i44/g+nPUydD4onnmhwYhhgYC63uXuXzwK39geui4Tr31s8RTiE2Bq3hkBES+u9ceuwp5+QuR1z6HFdRrOUbx6+xfLTymGo7z+cXS+ue6jr5iHqubNWmUmlgVV87wWGAKmPIQuUPwqUJOEgxKsVcSQlRoqGCP5DCbWRkjo04yoRow6IeAWtbuOhsvJFPBYgpEXFR6rYiNyp020TRRLLHyUQmfpUFg+jJoSb3bz8YZGPP2dlPmM1B/NwCNhxC+dF/2HYKd28VRQ3qDoNwvS8OoZcnIEd+VO6bRgpUwIR7dyKUCtVTMNvY1Dbav6ZIB8rxp9mWOdgCe+5KA3/1VGzS+9IJg5i5R9ZE/tSefyJW0B364EJf3O4xpC066I9U9BHsDKZ8EuwIGJLn7Q6eWgE7vAstvF0ejFt6/G8uFU+EnV7Zq8GuAKubeNu9F1IlXttwgtYLwAYVbGMNTI0lPtoog2nL34YeppWZtMXY0MO0dU7b9ozdl1aep21OOvTIWEzmhTaxN2MxibF0SMqEgZkXi5K/wVkVF824x9BH7QSwH+s2CVA2AVuUVgi4OALsMDUuqVxdY/bIqwGusnUkgSjjiH4MnTFvm2MdJ90fL926uVxuFkTtJtIRyqWXS5CnU8wGjnSl+Ypu/CgOS/uK3uMIuzf1gpfAuaWl5wecj1sIzgk2eGd6utj7oN+LnLzBtKMQxrs35QcYiE/1TIQnYFxGyQ/42Mu23baXH3arjTBjO3Q2W3tHj03frtHo9BoZsC9vN+WKVvTkn3LsH4DPQOSFqaaFn1afRtKEnycudt2Sbp3v5ulaFPxaNIP/iHmI/fLd6xzMvvjxNkUmANLiKumRCscT8x60xig1N2IFs6IjA6gD+onNbtfZyExHt3kofObgwtzMXx1+4p+lLqId/9IKjmZPfpbLkAmEnEwB/WS5tX1QPq9GxPvlLU10ctBqbOwFTMJieJhfamb/+i3mUFraNx6v1b7X+hdBp+6KDFtpkpnpziE/AHua2J2r1TAFbWXxLN167qcRIle+zyLotvURD84nvzSewXo3dnu4OeaYj3R1KYkWvlDZA6b+JJL5K0Xl34QPYTpBaP6V9QDmx3UNDteVq2muAFw6O+qMX2QSSH3WFLNac0Ja0T2NaCnD4odfLDVWdF8jTkjnF9HZ5xT04TzTkJnk0ZvKhBXiCL0v0yRyQjaCSS68oUwIz9t/o96XYBIhJF8PwaWp30BushG4PHUE5CUbxpsLQV9n4jcVU9CqtgPV9XKler6ioDJL6mSw/h4FV5VPsseY5TKz1X4xIei9tMB64YfWysoarL4+KDUeSJEIKilm+Ch5quvQpFC5UNi2KimIcPUcANjsXDV6eqbSY+jo2Sh4CviSEww0dNr6ytIhunmiWt0r7Vmg/SBKruq4OHaqRO5boo31UwW9jaZq/bMKqqsrsI57vr5t/bAE0KbN6B505/XyEqNzHwPCuwjYzzrleufFL3SmHQ2I3WVAe9p5L12FX7MTus2YbjmbAH/hdbYge+ewCGMJBxxBJiYnUhNgIuAloAbWMHoTERHfNvD2+FD6CEAPxrT8+HvC1LudC/GXKEY+ClOh2loBqcDa3OeQt0NWq40MMFeUfU6JWAFQs38FcZE2ID7YARHCU9a14BUDnOrZWfh+CfD2Q7vvK5jSmGwO27sYHtmMqmjz5OcPMbuEdXA6Ce8RyKRWw0NteWe4wdq8eB6UHMe8IWNkWfkwuTOzE2fl2sfcy+bGrWbpG/POPWay7u31uDpRrNi7cujmfdWJoTc6DMvlwImmcsBb4h1TyY5V0mOrvt1sIgOffnS5mzjRMSV5+VcJd+LPV13/9dfrKz5OXf6bG78b2S9RdqOHud7rHIFlMmHfc73qsjsnVOXl1pvPJorTeuVbiGnm8P4vP1gMgywaqKRnXLu+kfDRTI9fpsp/aMThR2zp4ap8v4wv6ricXJ0p1xGWGC6N/vnFxTQ4BkMF5Cc3rlJEgohxJ4SGZu1kRaqdnFNLssKOREg0IrIDE40hRSvPydkVVeXlqpnb1mxfK3ddMSsZuJzK21DDxE2bj/QMkbNqSEJEeZKU5zpC1ZMI+HLudY5yOfvQtsOHVV9sr+nvRsYiOXeOY4sEasn84G3JL6lgBWZmQ/vqEenCnouUMJfssmABN/ndLEeu/PQH7ubaFcNnpOWWijIzOao+MemPJEup/n6MMIM89a4guTW1k93YvJD0lCYlRBpnqKkrIZsxinPxR3kNTeio5t7gmFsl7w5t/v5Yv6nIIp9U3+anH0qQMITIxu0YL5pRt+D5wkt1cxSFvLAU6csj9MUR0VAikdIPM6iQqjKpKqAqUk6AAmUVU9ZQZSULlkjCTeEPwjuLM9CuwPOG6llMLQGHy7b/GnK/s6ig9omlNK7lkrexD+XWU0ndUMZoyuDB1PJldm9+gAkWLgFIad8LmGhWZNsVq5hlB7vMECx/h5HIk624r8f/iug6WZ8EQa8iilwvHkEp40oF++Q1EAQ40h+0WekzlkuO+z1O5Cu7AinisHK2yx+0VcGbQZIOFxyrIQ9l5pzBUzMgK0k8ecryyHa81Cp5ag7DbfYGwcGijOWBLY6g0RRxyB0rNVRZzrzE9u9CnFmBzJPIcz7yCwTW0gwFyuOGauKNCs9YEfMP04NuZR5r1gcjJnJc8LM0SJKEz4cKeR6u5+gqKqV/yW60/xj81D3GkJJLVuXGWEKkJJdv1Oq7mTcvlVmGusmw7inDmcSbD2qefIz5PSnKxlo1m4J1cX3CvAmhBGPxm4K1AZg42T47Ye7q3FpTGGcy7d65Xi4QXqmt/7ZeurbnJAVH7WfpwR9aJxsatmytlqvU2xWlO0xSil84A0d9hGywMJMy8BEM60QYt4huPMjTFbYT7x9VgQWLu3MNHQfMazFWjvZrutE24kk3VTCeguGdQxceqpBKDlyYPhglly5MjfjXw8XxnPoY03j+H5MKGFcYNNnDmOMOCx8c2LLWnAxfWovYy5N/47lT0h8/tYr7GoYKlyi1SLFVsRhvhA096nbmK9c7ufv35Sn8OfQQpaaxYiYYkgNAAuq44orE5Xs80UT6Q+j+UqzNI5DRSzTce8XG3XqJ9AbMgBg6AUUwXOAEwxtzgTeSz9QDJEqoKzZNXC7f/FAz++uvdzzUdb/y/zTq1I/ayBIDBtSU9v61Y9KBnW3nekjOLVufzfUqqWvAl5mxZ27YkwiwRZENo3ycmgaWzx9veIff2I5+WPhphs85f+ACZj812zpnO7ph0M/D//bx3gBpn4GrOazUqIRnmrig/P72qJWbMTaO52WH9nT0DYdJzV9jFBNuNhvdt090EjWTPR7S54PbU6Ts/Rb7K9UwMC6R9MOROROOvnGp/XlYYdtOL7QnDc7DjH1s8l2NZBrU5cBM0Oio1TYbxsFv0NH2PtvZhRWa87B3H0dnZ4NEdAkRDn0Idm+F9PtDbIUGo7N9L8t03JgxVezCvvZVdNTmrOUU51/F79KgsaSiAxF9FRRUiouSSYgXVujCKpR2t1T6V61zKSKBceIX79orbJgVogHFFyUUUIoygQooGLntUwwaJ9z3bMcLjillQqEnIO7Zpba9iNuRTTWg9zqhDStytNuliTuMY5dSAKXaJmsZSvci1L+ge11pXyuo50NFt36JtpdiJz8OI9J51SyLUbxOJjiqyvcKXFCjV3A+zCzVfjQLcAVcnf1W2QA0IiJ9SaHzjcg9Hc/DDzZyu+Pe8uYehFGm0CEpUyMdoIzc/kvKmB0yIlYJjKqOHdgF9UN123vKU+eFIkEORJZQ4fAqeEkLjR8dkZ3K7dFjiO3yDpRYJCmr8gE+jdv2vOE2bi+LpuGIFc7nsPVRCGds2bTwe4NjfQw2zHGgigpWQIiyFrdg1tYYxDFSuJpCpWYJ9lZKYWwcAhUGEcnW4NP0N/7LWJ9856PIk/yMfmn5Hs8hapaCRTHhb8mKP/0N2JpKPgtOYn1/BJuEJYofMlxF7TaEWCLzyrvMitLqMKwVemkEI/ZGKFmFkNkDYdo2oEQyDrKLKK0Pw0oh68pDZEYgXglcyP8PgYT2gq4TeqOwzqeVYlaDFGZKiadtPhCLMxtcRVYUVvm0ViSGzAESVEq4f/om0MMgMyd/s5P3h1G2MIvmhuiCbxEoeMt5A7CWbB9AMAJG7p+lbENJCCA8DBJ/zMlcN4mY5lRnKSfsYXSuqJwKvnI4YKGwBAhHwKzp0BChMBANwsb4agklPvO3TmRLqnhaoIW7DVnYDWDXJcldwsdbuzbkFiLAz80PKnlhcvi/Np/67xXKJNwNAHwSACsK6EsOiH+GuL5u5vgD1Q3B9joEter0Vrf22BPFclrWcr93E17/Phu2Facab92U/9v4Y7qAhXQuoYn5dcoQEhKdvjyfPFnLDRssPdqj2rq+67j837YkxzWTHTJw9cL0yHwPQTjDRY/goNUxkn94jbLFNLlZ+H/2G9zjIy9q7O8y9u7I3/jOVRJd9GUT4jRUUR0yO78dmZpTXSg8nbJUrt/FNVuk6ZhWle8w36boqp7Z3fIFtVizdCVjicQ0jGbg4tbE4TzSzpgT4adqcqX7s5zI3WxROX24MFTVOSr3E6LanlyRKzcRJtoupVJ4IqhHqx7N6MZSrYQ5v5kOjYlj06rtW0/+oJPPTOZ2PmZPjVZ1C4j8eKHso9v2e84ZKgj6pDMo6FCqvi3Pl+cJ4wCD0qLb4+hDHGwghA8GvA+8gaXN9CVf2tGWNEqZVmsWZkc3BEvENng/PlbbK42A3bahrrOXVKsJebHaICnN68qFX69e+eWSXWOwEL8+9qHIwObuF3YMU+v56EK1qfUms6bNXRfYRHsXEZR+5gc4c4YCoNPNCCI4PZ2Bov0vmqtlwo4U8Qvf7ins5wNNnb2qXzO6w+UktlGW0slmq1xmLtXrVpnySE/en01ZiDWsZyvtuT7NevsINoEC40ULRRNe3UJb5BG2iE3yMBoFGzfTq82UT02pstOkLGRdv76w8PCJ17F69Vxd1fLtN5y3rB4/dXIsITwsMekOTB49JfvO/RRbTfW9zGzpa7iiWS53PzOu2rLWOfoinSrIvh8LQj9KFpox06zp5uBwcy+4AwnXupxq2SzAn4EjHFB5JVwTdWQTN0Ug4mC/B8u799VY5ePqMUP+er00PrbuZ2LBcfsWWQYGWg3hcSaXxl7yw2Uc/+bPnFlcjeKe29XJH5GTsH/Btx332uG74eb9Y48eu1Un1Xd1e/udO1nXo7FGfDbj8G2V6O6JxGu7w2xdFx8WmpAQFpY4fvrU2MQpAoZjm1mAOT7P72bgYGv+zvV80oagP2Qq3K37oO+Io9H/Geg8N2JpaPYC8HV39LlskDk9mVF9/jX42deQXfwEG4OIT2JOnaDzOmTVc6CWiQzOHuBZ6VO3lytzOT9Bx5GRNcY2WjAWrYMzHMKSwyHE6HToe1hx1PdgZQnAOj20AgY4IVyeRWfx63pwwIB84hejmD/ki9n0k5D6yrkXsgj1xCM4OK19CRbQd1+blmvPHZRv60WfDHZ5Qlht0uUXCyfG3n1fpyOvmdaR/WP+kVOP/rMfKfUf0cQP2w/zHPhw30Eh8vXXf/7T66/oCq/mDnj3lX/WvPnKv4WuZuW//2V5P1mm8N89hVldaxj3p1CS1+c2ar43ytWkzy7HXMutrm3JsxTuwYg9YuX4cR7yeE3wxE7y5E/Lf7eRiUYzujGNd27NP1PXL3aMI/jKCRlDeAkSYZs2Pb6F3pWiLGlUoVqtFJBfERVFqq2uvprbtnCHVtlyvgte6rK2f+xJpl50myuuA7Nf/wKi72JDcamywIcwktFgoIzVNCFBhZ4gKXbYheZvHox53FvzYKTJZpmn3iJLXeNGx8XUatauW78xk65bty3tfxLvjbT8Wg3aF1NqmeVkrDhTG/uv0aZaSZA8dabcBYqWKttmuTpdSZp6kBQ4mRyYiVs8hpqmkOY1OfYNKvo+HCmbOuv72DXOv+/LREZ8iEHoTJdbCwzE47v7ZnpIpkCDwqA30j0Ge/LkNGFC3zX9d4mg3Xp/DyuqVGQrBji+edd97vbnNxUP/5z3eqOu+/L3ok6mDTo7VQDKN08KXA7pyDar5wYXbMSpVcDc6jIoSaQCXhce2iRjzBFTW6vqxwHziclj5cnHIqfVgrSI+mCptnfMV52H4xceIRWPcTuebDRoVYOii8P9Qyx9qbIeDWky09Omvsft21+eHnn88MayOq8vX5pCnMboDZrcJmPXFtKXMcQ6vhwc8X7jnto61U/6jixZF8EsiOrW+B5EdKNgYW/fORvRppmn91e5p9v98fHB7TsPklf/d+uWMdz3CXrwuNz5G7dxb/eJs6oLrc81j3zGaGZqsHd0bEgTHZumSUxIt9llP6Vg7qCcVXXo4cMbHgxECzykONcbs+IA13Wl8ap2Pa5fvbB5fXFsUmpxXEKSuU1PWguPWYbKphN1uO+hQBwLUxD0qi1N7TayGLW5BwsIvh87uVGnesEbgjYvbKiq2kje3//sf060kB2Wc128ciICVU2ud/7+9LUr9+dDrzSMbGGzzJAU2/TUgG18bFATE5OWlUj8RGLrFuHtBQasJrQn/C6rbhnYmSxFKV660k8DKAC+/X6gEACR8oYSeE8Pi2/QgzlbYV+4GDfkfZA0A99kw1jUJHb8kA7OsONvIEYUuwzR3A2tRRsFO/SIAp427BLdqbpR+aXJU4K/uGUtzFiLDxdqxZ4DWefntuypNj+h77e8dHOppM2jEOmEXSHqN/L8eyGpgRieMo0B0vfwIpt2qAmWtHJs4ixbpEuIXP06ANbyYOd47rX8bb1oKfXj1r/sPBSI3tPlydkf6480yL+rOaipwB7RF4qSPBqztxCbpH/1WFxaP7mJWJLm0c+QSDXZZFCt2doZtDU3dkv/xDXVH9QqGtKoccGrbfoT7Aa5jT4y8NMEhgE6CzawBrr6ufNnS861aZdpglZzaEuat094iodH2PDlK6cGZ4m7GNcyZ+z77++M3ltYSPqi+ZLEr6NOf7QEbeeNGZERRiFpQpuFYNJ4CKVwhPPhvPvMZ6DN64hCqGd2mowbgDbDYAz4poMGX0NtHN0+EeNQ7/EmFG7eYCLvHzxw+Q7SFoh+kNC/YR7PEPUJ7vd5PRWjwlDVrRKAAtwZFqY+NaB7pNIRaz79+tLtj2UHf3o05/l2kovXJ1Gn7+B7jCSDDue6RlIadSxOQ9/AnvcFd0k/pHQAfUK9XWmoTpFo1eXGzPlEe4nVW2auHCAF/OT1JmNagPuulonfRAV5rydVculBc0v/hTuBdxP15J75BIpOBPHyYWr6qtl1ib4XsgA0Ih9Dh+Yj0wWBjLujmGgzaQTGQUQ7/sAPChljxojdLOoF4ryc8NaliYxOgIwUvbh1LUxv0dphknhODclYGf1BoniD2yfxdKnG0roKDdpxb4PSBvny6cbJ4IofwgaOKN8sQP0VNPeivun5sF+BfSFEvp3pA3qdssPUuw8T+VNJzeOngpqkJBeXt+T7bou5AbcvPsYk3r2j36s4UOfGz8gaytIeCYsqHe40PbAt/zDoprOnvZ9gtRnId2Qc8cKqzeVlqpHtul5bu8XWXdyWt1vWVKMDyqAGcOinrkERAS8jyQ2MHzsCKcUZfBA+8sECERlIY18hMK/kau1Rt4a/6AWJJWAJVM/DKQiK5hb+wlyrVeyxQr+d2WVqjGjK4V0+heJWrl1UclSgyt8zCbTJRlqyh5m8/8qXz1Rj2Poy6nvSGozY83j40Tw4gnbZzf473WjzDtpPhvVVO5tr21vcdidumP+/AGDnFt8Wl+sL5ztLxYaAtwMmNRd2ihSbT1BPxo9PFyz5blY5uo49+Rj9e9ItrjGURfMuOIFaiP6+9VMz5+ImfXxj4wLFpR36nBydIS/HYDkqthXO7uH4TH+K/rSjZ/X3EsG6fmOuQ9T6tBDH6HTZojmy8sQcWeRdIIxY/XkizZqOAXmet04oGoy4HdH2rukBjUDMhaMbGkpqWHBHYVZDjbhsZexqlbdhfzuJ5mf3Sw4pIRfXoT64Izu/i+iab1BqqIUOqzspDfe1B6ViXIbafAIXlA6RBqcPsNOSryAOkX3sbBd34pdtsLOwmtALWor0hsIig6Go2SL+KpxYPHmHS2URLn4MgTg6piOeadVPpHp+b+Mt/xUJM9svK4RivgkkpsKtKBL0iTWgse7JV6572We05VfziXaCGivQZr98m64VOVID1GxtsGEWd8BZx3BIzaKb9AB+Rhj3fPGWdWtUUxpLrSLz7IFfcQ7dJFo73vo4OCD5X2VRkkt6WSxdhvnCPxkCmFjtDuq5NeeE0gz9ao4l/7IqEjfgepLsy0mMdc8SKafHCz2xsFCMSU/o6vi1ZauyE20UIBu1sfEVLl76xq6QnJN+BN36lghpW02coE3fWCqqe6HZgEGa/6CNZh8OanYiQwucf2vUZbRorPDWYrmMPwDoGDxjesKGQ2n+7TFOeHJESY1oeSBekpCmOiNdpSMDjEbGmIBMsgBZZCWy2jZkhxPIKc+RV8qRStVIjTqkPh6UQCJYU4tUYTokCxsgFG5DMAp6YDzvRXZh73HVjOQUEEDuzozArneDdmlQP/DeY0fAFQ9AQwNsHfTCide+S3MjEq+blMZod93Ucveb/s0xM2/esZ056jYd29u5t7OQBV/sLae00vdVomBQS4ySXZH76pWbWOKpOSwJNByXJLSclqRsNFoS6TjHOVzGlgvXB2TljMAp6ZJbHipU4r3PapvWBw3PGUpwxjDskdDwCIk3Rj1o6HAJlLIVqVSnWave/896AAPQNncYbpgbPGH4dAk1JyahYiVjRByL1GT0OcKh6/FHpx1l72yfDx5AZ/kCNp/tR3+RLL34D665xAB0qVuYf4ASK+DO+pNY7c96Y84DD7/7XubEiWNnHgp+oHl00BA66BucjgOMHyGhkwHnq6gUI0xDSafCTBCHODi2qxmgxWDBE+Te8jShmXTcjSi8ufgGcSf2tHmIRgRYp5FOU7YJG+vMoXsAyvZ9ftAxj4tHOUohjk7VS7koOLi9gU7phtjSdqCLBkat8zgM9ywFQMW5Z6RrsJ0UP5SbbH8X2iG+juUmVKt5NPlXfG7zUwrVdLGyw/B5G4b1IlXNWpDhWCjMgooG5uPXxpjsqFnNNSpJg1xH06ml2FsZnfZv8zffHnvfSuGcLvJe8AC/h+ufWWCzEwo8VqhIhY8+BzpNhHhJiiquorTVpu/fxpppKU7Yrd0xCM+e9+6ueHgKev1NZbN97ASHGBymcoTWsf33OesrDahykNm0+P/D1mGiI4yO0WkLqdnvYZE4xC21wDFXj08JcJatw8VxTwHIY7NZe70v8Nfqb//4138QLCNGjZkwacq0GbPmLFi0ZNmKVSg2Di4ePiGMiJhEVExcQlJKWgZhTTbYuOavU5l8//gi7E9/49sKPHy/0XqMQSKQaLgmNS3SRRR0PtGiaCywzl4zkNkANOUuQo7uagRtfR1kfzslGyy+XCxfZfTmcHtLmsF6SSmjUah38ERvVlqS+2DObJg8/gM4Eeg4MEZB93ZN45hQfiQDCZtCNGB0QOjEBZ5s7F5ICzANXu3YLJoYW/IB4hQC4nsUQPSZTZagvJPgoGTkLMhhTCtsOR9Qx6IN85kScnGie8ttFgC6zuBHnGDA1RcTCeU9NzpKxzAEkydDBT5KFQyavbuCEwbNzmwr+PAZbVmR3Jf6EuJHfrRX214Q0PmaUNGtulrBjwWeDpn5jWpBaivm2PPtkJAzM7kaPvWuSF0r+g5LL4qOEiQnaOZykdoZ4T0D1lJdKVgOvxOJv/wogo5/oRCPJ8frZPxKgYzO7sS+PQVjPMzUXTaQnufotZQgX8V2Yx2rj6MVfSAKLxfsTJ00Ip3bQVFRjbu9FiF6fkPZ4oGnSA31em30kZ8L8DOm4H7155ANIEs2ELHEd7vylpC4AEdw7ZgRqpQDDLoPskMEjDNe7P80VWqKlKEf1C0DsbMfbvIC5tgEbGyBKG4jHisj04Z+NduXpNo7ztivUkhnEpxKwY76hZY0Lkzxs3O3Dx/XxMavTFEzLJbpvnKK1gxFasoRQAmf880AjtyFEbyY8gbOrtGHND/gWA+Ube5JZzjsckDxa3oFqNi6CrPh0muB+1J9oPMH6WszUOLUfiJxENSrzVjOPYgSQpr+lMzg1mCJulCoBQGE123csnbPH+lw2ZLb4HMpz7wzMNx5yTGMjsfAjyz1Cd6LWfMATUjJnbKz0KzxhKDpDkgpJFVqSqzCo9/pqBQzAKZWgWuEx17QF2h/dEHgRx7N2ixzf5lG1eFd+tY1je471Gj8dCai9zgWystY/P6e0CJlUCUD0LxlQATD9FLsgACYORvdSi7xSLcI7NfZlTT0+7i9/ZMob7GLbLdRrKhOx3f/yyHBe5s2xCdOxoRD9z43vqRjoCUPbDtyB8flCZoniI6gaIaswt9/OGWBh/cPCvYQJ8IUWOOWPrmWyHFdFtNy9uTFolMb7pPjpA+nq4odIL5pzj0ct6Rw3keKj9DgrKA8TvQg2miHuve+mq8XuPzZ/k4cUdVmH3SNXc3p+PLbpG70B7tZcMMaC4I0MecquGZQPgXIo7CoeTcccieuoxIdSMiBXxoqXyseqcQ+oB8KXBALFCaCZmy6RnE9jQN1QGXwuJQadroCB/XOBLjLoYuxsAT4AsRkxHUR8dh/iqXXWXZVdsvXg6e0mjvyEfmM1CD1KICSrKgpa519yAHbroAiQAXWRFzTwLMwgVkkS5KsVdMB0pqeYZr00LKLYfRMDrn6AAB0SEoA+C6AJwDQOXLzHUGXCpwCoKtNAG5WNwCg25UGdJeygyjYDYAeXl3VAOoXifaN0pp6hy04ZNLao98qNgOaYjaaY3E0zXE/AQ6ZNEcUmxGaYh6aYyfzvW1yb+lPaGFvw9d0n1FJRpBtOam2NYR0eky734HVUNnouJ1omg0b19CgE4gTn5F9MT2h79OnRPLCkOXzBHniLAtnKduccSYJh2WO0tDQ6f5kAGHdASU243wjq15hHbBOy/mqHLx8wVbSAtptObtQuTvmfHGVed+T7B+WfBZgEAwnsYCJpRb+pXaAqaXuAvYtZYYqDQkPR5HxtCqXP/g1d/dEBD6qN2r0OGHEuy+AhkIBEz3CCULaZhJGPtJJJ1dFudZCrfS/a56xmQGga0m/3DzYyAEow7HjJUyyKxv08g2mDLzXP3m1RXXfWZHHkBwAtWLEDebuFN1pgIMXfoiJ6JIFraCktb4wU0PGo+B4ctNZ0NllThDUiHzOMkfDg/IUwwOAgWM6k1/CDHQjLbDQIh9bwUc+UxPqY0BSKB+kQw5B93LVzbPDFGkgM4oECCxK9lYW6+BpoGdfOpTtw3TL+Xpa1dQ1B74Im/Na8HKgjTFBkB55LVwNDFiDeybUrJ+Cr+PoKYB4RQlV+su+UgvCr7jsoQjAqqurQlw9TjKuea/HshAgJIgwpCQgV/p4EHaEjZ1OrvSjnQHm9S2xsLztPH/E5i9n5TSwYPG1Awa8ZWGSZVm2KNZ4tP9gq0FdsMbDb5QDcLRbOx+M3KuvXH2dAzixwA8xEchImvGT0jLJp0SVF7lwrojEJuh4FjKXC3wpbKXWW+x4V/JSybFGz82WBubcWJD+TK8+mha25FEWvanQx3yRmMF/n80CQPHoUxyfEuq/nVIyoESHA654YirMjwBAI2gReUtjOWXAKSVIO4DmdgDAYE+le7awYZ4DJvZNg+b4It3yfrKxFkpASFN1GcpKtQyaDxEkDgEkT5XmTCj2NXj9C7QDAADHOQWnqzvKjvZc4AJcjMtwJV3Drje6lbYNd+BuxX2W1u2ik3FzEl2me+V8LNQc/UL70VAAzUFgaFy+9OpIYs98DaqZwIrtR1E1AFp5QOLHxRjf1ruohrDH1E6MhY+8uUfWS0hCu9E/gQoGkDEAqr0r2o8nAmicmWBCtiYQ9mCND6EO9LIClRbymQ/mu6a83U555FMBVK495Fp+WAQgJyQXpf5QBggXVeMo3VhEUGB1jiIZJox0WVEPANS+0Gbf0TUErdk6iYE/fCsH+bd/NDFxKPD61+WCe/OoZ0kBZ8XB2tdrewtVqST1PHhGUJddda2EYrqKGq3pXdPmCGodkMTh2qCoZa3GVLCtYo4H2xJTk4gWkGIRJm6ykNkjdgQFc2ZtZieYGWRB7vhdAprd2KG5croG1UXpQY0raPQoGi+QjEM7SzNeMSvhPWDN2wKoNsQ2CbGNBR6HVz+OUtpadrWiQgA0HuJ7XO9QA+YZHRGm5+MovYZj/ILRWdRXED8mqZg074OKxu4eGiIxzfGL52QAKtipHI/uxgAaEXKUr8aOHuorMe39lMTLMRTy+D0BlaCYYGGCq9t4vW0cZQaQjTEbk+09Jq8pZDyAbKfhpLnkUGW9Q7Y6pUnznDA9HUdSI6RB+5LuIh7SQm5PZ5HxpugKysOR8kNFVYrJqyrX2XtkexyuCN6pNI+hdswzh9seSASxS3wNQu8syqQGNRJA9UVOD65LVP0FpqfjKF7T3iYc65pF/QTQulgG8/OHyQBSoPiNDxZITk40rwKQD3GoNukHUVGrKu9uWwB5kg6pCBFrR24SS+YHoMrQ5Id2WgYyKc6RxPR0HMU07Uk4hi+bs6h8IPHGPeb7IR9TYyCQ2Os0TYBAI3n2C4SpFafaw3REFWVb5laAHgb8HQOoAXpEe1yGkRk+by22dLdd5nEFPAQ8B7wBlAHeA/5Z59WAOvtuVqANoBMBOhXQGYDOBnQeoAthfgmgyyFdBY6W2UOgG4TaiW4GdBugO/FT5S9f1foVI5HUT4T/K1IesRIkLKiwpCUkL73c/4x4pWqqL0375iSQTDMezks7f6qYAmeH0+CzoB5p9vQ8OBs6HEsrm12ksNHZX+rcPuCBYl6sbacSrQsI00MUXpTOR9Nak0SxJoqlF4LzQbO1JxyEgPO0aFpHqVkrsiwWWkxIEpUGbfYWoa0YM1QLRF9U0clKLDl5ipRlllV2ueWVn6aCCiuuokqMkD5LoDOER/lHJyskNnUxjcAGozBANiDHBIJJplL4YzC01ho2tst0ChSyVaScUc2gewcz4ZN8DV8MP+cHCGrvLVoSH63NFBK/2KEW1W5fAqHuJZPWq3SyMqtFeyLtdvd70MOePPwRMUqzrACsWtR01trK1nYHOTvsBF+nh88b5JwLgl13W6i7ykWpVC9FA4kY9MDodHMwfIW9Afpe7wnVVEfbz5HAgMib2pLWFKqgeyLGGjvs6RGcssHWln8FT6NIybmK0043Aw2Ta74VdrrhoZKfrURYlVUhVGXa8yooY8PpY+ZVH/pWrOy/LjnPlFWyIZmqTGqPOipWyOqDWH1/IZRZNq5B5eMrZ0My3QpJGzlElhp6ihjNFLIMkyh7UuRAXE4k1ohYziTPZU8STEcgaaMEuhUJHRCpJwj0iuw/ROl5UwNUFDhERgoQzD8q8Rg5EcDFhwb6WkwAngpRLz1Gy8COFz85aK1z7Qqzq/ukzowrWeNNxKgFehKzLKGz1EpZypd0trsRsqbzcjFdO1gjXuD6Ks8uDA070MMGzpBBG9L8JikLIEM0ahydVIWQMbFzKx4UoagbZw/YmkPZwrGc4VwITnNFwYbVn3TmxEDjaBYjHiqbeo5knHjgeJLxzJjQvElTY+Q3seJIWSQRtZZKprPAsYqTtkquS9Qcfkymm54Uekmn1B+RsNpVGWg0Dbe0bOiG2ZpmJj2mf5m4xT1BCT1qPVVJ6gwxiUJBz6NtgbbVkoRSniFpulBJBEkISwGHJ5DwJAX67lXo0nMWynJn1+1URa/7l57FASeEOemUqheQtevuylFN1BdiEVYZ7ZW3qtTHdyEqfRDoo2rOvqvj4of4m796Vq4aiCE0GEmhSowjsJ4QZLY1FAHZDhddSXCCIxRhEwsZY4soFfPqk7QYEXUTPsVOiiyeDCWQb0kuviNEeCnEoqlcTG3Bz8TuEFGpBnmXRnGpXZOagwYmaM2na5hdu5t97zC7pg/7SkvqcshcuSgdS1BqNByqGqRuomhaQ5ROJhjW7vBZaMR2ZZK+cZL3gBo1IUKfIFkvIH+XYFQHgRXUSvCwGgBoaLvIpyjoESUVhsMDZGgNHwXFa9yGbl0jJba2tEuNM35VSokO6FppgA6jY0tHh9FhdDQUODzhVVU3ing0R08R65NI2hXtsY/+cOxqXXSVviZPiQqX6BGxGk/ZqKDoQUbeVccRD20dRsr/aRFxPhRHwAEAJt+dRxhVlyUSicRdOZVsSCJNukaOEO1KGcbFrGVb3myLSSwJ5RtpS4adSrpS62xFvuGyxncl9juIPyPg8YSeZNBIzjKR8hC+PYlk5BSUPdVghkdlpsffLYBLQiLkxa7drJQmsqJElmacaHtZZIWILG6Ntdcu8x1R9nGMXxBJhN1xWto4fAOHb13yKBqVIw1i3zWUUQZ9i9LFpjnxlFSUVBHbMmJDUkdsxXqIRNaEcWg/EtozEgSYue84eJq9IHxeDnflK5RFC531qfLpKeY+2NbVRBtd6pctJuhiIh0jScCKL2vMT5gmWkrT1yA5cs2z1mfcn2ZkEi5eK130M9gYU83Hvnrcfc6Nv4hjJCnnuOuHGGuaBQHqo+/Z3AWIlKiNbvob+vWX9i201qfgX+YhUJQkbXU3wDDjzbAoRn0g/qWegkRL1k4nPWQYboKZFqM+HJ/dS7AYTbXXU6YRJlZUpfqc/Mu8mcVqpoNesow0yWx/oD4yP+cjRNxPWvRpqXrLNspkcyy1kM/oD6G8l0uZCmjpNFml29rFW297DRtz0nlXXXfL9MiTLRnfv/Le1/7PJR8AcIbM2TTtbxvTBwIPHD6CRIgjl9kseATyH7Rq6TVbpVO/9baO7f7hXY58GILDjjvrsgk33POo+eKpYD+87X9f8hGAZskeBYtPK/6Lx+GjFBLIpctVRKuWvtn8Ehs+rtLZ7H/XqB/X22q3IYcdd9ZlE80bH3X88Z5HXnjrs/n+nyWfoNCHTL9//sgnDOA4o6Dh8OJH3Iz4QSifZJIoZcpXopJOw9iyn//kCK3QbdBG2+01bMzJw+f/kXMVrrtl2hOvvEf++tr/uV96IP4qtNUrnyyiI/doflNfm+FkES3cI/75cmTkFO+TRWxAJEQgvLuk7lK6S+UG2+aWF6JfHEIjFOJMcARDTAk6E4oRAkDUVkfhLJodi5h5RBvTzHu9jdW22uOIM66447ES731Wy9r5JkaztpYd5z0JgFegyNfYbgZLQg4u0Yyb7mos75mAJeuJYPG6xSkWW0QVREsDS2d9V+yNJ6ImC219GiuUH164Nw56CdGyyNIFFBxzYs205GwsKxGtVrpuGBcNwlaLxUMutKx2AGJdTSoEONhD7WBMl3CbIcFeJfDSZSv3QaYDbNkVW4xxwE4vreZEpn46WoAvmnquaKz7JTSfR5VDsA7yIqA9oDb9H+50LyIifM9xCurwMo6QY8U3ey02JbT3p09fVXU11bY7RcpUqQNpW+/3K1URRs4VI3ndWALOdpVJwVSG1cS3+MchJZIpgF1POOI0p5JBBw0O5MyHXTmXw/r0GUmapfS/MmjmvJNsFvBlEY9eSjxcvmD55ppb7nlEjRY9RszEeb3y0azZsufImSt3V7vW9W50M0dznkbtEW8nbfqajZVrjiXyrLTWRlvl2+OAI04454pb7nvqFa7QKFniCss1K1zhuYXBFZF71rgi80h83EVFzRZXdLTscMVED4srNkY4XHExw6PkoBT4D8e/HBUoNSgNKC3KBqVD2WLtS4e1Pz3WgQxYBzNiHQrHOpIZ62gWrEs0DjhTv/+q7f/q+lF9P/vV76w1MIDcxYVlWcJLxOr2ZlcfvmSvRSq0Q5j9Tt8YF9zG3gJDVfUejBPKgc0hKFEVb+aNqZoBAEL2j9a+spR6ryUvIhTLJBZHXf4PaybVW2ILQzw070Ca7z/xFiNN92X14XXtPxC8ldLKKk/b+rjx4icIS1SoUlSj0yoR2pKE7NDN086k5CFRXUlCXkqnegy1OS2A+CaN+109qb9ghcaOEzde/AR55pV38gSuvSVxkqTJ2gw1E0+mRIZLTi5ALy9efZIWjhj+Dg5xsUdilX96ewxqhLG4iJsWtRMS2aL5ENB2uxfdQ2hkYCcJHGP8L1Hg2MybP5GUmyX1QCLV0f6337tG/apWfy5YAQD9fi4AjOcaAl3/tcmc9fjtBGCiRIJoqgvcT22avQ4424vV1Tn3DX8uTXGWcTlmzRYRLX5n/zSne9lhNiMMWMCqrM+GbJmS1GR5lHMb1znwgN+na5ZH/y5Bh4ItsIFACtuX9rI+V/8+Uof9xbpPiwVUjFfDJbfa75DzvRwV7m764rxa4A45OSHDjOarjac1OhidjUYW0/5Y44yGe7nlua12O+J6apfM2P53/7RZIFpu+ALWR/GW0vol6/qn9+/3F5R/dA3fJqQsv1j55LPKI+V/K/vc8nXiyBZdnBS+cZ0BoPQfx9c2FTKUPsKjxmsvBXj7P208hLGpCDAesLx784hW0CiBfQyAbBd4PK+mCM3DvgXsR+uRpmq+ZsFa4PHxF472r5nsn8NHw9W5ilJb0trCjU+ZquSaeqPMopInLaaVP61E8r0u4W8h0e76/0V4MQkULZZFsqZaS9NVN70MMFCOMSaaZFrpKcqos697PeAfd0rWtbbbYU+LfePPuei6Gwq88NIrRSp99F2NH+o1UHr/1b+OfiquxTX0a42lK+hD9xpde/G+9bClPZ+oN20oUrc+16SyJIUU2q2+VSClIt53fhttuWnEVWPhgoUIZa+VDtpoJ1X7mnUyzCBDDDVZFxXmm22uxeZZZIlltlhno02OOeiwI1b9pIdv7J4HnnnYfE/965O//eOnQr/JLXg1PYfCQjb+/GthOYMVdPI4WM3RGu62crae0WYetnGxgY+dvOXzs5uvXQLs42+vKKdEOMHskEgnhTkgyHExzopz3gVNXJLginiXJboqyTXN3NTCbc3d0tIdKZ5o676OHuvsue5e6+mtHt7orVg/Zfoq1UeJLO9leidDldGqjfDFYH8Z5ZvhPhvpq3FqTfFLrukBmNklzIiJdOWyfehzH/vS9772d696XVFllVfSywor7U3FJqgz1n/G+99U1kZWkqbCiiposmd1b2uceAkSxY2fsKX+abyxC+YNk9767LoLj3/3+Tu41RKTi195bLe0Tv1TCvHrOYC7801FwP1ll4DwYItUsFrvVISF/r7cZL+1M6x9zL5JG1x36eK36TcHRWDRN/otBHSQsjYcENLxnyJK/9DPa0QgC5Hli1yZ+y24It3JlKIp9kFySp4cE2cqW6pf65ynhrBb9fZlWaPLmSKkt1WmRz++F9ysQZ2u0H7w66SMQuOu812PwT1Ou0VwHO0FR9C0UXa4RtMuLmcKrodUrUzKGK0T3MWe5r4D/GiuutmODmtF6XgpklDXfky1RJYisczdavdNxfu9qmy6GupV+HatVSdIit/ONx83alGplMzQWhdnPdD5cUxF8fy36PrGDaeGy5lqkwIBg2zZtGhe/jN2jiP6zsRoMwhHqtV6NCeOw6Ro00PzQqqo3s/XMX+z3RZnLudUEo5zhutkixhgKKRCUwiEjuAHzSDuXtGTKzItn2ELH280XStsBEJHjRa5PEnwpAlsh8iIfNIJr0YJbRbWIqH15X9oKRzrFFyvSx3e7IlrUXCVr9MuMa2qDa5N+1foKiMrDInBkQQJmbFMEn6IFZV7wVY1xkiV0qTYARDRZ5p7WExD+x2q9rGuEqoZOqNJtcbVy8w1tVX8+MrYgNPrwvY8Fp4kTNw0ePwJI+BG1fyTcavTv3O6+llgYsowxjyB3UMiQRS0kkIy9huZ4tCnfArsvVU+IJZF6tHl5wQhN1o6feb66JakV99Lu7jmzg/Cp49sBun3The+TjMfFDGPROhk+OlfN2UPFkwGzFWc089p3NhpFbnMhc5eIa5Sq4e8yRScZsxUiZwJKACL14wJK1by6usFYVO7Qmk4ytuDxZuMp5xsSeudwAVB9DwWNHnCVo/P/VhM003eJSZW3daleiu6OZ0psXXqR0uA9QWhIZtocND6EAJ//fWY9pbQoIT6KFR7R2joBhaId3YB66fpoKau8Q2MwKHhY8zVaPz6PP0itk9AFbz8TZWdMLA+V/aeVs9hbzQ82oVUnYxHMx+LoUeHxau5bt1t/eq5A6RgxwA0KuxEMIbOc7kyiLBTRpmR5iNzHKKZPNV/cZsGAIIr66xKTKx7odhoWQAZG26Xx5EVtNXalerhKtUtwqFNBrDrjW6QiXy7IjPqrUDmmLc7Ms/pACkL5AfuqoSYhyzSHohBxhLscpIVjAcldiXVVFV1kHcOAvTHZM0jPzbh7p9Hjr8f/x/yPs0zaZo0aZp9fd/8n59bd80frFD8gTV/L3ESYPjb3mUPU0Jzguy0pv6KNuk3/2A1ViKrb/nNuqRByXfF+Mx+YUyNVydjzg6DOdd/74NBjXHmgfn1VWBGXaJrGBcdGsStaIRCwobdzAJWLtA4m4qT/t3PakN1yskbPZVOarrJQFFfIzBrVTMhf1QrQ1qwBYuwZiMpD3xEDGHq4LwFyb4gzMzcAQsmSwxcZBpXDGW6SmTETUUkhd7ncho3+gwSfKZFTUnRU+gMOJgOlCCJYSepDXTgu2cxJJcgMcg+8HgKX0V10cBVokGfcaPPPwWPlCd5V2imtGw88t76DH29HXSiMV4+NPGPk4P5LR5xfNOP6TF+nynIM3rmZDswFDd7/Jf3uHGS9t1Oa+qXtzWSc5os/4XGek0wjc8138k+/5e394oRzA==)format("woff2")
    }

    @font-face {
        font-family: Andel;
        font-style: italic;
        font-weight: 400;
        src: url(data:font/woff2;base64,d09GMk9UVE8AAGJAAAwAAAAAusAAAGHuAAEAQQAAAAAAAAAAAAAAAAAAAAAAAAAADYGrdBqBGhv8bhydCAZgAIlIATYCJAOPeAQGBZFGByAb6bk3Qo27dhOP0Dm2muaPCDHAxwO488UCtw0QqyRp/ooIilYms////7SkIkelrUvabQDc+Q+QYhLVWqs+qrP33vvczFiwJhZygJTYsW17bTtrhmYcp9fZLEGPkHCBaQgZQR7BdDRcRu6reluWB9/CcBRotowC5dOd3cRvbthMi7c4P+DrP4axmk5G9oW8HfQEBjmBoqdpDvtfOgl6BD2CHnFcjux/WHkc3bZWBZkcdhjJdiPZNBK2scbO6HVrx5s2ww+nUqg7dAq3/4LpSJAjI4d5M0a/fdAV+EHmHfjuxKlhhq7lsLWWp8kPSYqm/zy/ts59/08FwxA1VA6pPSpgFBZdqyApdmHHKsYGGN0YRYtYoIhRwD8Pdv99a5+6/fqLjjggonEEgzXAz61/S7axjbEqYNQ6iBwIA0eNiFR3lHEgKSDahxVEKUZ+ReSwOD9WxLAH9Ky0D3CafyanX6FhOTtN4dTCgdtDxK+9zh0HeIP8UkAFaL8q6yqFQtb4EAlbllWCYPj//z/gf3Pt8179tJFAAnECWdyILYqigELt3Z/n91v8v3Bv/lt7/v555z+5rnvsGmkFC5AapQURdWTEACxoo6fSBNFGdEQxiiibMACjeh3eOvj7OxwA8KJqeX1YMiwcv+pa0idfae0fJiEJ/yTAgKBl375mWLI4p7QBlE33s5pwZ2jwbwC79+6Xka2RVRWqwgIKx5o1cEpwnEOeQ06Rp5C9e1mgKST7L+1yAfxDaoOdwND21wnhISgCJOA0/v/za/q1c1mf+WJnVhbpMFEnJk1oHaJGhbgRtyoJbaoRpq5QUxJvQlRIxfa57Pv4/2vTX82XmXVt3nlzlxU3NErSYD5C8Jg5klL4UBPffrEdPYdCSKDQTYP4K2p2aQBrTIQmf6nQY0wpOZOWzZjJXvL/QDJ7G1qrqjqLx1iMIQAQoxO0vQpE2B9kAyN2jbL9uJO0pNTK//+11M496QRkgVEHVIl4Z3aT9O+bH+DpL9GG2ykhWARFRCpVrUddq1CY6qq6Gl8h+3/TmgUylCZrEe6ECnShsBjL/T/ldiebvdKzS6l1JpNKL13iBA+H0SiDkackU6q1dvejjkq2GpOyA7nqoKu8MsEr3w9IPmZu5f8ZpDNB/rir+yD5mPkWKpoWSr4kee1PaxO0OoL1eV1hE+0jtw1F0XIdQwUdUOBNT/AAH0Czgc4CDAA/Gw7DAWbZNLE1ep5NHUBWPJzZl+bVfr+Us54FfQt68ZROYSmNh7ebtnvWgbQF+DGBr9y1tdVhDiekYYZlAovEBP/U8n9Zug/MJaSnKB+jcBRC4dQLTZrLe1NFE1Ju8pAdfIUEIRES3M6GqH6h0CvUCodaq1fKjQXAcsXaPfNngEXjRXUYc/VYZsvbDbWBCAoICY47bTmr99vwI/PGYwOwSxNCCCFdrCdWrExFZJAQbJr77f02GuEHNA6tMNc9yWBkV/vP07JW/cFDbWTirvE+17YEXGdSb1j4xb9lfOYvX7e37Fs8OeuPWPX49+iG2rpTdzwNiBs5BuGIKGhZsuNKL0AXvQw0TLQ0OQpMMsUsi62yUYldDjrurCtuuOexCtVea/Er3v8/xKQkbcw8E6dKl2/GBhVWchmNbFTjm1pxqPAx4ydNn7Ur3a68Z72qqS/9GjERMxrqOI37SEcz/uu9oYtc0lI2fHkbvUmbu/URBo890WTTzDTnruzWnq16r/dhLft5jFNwWv8JFTbuCJHjixExaShQYcWJnyqW2AAPFQFiFKjRYcDOVW7ziJfU8ZZm/m1lWw6UY7J0U6BcnX4eVaZCjVbzLbLadXHS5KvUqNNbPrLCBpv915HV4FGOfe4nPMXpz/9OXOZpzn4l1370U53xHHft7tzTq7v3933VvXWMOdfxJ5t+/hMtfbnTzj7nila5lYHDDx5n4unn3sNVr2m/2rEZzSVRXoWWlS5HxdUHBSfMVLiaPr9b7Xgkzdh14jiZbCpGPJ9SDW2GjRIrcaqMOfIXK1uzPZ9r/7zyqKiioXO5JSAiJgkt41RnmDwcMZ7dnpyMxooTHCXwKrztQYW3wVfDkXTC+HN3rDjBXQ8qvJvAq/BuEAPvkW1XOmH8uT9WnGBlWkOimSf1NbURp/tBDLxHtoMx6IEn9TW1EaeHR4f43odI/8NEVzuktrVDoxjwCNta2fZgW4NUdCKI5dC3TgCdwZydGUQn3J3TP8N5X7kDrSlCtfMZXZGaiYTaGIauD/fn2mOgGOE6Vp0w1ntbn/w1uRmD3sQRYITyb7fxuLgd6FaJu9ukaLdx0u0p0T2fqe7pf9Z9IFQsVO47hQk++tLjAT1hez/piYCTBuw0YE5+QV6sqXxobx+CApyFpQDDEeGRNwZqSI0UQdnZ6+rUP5b4RHpGPwbtgyQtXkjNXXy8uTqmH8SKkKRko6r2yX7N1Pf4rVNEjsCBfExGMmZw2x4ttnMbO1gykBCxNKGknvoPtCyDLFfI/xjUFtXGftVVc7fGgVSnJixbU1rW05MD+8Qwd4e0tQbbzJpZ763fF/vR7CCaltATIO239mvpmwHjZnpHlebeCuPKscHwrVe0/Faqrh2aALfQdOXhBBkESF1vVpMp1PrKtAEBa+wJEiJKhDgxwiRkyjFhz5Is2IANAPnDFmyEonhog40ApQKb2gDQBoBMJz1r0lDoOMMRxANLpIJb4AQAAG6QKTgUAAB1elB/CV3lEIcCczbWzmaAI4AoMeIkviwPUx8hhXHsZ7lHbnZQkEkBSu+2Tr+nqxQjJrGIrR1JlYwvzi7EXcTAkQJQwGzLrpl7u3t7O3/kqh1fYouik9jOXe9jMfy3QuwUwVC9iRFL2S4EOatMrXcSt8RkM2LDTiEmrgrplBsIDOdnQ/VWakpgJKwQyEPMoEYQA7Wt3kr8tlGVoWYP0/dQbPpuRVmYDs+thIRSgLwKWGtrsk42cpt0uQKANXoKBxVuC+Clzm0pVEyBzUp59P6VNQRPBQrcFgiUuS0RKCBh3oi1Zl+3byQ2mbCE63KJAz8d6BL6YAht6LL6BAu96FILY+G7vCN3CKqR11vYpnAWGAJIL90meknjGWwp1Kl1TW8quSIDHVGDmGyVqRLGkiyS9dj7vW9Wk48ovxpW7qogVEViqfpi3Op+uvwVzyIhv+qbNMMuVhOi65IkL3vNQsB4PO6FbuIS1b3QZ0L3ZbeqbEvM5FlKn+pePviXj25jLQ13bxFz39woRneFqJfzObCgTjA07qZHR9yK/n4lnBc2IMbgelQk/hLw+XysgbhzA1kv1VykRIYLW74DDs5mGVvwaL5WXFaZryc00Jkz4W4SkNKDABtZzI3RKZYeBMMXnnamaT9iN/QS0Yl6ZiXCfnEQIBsGkyRQSw5CRQOVgokY4M9JhS0hI3CaFUtxg5IZJsYuKOGKtELUfva5mpb1X91J/rbNnZ/jZT5pCi+qgubES1KviV6rZcZDm6SaChbVT0S3V7+vKItreJOOg6Hl1CjkM9t0adOzzaA2w9rEtklqs7TNn23Otrnf5rEQ9YVSuzBER9FT5CqGCl+xXewVleKkxLqAinAZI+Nlulwq62SzvCcfyxfyPbzKt7aaTqrM2fLe8k8PHT56nPjJcnW/l9XXWHMR/Uw0fQrTm7VozTs9Vr6u4Di3/lCGPRO6AHg04fWnP06fXQn+HbD0rLRoDRaMRcfMzs0vq6Jr28FPD4aoa+E/oSe4gCd4gz+EQzRMhrmQDtmwBFbB77AZ9sMhqIGL0AQP4A3qD9RcA5m9xP6t2ipUHVVXNVC5Kk/lrfxVsApVsSpBzVQpap7KUSvUD+oX9YdarTbZDq4LRi/RJ2OO7vQJyD3KDTgni5iwHK1SRg+vi7lx4/qJbwddYXaEGUccLdzptxpNHqtdGDsdi4xHII4ndNI3s/H4b6evJGL5ep3Regq0jbDtTuMYcLgCW8G+BW39YLAllh6oewDjTvgSCvizTcQodpyhw4Wk0roU/wtr7Cwl8iAy5fQAIh44W3j9PGS4CAZmBmeusvfyrTxshbR+Irq8KfGunfLfFnCUXFLGx+lHxFVyywnsF3Tuyad7Zwm4UBc4sOOQXr+jbUhGwKmd9lFR0a/rW0bbxqCM2grJKG6V5SkNLh/NqN3BBHxbtfnqWSa9r+iWFqLZZu8VVH2Ah7T+IqLk/cxrdsKeu0j0lEEw694DsstM+AtETPuF1T78dO9nQlwq9xvMkKwev6MbHOIsYaJ9HZ9g2hTvLUyuzvY5lwi8/efZjjm4akJ2oXpdXf8oF4bJsIWCPh2Ny4nfWg3K5hNkP6aEvPvCU3a06kvIhvOP7XX7bEdLGguPkGOqejjURvAChzqfHJA4gR8MJMSP5/fdPwqqPx5KCliGQOUEJxPXpciNFkePNhAlK+JOHT1+kjNXnhcOepjsEcTsbZccz+wPG6tvKVGata3YSc9Pq+Dt7r7eEiYngFiQN1ceRaerdz1QXpiPDmVb/GNFU2VjS0tra3tbkgZwNRc5ZJQYFhgg2urscfbr26+brjxuiKn0/N0xket14rfzV+6UxK9cjNiUGbkqRQ5I0Mdj6MARpaI/fm1vam6HlSvr6+ecpUgEVXshmy6Jc6fPn7vpfMuv2sPRmbVacujarcMxS162SpWpMocvMtq35vm3T+zkAtBpwr4NxnBQ0IMNDxjg9osLnan7XgQuDTHbgLQTR/5nNEIVsc/yKH+0rX2EWdMgFuUU1vpRUmp/gLLFm8ofkMuCfLgpF1dZa9XLGzispn7HUjvqB6xeBklNqwvl8GIb8dv6iY4JVF7EaVU6S1qOcSbihuyRxMyd5z237M8v1d7m+DtDxfi6IxjS7Xj03USDsDeL48kBo5IeMVKziVGdrhy1M6rq9gYYJaMWF3o82pKPXnaVUMBHo4FA9AwfNFE27mcTK9nDGhgZgupPa/4eu2FsuC1mR8iLpYgtdAcPsahCxkqiBhEQk8BAgvswuvWEzPlik6qGVou7THMRNXPGRffYmVqP4RrOst+D4F+e2XT7GMSuTfAP7OT0E3GhRCnDKXz7tcnB1lftFlHRePfC5fvNFeHDt/t69Tf0Gfx26oG89faBAUfeZBtqCHQdOs5F2a50ReWCxyr2fykFZeuJPlLdUjH/ncTk3KKJGbq4eOzKjbPzxl1gcvBfxMFY6eQJpGwnLye5rTb48a3i6R/f7r5h/NPWLAkzEXrKSyw+AeQ8EXpJBSt8YUIpIugEJqNi9K4y5TB284jyVjFXE4dfXmFnBeGkUkL25QHEvHq15N1R8NrTGPuG8STGofWBD7aEoq3lpcNP4bccvkeNGNN56Lrh040FgYRqHQBK+RAf0ROPZKCksMDP4cMH4RQNG8Q0ou29NgYKi29Kea72RrfqRZTNH9Ro1OYHfRR95OpOaEDDG/Rz4Dv7Z9FNBoOaA8Su94jpMROmjQVXHzc7vxeXMYyYuq4MHrBVFxWYnimjt/dwZgzsuhAezrA/T7S931aE7WK+orXaUDnV7+AJ5cHDWecf11af+GR4WhM60Lf0w/XGk09vNk909RgRssLQNdCtEF4noCIMEziHRSeBipBJwieoWCxqolmC77p/+9U3N52bYu4wPpNbHHtG5iJMZA8TyNy1f04ptoydvMwIk1OHiRvy5WGZ7ETOno5x8X0jfLEea/7uBwuPISJdfU4OX6acHL0LNIFtmU6B01bLEdx55nJguIswNGk8mGEB8J+N+iFJnEgddXL0+Chf5n5J7JKZUbbB6IG6pbotKmMYmrKxYKnzbM9+/3bvLePLy7NcK7vtogQcs1F4o6GvA/PJIJ5SIk51It629S2tQ/DtrNRsmoTwjlTwELL7/dVVYmYQrdZTpmdyEnv03aNz7x7uC+zfadDgTv39zt9zaJs3loARg9qWBYwOFyUXtOf2RNVSfTOpNHEmOR2UG8jtraCMFonyY9k6v6modqKFcz34djFHbCg613MOPb0xof8Ar5Gd+vgdeRxrpPUUIZV3Em/ZSQgsIHACudYNJk2bXV/jgkoKERp3+tMC0loZxHrPFEuQZMitK2KbWgPfEu5zWv3Atg6oDN+2lFaD1hEhnEgNjfQpaypLozlDSMbsFvFbuTMJurpGyXnhBPVI+9wM0MMwY7CaS/5NLkUec0qAc6S41IVJDKKKDEYntY15kflekuxs90y8Fs4c2oVBky5jxX/Rj+EsiV1QzlqElVyNyrYC6qSAsvp9GJwSgZU35D1WNWi1P08q8jZzntM5KAdZ2iK8Z2pFvQnkGv8RnV1Q0dh2rNqbqeXIB7gQgP1yCHaRO7BXicAWeSRZhoPoQKqoDbag38Ur+6K+L1sky2GQVH+UsKpVnnkxhfkP42V08T2ykT5iHT/KL3Aux7TdiNeiijdPzs25JwTB7RFE4S+H7lKtSKxjWVpFFqiP06sPNMh1aFf/hdRUdBXZDsEAy0tOorYUk4BxEXca2Fb9PdYwhB6frnuRD4SxqUINJwhnJWJRoSkdLchpaS0DzdDlbZ1pp37/rz23rZOcfct+wpkzr5GGKkKqfgdbe5wqgDtSlQF9P/yra2o4MLzzvL2ssFSH/r/banchX/gpwB46PX3bAkOJuajEMak+/GtkcoKqpk3yIp+y9QX1QgFvsXCCzSLMRaj6kusPzkaXHD2myBFRty8VBn6jEmZxZqpx7LG9OTkN9aWU7ZI8XYkDpXJF9ULtx2NULh4ylst/gGwfgviuMIOXbWkbqOwxUN6silEUF+Hl17uWiotSaY4vsRSVhNp3ZqUIJXhBTg/filXWcGILRl2MqB4Qe80e9QNPZbAsToGbuRdJD1/sDI5srmrgNHXIOnTN0Yu3qycckaepVGlUy40ZqGwRIILStWRF54uo7SQCDlQoQY/Jp0Bp8mb3XAN2KMlYRpRGUQ+6+c0T3c8101AbrgmlWeATlH5TLBn8k4wtT1GXeEo1UKZ8Q2TMLi5008mbvQHKRpvWEhcsStLvc/qONsQoU9RG2iAjLIpR9kjetJYqHwLJoNJUa/6ztepibLpO8gzoaPcYdyDEgpK/jA8f2sd1LCOS+j4zYhufI2Px0kPy59C3YLtQa3mDXDKZK3Fa/4tajJ+pTidPgxJCXGy+D6HIujyImG8f6B6JUJnZeX5eiR9V6ajKhtfWNdaBanyBhEOlKLYyE77mwT/axLZvGQmMlg96eqib8NVpVDPmOCmzXpUtMiqpokTUDkJmpaSvzxgwQQWdKus+Ban+3C5qIEE9oFTjVCsE0Tz0CCBwgFL0KCgbohg9DvYEFINjoIXoMbAPuyZ2DXCG9djVsauBC+xHjw84EGIZHkJP5Mm6BlqRT0NPRU9fuqNnBHigZ8Fh9GwOHwmxAY6h5w7wRC8AL/RC0KMXHbAQvAPtOOA4+MIJeJUnh/jfRXDGxeCXm8A/UNnX16PXQTv0BjiL3nhAe/TWAzrAOfRO5vmheOZ7EZ2dd6P3QcdApw/oHHAJfZi8jD4CXctH4Qr6GATD1c2Pw7WhK+FmWAo9o2vhNvmZ0Bv+KZ8LfeAO+gLeje5xv3w59I3KD/3xm2HAgWXwAH0byqPn8Ah99zAQ/TCEoB+HQfjTw/IyOGo4PIah8GT5W3g69CGsgBewEobdJRCqTUN4/zO8RH8ZVkGEz78fIqFC/l0qh359ICoGdmJCDbYBarFtQBy2xYE6bLsIRj+AVXJmhx2KHYIdjh2GHbkBuwV2memxgH2x0zktz9yAO2Hnc15euB1Igw1sLtvQxQcVKEirgPHASMaOiRRSNGSeuQR4UEM3kIR4SAQDdAcl5MF8COT10mF0GAFjAR8xWYwjGy6HY1f4RAp/KcBeWzIgFdJBDjv5l78v8fu1wBZssGuHjZTrwhpIgh70632DECZgN/8Z9iDKUZAJ/7PDdbCVBLaYjz1sFOjDf/yXmTkDJoU5TGEe05nFj0KmhmAwd/VZQ6qx5yFe9Rf4t+b52Iuwl4QswV72HVLEQJRUNExYceavm75CJZpsvf1qMxRYSBGNbmoLAoOiBMdJlqlIz6qrqR8TMN1oxnciFr305W/xUvu0b8eWUvQXUwjQEIycPJyUUAkEFipslDgpp0quvKjWIGWq7BKWq1yTXh/40jcO5QNsmsgWh0Wj+AC/SfrJUDlRzpSzZbZcLnfK/bJMVsgGyXaDd6NTd6d+Tu5Oo5wiezPlZjmlOy11OuhU7nTO6b7TM6dr4di/uK0Y9BWpHIZezI/zK9MYFDV20kwtGFQdSK/1gsz+bLkgwqI+S8xprfiflh8ausMQSIL5sBB+hC3wDxyBKqiDa+qLWKbqogYqT/W1ilGT1Ur1h/pLrVc71EFVp66q6+qxsh7PSLQ7vhjohRINFjrBwkGOERdPdDdYiQqNRjVo87xNPvWDn/cfWMLGr2pzU2+vtlnnVkBdC0pcTjVtxY2fpu3rivqLPNnRhU1harIRQpiJJp9m/hdqlNHr6O4odcyspc4Wt7abxZVZde0NNtntu47n4v2u4uZPeLI7GNj4NMb4JlAJLAKHoCf4Euq2OfQIo449wRTTzz7fosuuus52drJfORolejGCISpmsYIdnGAAQhGLVGShEBMwA8VYjvUowf/Yj+M4jwVsYB8KQRj8lUmh7MibZEuBjJKpslS2SqlcKTnlYYkphWVrOVx+dN3dbHffTepqtEAzdJYu0GW6VnfqLj2gx/WkXtVDDarWX4bNBmzc0hZtw/btwoZYqIVZsQ2X6IOdq+1d7Cn2Evtj++t22K5/u6HtFrf7rt2v7XLb7Wp3td2jdhbrBmyHGXjM8X8dAxxjHZmOdY6HBhrdDE8j0sgwvjMKjINGk2Gv8mxP/uTjvcRPeqXrGIqxOIy7yIvFsS0OxZXYi1BYVjzDR47iWh7mDbp4WvMaNepS/ahp9VM/1/819/bbHrWjlszJnM6f3JmV6U/Kk4zkj3yU/ARxPVxxvT3JngxPZ0++p8RT4anxDHKSnIKaCcutSIVFGyB4FExcQjJaRjZufhFJeRUNQwdsfn7voJf4j+dl4TmN/flg5yVh7/7LyVzW+T/2zalssPFzSCNoMKt8XzaSMerbYcc6A8mriBPGKQeuth4b03/tBPKIhkGcvlQmnsM/PrNga1vJ0jq1jMMNDnKKjI6JGh+0BA3Plr/HM08/31drMYYemVBtkPiGYti5ZcsOg/yq8NG6AzahlVOF1KmNTuPfld/jngHTkR5VtqfQ6nbW+sh8EkiEXKEON5FPEjPGdYXWHD5UWoRHskeO5McfRm/54Ro176eqI/9qbsAPPbmz/Oxt56d+F5mdyV0FQMccecL+LOG+nVExbofhSWv1SdGkUK8RUR0NnuGOU5WwXditpdQsFO2eHBg/1nNYaHtD7zdn++QGsL/Fcwl87ba9JSIXfExohi3AgbAnFQHzjSjPvlhYeuHX6k37t7QdFMRc7AzxHEF0Kb7+w7uJUuY3gOdk8eZZGAvPW5xygc82846Ja3Hw5vqHNVvyYS+3O42IbLAtWaMMLY650Dp8Q1fYcF1YEQWg48zVnYECmIBg6UtO+lOG4LPqh4BKCXa18J2OuhnK+i+N/C2cWZ8D0iaKStMHd2fshNhmURt/UqNQ+xz58o6soymh6+8gX9fDRSqFXnyI+v23v+NcXXg2p7dK0kKE0j3mVGd4bt2YPo2MJFns2vB+emncrlNosJPa4vEGunkcRvNNmQuBfFgsd3eWDh4iOnn3beFdCvPk8+2Y2ssP5zsg7fwBMmuYOCsZGrYfhIhVPYLadph4fbOwHjFJtxH2OMxmrMgA9refWguU7vPvkR8rc9DCv/NlaxRMzYXGVtfNB1FTLwFeEg0v9nSQZxmKqhDtwTvMcDSsGSAYMjREXuufyIY4vtjbeibY5+3wwZeRQ8OHEG/gkM+ssT+YwiGNFLRRRkZHjA/QqUmjp2wMxreOLcbOC4/8su0WMI/OZFijJ5MZHAK9Cr8+zbJEm2oDQ9/5cjlohsq3rHsb7WzkGbTg0XyrFseJmbAGLrMixGKTH1/0gShaYGglj0/X1rFHv0patQuD+FDNydl+H/dm83NZA5oaLRYblJ0sRNiuAG5LItkHJILhINAFM5AUPsiJZGSi00S3uwB3gm3oWj70bb0xW+8zc2Ftq69fDelYXNGR7+STU8iO4eEtsFouCBJ+OdNmxNrnp/6+JsfIdBWL121bttN+v+EMQbcbTWQ7Y1IJzxZsQkJF61gNC7Ryn1wDKNCblkB3NydswlmwjOvMClvndFeOqGDnQXuWtqdexmS8w9IXkWvNEvYbWMeWVAF+vV+mHRkm+yL88n3sXM7QNoT07Xb4HA8zOjG0NPyTLU2mVtSmNtmpHCFNdwtyPPlyTJXx1nat8PdOWlmyYG6xYfFDqMw8mF15xpn0cAYXhswg65SGRa/Z9o1h8s0ohZPXhQY7j0rWkUM+DZknQ4WMwQSqN/v8b6wrhbmdFgZwDn1BIhWWpFntfs3pvkTXKiuavrUpgqACA9HJclkOKRddSJYUXoB3ZBVtEEoqBV7Aaf2C+oT0X+KvtMIe6BaCvAe7Z5IUi4LVOz4HqoWmQHNbYvtD+mIash5g4uEiTT7NSPp+5srpWVle/5lXWPj79keXPd4xXtr154adxglMn5a4LMXuHVK+fpjBC3Bbv0J2rf/BVitTr2vxsGUtQK8zK/Oh2Qpzu1qAXKBwjpg1IxVzQmBtiN/3JBbjzStLwFJFZkP2R256N7fxEG/CfXJfOB7aNO3K4raRHiXlFy4RRH3w9R1CZhwGx3DQ8WZdZxjNEZiKhwHjo4HaEI0RlBu/K//CTA9BNU5HtChTeA9iuFI6yOxR4iP8Vr5+2XihgXodgQ8gg0swqxrvckG5YAEMegH0PWRaZJfn3h+L5+yYud7Yd/4v1Heo7gvwpBBzPtiuw9Na+OFbQ8mJf0h2nzD9t1nAT8IXVNWkvGJ91IY4lH9Lc9AfbMxLt2aEbsSh519G/o5/7z9eRGsiZuMbCV4X/vM5UIH94Sa9Hll4aSC5LXWMnTh5YugSPFq+/1qJQaTi6+8GwT9r6qoNkfrDdOONwO9Cu6WszhjkWaGsFhbT5Bkbw226MJ2om+Ed3AKXQ2+pzRjf9oc+fR0qyYdRrXfdsrmdob51MGw3c2Bhq8WnSLoTqlqDZk9gPzOF3MdBqjAovSVZ+DiAAiCAOzqMUfhyVF5IzsNX/IGfRK9qIXjzXbjKbMqHg9zu0Cs7A4UywWDpU076a4ZAtBk7pbyaBeBv5OXNg+E3c1k+WBFsB2wLIxf4YTNQ7PcQcBfBVLLZapyaayY2H2P4pROn241sJDDDZ1RONjzkA6CUTubgas4qNak78Sqb49TlI5/DEB7zEb8vT7jItN6iD9ajT1RY9Jhq+FL5r++6YbIpsCnNw+DSyDqDgm/IxX927PzHeMIfwn/+JxuRNByqCX4408TuheEB0yImG430tlFTjVyT+a+E7/Zzkx4cxr4PGJH0uQr3XxD0QuUJYJ3VWGIf3ITWzYb7TJtFjo8ECxoQ01Hnxr29kAfseMSFEAuvEDi7fyn4Y/vatomgyZyQ7MLVKAdvfqK5KjOFMrsPLgMejeT1cYJp8CB9uXfteXYbGN3c46+rl/35SMjxJ+4nR/3XpK9NW53WNm/W5NWxdhYTdxDZ6U85nKAFGgT4AjT4UnydweZQon1Gnnvx8X4FIS7VB/Ro79Y7QUK9DAhMyzNoJUTe9XHWDQlD05vIlL9XndqbykbptwMH4cOsh88eqDlmpA0S1yVh7ZI8aETLEq7XR09zNw7XXFOKfNxuRTtN+paWbgT3wAYdHQlD3GxjwHCF7lXPsWLEKMAGZgPpghMu052D93jSOfT94QSZTM22My/iQasqvX9+6yxuTRxq7j2MIbB188+/bHLExMWFhjpPKEg8mb/1l9WbHWvPiUWZ6cvT7SnpawrP3jhXWxWHmpcbzxvUFyi6GDnmOdBpZocx6mBajnPhjN5BwH3Ko87QaHuoV9A4dFaUo6OGk48xQ6Z+MBbWwWATbR2T1it7oS18yB7SCpEOIJPcTeyvtrEeScaGS0MgmB77K93xqRU0CX9FS/Hsl9nQcXybnc6Z4e40rzvXbq4HDgk3raFbfbUOkgXIueGurkS3xu+4aEtx6mfguJZhkwGDucuA6VGl2DAJqCXuDxYk4moOJLQm3IsM/XQGXFsjqaXJ95l6DWdEgsHGKE6HR4WN/334H6aX7kFR2C2YYn0gisrBvw/5WPQnakdOHos3NoyiSBVg1EzgpdEZzYWsoSIL9DL82hR/DLtrQ2czoxz5CNtLqb0QWurldhAVxD9t/+FCeSpZiv1oQ7r8RLkDfgabpLKmH/I/0T3dBBCHILmv5m55dovGawMf3AE3+WefdIuI2Zau5+jfrBRfvlo3Kn3w29Fb+WYRXjMRV0/k3hOa1nvzXvAJmOYba9SnjftnuD0gZFZwnJF7fQ2epEF5mNdQc9VefXDG6Jzvs5oPC4/y6qoLNYdnjALZsqdpt/yS/1NervOHwE/6OXSwibGOxrgJh+cjq1nnHbwyEsLcnFqAChaFW7UhmKDx9dh87oH9SvH47qmGD78R/5zExBh7eupvN0Falhdn7ZZlBfaHtWc/bR0Lvgo4z/peY2R1n8AZARIu3+k07yM6mG5vxBMcQF9Ag0s6Q7A5MBuYFl64LLWNwMmtDRChJRu8OULDIAyNKVZ4SwRbl4vsFCnMtnAZBBEf7BwDvN6cDs3bBrtbE+vA1+aYdau7tyicEpEbYk+HyLUTt0wz3IYennCzWcwoLss4bU+D0pzDc/8xDqbDOwbb9u1bnL7d4GGulcVbVhYUOH+88YvNZSZYEJ367R95yQYNY638Ne+XWbOcO3p2ZbjqJkvdvbHJ+lkn3Q+TTMxe8A5ICJts5N4QHpLFUX4RXqA74rfjXPy9w9irUgUjd9wDVSTJJGN7/gmhExRl9i+lyaxKLMIGuip/Oo3eVht//zAOxj+rhxWufSLq7hHkzMvqWJBsLjKmNsz2PzQoAO5VU1/Hodp91UcNP54qQhL7fHGXvDj41ccFoHktvucnuJXta4DXWuNIYFazVbBA61qGjuSQp09NQg6x2NnAE2Grh2sxvFWckwdaWLu3a7lvCRizsSihck7VsrbVu8TuMnF/9cWam8410w4NL3SMRB1FA7KfupI3fTEEhnDiRyNnmdG0nyNHzSf2Mi2+3DU7t57uOBXKuQyRHjJjlHgDX+g/ECo3MUW43AuCzW4zQYSinA4f1vp1OrEeul4G8CgZGoEUVczkLULTP51l3whun9Nrd3B9Wttwl6uyrmM//bN+0/q2X/cuvkFLJDXeaqkNQdT7fUcIMrtnA1PDepelphE4pVUNSReVDYesWfo9dEIdRHNzkdnhKbTtuQyCMQ8uGgO8zmSpahvsaUWjiBEFIfg9gIFv/Z9lO76eODnutkjmSMm+5uPGi7y6i1vI7ms6XM1NMqS23gPR1q9xMW3ujc3Wzsxsj7knbK6mSFzk+59L5YWki1Z/BDQF2+SPrrgOHcpH11aBW3EmGyqt6QpBDs6zthXN34mHrGUT8TDnliPPZCQhiJS+ktxZzw1cKQR2lIJ4YBhflhXL0I5laDs23AxBVl0sxpiP3a0BB/0tyX6rCpTSwRz8xuIUm6iduN3C0SwCYNOnbrqMlI8Whu22aNNI+JkNOgMsjqtHTdB9+2HkCkKmYmegN1hFfMCJ0pF1D+CDlrpz2AX8kdf2RVq7BM9lbzPrbmwzM3U97nkOSOBGuPHddPdCcvfdgct9/Z4c7v/TTs8Hp2d7jPxNowMtTRE+MDVCnS6Yd4tP1t8jH9t37Pjtr43G+itiUdrcZen2mD/27/zNOE17hUBufaNoRZzGDYih7VMgxrSm0FNyJpFzelEiEISETcIml+EhzJ5s7nXBPk7HmMipEEP+Kczw2I08j1EL/cQ/koBvQ9wG+QQwuLnP4bqInuy7gs/enn5fSgBcBbEuB95gYKdBdYjddlMw4Dd+AbzJ0fdvEvTz3Xhp29hEDD0dQfdPQacXIeYKmCkDMMbE3Y2JNDgFeAQwu6VpvSkYMBLDG7mbjF5S96F3U8GVeJLk5pltYD38DP7kvzKvg8c6Y/+EIcCiTzAx88DzwGFoN7CAXeRbgLwTx8FsAjz0LjW2A27AloI+wP04hsY2wB0IA6YV8tkiMk5EXoqmt9ujjx+NxVl0HOPSsfENvcg/wUnjmClunYAIGI9MnC/DAeNDet/qR5FpVJrGbcSQ6cPI25u3mKs99+HmzeYtBrGZt5qLN+eH7MYaoB5vGs+sw9jrE421RjJcvdXQ+ShD7w8ZNDtoaPwhY9wHGHQ/1/hlf+qTflzCCmHzs6CpeRy2ZD3WG6hxSxPJagp0XSpJnZai4wDwNtcPDa46gSvwtHUAgdtxzgDdrT3SvTEVdP2AHvrpgbopsv2RIN0BcLNy1hAYa/qwAPj8QNtjEPTCILEOzHtUMlvsXZVj4VewWL9NN++Iw3i6T7pFh4/N0nz0QuPgrBMSxNlV6Y60OT7gJ6otxCfAsohG9tNFYJmZ9CwUFRTsdYxgnY6VbB+s8lhqNthKW66Er9vElFvGpqZNcaT1E4WlpzbX29+PD/DpOziKsckpMoM9pF5uuijI7RFCHCVaBr8LtLgRhQ7uGExpqzgLRkdrpXYKq2h8cq+UsMlimUse4ivnjxTstpQRHTncNPC/+oGypyZ/Y7Fj42MxIypknq9d8+8z2NwH2IRVEOrjm5c+fumwr18/1xEdOtwa8TiGWTOxzhqVcfUrQggG2GfMP7hnOLlA8cjS6yyfdpDEnXLnsIL0M1NGC+1WCZQZrPvAioloHZH2K+SUwpYI26XdG8Sy715IlzXsDvTmeT/gixLCeH4XSAYsdKPgiI7yGc0Tgrtg4jz1bJkjUiCahZSwVl/KFlxlsfSUmtWnWpqUyqqK5ZbkcshUNM/jmW9WDmAw4VzA5gymvMqQDwc6bsnoB98SFNQMagIa8xGI4EzN54roTYgCEAw4FqA5gyijCDLkgcNVlgzcy1BSM7iJaM5nIHElcn+NV2ZNOpyeBFU/XNDbMw5l4hiLM/gKIxqTGvpzI+whVVFtWmne+JKq/LPX3mi/Xu1fPBJ6Yt+3paJiAHe8vzKdvWrEoNtDU6zJRiKrJWhBplKG6vHkHuWFIYbMsNmXSqxnJ95mUPWJs8orvFCPf+UGemLofD67Ki1CT9VC/zHFJe+S0FStotA+t1rvtGnsCTR1bk9PCSF/8Ybp8vOIQD9UESslUkQtZ9bcPHrPzn3168SLN+LhdDt9Q7Kllm9HDnBk9DeEAty6BsHLnX9gLD9PXSfHF4ZqF/YNwfGzRwtC0f98RfO+BZeV/x2YEJOP3NiJTWq6HUDLLbDQdZim8BADAQs8EuCvwDkXCLMNyRT384aDa8f1T3hIIomQVB/ffnyg1CcjWYuJYyncvkEQ3gR0peVWsBRc3q5c5P/vMfoj8NSvo97I2aCbqQSJz67ary3BLqVdaLsdi2ATeu0i/2vUwpg2WiS1iP/ULmaaX6oecgYLhLkLGUbJSzhSGQz6yutJsiORlXJdFhJfDhc/aKEWsjFps3XQ2LVE//jRZtr2yLDaeEcA0+WhPPZaLM+fqB9Hm/JbO8bheLdjVWOIIXWHzr2/7XxnYpPfYaaWmDJAju8ifkvztnhQ6vyGGh/EvP2X8hwzxX+iat8W5+tfPm5qfPKk0adfX+/v6n1VDp1olvgz6i7nMFKIXdPDn0EZw47H3E10POIJzWUjdFsY3fkSUrsdin48o35B29mMkxtyCyEF7E0fbgHdNLetJOH2S0+vx464zmx6k/2uJCjqX6I9zeByYPc6HZk22AgvJI/LZbNq2QbulwhZjxcki7c87Ecu1Y8f7Z1NQO4DkTghu0SDhnodIewCgyLd7kbBFe6ngvZQV/AXanO7Lwte5h4Uv2h4ZS+rSA+7DBsfiEPxJyeOIz3W7C6HgX4hKcpw4+bhDyrkuPkjCGI7pgZAxInxugw0JXliwg9ZniJpd6wigu5dPkf4dwxiGV7I3RVeEixwe1+JJ7vPJW7bD2z3eEdgw1WRm26dyEQ63lwTP4E86U5Qo1C5290kuM7lv4WdyY09vGk/WyzwM/Uz4a6Z2WPpqFO/IOZONOYwpipS4U0QxA3hRmGoK/AUOs88m8Jcy6OE4agMkkRgIrGfQuKU7jLcBKc58qHpbgZzD0IhcYXS3PomP3StYHoIl/F21IUr1zE9scbU42QVLxnDXcyFLns4QY+J4b/kqjxOHcp36y4TBRdxaSFuFA7Yv8oplJEKWb/oJIkiWih6KySZDClolH1akiJDjHiIIlwKTdhQR6StLF2ISUZ2H4gxX5rvQjSTDxEt/but6QlzAAEjXSWDeAT8//MkrXdMppuw3msg/Zp7EUOEM8WYuxyR4Sakduw9ij0i+iqd4JbJehV2daZ9dAdYQtrxeybuVWDHcHV5BmaQZ+qwk9zVvKMQQdfIIXgtotlGHA3xnDKaIeeRqVbT18VxES51mvaI1c7XN83YF7A9mKkp7CJZXgZXJeHA+4J50iD1x+m9tkP5CQ7lVEY4kpwTFCEGNe7DQMsG7xenqwsuxCBu5zXukZ1AF59+fHZrU09jBh/U0CnnbpyrqTlbtU+VeTwtSwz8v3ULxk29cLO2uvxMVbE2/ag8Wwyau8562gIWWFxKNC+1o6sI0jzj0rz52gB6VF3y30YggsfL+TWxqbNoc3511RCsv7NNkmFvd6Ah/tFL0wxNM/1p4+rZJHlAM47FDKGeiVkFfe71dbBCORNY4tZdEj0JmP6izpmkoIMBb7gC0ZjdSW/yFQsaDJu3aUt6AJXtfHqw/3TcMujS76ZvSaGVvxlaSh37LIfaVju1rI6+2suiSfsi1+pdSTP8MzEJjmdEz2SXm1SpFuuY00kkTJ2DI6Tgbx4OsuI+ttn3DFiBjg4ZYmsNC/FSzMhnQP9KaYTrAhOHFfC74HyCb7dU8kKanUyy95J6qklIYS9JHeEZt9XXVdZRsWTDdH2XEbGAOBKFT0H5jQcWlMCDDNXJhBvhd5suFyBLB4448+jt09PvHv8wZkDnr1w6G3qCKUGVdpnvfXKz3e2bU2+2JE/SNvGQLIny5bo8SQOSsOWc54b95Jntj0oqiEu5koEeUpvrUGz+fUE8aH9hKCpBZkB8CvDXfeQiyA32okv2QCMll7JY+jhRJrLEqj1g1u6HKPOwpWhCkeAJ5+dLBzZYDil8FGk6SK7jA2X1Qj81HcqRssrAGuxhDr1GHFTDXi0kHowjCg48sKHO9xYWFf1IJ24j5XnRnd9IVtvdqn2JzO+0ZqU3fAMduM33Rz7xSsItrKvnA+uYI8oJyBd7i8Ec2i91FBnNR+m/41cvSb+EhO/5RJnv93TAxOlZJvQL+pVK9JGcGlYinSiVaXevChIQJ6ZPCNtvLg1NTr8wOSkkC2PFagpL95th5hMMyH8qKRVpUubEqUilFG1xwFq1fByFdo8AL2oUd6TqFsT6Tba0x3sn0pKVwkctHwvrYS21JuQKY5ntSgVp71RhklKoYPACvOi9lJamcIy/oH3O0qdQEmnqNyd8IK22TtCJtKlFQhPORPZe38EZMHnXJnMTUIgIDyLtE/SfwXn/W7ivyGr6143AL+AFeMEsNQ/aiLKti6tp/n6SE2n77LXztdUQD2LtwdfcDDgJlmoee8s+N6bWmZpA6tT6RTNjkSkpEzqLrtmEcjd7SiLIBE0m9j5geqeRibEl5UKHkdS8lDZttJBBSanbmeVbrKFXVqMUywixarqbNe9hmDkLWLUCkPyISPQlZNFP/EdN7+6WdxqzPPVjCDMXlaNll8KnaCL5omsoFGOvgFlzQMZBhZr3x2iiTInU0058RsFRIKOjnIoenJtk0iGipNFqYoDh6kwO/QwJb70+4yhyqGM/SNkkUw4RKY1yK15STiYZPwXaac7zqYBQezWiXQyrk0TpxqQ0zm3Ug3PcacxdsiJg5Oc0ekm5SSJ1Y0oaE0NWBaFISS+Ww1gPQ3ThwmHzQj6M0feuogKPqnsHgbrBqscR3Tztjgn2gX35VWY3QiGA8Eyg/8Z/Cxe6WBcQ1arBKvOo7Q+uBmmp7m1ViuhINTcT7gOrljwaBZmgV4wJpJD7+RH/X4+Vckn9+Mj/b6vCLfylKEX/BV7BMvaLpvdW6hVd8cKiqxNSW5CH/vf/yTc7EKKMh78Q6IUXpwjIeEOrOzG89TAGBudPKoxzMHJ8H08GZzD0Sghhvr+Sd+qK4//En/AV7+FtCAX6H1sAFj6BI3riREroKO9JrnON777PzhcpRcsKC5zPVe6tcvyffMaHk+oeUlTf3Fxyf4dBrkyWCcGhOePt+iY9Fb4PmtDOjGlbPe5xd7LYMTzYixTm3wjlOA6L3uzNV1KlRvQ0E1YO7NBM3gUyKG+9IcCD+/xxoh3OXuWhNyc7XsSIk0l7HTl0cLhh6+CBh5rHO9L7i1GVL5Lu2ol25QLB38+ICrNwPf/+S1BzdjW0ynOfY8AhMXKPPXiZrjoaevP0+VT3MkfeE1Eb2nV3P/smi6qlc6M6Je3VL9a9yDFiNxGxxXLuMn3tVsmXbxyaMu3vJQsoHVooVnYqNzbTPykd5UyjH+CwjOSpNuxFJqjwgRcM2gsGMEhdvuZNOmkKkyQzq+78NmtMgpjRqJe/UlpFb2J8UZ4bjsF1p+nTFawY9RvV8OTJhYbHdaUmYQ50nInGbSXqX5/oEXKN95NjqDU6M4U/wPXU5L42DMp6QKDMwdkHBOBfzwxkEMFZgxiUjK61vSz7+XQPcUKOfgt74+/JcIwunXI6jenCm91BqtUauSffz3Menw3GSr2RCpdgUQTxWobxKqmRlbTKm/3f5YJcWa5zqVwGSX+elGpZRi07Ui1SKYmAhsGpBqmStTQp/aSmGrfLgUFN+jJoJhhMZPwFTBQ853OnXpeUXZkjHnI/96vta/LAVI09zq7KmeTum3JaUwcY040iItvXHYkFFuMEBpWI+54TBMiM21HHdw7xDV6e5gjnNa1j09ffO1rDEwyeVXYwCa2+fXt79zTk3hZZyXyVE/mnXXu+BlafEedoQs+sCc/E0Z7NXvUe/779YozkmvimdVA+Zovlcrkuj1H5fqynCzuwL194FQDr2wG8OCnKIFl92/etG/6SQBVPPj7r0dTdsALDm05AOzikUTHRe0lgvPsxUK94CJ91NzWZND5Yud/ZFXlbLneoe+3HrUtA16SC5odjfmSFtusZ1N8eQrbzjg8ALxyBmqX3+NotvR1t1bYbEd4yV8vxCjo0V3XuBIxfiXxqNfBVpCuNH0Aed5JKiGhzrEzIX0PLDb0c0Nq69O4WA2uRYbxZtoax0SDDcDVcy/0P050Hs0V2AWNFLN3F5WhhxzAX1uSBTm15/25CN+xF/bYOz97/4oQAfprApX8cAT2y5T5lmQW6y0/jpeQxncI3UC9/KOlcmjs3gQ6YgnpyN2Gg25s31pPc5Ltl7K9BL1xt1m+h+MKdayWvKfxjtZMj3+X/84cv1GW4uc76+xdf3Pz5i//ewtdDRY88zcy34a2TKClKXRh+Pv0qP/yOUaeymxmhTO/7M/vhjXpmLHQxS93cbQ4z2oQrbrFfqRiFDgcVM0gjc3BwoIXDP0BYpgoQOiwEKDCS4g1fnoCOLuuh0BinlltdocGIb21xyB52nTQQfcQQ4S1Gi/EiTkwRKWK3eCAeC4JF8Jj7t7RJh+wme8v+coQcLQNlnEyR82W2XCyXy82yQBbLSnleNshm4Kgpm8nchhFPR5d3oSmzxOattOrWA8PGTJQ8dfrM2bvSzR7W1Pf++25ve56TxhFYHmDMlzAq1h45Ztzno0fZC1asVrvdjrX8j6RBu166fufls9JqdIX+Feat2EBEQSeiZmDhFVdU1bSu7LB52uyAukbo9LgtDXkmnMhEzG3Y8G8l6WM4Tht8HbUfpg8WNzLQRXJbD9Z82DphCA/L96A1ZW4B7+8tnqiA+ECiXG7fT+RuGxyepHfMG+cZbQvDMDB+ah4AtomcLfNipcUyxDwCFcR7+5HQ4IHAKy/jfG4Zm97A9vj2KOhu5zkMYTgrGAUWyUi48GBn/JVxiR4L/+e+8RTqKeDf7kOqF3ryDMlP3HEYoWkX02GGtcc0id4CyfjjM8lG3PGGrbPnYRAMiznyaX3LcNsIlNPSQjLyLq6Y1+Dx0crWHb1gIxjKdjKuYmDcpGKvnckaSWwvOjuSQMd3OKwajZClAxYRtcifoO4DwCb3vFE0lNcfeuusbZs/we6Q89oLpjqKwirxljyTKxZLCcp4JES6Tm58Jkrk6hqhxyY59I4h12wlDGCRmshLcjXnund4hi5KDukY9QOy+k8ZlAj403Y9jK8yD0zdLlQ2AnW5yU6Z3F6Ia6hXiO6Ixt7tJLugX0iy9fkzwmVYiZRpNW0RMrgnJ7KPb/P2TUFPaKsO8j/18uP1qwS/cDawd0ev7gxPakHU9Cr/d4ySfcPDU/A1qK9gauz26R525tR4b6sLDVjwgNfFh3EjLz/FuqB+Bf3t2tZX9uw8FJS64SY02qUHOj3y8KvZdfZ3j79+3OEIQFrZ+mEpGgdAd0NTMhbUOrRiNpNTQ6nzN58dAb4cnnQ3n4i7fPQL+VjSZbtfZt3fTpqM5dBXah0FT5PzWHa1D692RbVrayc55w88dw5Lhb+DdZVXo/ClVEoOZSJuTdyf0SV7GHc7uxFN0OfhzcYvZ21Tk0LPrxYlceXFc/bju6eyYydD5z0S82bm+RWov9+Z5wScfEHwr4/zxiCotXDuwC4MmHIZqyQsbH54Pa6l6XJg34b2LnSxK/Nud1S2YCDsRFActYfS5xFG1tHuY/QkPq+kh/DQDE7RTvl1c8v4GP3G/g7sUgjv6hKqL+hBcA1nOFQIbERlZxFxpFJJeqzl2FOzO8ynVoa0BlU/Cq8qpopIkimhy9WB5BzbcEvibUNfoEaRiTPfc0G5o7Z5YGo3ZVuB5VZtDUwHZv80gJixdKyi9Xvwjn1HflVVP+TeFb9l+FqKkOIiZoJQBvckY5CAOSgSNaGULNw2HQ7nT9spW6aHMJXO6g87C3YIs+9DbPbbzm1fhC6B+vNP7eeK2SNljb4jpP9z9AIdA7oviNaoiIP82pHHE0egZSH8VPrylXthCHMjuD3JCm41UTMTm3WamdXQUAp//dnb09udXAhTNcY7DqaHtB/YnmFk3TK5v4nRfqCGBHso4djsFTMzJ9zGQcNrXhL0fOPbl1+NGdTVaxCDk7qlWk2Bt2kTVFt1uyoJLssdh2rx1QFWnTzsqPxyLBjBDiXQ5KgdFgQk+JN8SQKVliSvikCq5l294Ey9g5tPvSSJgqwXsHIC1acb/gZvOWuRz6E9ueusi901POhIOTTJ3avHp+NPrgfezA/gVtEd8eOfzT3dtMpGsXtS9oMMGdVAWRWFygLz7UvYFBQjjzoTjHePkQpi+Za+D9X5muoz1fvzssWZaSJqkY2yYYfOVWbtTW9+VGcOoVzKXBrPuRIq+ccNm0/otSQZwv10DUAO1kSgZyPsxuUUJTU1K2ErXt4mSMY73QEmtPaaNkHOpHUXpy48KP5sv31QmblzoHf/4QYP0tpKAtKvkp86rdlga0BHIrCKeNIpTeo7yThEqhZXPsGnp7c09VSJ1falX6cfzgyM1AwjibGCqKfI7Ri9UroIyi1ClZM3UxZFN06ffJgHhLU7haRaCPpYBrpJxbUG3QseQRNkdtj4VISDmrTZGQpOTQeDrmmOdTs5vSPWnINIxPiPYN4dxe29mkVNMlvNRQd7MYVYrYEiOWXneRFQNpLviaJIh2N0ITF47KjMA5XwvnB+PG37C1STtHGK7fYUvZTiW43r4LcCYrRcPpuYvKSYM6GEBcFEN/y27XjYLGJ4djz9s11FgPZ39XmBsmLsKPl+gRsnHS9zvrYQiBXftorEswOzYyA2AW1DgdwnVlbxHbtCVMuofodPbaoAlTG7vDCfTtjBJiKB2fhs0ZSjm1E9JLtTvB1evLMX3XxvyhUMZRiLY6bmHeSHTr2xZtc1u6ICx2V8vzeh1l8WyqNmoIpc5GBVaO687uFCUGnGi83c4gxTG64LdUwn/eQHqMRFqZ79clNZAl5ONVD2YFf5E7RS1ifYS3IxS1pK7ipmsTxvZ3+CqsDelQcqviIiC0uJO7nxq/wd+dLZhq1xTI0AefQ1qloANR1cEO4Pew83sccW1QprjtNpbC5x+zhR48lLZZKKE1v3u9A6HeoqZ04sIgZeS/WwG9+ktDS1n0SULplQzf3IYNKjLy08lGbR23ZTKHFaZfA8vNk0oxejZGjxVhcvOF2C4Jqao4j2yzOiSTUS1ey9T2fdsZPo9zswvw5PzIhdGG98xZii057UWrK8s7gqlRvNfgehiPzkgVx/RWhp+zcq+QoFxPwHtHfp9sghHbpH/ShFbVUhWYvrpx8POUgV5ARY+7ssSKrIiBduBegZdENogFGxD5TTPS0piUq2ooVdJu5zaiJ7isJiPUSpu3A8p4ripo3EKPPl2k62k37qTQqqUyrcjrnQqVdmBUwmnjeZA1yUslFPMeYep9WMK8ZWnNPJqj6JEvKdYqYo9x0pxEeO4ZZXhaCtQ5WtRpK9WaWfVGnIYOYGTRO39UyI/SelGjI6uAirRTdp0x6aU/6v6vEkWE/HpKlUPjnyDSkrTakgEYXDStiYmLtTekUq+RUec3exXBrlOeq2CnvckOcNqsGCAHIfUcYMT4qO+EpEzRFx1v5fYtJRmERKllS5kq9ARhkr482TYitlta2yzUE5rFyeqJZaTfJJ81RL/AUJSAzWjW55nfKI/t+j6nG1TAgOAaSuTi52+a8h4VDe6fcir9LhAWhrwwV9RKsd8SW/9bZD4GVB4XYIuSx01Y6+2ncu068xJIT51x0yqDvp+gE277895kGwsdJ3h8iYbMrImSpHwUx5SuYqoGKhQmqWKmLESsU0rK+WMGZD90duYS4Oz6Kcdtltj1So1+hrbL0zFGaTkJIpHRfeOuiuzzL4z+wckRJlyjXGFHMstrqa/j+bAQxAS9NhuK5p8ATd9wspWfLgr4tgjBjHILRw+hHBlt2OO36aRtVS18MD6OBXovuhlwLCjqc9d9YH0Znnmf/G5Fhe6/1813rszOMAHgJ+UaxERgafYkUwbE/UBwcbgv1FI2wJWSE4rkjw3Xv9a+D4W4HVwAtjch83rcz93UF+6XEJV75czWOYJSPEY+Mta+OEYQv9EXA6gMAEw0hxak0+d5dY0oxDBRzjMOqk0ZGU6Jvoj09z8Hp/CdDAB5ZH3zZ1qFlsxNmzfr86ZCB0uPFt9mqR56ZBSA/I16Xdy4c5rc/1wMSZHLJS4OOr5+ELu8/kEkDcEaHWmAoxGASNmc9li2aKQ7IRSzRgpF1kyJfuMjSFSHlb/GsrDEteWy5zeGF08vPhAQHyLVbmuoaE5BQ/aeq8Cii5KW1MX7aK6nrbx772e55czJRMO/RxHv34rc9C/t/z6qKXuPRlLX9jNmkztrj1QT+U/mqF9+8IPrJhyyjb+tgxyN5kk/WnznMqWU6+OWbLBNtW2bHE3vT+HZjgyBUytgzOqh/CGEGLBWnYafrbnFNbOuPrGEXUbFnMmTSpbH+PI+c4NRLcA6vylrn/S7wek/WZCbOYwzwWsIglLGMFq1jHBjaxBRAoQMAACxzwIIAIEsiggAoYNDDABAtscOBHAEGEEEYEUcQQRwJJKbMo/3q/TN68VPtdyNP9Es5+Ptcwyj10198PffEVUl9Kebf4cJl/1DfbWYdoErezNsTG6tvTHBd7lK92ZDIac986SMe7UwZop8OAqk5p1eJ6f2D4yrMmzYrJ5FcA7Q2ni+gA3I76qIrstkOSJ08igC1EPMzqJtLsDb569PUYC+YbvRbzy0tHbgveDh+gHMhgtGOwbkODE5b5NPxfZVCTTUzlj6Xt2b1Sw9RieWvjepnKfBDyaR/iRmuGrplF5apn3/jYhBTklZY31GOia231L//09/dyPLEqw/v3ves/D+fXZVuKevE+YAhpn4TiC3kdwxbnG1+f4Rddh3vdl9Jcd7eDK81auqtp/oCrp6YNx1TN8YElOyGkdJPchoq6syRSDQvhUBIf7tpy/i725tlcfn57m0kwf2gcemH48b9G3lDq1SH2wUSkwgwph64+3VXGog/iNChSuFct1Q/X0rt0BD2Rz/bCm/TxBOD+X98D/GqYHXSi9gcslN/Nfr91ZzEaIBsz8PCwYXYlPHvptMLT1b6wuywSZG6+Rgg13OLC4e+8/glMNXS+GBtMFyqK3U/b99FY9mk+JY570AUjvbHapQ7FF1mDMDP5/rsdrDKwZaFsxhz2nd55HWOfj90tbY6lVETn5RZmHIXpbQrgqxOfAvrGOznRUw0LkJDnY/RKCuVVsI9swFqW0HU2VPee+VXLjVYQL11LTBH/q+RQtLXe+hMFGK8TxrlCpR6dgshv5G/2xxOvpJ/jddAcc47KvHWb8wn6SI+80eIgNV4x0AqOf5g/n92jhB/ndQHPxxi97guaZ0jW41tytXFYy5sgAkbeJgR0FoWKLlzIq68IQl6jAv5yOqZObPAXE+H7xYVMbUd/cO6Fe4QIAGcJ/8jr/8zHXCAmw1wSuSrMoyVPRVoMaZfihlRYtHCVgR/sDrcUQCutPcJ52tJIOHm1Ag8Yfsz+ZFk/j5mJgONn73DYvno+YEXcZTNxP4tuJqdaQ1eIFVaiVZT2tGFcH4sseUy4wzgWvxi0is8HTwfa0AmATVEisQ/nU4kSFt8v+qjpBpZbFU3tBOUf58pqtKV+sVRuW688WDYgRHEO2XqDl0/ucXjaztLTAaZAddu1FkV7jsASVhGim35cuD3NCBIby3aENjYQQpyC4j1rmC+St+2Gtl4Rt67ruF4/2fK487vdl6a1Jg7IKs0xFOzwU6uPy24DeLKBMwBnDrZuAtrRmePGGFvS3jeSDiK0e7+EBPjRnARLNp2QfTPue3AaTjo+LMzNW4DMLHxmY5/HTEEvbyzWJlKG7EeOIqeRi8h15C7yCHmB1CANSCNgC2AnVizSgvxEYSIkp2FOx4kHXx0YBOtncOEhRX4b75kqQL33gGatvseTFACt+pnUXl4fOM5DmqAxjwrms5tUqns+2esfXjkjotv/EOWW110gmD7W088jFsXtmRrOCOerRI2tod2uOhZN0Yj6LJdyXxabHwUjSkSa2460jF+HqNlQi9UM4b43J/05FG0DAvznjvmXQTZMsBG2gJ8UClxQGxcsBJRDDTSHOuRKoTxwvQr+bULWcKjVDMq3gx2gAQbjfv6wBA6G4TAWJsNMOBIXAo6DU+AsWMxj8NLQXb+TqZjiAFZxJZZSevnJKBPRSxOUppyti1SpearQQrWq8xWLVrL2j8Y1q3mAduuCrmGob+tO3yWPdFeP9EI1alCjWqqfh4zhFw0HYDQwHqLCftvNAj9Ip1IDr6UBDnVkiG2S9CYDylOJZqtaC9RI28ql8GrWh630aUfYuzTSh31DGQlvX7YkhJurX/d9V7hu9ZcAv2++qurnCwEDCII2ChaECL3tHGHk8YgW8lGQwmSuLIe9HqTczkIKglL2KStSG6ldhzQDlDpYPulSc3x2shGpNkb6FNvVCxkAZARzsv/j4zm5vus0milseTnP3AG5vyj11fvDNqBphr5XrYsOL2lUdxxTHCagE0dciVEGfeV3OK/RGCET0SFBacpRERUrK8+8s1Ct6tRKrdVm9WiI3UsP4oyGCSbDeV3V7akeWvSct1/6mQHO95HoUMqVmqECOrErt8R3ROI3UpJaXgcDGPKE0olI5Gmk1FmtXDSxJIWMHZdMHrNXr54F04jQpqVarfXaqr5X/NgR9uqwxjh5+yzmInR99bsAbfZjNC8R3vN16zYUrPzd/ybsSH9fpbUkBMvVPepcYeUTbfjD9VkVNAmLmSzv1+zyRxaA91bXgqa0TMmqWtWpWR1aHrseAXRj0Lj9FbE+1AF0hJJURjr7myOW2+PoaaWpqS6Dm819FZ7+24990e/9zALugttuJy5tUVujY6l2U3vDDl7VRYHqo5Aq9LAqDE00lEj63VlsCv0QSlW2lrAq/Dz58xg73ALIqjo1/3QHYNdhty/cSXv+l/7mnxP/AqGPMKqSN7W0Q/z3NrZ5pW51kOvv1BlAswpA3dSems7LHtSPOQ/U2o23GFX1rd+uGNUG2UHDuOOoMwBaMgE0YeG61wCol4WjMYcrgnrD7IGwMaJmWlXcEuQPgAQBqL0hupUASCiAOkd+5Vq+BVAlgazSfGfmMY98kW9dEjR3WPkWa6+ichqA+uAdLeeNfZn67kJ98PBgRVWtpZZoAJkxJ7/yIIAWl3COVaNAM7Mq/tqWy2oUYW7HnI2kk0dJDrZYrry4kHUji+yHdmxP3z2KXiPP2ZVGAKrMVAuwP87ymS0B0DieSvIkpYdr9H9qJj8Wmmkeedy4bJ4HoI717d7TpGg42r8sQZ58b/vOdKydE8tjttk7pQdzATRMQMNwvqjF6FYqANSyza0s6ssq+5SMF5o4x9n4ueUXgBqQJMt9xRJfziukPAWgpT8YZMVslnu3bLalWkYD2YURm7KjOc7dN06c8H+JxQ2tNABqC1Hu80F9cLMtuczbFpqrZ5cJCJE/ozuvD6gXq0Nt7NhWLpsFNVNNf/0MqLU7RO3YAHUBQOPpd8wVqJi3KOPNoSafUZ6rmFOO2U0Uw73tJws1xCNPrKvtqazgjxqs+QSY6Bmz8xm5MIRTNY/n5RjXbofVEipvb1Er7OkrhOvncbImVTout5AxJufP5cu5gvTdvDdEbePU4dW8Qo6v6L30DHKx1K0HUHc9/GJfvLdpGhBX0zxPy7K2kcN+9VPKKkVDrQdGeHpQY5H6abSPtDLsXiHuToR5CNHMq3IDgIbbnKn8gJE3zMczoYRdA5TeN1SkKlL6gGbfzd128uKZVZ6ZUY/evAUsJLVeE6hlAIAy0TwgN/biyG3LTB5HDpxjj2yv/Xg1pHdegzp+WrkNCqTGxDMsozwns/hCJeHuIbPjE2AC15jPUqaQ77ncPVusLPdjxPK5E5RH7OSvHrHBas4JcedXc5WtvqJ8wSYy/jh8N5H2rxRtJnzMQK81fD8GUAK0iPpQbjM1hTbxH+Pcrs+hg7w9WA54BhdWY/Qz8I8EtAJtANoJoD2A9gM6BOgooBOATgM6B+gioIuBrgh0daDrAt0Y6JZAtwe6A9DdgO4e5qR74Pf9+HvpOeeRMHnafApqQEOLLL7UhpdbUROa1nyrgeGivPnHg+qM2bva/3+tqr73NbcbvdZZek92s/y6OrR+nElghG4Gerf2ubdig3obr9bqk79A+e4JrhWCP8qn/jbPyw49Dna1uEqMBNsmRLn/1hGdssMBUuswb23kNhdG7QM0h+mNoPXY6RE/d8VIt1udUo0F4eYKWg0r5sZEa3INWflxGhCqD2JaZEMKLaqY4ksosfQyymx4I8oqu5HllFte+Y1uDEaQNiLQfrFQnklI8ktBWedMgRFGKlUmoNBYAuNNJrPQImprldC47hEbL1Tz0NLpvsEK8CulhD+Gv9sd4D3YRSdBXPU3nV/kxmApkxsUuYmiiyEqrlSS0ptA2YioK93sVre7V3kPMRIzrACsGqu21tr1tafBQe6OUDIfx53k64KfArRRi+wm0zQ60uMf9Qzou9XV690UZS19p+rnhNAifDdwsBzDXqTaCWKE3TH/aOC1rsciqc4nJCo9M3vinOXbL9x6lk1/eYGwaqtDqFoMzzurCYwhP2+UUjDL6z4FwGxojVEKokPYW+hcxiSi0iRpCRIr8RGC0svENbwsvEg6hH0/h6jcInF5JCo/EstmJMHI+iTOpIgyI2nmxGVJoqyIZU2SbDYIAodgLgzzYyFKy4USoCDDIRIiX1VxlKEnx4tyWwxI/6zKfLEa44WnQJTjRYyaCVPO3GfpL8wikRsknSl7hbgyVbxxalneldCMfqCx2EqEkmUa/0fquZXG49E1gner9KGblGYamSoL0MII1pBAnUS5XyTPi0wSk20SUuRHdhkj+4JBlmRFGZkBxm5eqmRRfkU2BEuXFcbFgs80bpmBiqManfJgrL/IgoQlRxwncj4zLqjPTGWd54900ZWIQRCx/kJJhCnhhItUhCtz+JBElFgycZLJpcCFWZ1U+EsBVW6hhhE0VxmbYjotJrNMsHcHhuiRkTltgdWAeOiIgMzR+sD6jd6jlAMSLoICExB6OOMADjwEEMIJovPOhQ67SkNebisZG4qiWykWG5TZK8A+MdgvAQ6IwcFBgEMOb3YSudUF1+ZlqdhD1QgQTPXE8y3I5mN+ar2m16CZtc++s/FDvc/TT6102iiHfzASQZGYCL3M4O3G0kpe0SrqJDBYwgKyZJRcsktRqCCkSdfMDdNeTsm1mIs6FEcmWcithKj77pDalWRhKZONOksO7i7eKVLH0otcyqCuZUbdpAgVPKB21x0EpjCDaTJrVpGyQvJtTrGVRRYI0k3mVRUpG1doZY3FVk6wwJKk29UXBXaFunSGtJ0labfIqqmCynuSpIeRz8na9fIyIe1WAgAV9R7zFRktIqfAcHiABGZyDwhePSOaaUZEbMa0uvUYdwmfD3Ko0VRaXzQwNBijQQNDA0Oz/apZiqF4j0osGq0lSwgJ4lLiX//THpGl2innaIV5VOLRaC0skeRRIzVkLZAiK5VxxEMtxrS7HJOgnA/udwtwANy+NwDwCKPYgxEjRjwWJzZE2n3HwmSGrC2JbEG0uyUYKzPGkjfTAsIWxKJa7ZG1yd0M5hMthUrtwjcH8PAWVOZsoeOPiJI2X5OILUndnEKKDHlQ9GMeKRuB/2kBWEISQ4px29+G5bCoEImhLSgBgUXZT9EtCo+RuWTHgsNzWLUW16vFlYrE0rrEHCWEaWlSdmm0FYkm1SJiZMiRIbewCi2sPxQWVp6Fhbao2mxWZ/CohrQX9OH/36QvmqvdLGW3jht/Bn2ESRDz6Ylmv35OJOPYyOlYNZegc8njIIUGTLhuy13AL9MN4Q8OV2iSOdb0Uvr07Hhop7t+IiQZYZTJ5mKselX9uj1P7Q8TD23jHsxSZIp5AdIr7F/nwEsHgQaIkiLbaFPNt6YX27/OkV5HQQaKlmqkMaYpjpFed7fTd/L662AhhomRJsdY0y2g9Br8Hzvz0VlPg8RKl2uciBKll+OPu/B9I6yfHixOhjzjzbSI0ivz03Hlp6vehggVL1M+Vu/9vljlEwCiLabM4yZHCat5GnVYaf28/WbIbgeNmjDpvKtuTw/XgovPvfW5fK9LADg0PGpk326X8pIbISUvQUxipciJJfdI3ZJVrTrNOizXZaPtbeDdhPrSCOx3xLjTplx20/349KHgl16Xr3UZgELExiXntRv/4QeWzWCRIkuBMla16mLzU3xc7rA8dr1q0uWNthswYr8jxp02FS+/NfDyTfc99dpH0+V3XYFCXbjP3+8rZGDi4BJT0vNjjKYvRFuJliBNjiIVKs2zsLW+t04XdsJKa23WY8huB43eE7/IxyScd9VtDz331ufy/VSMRAffV2gZRTSUo3rVD5oYRdTIEf8vR0JKto4iRiAkwGeJsuRZigTjzekR7SmJcXEwkeGgfCtOUDQXAKI0WmjHoNexSOlHtD7FnMeTWG2Lf+111FlX3VWhXqOvWhOCADRrpXzaqSAE8K574WPsKZwlJHOXwOwWrjPGd0orB/NAyN25walTl0wiCCwccrKcOGo8nhg1QWnreYzS9tR5e+bAKyhWVcAiDRi4uDxzA2ldkglfOqGFDzfRwlywpXtJLA8rFUmZpoYGf+cODArqqT3sGc3RtKo2XYg9wnjJMt9U70AcgC1KTot6EBDAVI8t5CALbTTfuSF2M13sr+8tq78zjnw/gnsEMgMaHepUp5MRMcJXjnO9wQ/9X1KMev99wuYR9SXpxY9tXOOb0P8JEiZKnDRZqf48DlaOkdJhhPfDC8EpUZsITG1YTbwGz8FIWQvAlOA60+xmQ+YatrvciM0ui7HcYVwYzRzaP+k0k1bG/iCnLNK+k4iSyy8st3jxEyRMlDhJ0mQZ0zr7kcxZsnau813oYpdSE7NY1UXnEOH95RWZZJaFllpprY222O7fSxDLWwfe/GU33fcEl3/ciLgC4kXC1S5+ZFw/oiAKrg4JrwafbsdE0XB1ShwdV+ckMXB1SRoTV9dksVBSULKvFjZ5NkoJSgVKjTL6CuI3zxjr/+RYpSmwylJi7UqFtTs11t60WPvSYZ2kUuZoR33pa9/63o9+9qvf/am1NjAgX/NJZUTCC8SKWuVzZ1/4PiE1QhCm1JGLYs/r16NgqLrqwdi9GtjgBzmS4k0/PNUyACCk9GZMlKFSvRZ2CqFYghgcNelnX821T3TVPyhD+WcIFN8tGfV8jquNxdXX/7dTUGGjKmpz1OBo0WPGylMlkqatFqEljJBtujjiKCeFzKIKI+TxTD+TOt3mWECvTkaMOHGnUg8lgS8s/xQpU6VOkzZd+gyl8Jh6W3WRpFe5HJDhkpIN0PPDquVoYIHhr98IZ3iinKof+mdQIkxdyinchLSUIDEr3te3Z+ByAQaUyD9PYDsLOMZ4yQwEDkv34baGXj0oBkTx/8f+PRk/l2Y/j4AVAHzNRmfArpmxA9f+eLXTa/Gbg4BxAgl0oji3vW1T/KfMsZ42pR3tfB49mufU8xK+aIveYhguKl7a/+sZ3zz+2cMHPu709CXf8T0/83wf7/O9LIyjBCPjO1bEujhAxpoDHOaA45zlFZOZ0a63Gfy7g4HWdRgACnYnwmG3KLXbiZ5Hxf3cT+7JgdvipHaeeN7v3N7OVGems7OsK7HIeZot2WXp4t8vxljgfE9n6Z3Wv/kMpycV0NYErQ96XQ/a+sXPpq9X/xfMofojk3ZdHLT6lO6ce4c1Vf+NMen5Lv/wA0oVSvYagMq/V9b0a6uGygeYL5GvHsPz/16y24KxyQgwBrC8hwkTF7REYB8FINlB7u7JXhgGYN8E9sNpY1e3BlB8vB/dpv6qaerP4la5whpdXFPbmLcxJZZUTLN6U3qDi79cPWwLWmy5T13BXzGS6an/ZTjzoNdJFwbBeuovXKQocVL9pdAo44w3pdQSSmt533vT0aLLI+NaJbb5t7be+ONOueCi6x567IkXajX4rMUPP7XRs+6U0rJGCm9yMxpvZtGu97obFbS0YJ+63eKe5NvLNuQrqua6Nbt+9a1/F/okeANNEl9mvvvG7FnRsdWODz/+zPQz2AAhQg1qjmFGGi5Ltgki1JhrptkWmKPYQsv8bZ2NNtlvlz32WuWaO2645YHbzXXfB2+8894vj/whNY/QLDLzGVnS/wsvZ2IFjaXMrWZhDQdbWFvPzmaOtrKxgasdXGzn7h9udvLyP0//6eiw9g7ytVsHhwQo4+2Azo7p6oSTujmth7O6OyPQOUHO6+WSPq7o7bK+rhrqnoFuGuKuMOWiPRXruRjPxHspSZVElRJUyFAv3Stp6hRolqvJCG/l+yRHozwfjfbVRL9NMjVgekhMC4Fk1TK9rrGGmvrcx971pKe9qKrqKnrcoyp71ktjfVfkizG+maz1c7qU/dndEUd2rwdFt/0NUs5OjxU1WoxwzbXW6rnysEHX3D2ZnKQy/G2OW2qiz8sXXi5Hbf37yWrZtTDche7JCLg/PyEQfOVL/qUsa3c9NBjob3fM1VXbb6pq9p13y/deLTu+m35HDcaQX+nPjROkwkkHTKX7bZDQ75d5YH1U+guhiSS/9QB6TrK2IG4WvVsebSab4zXTH7PMgw0Wvfhj5CYDZyv91rmvOzvoqfTFXBpcxXaZ8imPVk8bkIZGPa1wE2FiKy9828+tkFvyRkZlXctr6PtAvyq6nKEXnFbNC6Ci7ELopRmtXJcuW8goQSJdUfgW1LvNf91KXb6v2ZR0nnSSpCBfu60fKnQrkUmWzXEmhJn3Uh2TEcy5ETVvm9gELLWUDo353lTLVC3/CJ0W2DUWiztVm4nWuza2Ape+rTh9XnfJjCvq12tL4ts6M5Pt6vKx0Ok8h40QOJf0mkyYhAE6OMARftAjFz4xJWmK9G2ChOmEn56kM5XL/GiWx3NMgyaW+wrEt5s4D5ImvnJTXql/3rumv4dtfu9LNLP1pG+mdoGXpHfEHJEjU0cSJ2aSlwKTaIcsZCMQPRCOvohAlkmTKMQ0TEckIpCFBGRjmkmTB5undtXFPJ2uebLd1OMWEx6c/LG+y1z+oWEVtu1Nii41bm06J53DBan4msTd1HuVl+gqhI4S46cXl+3n1vE3tf1xDxQroOQnz6WzmbyS5lAu70Qo3Rbg+AE7QD2vKNDgCcJxw5tjWS/DyVg9K+UiKbtPT27uIaBb6FRK/58wRxvm6KzLpHwmyVcXU09NZIMCPWLW+FxsEY+FsFnKQ+03yWTxXJ5+E/ryYQv3AWzRU+Y4X3bEofeDuLQA/Vv+9t47Vvv1Kq4Lh9W82Da8z8vXYQX3ST6c5W57IHf68V+2zj8vlmcYKBiwxf4mCbmnX7Cgolmsw+H5b4ifq9SpkDWYfNcMlj7ReeIdCAarHrndLiMXrWFYS5NtbEUojUnuzzBYg/GQlidqaeay27z2XNaMIljSTJwR5g8npRaT4mpZnfr/JKHfgujk0s1S+vskCFr/BG1bgM22Qmh9MzAcv2JSQJE6HVo/aVuBthiwHwJfwucO/v6U1rlmc2extst9bGdMaLJMzO2/uDMY0W7Tgx9vvE9rWY/XF9Bm5bt39uV9uf7/n89mBzu7/svp6c8ndOz9h1y1H2FvBUOx7QCsCjtRNelKaAAQAS3flBHmqhyzRMqT18sErrWhJjTVIkpxNkqBSigacVYaR2XUVZ6Vby8rNDcHhzYSgF2+cZ1RhhsnoYx8c1k53h8XlWf+CaiAdJu5CU01joqpP/UqYfkZdlYaR2XsPnPQTy2ndIrqPmdthQDt93c4/e99Oe8Hf/tx/L+zfBhgvVlbW//nv+/T/PObN4/ze2GaPz7OR3pcRJj9S09whDmju0AOWvMwApv8l79ZjZeU0due25Y8U+p6cz7wHzkb1qbTOSMOGN0Rvzz7xi3YlQeVx+vAgjrB0HBuenSIW9EERsKOX4SBVVXknIViz7/4GX2sYTtd5wxkvVS+YZGSPk5guWWuJ76ntlketAWPMBYnax7UG2EIoTPn6UjynmEiSg9ZECwxaJxoZ8VQIlSi0KuKcmgeUhLOkABFHya9h4lydDJlgwDK24JQCtuZ2kDeXzxVA5USUArCwWMC+VI3Izo4ZUroI5whfTKMVR4qTyotK202xlrpMGcHi+TXNdbGg637x8XJ6JHGcpv2az9ObiciwER5DXkRYVZUOsq7ugrngu+IQWsexuU1sjM1yf0MTTKlaBIjTdc4lMW5H3q2obeRAQAA)format("woff2")
    }

    @font-face {
        font-family: Andel;
        font-style: normal;
        font-weight: 600;
        src: url(data:font/woff2;base64,d09GMk9UVE8AAGNIAAwAAAAAvyAAAGL3AAEAQQAAAAAAAAAAAAAAAAAAAAAAAAAADYGvdxqBLBuBgHQcnRIGYACJSAE2AiQDj3gEBgWSBAcgG0y+R9BtmwFPq5wbAlQ1r9W4a+MaPDeKu7tVsdwCG0VQtGKb/f//n5t0yNBAZwBatVXdd+e+qzR3FxThRmZtiZiX2mq1taHnyLqNfUZkc3GcgeYgeMCXRXk+f5aAo22OA6twxRHWPMbAqC9UrMJhXdm34t8lEqtYpltHJqqIiEAXcamkSqrk49/vojad4yG3QnRTDDdBM7Ftit0qi1KhoMIThiocNFAYdoe5G7wqJi+5FK2IyhSf8ACF/6mkSqpflnJO2e/rneKUBOvaZWgXqN6UOz4wMZd07yph4hLW8VICqfwLUyhMSd1SJOU5Gvg1HJ2oJuuK77aJyPiEjPJ4xCkMY26alfcpzJjLHKY53CZyavJirsXTnD/77i5yiZMEcS2ECh8K9VTcgZpTo+ZG1RCrGx/CAM2t222woJXYoMc2trFmjEzJgfQKRvQsQKTK0YIIWERZlFWU2BNFeMzC/BcQkKF//3Pb7nx2H7fQ6Y3XRwmEQs5EUQrILvivnr0HiRHgDzsVENHL/7/s6efa587kB4NQGJQmwQCGVNWhm1YoVelff4cDyA4A0ODCpH2mH8uAaGS7bpqlkpymd9GwVNxLdq7uQ8o4ErsLPQnQIHjhi6ayj/FT68j/r6bSHKYH1tgppOgQFSgExRQoXARIurspE1/6xnrjUhD7/e47UHmISohMpxJaxWvbBv8GqAv9xz2/ebt7LvxJLJSY0iZrPOAM8+X3+33Bkvjedt92djCRSvRsHXKkkYiR+c/NmhWx+nHve9t3F725nvasUpcUq4BPMK8gGiRIoATxgQQINPm0qfj/8bb1P+89qmqtrvfvj4c/H1Z3PwFBxIiKIWFGMEbGjCFPDoY4ORozmjEDhogRDBFRDOOuZt+eP3StrvGUNqpm+yoCHyyBXv2pXsZPO/tyBNKfoLrO9ufXGdJB7x/kgQyxrYXlgUEBAjC3XQUxaxAysEM8brGYOJeyE6rdApdUNntULAzT//8/Z/91S9e+33ly79rnjFbMoEaHYh4hKTEBAsFmsOpQUSgviCaE5AZLoBTqKVrJiMtlVvrSoeGhIFbgbT/YCyK47W4/hK6YRAUtgP//W5pSj7VKaX1TCZHzgvNCYFjo6c+WW/2Z0xXJfuu9PZe6lpu0bmW0KjeSXFtXSi2oAFJhkCEyT2fmISQwAAbCzKfudb3DkCdSRardIRVS6rCkz71tGT1x4rsc/HbgJrkKV7mfhMvJrb49fYozZip1RCKF46dwfDdwQ9h9+pDWxwzr6Ez5W9Y1RNGJOoKLwQXAjx1WawGMxu1rASzF8LxG98DWeJ7/Q9VcsDwLyPeYhDw/NDfGVqfVJ1a8VsBaK9hTHvju22vNrR1ko3gwgVFpXWkV6GQQPYOHYeeBefgNP/zzzd5ZktvuKqxjK2lV8SqZ+e1J8n66DUuSLivbOjh2VxzGYhGuDesiOTiOR2gUeKQC/qlp0z9/Zp+7owlTqoQIeRKHk8lSuxHXHK253QiHsAxGnaRYA4imzS7qfnklKEwMss0PnMV9QhsDNtak+TAI76HMmHqlmShAV4cdIhfwWf7Fb6P8yiuHBGCO/gRpQm/odV0REVcKKUTElf5zhJ5jIMIP0DmTJvW/gPHb4T0TzSSG9Q/O95/af4f0+x2/Pwv9/1vWn7XTEoFfppdvp7U7aPTXd9Yd381aridS5v9iCRRM3PgIEiJaogayNNdWZ/0MNd4Es8211Bqb7HXEaRfdcNtDz5V45aMvfseRnDRkSj+z6HFyyC2fggpPUEySMsuruN3V1lp3xzrVhSa63p0eV1h5n+KM3vMFwSFggo5HQsWIJSwiDiENWgxZsGOSFSBEKNBgxo4TP1HinFCnDc1bQMOkpKlrbGXfqbSSpp6xdUeu/c8F19xWqFyjFg916NZr2IQZyzbt+ihboKBhSnZRZb2moTHJOcU1G7Xq0lJQe8nTZs9TpFSlyJhUqEmatMkkw/BRssg2l7DYtIKaTbrFaS9ZtiLFO6lWp9/VLKR1Olp3k0mzdth9Znnr4Pq9p28ef+7VBSu37j1+aeJzkmzCBJUNLyKgYeJglYCCHapMPHD9C/yKVQbmcByVp6JtZmvCvDU8QgpaFsd8Eoo6/obqnVvZuH1aYd1m7ZtpNX6SlFkuf61j/nWA18HBOvhquO5JfU1txOV6EAPvkW3DgwrP8Cpg62fTBMFYvDlTnOMmBt9EUbKRNqUTxtftdGmb31iVaTgiGlOssjMD3UnrtLu3i2a7zLZs1ygG3KNvZkzZ44EsbbMhDjLirjw8KAg7coTkQUSH3B0zrXLcV+5Aa4pQ7Ywo4sxRrNalc6Fp5x4DRcIMptHm35s43cadz2RR8gRo89J6iRecVruYgV6KYZei2aXuvksl7i6Lh9fCIq6l27Dqdacwx+tAqFio3OHF76oJwcRbDAa8FUBPJHku6DWK+2wYVhk6lEUc4xm+MOSGofaxS7+w0+pzEj5xt3orokfCPiY1UXy8ONun78SKEWOkYtNSmyPbtY6r2K1TRI7AgXwshhwb++I+IqMi2Cc4cCdGiVS6IqikEeqo/SxeardM0WAX4678Z6CGnQDHJaLWfJYApbJasFit21ANLSIWdYuGxMWztIrF1Rq+YcffKnmw742HaJVEI7t9bj8ufrY2dthMb6jSxFYYnUZbGF2tV5x0baWq20hz0LHQ0umCc2TgIXW9TZqYMg1amcZDJ1fpFFFYaRVVoJjiWPToGljSBDxYAKDiwYcFNemCJlNF6QIWACiLW7gmBQ8ABZQMAgqoD1wBAKAeBRBo+QNAF+DTRcLaWBATXes+HMbYxQmJgGJ/4zKYiimuxyv6/OSw9BFSmMV+lXvkxkNBuwcofXhh+mG6SjFiEovY2gaqSmBREKvl3XVrc2srcfVC3EV8uiGA1GZVWd9WD9cpgqHifxXmTaX4ON1h+fTQS+eWmGw1OdJ43OKtEqq3lY9oRPhCIA+R2LBTiKWmBEbCGdQIYqC2JfIX26jKQrpWVfj7WqLmpJCDutoqwk3E8FkpbAyUCR8xpbkROBvlAQwF9KQ1TyOKWUJ0pTZknH0Ruyz431HKcCREITNkmYAyEggiCpUsxEowJo1hVDriCWqICfLELB0rYmIFlUy25gEYZpGzdQ1IN8srW2vTOMpd3pA7ZLHtiKbN0mGznTZPWnfRjmDdvKTZDHwNycJN9s2JzJ20tKEZCrCeMIUsIYl1ZLdu/bE+SZCZmrgkq3BREa2KzGe6YuoiksgRUa3E1VKKF8xIhKqprhhbKprIF9DJ02VqSKm7sJUufOpoyi5l7edNzirL0u+2LnnV7MO6h4/+4ZOjNrC5tBjBPbtpjO4sobbsy8CCOsfQuHWPjrgV3Y9fgPPCBsQYXI+KxF9TXp6PNRB3bkHWSzUXKZHhkvbwDjg4W2VswSNsKE6Xmhyd0EBXzkQ4ENilBwVGZTE3Q6d4bLExfBXZkGl6JGK36CWiE43gqJL51W0CZMPIeEigloJo0vCBSsFEDGhTK8sKUgWXWbEUt1Ayw8I0FNQwIa0S1K5z51rgkTVI6ep5d/Iyim6hr1EmXihZ13iamjwvgZwSyu1Ez3qbhODiJn6aQaGCLoiADjt4LLpM2CIExkeGMgwfBTtaRnYc+NXWt+vFWQXKNF+ieBG2KOO7bnJVq4jErDr9Vu5WZwM+XmLQ0uK1Npioy70nPOEU0w9ZauX19zdu2ohIJxtsNhXbjb/JyZOPz7zyxrvDW05NXUOWjegz5w7jqRrZm7ZkHWSPgomNT1xaQVVftSAqPsgMjsYUBDPVWN2ES/5/lnDw7ZO4ycg+KcstKimrpKaJ9ieFzs//0U9aVl5xRW2DpsHh0UW9n2RJU4u7nzvQ/3Zko35p8aoWk7uMjCw15WdwLU8N/vTxqa3vTZgEpZM0KAws7XboDeYSo8HS3OvpdvZS9seM0bT7B3ytfsFnVx3TFKmpJ3WDz2EIcn4mNEwCDLj0QEwwMP1fzCGypWlQMgI+xjQOGq9W8AwDFAvdi14gLYaOf0NrBthp6g7N3BnyBjv1Hj9XcOCXJ7/NDlAMEWwwS5W71yxSxEndf6VQpe75jM8mUqAHOg4NELS5XOOmqh0Bgad3KUiZVouL2zq4DRud4+P3HfJbpBT+R3ay8yhPWOus0LjD2Z88T08NYY4MbS00c4W59rS4uO6hXFImVdEonrQEwoknBQoEYWH9IlIu36kHwqVi6OWVgUlJG9zSprnPSFV+dHeTnyI9/Um6vfNTZKpJiJwodybAxfUU8XtAsdwI91P0eG4lUl/z/J/TYT6cQYDCP9pK8e6Vgbtc8YCHgf1yiopMpKFZ5hltG+Q3dNv0WpNFa6TUIkK1xNDZyCbjffo+A+YZ7tKvRcLX5jNftHZc7OC3+ApUKr01Q37M2aujGWa6J1B2k684dPCSpQhUWkA8BseAlVdLT54op3WCF7rc3Br2koPUNDbSmxSwk7BZ0KYE/2Ws1A8OQOteIJaiVo8N3BBMj8+hFXIYJnh+8+zOT6aeC8Q20joBr1HW9If7Rw5duXKk65LUrLiNYS8hBysVi8pt5EzLwNWtkLtNXsnb+jroWxFQ0uWOBrBUJytU023BqmT9RF43H+yuAJE+mioOrYjUcPSl6xH3WM0ivmbpqc5OmqHc3cEUnb2iL1hom5H52weuiCeBEAQkJLw+aSMLMgP7YghhsX/g6hQI2VyoH/96AC2D0aW6INFuXmYjSrUn9QNfgVcYXIUd/tDLQhshyRiXcTANQ/bRxPGbs2lDPbhQk1M/Hd8YsdJJpKuPwIadBlQVdF5ffcuSrixQv4S+rNSFcuN7tAzx9FJEC5Q03NiibCcYwVu8GAg21CnqPaertoc/tNM7Oa5h3RfJhjyzSXMCwwiK/QLyus1+Wua4hQ7RbpJzK+3JOPpw7LKubk9NAfBuDUHHfO+BJTHKhaK7kCcX4l9QdpVrFif3qNVms5pd2+v295fhaPYpfGGV4UoOT/TXkJpW8TXacYGP5SIsHpR7F7Chovt0ZUE9VDl3BotNI4H/kzQoIErjrkyttIepGG7zapiHenN7x9THyzurqhsJ4OaTouL6Ut5ODE4XzzqBuLy//NSAm+t/0xt07jMUk0oWhVZmoj9qFqAnf67/nuiwxsf5BaqaG368nma8DfMdUr20yePF0ssPFxtfTkxs3CQxdN3vEOhoN7cSuSv7s3STnYGROxWRpqfKFdTwHWLfkTSzoxLgqEIjlZ7Kk99PN0r/YiProEQoCOE/YY2zw/CDf+HVsrLCDhF/+uXEbAp7k5FkC8ivULDn7Inu0PZDKoU8xIICC4gsSgTA/VOnb8cBXucWSXVa5snTCVXNvoMlq9/iS3dmxydkp++NodzBBJXgkh7LTxiPYbh/XRYCErCpnJsmYJ20212xVKWWQdsGA+YjPLG7JzqFoErkOhlC80LKykdwX1uqfiahCpUjARNmiIGQNBCYHraMQYQMxFfOrnIH2FyfdiTo846w5XqioJPRfiJps2DESwPAI1a6B5Sz4/FV/hfMdjGdM7JTD3Oe3NTfizGKEG0jZJkMIMd2y9rIW+k5lj25EEP7Y/9ob+++iiH77NvwwzhjmwWL0pT9o/vi1VZy2tiJbpXSZGTXwE4M9Ufrkws64df/J42DITgfjRfJ7gxW3kefY34Ar36Ct2/PSJPL0qo7eNv+jMy6cu1UA3/vxEL0r5n+NqOsrurM2RriTfM+NH/iBOfRInLCzp4Ie3zn7ZnC/rf2H0hPP8K+hu+WO+rYDHP9sOJD+weuYt9zdte6+XvHF6JNDZwvXB0SaAYAW74xJe6wNHlVmFZWSrfefy/8+8YXosZWWPW6yi4f+WXjtKiW+Umfuiyxmmc4pTBVEMQng0v8pGCu7dh3fsUkQKm3BG2LAdKjdnq3mi+1fcz6nBL7hWulxB4BMuwmCFowXcoC2BfYCLA7W4b14gmJVCaCpkSXEwn2L61nL7RQq1aCnZjRHccT2bAuVaP5rtQDsvDwopCX2sgtwXQZp7X9vaPQYikosloK27rZQ1vHHjwcPBZ3NDs7nlWF+gRclfWJAB3RjnGZBtlI9k8QWZRv8AUIWdkFBIPXIOS9S+/pFVdb23xTb9uEpWDjpkXvitcddQ7exkPv0co/QL6axk5y+MFKhV+XaqzTI9zSTHMjjVQCEX3XJMaRbvN6zKzTkO3d/ROPuceMC8RQz5LzFdrwtGd20jDr8Vt7omlauI1wxXZfMDWRebew7tUybnyn3c/CFuJPkbb7Al6Eq2y92XfZBWKlqu+bOJNrmtUz2DFHo6ci49O7sbIRaGcNwTzGHg5oW+JcpUIvPBo3EwFt8U4s4cYOmjCTDqb0uPVx1LH+53xAk/utrtoX0VNU1LZ7G7XHYxeDPXF8xO7MQ4q91FvRVVXZxBI0XpUzA7YBMYxB04kwL3Up2sOFCWgEVlFd21w9K9PQanrRqThH7LfbueO7ZW8IK1UuFT9d9C5dtdhFgsAKasAy97ezP44bp5xA3LRmHdjBkGJPr5URy2acttyLGMt+2Fk2QRD0Q/ytoYF1UrG5BKLYXI2WLTuA0Az0NBB4wC7sZNg9SB52CuwLmA2eQWZiJ8AB9HiAN6xETwb4wEH0LHoBHAqyAI6g59ELwTdI/gT4o5cFBKBXwFH0JjgWZBWcQK9Cr0OvhkD0GghCr4Vg9Gb0+gHMhZAgWyfgJITBKfQhOD3ILvQOmAfnIA/CgVoyHRFk9wCivNf5U8Gf70MfRB+AaCTHx/LhgBgXfHRzcdDJBRAb5Jx9CX0C4l3xcVd9NonoU679+2moC9fRZ+DGoOvhVlgA9YIUoC8xd/TFfBka2HYu51uQlrvoa2sO3IvuzwN9c/nBf+Yx+p7v+s5k+Px+aAgLIdEPPUohPLl+fMg0Pw9ZfqnR/deHRdDY57vDU2gKPO6/g+eDPvtdDJle86EZbITmQb4GFv2li9BfgyXdEv2jaDXF+o+S1+oHrQOJQ9uAcmwJNhXYkkB7bCk2ldjSUug+gdqMC7aedW1g/WujpcAA23eAsdi+2X5ZMDF7B6bOwfb+E9AdVlm72YQOPkADKtoxYCwwXbgZb5gRrcAOBZ5WnZaHDtBJkmRqg806ufZhA0YG9DW6U0EG/YzRH3fvgx0Z2NBOD+gKvUfQ8XrqpkeUsNV26+KCPcR174ydGLAaexcsQ+crBTtVZzmjTwtsg53pnJwPkozDLuhzAzth1y/f2UUDe2KXBfbFrhw4kL42cBB269zi86bA4W9wPJbJ7RynDnd9AO4gheHQC3bCFlgBG6AjrIchhN4J5Ty8KqbAZMgOmA65MBMwCUwdOCFgWtUzsJetyuAMREVNx8CBtzCJ0jTTAb9ZV9riYUGxcsirsura30BDjXWxGz2qpPf9CthyImCIwRIdQJ0RO2bZJw5Jj38Fk7apXRfStpy2p9EbCjVoa0XDaOsZr92TTdomBWr10TpWvSxDjvIR9UeuSvryu+SK+KlTbj//fL5ZSLzmg8u3Z885na5YApmA+ljsagWPlE6Pq/9C+pPonlmyHMvTCu6ZpIialUNIWgWBCdLOHrF55ohfLVZ9eNH/YS+89maXXu9Wd7r2XaZTKWgTbR3bxLZlu7D92DHsdPZNtsCW2FJ71zJCD7XvyRvsOGbS3NU333HjW5pqx6PWYI7Gzn+6WlmLkkovr4rWkxWBpos0ZopMWQARMnF64JmPhyx8YPS1o0OqZEg25MImoWKUmgPh4HMo8EmGKZsKqZoaU6+4qaSfVf5yHCTN9PI/VqYl2qXf2CR0mXNmni1gLLgIct5dmXsH/aysgUba3BMszw7Zwyb7nGzH8yzzZWLkn9JQOkhGSD6TfCP5WfKHZLlkjWSjZJukQA7KETkp56VMbki5PNSCFrH/dwEHL0CggAUBZNDAEOZiMsqaAhMb9py69j9nXJWrWJUW0wLnL9AbbW88+v2jFxdTmZNzGSxLJCpvZblyqvtqj96jpst6oDfaRDtoXx2p2TpJt9SupC4YYWHbdmCnZrG2NtRW2L4ZzWLWcl/5KmV1SL2rLriub/iBv/lal3klwChxGn1iZqzGfhzFUxDwioMI41Oq5UJ+5/bUZyR/EfGAzxzHNTQz4IuJ/0isldjvxXde/PXFvYnlSV5SzaRuL016acFLK18qSrpZ/e/V/6c6/6gdXu7/8ryXC6o7Qp3krosmLPpo0S+L1i/an3wrOWKWkPLGElOjVo38pU1Sf1x6PDVKtjUTa6bXnLXs92WVHdJn4JAR+WPGTpx668w5C1eevXAlv7C8pvlh92B0an41kbpcfr8C/P9CPb94hOdvHqfH3xPgqeYJ9kR4Yj11PI09LT3tPJ2Bq9R2XyJc/4uW0qh91PDcK4mtqJ5r3YEK6X85VxfPNSJPYC36Uxjrna4g/0vdDH1tAPujp6SlD86/E+2Vko6EBH8ZVOp1oq38pjzqDkNUYV6RPIdL25M399PeoCxS2ovTfHihWqh+wpvCYMQsUBBT1r7/iT7RXOkj0TOCWHU3cV0ylXmouRLtoaCpX8M9RVXkuuQn8qeaHFco+3ibUVr+OvXX1Y8qIaWA4yaQ/9CNDiIX1/WEpgcAND5NfOhWRSvglgb+ygsAnst90N5NSUWBfNqgSE3VZS1xkwWeNhUxSISLebZPFh+XK13vliV7xIVWgRJ9fRwae98rbMyLTEyn92As0Rz3U9oL+kObBHhPox3DHF1Ej972SxfLz5Nvtcy9J6+BLt//3dnH3iHXf89GmRK9K11N5lEWRxaL3wV5w9/XSrx6/DQqdE/FKg24Py+6aDy2Fq+0NBMpy/DzcSfBOlUAHq43dM0fBiL3R9XC2Nk8oIq/hehsUm2TnwEkzfSQsj97M2xrA0z3i9WZVyDGVySNfZByIJsE9hFDx/1vRNfUoFOPQY2uIa9v8gadXtZcDGkHGqrb5uilqa0ok9XcdzguYPqJ/Dii8O7Jej8t3+I7xpOFfKvZeSLe7AivlpGuEszjthTnFWZLgnirLV4RCaYM1ZAfK4NjIXMAL7wLHPYBbCE8yjXyx+9mbkWuE55uACe3YehpcxhwPC7g7vDBr+4xwwyX/68+k4BrX+2ZruDrx0v2cQVIstRUMIjSsiPBBfTPmxHFv6MM4kfRX8ibfqMpLvzp/GryyhePDs8RFdqIid+azBWSbQbxSgMM8S2kzDq1FBYEZmyeB2N9vdDy2nz88jeISFFKiviBigSblmyOLJVL36WaXdR18WrbFLLZle01FRSjZ14Fgr/teg0JYlEYRZUoQYrcxpqxypaTMO2gAhneqGlKTvIil6lpis8cVBUZvwTh/7jsDCH9i8WoEO650y8id0WLZFnjLcMqW+Z3sD7Qk6wpUcLH32NN8PBXYHLA8damSXcHpITzoknqwQTal9cwvPc72BJSF4ZpodhtVGRHuVBw1zWEvrb6ogiR01HmBmARLm1GZkM3D0oH4edQBqoLvqOz3JFMBCGqAhOpORRH9ycIq/aOYmP7BRk9jblF9gsNpcTfHl3UXdvLv7vpB5phbwkVmGJUUlarRfXpS9I2Y7FaEDR3bhwaqu8ZrYLq3siz/pu47uR0/6RjTLYKVm6zHnNrFpFcc3dbNPr+3kWR84C3aS9vnwMmX0bl5xrfHzF/RpGESIzEHYxZ7FjdMqEpls9WhGzyXEuh8VWvtwrfv6vXgVDZTHwHVRpzt/1s2BSyTYB9umJgtH5bTZmX8KrPUvl7CueOD6CSrZJfcOm6juKqY6tt7dsOH+SII8BfaBhSLFbWXDHQD93HX1W1cF1aCdNumE4aCRQyBiyaQRLWHQdcUU17CoRUQh6uJAP7ePa2fvioKdJy7mMPrlOoho2B7c2PAA2tum9pE05x/ioOtomLyUpa7JZzwXMfpfRaECawwwLXh+hAu75sx6VIq/jorJTvFGjO5V0Jwr4UjUFDeFwHka3oAzUS4DKZ9J9YVGOvXOixi1a7L3Z9+eWL3/RWbrjS1EW/w1/ppq+18HFJY8273WzDH0kXzcALybVeZGy8Wot/ByIsDisUybo484KyaO9e+qJL0hX0tXF18wKOnqIsmPquCaLb1eI32qYF45CXo7FzKSOzIIRfGinZTY8jXG79CbuyBTXN1u7h0d+9r904SEHrq/vvAHhcukk9XbUxPrjVot0FNlLRJiFBZIo2qIpdK8pjm5Zt9NNlaMajCshLDP4u3wsEJv/8VA08bE3BKdKozwxeDnLvsbhbgq1PCJ39Tz8vKKzuGCl+PcUUY5lL5j8tB5zYzdkvT3AzUX1Z/U5ndcGfHsor03uHcqMqtaz2SFfw86ckWhkDEyVs+WVlUlvkG380ZWHmPGA9+WUfzgHjaluZ+jkS6395nXIAd7OVoM89qsDxTVdBgVWRc9NEn3sNR11zqrSE7zH4uqvf5b07TGG26KGIhENciRKi/vIycvYNRa9trqjpF5c4h3X8U7jDPd43jCPfr/tionF0JVJNSx0WOQ7jNKXD3P2B+N53JrT+SQ+iJLoLXpPXBmAcJUjHPpCDophygXRRDiZowGtFtGYQ9zEY+0BcvWnlex7zgfWIJJxCMk8pGGtZrI9FuJlQjLWBwcMsC4gmSVBDuckyoaINvK/q43+4C+Ey6onp+p37OByn4+tAhAZ/GLLOzwyJuflGePIKoI2iUn11uONUE33x4W0cw7kRPTMbgKYluInemKGA4UEzMnrgVnoD21gkeyI+ot2Esi8WQ3gKjNfNJ/a/3EfE2tVFDTsnxyKdlWAKGlNVX0y7KRmnrnibwnCPGSvgfApdPud1ms6qJ3CdPtUEnkdEZZKY1XurgGoVKB8Ww0JeUT8+OCH3SB69kB09tNpJ8wQqkETin/IYkG/d0MwFacquN/N+jP901eAboDtEu9ydbSKcQ3bhyb3G5DbKIw0dc+xvU4fxEWPKVxKddOEuGfLnCqHXl1ZPTNvkln0uB+qkd0xWU/w4OuxLf/rKNN4ynf/ezxgAKPWXqLeXQsVS4KVVgWlJ69ySRi7ZiTugZw3KAiCoFnGTcqAl3UYAjXDP0WRR7D6YdoKYawHQfMndKaylKDowc26stbf9v40FBwssQ81nN3Gewt6AAvI7YF/ym0e1UlV7/RAVMm3qOTlklj0Zujk3mz+Ne+/ZB1uYx7eHM5s9VNTRH6tEFjiibOCKDmQNKJmZg4rPFvEkUoEQpw+TAE8ADQzAnqzUmOtmJ1kSFX/6fivqyxcjbyypktBwg1v2FXCk/4vIf6KkVNVHX4+YCsB1qj6xjYEl1UxW+v7p3D18599NVXUhKxsTmKfeRmpETUPqymxYakpGsTo6B7KN9OpYzwguM/NXE/TA2maf6xU3L53EEuVeavauJo/tSu1dSMfizRLjJ/B/q1ZZmXRKdt2yLAn+3n72fBudklcuU3Kdh7OflHRcvNp+M8+bytK6Un5SoXP4gX9ierYd7hy33kQeb6AWRj2eLioNeazEkzxUuRPD/SnfFdzL6b4GXHKQFjnLRDEInI4KCXwUylozI2TMQxVg1j2XM8K96jSzQblgRDvE0vW9AXGsNCcL393eKW5W4hobt5MqCDAppQnAo6p+3ejb5v5ozMK5yD2pIq6zFwGdU1NguDLk42W7irGhLQsqmBfjwlU2uMdzsKl5POml4zfimM9a+ggjNdKQ3xqAyT7yOKr5cM3FCeRrkF6QhKiPbbfSWRwlNQ8zXVhARVOGERX+0gsKMi8zU5/0hbLEGt9p6eYKm6H5vhg5LFzczbtNTq4lN23fROcbyrFQbXRRgVEFQ+G1+cYa4r4kpNJfSvyyxG7McquF0zeimW+LzFQB9iRly5r6diwluAYxItVksUpdLcHJAicyFOOhamKUE4RHX4plAqbAQ8D+oMUMJiokElwqYGPu3wKWLFMiyXZlF0Rb1faWqoLvkawRm8q2mMyvMr43XXzpgEQaTJbvaYJgc7zhyv8OBK/2ei6TatRyIo0CIl2K4PI65KyJbusg1Dzex3AEIOTm/G4GUCPRGWE2mBf10rVH8un57kneaD6piTFBQ+8WIw6al4fuhn36vFUu9lGsddi8OHTnDa9htcAZA3yru1QIyWYnjYVnmnsbK3PXTDncM4PqIxIJs/PM84QtpKb6mfo4DX1UjL+LY8ewiCFnjYtzJqOnPrekqONhQoDd6uGOAPUw5g1w7R5QWQaVWE8gJX3Ga7ZZrE1QzXRAFnCK78ObANdRMdwv5GswQ02hk/RRwcJtbGJiU2KxjQQv+8wcLOQGmUp+mVVPZQxrhfnngnCfl6Cy9KgrkZa7Ew4wq/LTr6fxpBB6TP0ptF8ZNyynjRLHFaGjd/XeMV5+Jx4UwAAF6XifqRGjlFFvSVavqivvpIxjuRq2ssoncB8vIYURPo/p1fPitQKKeEjV4l6X1flc9eTkjS7ZDHH1RDAXE4JYiLx0dBdu0nPbGos0jA9pUBAnpWfb7ulf6+yjerdLVqCavkHT972n+j7+6+zWXp8Uwk7i2qHDtsM7lO6YbRRmR4zNXItVvY/a4p0S8+lDAtEeAHHbNNs8XY/vLiHFYvBoLacmrUcEA+tmdE6h8HUd/twMLbdM1pap+lN63MjLK4NSExvRR4c7Kzne4RVhd7i4fU5x1095G2BEQkhNRSm8Y0e45qWsQE3zQiLWKeeIY/UrQKLMz9zeN4GCxjfotWtdgiM71azJ+f5ZkybkiAY82pQs7kx74KQ9VcxVIPztzX1uOG7VaTYMUu8XzN3PD6RaMZGhRhoEoR2ZuN1UNDbAj7OJnVRn5NvthPdJepe3SdqrB8W9GRQHec5k9F371i/iZJ9ruyVKoJw1dKQEayNzLtMNFXZlvvMq6RjiKBT9z9K9icc1edfo8gM3znmb2pr+KzupruQkiMYYvf6yaqz9s6CVKQtige2orvqM7BrICELdD5NBHcoQD0BcbNkYJo1ENzONN+u/3ODBDAs4PRW1oQ2kzwXIvjzzq+yQm7GX6CTIXkPjc9HQeNuVm2+RZ7bimTevz/twlH5c9fADoBqH3l0MKI9eeMp8GXmN2HoCzv7e6qoSNEvULQGBL1XYqCF2UkWEJsXHKIkkV+2kTYS3YCYLiqMCXkWGAtefEqIcRtVVGDk40khsY4qUlYuVw+IJeqQEqamJpgsxcFG9qkYod1PAfUKqNIUPcPRZjxRhn5KttCOqU0Qr/PM2DjbFQUZDSwl7WmbE9cA1XDSSw9+Irjf5MUWQ5AROOtGzGGUJ0DJMiZMjakof+WCoaThmxgtJEvx7A3qYKGRIe5Ow1k+d95QhvciS9/DH76ZfgtTGVVWV1+lggYFj9FdyAWZpVryBqPjav+1RTo+1UTfXDz8lUrdVHWjnHscGdIL2tgRWwso1GrqihG2EQwN8HHzgtE5Rjw1vpHx8J8h1Sogjwgni2XFmN0xs4jPZ85yCjiOKIQKyzYN0HjJhW1N/WOq6cMVJPtujh9hrHXz2RMFDUQ+g/FI3zZZ5uDkS8zR6mapg0ZsoRRUDBygok0LvRB37WN4CI6SV8kCXYaKS8ALL8SW4R8T3bjjCSiU1pBIHBH6E0o+5BjXOR3VXrPG9VAB+sTGgsLr0SY5HE/0gD/cO3L9sueiHILVSQbUaCBsEWaFRu+FCxrrQuMztbmZODu6zsHELmtwkGm9H/bnyVhmiHvztIBAYBuIfOmgRhtQsn7R1BKHcFEYvi3pJw2+/E9a8NYHMoz/Bgf0iDlSB14Jbw0i93wyksEVeXveepBNvrQ2NT98WG3fu+ojsBtlIZPuq+adCZQMqoMpMAx7hJtoyCN/zMEZXujcCaKEHvjH0W/0+UT+45VB9IMdQERSBBn1fkA2jfBWwzkZQhOWlL8jh6JNzMJ2eNfvNEH0R9GyRgRrEy8zQSHjR1yBElZ8N/D8bZmyekU209yIMzSXcAlSAYbB+ohzRvCnn4KZp3Li6mtqanF74LHDwQ4AaPIlfmJC+1Yurgl6tBf+sguNccVP0CFQ3FL2aqCtiTC1xS70JUde12tlagtM/izbDxTV12F/dVKitLa6KMZl882mYwOQYkIYlyOAgjPldnHeH7ZC2+iiC3Ata+1AEaTK9Jz1o/jGdyEtJaxfZMf1p7RnjJeR17x/J/uFtwISAsWXYSJCoGgZeeGKgQq7vaNu4loBsEOpLTIS4fD2G+IK/wpx2lGSgDPOZb6B8LH2/Ev3AADHcup/MFPGdV0YCzxIm53k+U+QbmvKdemPprwzcjO6uy0+1FdLo9rdfvUszf2Rp/B6DtqGBwVtZKAYoHA46jYGS3UkrU3UZ/DU0ixx1zroOVzXvN+i8KZdIGDFTcTjWhodcpNG7jdyfYeiysA47tYvkbFYHR7xCYETrlcrUWikBLqosfXSyqm31MdM6kg5IjPAkOqWHRUaJMNsOzLrf5F8dyog78Er6S+4CazHN1ENr3jkGWj88eh/A4qBY/wOZoaHmlrTvpJFZcXcnn4wyYc7hp2zeJATXiFSGbl6ZTx2kY020BLc6NPnUa/vDaI01HEQVa41NY6j1SnQtQuOoeLMamJcvCXsCBHBT0DrWFM1Lyo/h+PfIYOSDIq8fovSvpidhqVu3Sbvnq11u942kw2uCSLdFkom80PNDYC4Sc2FfMpAgrzZ+S9PuDRPwVYRO0wOTVimPmiUyA2f95NHY/101qbmCtkoi3pGg1sfTyIi3L4J3l6X+NqDJJxeeclePjEQrgik3twNMnnpUfFBLrxOjFUDt6zFaopQJAdcDx5jsSI4ArrVzVepWXGWn/FMu2vmvVIWQjAtKLzaCnEiFVKdaK9pRGJfllNCunGohKGgP1FrBDsI46BLY3YVaCBd/PQLvAiWIor0WAO8DJQik0oC3PDAG+tHwQBMRsWXNFdzwspNUmPcqbDV6vpvF/SkF0RyZMJ7SQvb86Bl/xC2zZX+4Jz2dNdWNWNpnDtMXTmWI7kkRwzBJJlshjydp5sAGeSzlWtex+1K0IfCQlJvuisAsBcnAsPt9IoaaqqodJNV81th5ycMf/MO4KUwcszyZdweSPsX6zEOcyWZMNR7V2y5drjBRzz22apQH4sBeGJrp5msl5ni8PGIf6YJ9OY/rzeJL/8mTNNhHu2ifhuNVYoN7624xQ3CqInJKe62isEupMCnEGcIeDis2zo2Ei8Nd9XEaE04E7sOJM+6Da4k9r5uB3da3pO2wyjhhfwJScQbOADSBI10WtIu4qvdsdY4SbohXM9pvzBQcsPbmX0onwOwvOblarVTVeVA6WBYFCgJjhfcwl5eTUEv7ufCzezBOmEi+LrI3Cx+l1tbjAjgGxbIRaAvxCuxxAc9DLCsBthQPCsIbA8vZgMfrH9sA3TdvQEjYJff0x2LX8LSSnm+2Ab0eYihM1yJi3+Lmj4WxrMh0YwuAsYrNDnaIVbzbYhDJG5THy5mRlI1SKF10h8cbJS64r6V4/zhjLwXCTHcqnRmXFsI8heaGWi+tTyIm7mZM/KmSkPwAZLPj4oCzq2Uh4GaiLkkby9dpM/2x4vThA7gRox5gVZqviw7lkE4RIwWU3vQN81Fz86lm/sfm+vNOunk1wquOorE6sLH/jffjzo8ONwyS48CqM4HclWphSUl9Mf9K8anjDpr73UjwGLGqh0y5f3vcI+2LRUWXLhVlb2va+XNs9vMTCnmj5s8iWip6zxJcSQisrI/T1D3EFez5/cmPxwZKhwnUzcT2tL49VxZCJYEqJum13dkvx9Xf1/nnbuRRqip+2avL5LqmaHbVSC/IzyPUNCtNM50/HL2Qyk9W/s1A4Yc33gI0TshP28oty6bR8mM3KRTMIlVKQxrPjVTJijiNpm22HtKzK89UVHBvn3n19ddI102nNB3XiirtRY34nbcb+oIUUDNSmlam4DtE9/+WHgZeL/6UYZCeffXMtWuNrzc2cEjTiz5iuEs/WBr2h3lvVHVEIm+2eyoD/CMFmgT/G92LNwo4vewHhhb6i8fMg+98wyF+eVdFaSt9CP+6wNAg45M67I3gp9E31ikS06Cj+0ZkKuV1tSKRH29t/J+9cdzmZbGV8s2IgbXh4k3Efuveqon3x/2Ook7yFP6TQdmQyROV3DFiH26/KK1SPjw52VC0mmgZkswhkjCkqKXhzeuKlPoIacWQegihAeAwQMhNhpQg5AYpGl64rrwR4pqrIUipzhQKUyFkysOV8RBW/MY0JnHjV/QokZsTUt/tBBA6HBAJNFvRT7QXqcDAE3/ieOwkPGgqvPa/2J2REX36wSGPZ2hQ78lT6vRKgkcs+RXhSz0ZGQ8GYR/QKVIkZzmTpxJdx+2yiky6Fqli3QZMRVh1OT1wNhWNOorqig6p39ZTz5KE8aCCrdNPoK5go2XeUVcuGkOs/+mmKtq6DuHqs21cWuYddySpvAkIvukYYJ2BQiTL5Rq+ySfb1COYQtengW8ik51Oqui6imd1fO2wcwai9WFA6VLPYFXF1vXcvPKqWjbh5MojqVKRMdXYg/jRyggIKijQEPj8p5WtnLoME0yIaUVZgGUIjHi4ku/XUFahbXFMnp4L5VZoNavr6OLCfkyMLlIZj+LjCbjscs+ZioxTb6z70LlAHf+kyRe62Z2Uxq2seVq6o3NmVyJfITq6YsDj6O/Xt3cNemn+xnHrg/jvr0qphcalFdwc5pBk5QT6va4WvBO6H8OxzZfA7b4tWQfsUL/EjnZZceH5CxWkkj2uqPNkB186fRgohvVjc3lLW7Cl/XhdA/kC/2Sw7WwBXy4+PaIYlvDfOa8sQdvCAa3lIikFwxULaAzElIcnBoAH9C7wxARgLeLb99xKYyJCVTH8IEI2gN3d+sW3A4igJYwofqc5NGJESJ64XQ7GcibC3RfkTBdFaesHfkh1uUj1c5WENVS/xfiIyBS+RqeAqOL4M1p2P4QQ1Ucfr6doiPBKPbQpxG2lCY/XF49PTg6X+ZqPVHIDxmr6RWpAUZwIBV26HlQw0hiv4uxTshAXlyGNNbwY9EnthfdT/N8Zw0rrHTzZqUQRTVMoUwFE4KH+eKXu49Bb1YAME/QTpWbcmetl1IfjkTfWBddrvMMt88HWsQH1pv9vvVUCf+XU3gOBNvi+OpMAl5nAZlm7G7Sb+Jag4zpP+UZiegRqGy6+E3g1rQqlt2AEej9y4XuScZndhj40rwoDFFtFEp66N5JqMYkJiqoGkeArI7jrBNbJJE9BxchCPe6ipP1ehiM6IgyDCyPLRFFncQVPZ3Dw2hd3ybdYKAlCyEhlpHV0lWb0Ew/qGolIUBdsJiJJsTC2wFxIoWZ3Fql5XLng8/UOjOg9e+vF0QaGmoTPisz3GIGmCjaqlAgoG0I01ctdrUit+OkCDDYIn8bRLbkMrurnz9mhGeIyYDGRuCYQIrKZOYlMUqlnA4xGpNJVW3cVhYhzbMHQR+tfOHhVt2t3OjJ6bf1EDIJf/qLiu+SXVVmmuivyogaVZoNHfj6QC3+nPNthbO7rVmMks3GAEUcg/X3JXMa03p+3MVp5Lrn0zwfwVDadt8kDb8EcxwkxyrPBIKWY+vmQBwMRq6xurWGzM1ysgAuBcljb1DCtQBII9PMAP3lIP0uaxWQmNpQcBUFWdrt/j2VKAPLOResyjIrAwIJn+BhYnDyPLzqTg1c+vwujpu1eRkLfMe6nWOAUOOuLARr+BF9C3nX6EEhi8I6QlVzEx4MzP9uQ3ruXSzrymRU9HwmQICNTlCBUBUAFRxUxr5ynT7rLYnA+fr5yowhH0kDziH76jB2YoZCixSBEOup4RDQWTJNFiJBO3wnPRaz7QwZnyCEcAQoD8jTCSrpCjb1kLTPwwj0T9nOg8LDoAA9lmHc0w8Ce7o15knLBcgxBzcLIIp8U5ogLqPyIleqVNvZNtLyMNy5L4EUnZaLr6eiDQfSzHwM0aZ28k9ILeJiTLS5kXGrOAiZcmwS3ni1naGWwRTNrG5ahOIEVkKtLSpA/Wbk6iAU8VkxDibibhVPn83opz2rxDLtqKB19U6uU2An1mi0AinxFhXdJbMNDJMmnfiwFOAU3jYhbdRgVptZdoA2aqQpVtoTooUEBPvscG0MxHN1EJE7S0kVz4lVCdWyhClXZHCb6DrQMom7dBpEhuGqaE1f0TCMMGg9fllw4x3IhCty6W2AlqmgOA12LWoZRdYMYEaKbmHvgss9LLo+kiSAu4saLrPsGUWFo1SbasBkyVbSEXpB5Ib4wHdWNcq+AAsKxoh3cBg5VzA+GbelaVBT+DdvdauHqBc9YPrswdZ7lmDOeZBMfuwxYzszNQdAH++AA7s9E6WOgiCHFOS/jfLYZwMqqsBw4mGqGkLy4xm/6mrtNONBnrFaqYyu2g5DrzAmccqcwnD3AgaLGgUfCvyHerYNqxJowC/Wcn4em2G9fBGSBn0upJIsibgHsZa3QGLUA9WOtklhyP0SshJ1MppCNe7Bo7SQthY9qdMC+j6eAbNggKmraDAxIbBefona4xyikqZn23nnY9FIQMNC7Ob2G8+7AtetH9ifhg/eiY9JSY6iEyjtfPF+aX73/X4eB+O8t+iWo8n1RAWvoDppTD7rq4/6797IDX2yLCSeyUXL5JiWpN9NJRGHSkRX/838eA4NjT7iP3xr5Z687rRxga2PuVmXj7qK0NKn2iImOns8UbnX09XEHdvaMkn9uyX7W1tHcH+mbvqv1z/RSWNNa5bRIf1XOS2jk631S/X5tQENHzBQgkRkERmcAqbLyQzQ1WodUd8ueOuuinFo1OP6EexMfqrbBVWGDo36JrmOEO364+elfT/vlDxKgzPqc3VsCnDRJzSSi9++5gzqa1kOXeoQLudRQhOS5AM1znB0wYM/kstqatpere3ibkhBpuux6mv+nHizK7jI3p46qPJTbL0pG0bHBIHfowNg7NvKoN3NscFCdy7Vqnr29xCXR6oTvSCCCNSwcIqBHKDIpG7IoZBygY3T4yl9oRQw0YYOlmIwVOEBTkwU/+dShFq3CoLk0WdUprTmJp27N6tSmzj0PdAuOQG6Bfra798gyJPCxmacuZjwu3GdRWzuprIYTeC7MCPDE7kZzCf/v3QASiCYCJPyIwrv/4h/5DMCfz67Ry1calCPQqKG/O/uyvNoddSLEccJK+aC2LWj1CNyBQl8CKc9WfRCpcsRaXVRutZaUmWlzS6778fu/hHVHxbp7U+yBrlE6jkaSAoEqR9kRkK1vMVudGYD6MrsYskRbMnHNfJdUfhj79eelS+2uzaWAgNjYiq430yQHtwcmxoflmRmKvHJSDk0QaVBXWCc1nIo7Z9VRV3B7Jegs1Z9xMQFkmSWJ4FGEVF/9AcvfTBrqUSE71jAwqtj+y/sDP1wKMqrGxUUQIZaZei0YgubWIWaiTe0rrb/cOHy1yUMAmBd7HKvU8wXtWz6m+BhzqqRTENps2bnFB7c3dg0axkg45d9IKAEEEpArSEb3H8BuklNtqTuqQvBTAJzH25T9RQLVWtQIqHwvttQomoZF6aNAiHCp4N8/iOqxyMGdiowMhSIzI294YmKoPomC41vKKz6pZx/I/rOyiA3nLF8XKIK2MNLvP8AlN7T3wGYRKBjIBy7gKjyA78K0/Ea1kZB07Q0yuz1aRTJI49wT5WrBDd8qBn4G/N4RJat62WSyHp70/nNv6nkLZYM6I1ySxm3Li5S+yJwXkJ8QJXh2m32mJVMP8lQNdzXUDRKFM8VFr+h3BLIGsR+1aj+4E9K/BGqGtABqeVCakOFVkGMsQH1eGbX8fmg02iYQ1+/UA9NJdmfSyc5zQEXnKuefgIGRN5Ilvo9kI997E6V3v6wrbm4HFz4n9t8i02svBbgTENUsVLdETJpadyA2/BvCZv97+P3RT7aQ/OZiTf37ne2k39vy6at/bgG3Kvpas9/Nn3xlRn465u3bA7cXWJf6VD547/z20PNdDEw/f1FQN5m/54W/vSskev7Jns5zffQ/JODE3fLNlZBIWcJh0OHANvvIsOCkCMXbnVNFdT3Hbp1y3hUh94TV6eqprIIGrWIycv9+UNiaM6RazcDkwVzV+httM2Ha7MXrbb2/N7OlCSaffciYTi83Ymfjb8rhjiefdvbtbuP4Jzv1uc5/+DWu7cQXWHZA4IIhsgAVPRM742asExBTMZLm4DFc+OzPCz9XlC8SV6LUMXImscRqmkYOJqzj2CMF0zjigsojda0E7dlnQkp+SXXdhq3jMgpLq9du0rbxZlpsLSh++0lSZInJSDp1Uq+xJPhoZmuvEN0BPfhEffXJCSsNeZIWaALIdKgZlDEFdn3B9WJPLZ0az+zXi0LM520XGq5zy21tHpB94+KEbfE0TSKM9SMgPJT/HaYXDq6656MdowjplLy4QYdBn5Zswkn+p6avnGBD4R6swi6LgCHdJ0jDDrOvbxwvvnr1WJfV9Toe2hD25IGuEVBWkoKCfFrp6dKjJfE8zaoDgH80w5MlpFW+GywdptA0y3M3rHkxnmmkkEkRY0AkE8lQeHhux2OKGcqMlTq9U3e1zx75maCJILsMqV98X4Q8tW/RHYFkRiX2la5u2Fm/8BRhzvDl7tPKb4ISdrt3YSLoqkHQ7s17RdjVIGBbbOtCudUIpsDeugrzEHoJ2tRASeGqB35qZcaJM6dP0Ln1r6dn9SIA4dkEnRPDdDmQnxjL1T2T88WLU8fKzvd4Ui30QSRTRh/zjIz4ro+E/XqpNB8V2+v0tgc2ttzf8Yd5l868fpHOCsPMZYQ+W6m4/4zaVbzywXTcnTbT4aHWpMtmwTM4kEmSqRudp/EEiXfjgiplb6bob9IyVPfWqB0jJVKl0iHPzmntMdKG5iVX0HHHaadBh9oMgCCHMEFASbPuW8vAla3w3LaAHQokAxZXA/1swS9dXtoTLLCPVmJgCKNH8hhiiWvmLzay8dRPGoWP5P+AnpV2MDA/x4uQZQbeG47JWBkf9FUIWYYCpAaCsRkQaCA89BtayUzQH1XTS/1IMt2hl4jJSusgVduwhaVhcCjad+12MrYgnMC31yRsnEvtaBhkT8riaftARbNUQg02olbV19zAGtVO5Ne/eGNTOMqTTaevtrZ6O2PCzhMrQqxMxVAbbA9hT66ePnYq0GYmIr1tbARRs1NZX7rPxgzXDf/w09KBYMCjWpo2QSEnmcEwyqoWyPYG0OfbKx4FHP0GPc5aeZFT0hfvfZfDY/v4eo5U1hGs0LYb+rFRrr17YaDKT6Fllsj3CYviGU8LMhhjO8J3V4O0FR9wx1UftEzvCjaS3TJopS3cGgx2VU+P4DO71Gzh4wL05dk/1EH/Igbgc+CdDZ7r9vvk+mZnJ3kC/w3s2/PRDip7F/XdexR3K+crMkJsjXIBcd+VhKl+sFOVGJejjqbtrO6BjrvW15HBsUmqpJWdOl9ssNJge+i6kZoAD+ah0vmTX71Xd41b9uM5fN0AccoAZ/3aqQIhgTBduyTpYvngemcryISv+oAflDmmWF7PxhLVSbi0Nc1iz9Xq/L/wk9R3Ly2kg6Vjl7oqM10KO4Uzj9b/V3fn1x1S5retNxrH+JeXPtpZO73F8popmyZSKVVM/uGw8bN4WOBuAB7AAPoES2kY9oCB2ZV7IGP0/lonfN4O7VvziVXNA3dVHClbKb+EIPz3xEK1dBnyYvtlJ3hnEkAM13t0RdB4BF3ZTjKlu4wh9lddUufu+EYoB0oYyTa8HnIVe7JZam9nktnVByPBJ/tCcbTMqBodmI/QWAFftyR+AkzwQxXyvPEGPx7G+oGwF/unomuNbFbVtO3uZFKCdjxMsrEQkgIWY22kQ96DhvqfD/bFrnG7/ILRfUxpMqpZmQCH3uysKuBedFSxg90ynvR6APpYYBC3lIcKMwWp48+LHdttFnzdPT6fpUejtpg1xA7SS8736KxkNL4IHsmAEgTVOilB29uHz5FZGGlYh3Z1r8vvM7jzhbauhn0XtKWTar4uqvJx7qYmbVUbmmR6J5Io1cy4ibd13zhBgsYVGEOxsYUBlC8CfXXAVIKbUB85UrRNFZ+QpYw9nDkYerh9YI76+2Ns5KS80PcRHV4GDIZJeCRBe97ROdva1N0SM+3ctyT02WzaUj93yl5GphaHM/huhoSNC6i9cvhI2fVNUCB12gS6FbIyHwEOQQu7u7OBnWabB/rp8KwklTZ9tFh26dFCRmli0q1Nh5AF/FOwjyaOPeoCNLjUrsnOKmrU0m6LXmexGfTWzj62ynkiWg7wpqrpOHd52thJeDMHLaKvxCxsH3FV73Y0XeTTjAA13yroaEsDzSLmKFe6ropZgDA1N67CasNk3SPJwnqFHbRIb4uHIqSxbKcZ6/2AzrbfwX0iXNuuHmgnamcHqTo/oBah+7YhxG+BfRUfaHsaGAvvNFr2cOVHmFAEEIyVckzbbBhjMWnYzfexRXfP1XL2yL7xhl5qO22hengI615IuW46GH6NJZl/DtFHu4yD/6Eh9fvVMcR2Nm+8q1XYhvu60HJjTvzSFr0G3CZiMTwOCfTKP4JWqKo/AU/O6d/mkxU1tf3tgrOZy2dxyNywz9tUDtZ5P5Gftr/XseQZS4AdZMtkdyYfBzOuoteBBcJ9Gi7vYn0pQDuGeNJz3roEtM2JFW+nqBjIviQXp4q2UNld9kgXTKr9KU8O2a9dtyBse+ZoS4fD96s7daMlJI+xAI1IJygDAVOgU4DKRLT95eDYok3o9fXThy5csbB+z5+GzaBxg53BXPNNKP+GmSFWWgVVbWfT5trqxSJJpejJkYFWJaoHG3GrsMeC2q7v803dYGmoLavDk569kI4pt8v0rq/kXfbXC83N3BZW7QpYipXdGXhQRG3ydGpdhbxadupkBbWrOls8neXN+ousQSITbp0ikRy0hZrYr/BzNhIijWuVMrbKQDIepYAKoq+4T0UMiyeWJYi3s95S7CMQ0sCXJzuATEuUtpC2kkESE1WRXoDVbGUGAii9OTMOeCKipC7JuMFoecZbauppkVa6pJuhGW50xpqZ2fKz1IZscjhHPcozZanwPT+tNqvinySQDKwc1dKfQPX+Kir9a1RS0O086nH7k17j+hnJPyCA6PoYhB3+/eDinfr6P8bvXPAA1M5o+8EgiuyQvzcd87fpBcn6djZv82O9S6vHr+OD1pDfx4fL7L8sg5m3/Owyyfe9JQrGrTBKpsJRsS08Nbsi0LAvEloORUrHscjoOcmXL2fDmcs/PZXfHdXOuuqOJ4q99tnv2HrDJfr6XpEqbYYIaDgceXYC/n1NwgglkMhSoEKdZlP/edoADEDr+cNwl/ODJ1xeuoSagwAREtTFyHCStKuEXo6w5PFlsasXyreagwfQ+n/GLRstC0gu3/nA1KWgXT9kfvGMmgGV9uzHCjobX4dG7XWp8Jlzu+r18/cTLWtDG22ZFrgpHU6gMtJWmTXPm0MxVFkMixm/aMvHx0IebGyKYtw0uNsJyou2fiXsM3nwu49PPotai67jJwFHw79/20ed8gKteq6RRb7M5gw2jaJSNzXMR+rboFLLOouZz1qiFSfsqbuFvRTr9MMaHAuwZ5ioVDoryvmq48j2kkR0MDadjJthm03v54lC0zQ6e2otGtdZtH7waYmc+Mq+ZS307BN2fR26nu6Zt0QKtIGKasIWc6tcMPDcejoCMwtXdhqBrdbAmsXNq7aLRO2BGIW4BDEuFHIG62ablyqy+PPEjNJyqyMyolX01yJadnqxcASZySi5wBdL298FHhBugMmW2+uyFyq999Wy9RjZRcu9qLaWVV7NTfbdv1rDM/FP03TtoT+wg/jX6dHZw3Y4z3N+C17EL1LwUrb1WDdueSuOk/v5XBzBXs720dvP1kESh0elc9CQYnaBcd3IXo7aE6x5uuz/p5N9lPbzcZDp0o/8nB2+LYr2crOPwX7ODvJ0VKATTBTmYbZjdmB2Ys5gzmLOYc5jLmCeYMoxx6YSCAQCgUAgEAhfC6gO3FJ4d+qsAL5b/ixjmPysKs3KlKuwm1SlKtVq1Km3R4NGezVp1tILONjfcMBBhxzWpl2HTt169OpzxB13ydwz5f7ggZn20IzZxqNVOXn2oj2jX1jIvyZV815sm8vBQ/Bn6nsySsVOqOjULhNWFT2/voafmB/qyPitJIqeZZ6ptHloMBOP6T/+BXLZhzqqf4npCEcX8zU/zUW1kW7Rzb+edKqhkmK90eIEG1jT6xBVmd19CC2pYbNY0ceVpUL6XdIVtVxfU+NIkZfJkKOKEU5/0nkwRq1gv3HoMppG6avwISggsMGGxq0xuiY1VmHMuhrAKM/BWK/nGWPyR5Nq2fYbiOm91ZKmg/Zpj7kxrS7MqxBBbkVV04idKQrGykJKe87qkWWel1bM18PxtPfDHULqxFM0JBZu3qFuCpLj0XdCxaQEo8JMHnhxSvqhLZJHttPX0dwMm81vjMM7Ihzfv/DHB7XpL+dK3inngq1JYQPcOv7o3ngcHks9yhrZabmUX3FBjBVqyWpBI6mwwTeB1Whca1RhIJgcTpJCXW/FkGqlWWFx4B2DZ0nLmr5qU6ct+rfQLeZV5o9/YeYMlOQUoZwllEMsURMxLCfg7Sh4LubMx+h3dXMfGKUs2Vj0a+4JpwnIf37a8PYocjsJJOIYOgsRTVmTXlGWL0A9/GmaZmhdukwpsTdSxFSX/rbon49ewiII5Um9WH/tpqoL+Myqm4T0kVX8YoIsNXHwWoL1nTSkTDYXwxy3PB7jNkF/6XGzPEdhlD7Y1KnMWYx5JtjTyNEsoQI7FD/xGvvUpQnKikuwFqCPjGZvFC6aYxRLSEh6vBPGa6UrYn2lJaVUNUbThZmzexqqeUoa3Uvej67PTkYJT4Kna9y4hZGGPSXVpUqqwV6+esBrLcHn4UaYSVQ4bSG6fAepkmxZeo2nY6F766XoFSA0bHCbhDMzYTFm6alK9ZnsozEtwiwpeKM0CxAj7020HcHtXCXnb/LvSEgZwR9BdOrK8Fug46Vckk4GW3lKXMdUhdpcWHAfzeNQIaA1tM7ycxzvu8Q5e7t0zppIPQd02RXB7YWgmEXSi38buV87Nl0mzD41/kPIiYCNFHm4C30OHkU7WswpxHycBLEF9VxNGO3ZkxMTmY1Nykav5bjx0Q+mVacn1iQku/viCLoA2enqNZwHgtoadP7XkOqkcdoKB0LIkR9sMEAzM8U6taHCUocY3Ct62OOAbk3p17vkKXi21UkE8dJwuFupJfbspqDIe3d/J3M4TrNOBY0r++l1g9ljeYPy9o/qlWxGw2FaulBz/vunsRcpn/08nJZtfDxcls5ExrUkrU8X7xo/477EhDEZ0wsRFUrbbKaUUtyVWF7aeOfBOMf/x8+l1VEX7MOzB87j9kvQ7LcmCeE1L4a74/+wQZos8u5RWeu66m/zmXOOcAVWuP2b1Pzfp3J9m14Ih6PFaTuBWAlO054FzEP5IHXXuK5aY9VXUo6C9m3RvecIMAG7ub0VjvgNGYm7cQk5mfUuzNBN8PGxoAk8E4VFtiw+quXiycGA7KxaHVQqAU+JaRr90JLkS6UuUyN2mZlHXglNiv1o1Z0RVzqESYXM68IsZn6cALXxUm/bwBFfDAiONMweY42jpDpxPsAZ3JqPOTtlw1Xi+O/EKP9Xr6IdxrTK8f4nQ2utbhsGntJSHshb5DPyE0QVSAAluRMl0XM78+ldAIWAcqxcXFOT5QUJIGEkhiSF65J00phYSDvWJVayXqHJADLMG0MMvbsB0PIpALR2JA+0eQyzQXtW9QDQoRXvBkAnegDo3Eoe6OLSqlQDQLdVVgGA5gw9gKYE7xItdMee/v+/TR7AnTIo1LT4XPFzoDv2THGbPAh3cqDgMnDYhUjcXBSV8EruwTKXn1yV/VlanJA2A67WD7xLzjOwnfrimSsIaHTW3VrRELMxgDpd/UCfq5+uPepM1XQJkWX1IMvHJCCcZsFpm7PClHBtp7ygQUVrbG2Mg0BpLS/s/gDI75n8bWO9GMV7IhaoPONaEBNx4h42z4/ba4b/SMiPHGomJIREkQTLDE/z51kgzUkb0on0YP1iJlFDwpNRJPsnGD2Z34uJMlEN8MCAA274EEQEcU6edZePuOUwiZUkviRkOCctslDhmm6j1sWhdyi3ux8eFywdsHQ6wgNCjHQuH3T4EfoGFrya/LX8m2EARoHVYe1ZfWNNFO2IvT+yBc544kcwETlh0AqOW0zBW52lPJcgVd0s0U3exDaqlGd5Q9N9llk1ewHAiCfTO3gFPyjPudxvXejP/AxV7QAJSvSF3bW4EFzQswTsFZbhRBqRJOIKKLwdcBRiUdRRNEhoSoO3H2XvVfBxVf6h3B4cNWP1oQgiQgZb+qkdDSYOcBEguhWqHczZh2XkCwD8x3JYXzEgwCBQRRNdjE0QBRbWONp90We4EwYfMUlIyCCHIlfM1mAa1eo29XCc4aZzFq54Qrc+n5078wLd0nk9H1UFvnf6G6xrLY+Itm4eN1afxQIiNNi2lfP6fuvp4G7ECjdO7aTAVrLIowTpKz/XqYkDdLhv2I89BS54RJO+wwPN+bkiZue3fD+zFPdplaXGn3aiihqspKzRU3RNxtLWD4Z9Lm22bOHbGgLFlVFOybW/4Io3AYQQRXSRcAMoJ6jTZrc3uwXdMrSKKmKPm48OQV1HR8Fg0xn40tHYXje+8rC3+owoLlf2fb+iy6G6fVr00MswGvAqVPtMFQtdLTktoyaSqU/Dw6aFujqtQAe60Wf5IMAZMTXxTFuz2j7TPVeLppYjVsl743EcRPek/6Eh2VH79zNVGyEcDqCxHwxv10z924ym72obKmNHlY5j/9MoKwBoOgjKeWsmtHZKUTXKzSY/Yiy6HUKbdX8WuQjfsmlqQoUDyEgA1cSVJlPrA2j4KgXqY6pS9OU+VHKKKVebUEbVVYXKA1DrPFinda5T8+aNUGvDXACVbS+zLaK8a1p5qTevgPLYtuQ4nZJH9NF2tRPpYaKq6zSqAECtDh2v9jXd0VRNk5AfTpzZdqSmH86kseDDI5OG9uWhaVrToWlxyFc+9/2KzWFq4DiLOlvla/out6H67aprplurUEuAXBzlB+Wv/u7UCkrfNMxD6aRWSYTxACrRQs8qUZd9cHZC2/AE5JwIV5hifHsLv1n4sdXOeI0PoXFJ06zaY1KV0nHL9mk0GE3Hzrtsbl8afn6ZW2BtLQAXup+zc6AFAUEWgKo23yCq6uuOJlQ0gIZw9ym5JSD12ftthnh5dQ5l3DGuRUz+ivoEzk+p29TUfUN5KtSktlSFal5enkNFoX22ntvS+JGEc+32AtCQw4jy26mZX+WreXl1DrHS5XGUN4VxcxxUyqYUi1JcZU5IKTHjsDFrluTgDjk3hWSbdFinjM7qbbe1BMRWJ78PipeX5pAW6q76P7tQYzz23QSSva/IMIyboNwQyk0l8ACQ9ufzEA12sku6TWinsnycdCiyLppzUqaFvPjKVndAu02hJSF4LcifRqna6IFxeQlIrdKtgnX50smxIm5XdTYx3vUV9QcANB0qRv9PBgGAPNxUzYoe6jI3OandPkHIZKo+6bLY4jLodgCQp2mRt5eQmAqUI8JAADUWZSD8SLerZVpVoObl5TkU7apOJsa1SJO/og6A8+alDvhxgBkKsfTbbA6ExMK2GoCOf7uM+zUmV34NLXCca/8EFI9ePPl9DKAGGBBtly0zMtxepL/i3H5kOhfAHcAjwAtAKeA14OP97u8A/AXAav4BWgC0LEArA60JtD7QpkBb4/07Au0OtC/QwUBHhnat4E8/Ap0KdDbQhfy/e7RLRmoypJtxhJ8H+POtc8w9n7iFxU9cUpIyyqmoimpqrLW2ejrecOe873SIP+Dl/zQ+LOMzF9TqZFfesxX1FL2E3eSO5TIWQ+tr/HI8uYBvyMuCq6/WAgk4+XgfSKcFnmI3nUKZG2LMw3EnW3zbkhizaaz9jlA/5NG+sh8OZU5fGJspW7NLq/JbspOWmM3SJSpqirHXL4QVnydiKKDAggsvMn6ChMUVX0JJJZdSammlt6XMsjB8hgyAtotOLDwLmuL1jfQYlW56AYYZTTBWzvexpiRayxOdjdP19tnPxoXPMyrwhEmhMp5+WEVKIRmExj9OGIaf8AeEdPuIk8pXhknCk1Bjcb7pjCIJtU9MrEc5dBNp17rV7e50/wWzgnHzZIsBS9Slt9x6Njba8728Fw/zc4xvD3HSaaEuuSbCDVWs1CZD31fYNDze9Ce9APpRr7/np39Rby0SGBGxnAo72M0Kuhm5F1Xs5TbQ6LBc8D3h5TukiLiQSBat6c0AspnBYrZwmSle/m0FwqqoEqEq0h4sR/lpHUYwJ2/6Zq3oRE6lUh6LJFEEj/O28qhAtbyOGKxObyHUowRcfUrBS2aRJC6kkzbYsrEVz0UZRhcXNKkyusEyGfJsDVl2Bpe9IeRgSHM0KCeDz9mTBK7FBmEoG5KN8/UYinZn5IfJyM+T8q9HGfjQkFJT4hCRzMsj21DhhbIlB/DyhN6ytxYTgqdC1NqL0TJy4s1/nGRoUbRCTjUQaVLEla/hjUHyethLMNlcNvLkj20pU2xVTNjZZFtT4BHFU8mGQtcUSAo7vnBERItBOqawRzaoz/3dUBVkGKMZbtENdeGGe56eR1FR1Ipa49kCpUzlrJ1LNM+BcJGikCm2KiIbObDRcDQScfImxsSenANPHC/EsyShkiPNl8bTSJBIKkkqmQzNybWwhGNJRC2l5vNNcq21o9BeF0pdkYThqyq9DeUZLTr0KXfmmsSA6VYyPOWVIOaICq9ik7pIAsRiEXkXaRTpkrmsF4lFS7OJQJht2OVeuBTgEZDgg/Rx36LbJrRbVfpBdbFLe9Wx22GRjjhaitOkNJfcGPeEUTz2KlIezTMvixVJd7gKb4R46zvDVtoY+aduiip/GauNIUJItToZHiFyIrQnIQXXHQk44Yiy1sdywz2LGcGE/nELEi2b2r/NZsQUYsQWmpGHYdgW4aW0izqqKLLDOQ8vXmAESN466rhEZvgVbSQV4yULDy2B6OTfUmTXAGTfWGTXBmr7tsnQNMwIa0dW8hFkWKHWDu00Q9OYbCPfRVbycWQ4AbvXkuvEbrthTGYoum04N5V5fh9D7PEdZKjGggVUSKk0jeGqDiB51VrGXriqxr1sKvHtkInCei3r2dwPycgLg81uy4y/VNFU5DpbUYWXWwVDjw169DD0MPRw8AhIkCKTXKS9zi0DSUEoEEOF7XYydM1Q54wLDMJsFJ5IBkghyUap3GQAKqiG6kGJh06MEvmXYiZ+iYgj4ADfG/rsPMI8SmPbRY4cl+dHmVIMUw8oBsO7ORsxYHGKu69p3cwYF5M1PUxpxVzl/EgrWTDihGrFJQ8JKlgKxa5rjBoEAUeSSjIMSaMrqhqTsyeqbQpMokmlQmo+I82LE1xpkBMxoY3QZo7Lk9U8fxzFcXms/pAFF0UXLiRtHDK1BrEWIK5+ccVTqFPf18xMIzd+HhQU6Fe2rjDCSpVSxUyZqZqZMlO+nNS0BAeJqyB437n08HkD9ahqk+/CT4QkaVroWDmP8aadQqCVMVY7G0pbwVoRznkHHKGYK3+R6viPRSd9DJNtunV0NsF3bgJESZaupc76Gi7HDKzjxII8d4GipcjQdHB87WeEXDMDjE4yKOYhSAyzhlrrqr+RJphlHZ1v8MlTsFipMrXRzYA/SWY9O8bo1IOiXkLEqStLM211N9Bok8zB6DSEz95CxaunkXZ6GGSM3EY0OiOhmI8wCeprrL2eBhtrinkYnZxw8RX+B6WVm3zTQS9DjDNVnvl/cqP9wNfipMmQp0yNJodaPZfpd8oFIybd8cCc56W3/YI/zPthKay1fwQoUrYBOr5ihvfujXYBh4LNnjs/Ifji4rRHvZIUMuQoUqFGo1ZtehbHf3OoY2EYzrliwi1TZj31Ov74/IKg8C0st4sAFE2GiFjs5573fAFFLoThE0sikSFHUVzxkqBerNEYt75ro1ts0+O4YedcMeGWqXj28w2bxade++ibBavhb7sEg9qrf88/lrRBHxYRDZstZ56x3w/U+6VgEYTipNgqS56ShfQ3XDqmddDkgA59+p1ywchh8h95eQcemPPcW/N+WAprG+zoly77V2jNiugpjeanzhvJimiRRvb/cuREikdWRAcSAj6VNJUylSqBzdDZIoZjoyHC0qdNHco1LobhKQEgar+9KEnq90Xs0aPtXNN7b2Op9bbb77jzrrun2Guf/fa3eaSZxnIpVx2vSQC8AoW+xp76siRk55LMbeUuxuu9sg7X5WaEk3mSU3NCfiJIZkG4S7jT6B3wZKhxiq1MY7Q2d65bvXDgxaSUJiZ9QMoxULg+q5uNbzKjKX3PjdehQ7Ap7TioAZPuMkASIgMsOLGTI+zE7UIJ2GwJ1jsEr4teyryR+gBsMhWbXl3AtL9azcnC6hdGE+CHRhWGaFh3F43PDYuj4S/oEdAW5PeFH8GpGpEhfI9wCmr8dW1LZPQXzzJwFNMe1b7wnWW3q5yOd6L+BhpsuJP9U03vrRRiRC4YCXUScDaqSAqmIiyTPejXgLVIjgA2wwBcGkeTQbsd2d3uZrK13UVk5YUTUzTyGP5i05g6T7Exkx+LeGBmib6VZ1l+kSJnHiVqtOgxYuaZ1ys/36Uud6WrjTTaWBe62KUudyVHZzrH+nCzWG5fsxGyTTXXAvmWW229zbbbbb/DTjrvqlseeIYrImKauCIjpYUrKnLauKIzTwdXTJTcLrZ/Sh6CKy6axxUfPTyuhBjhcSXGjFEoEZQC3yH9MlSg1KA0oLQone+a/ubZYO3sFNauTmPt7gzWns5i7e0c1v4uYB3oItZZGrsdb8lf/vaPf/1nlf9bbY1Wa0GA3OnEMjLhmbFaP8IXcO4ZB8crl4Uwuxw7ojaPf4+DoSp7DcYuZcCGjVDiVrxJR6d+BgAI2XX1d9JTide71BmEYjkkyfE6kWya6qAxzeBGZBeI+32HhEPqPdOvM/QA0X414q1sa3s7yqit9jrqrKueertZCZKoV4HQNEXIpr1zzPGUokbFlSLkqcaq4Gzt1/ya+CWNu1yjT/0sKyKL2FnGySrrbLLNLn4Cu+6uryMd7Vid4dANkjkkwyWSM9BrSjFDkj72GP5wDzH9I7EKH14ogxphkpzBjcxFEJKx2dPrgMzT0YUiogBbTsoxxt8lgb6pL59I05/T23dmqv/v7zWzqJq+s7YxFgNAf81pgNtYEwI3nLdX3YBfHAaMYSaIo5rg1PvHlmuH3U7kXUGNNjJIhx+4d6JhhV19G4fqd1nuHO+BhcJBTGEFezjABYZgLGZBlk/kaDKn8jkX50aqeTu72MdBKp3zvGEX9pws+L9EHLcwMBuyPFIK5u4eFMpN/+AZop36GjANi27ZBQNBAQK79xyBidd9yAW5mlVS7b/1Kre6PPGKyG1erFX7B7DeP8LN0fo16/Y78M+Ask/mzKlbHMu27zPbvFbp/2qmtWKl59hI/eBfACj5e+ny5hsfSu6VKZkX0vDyv9ZtSQWWgwCjAIvSjRIt9wmBfQqAF7vMvT1bITKx7wH72f31V7mXgDYAuqTryXX7b5m2/xJq5WpRZrwKO9StRiVMVGRlBRZXQPwj3V5UnbSqQruJp6Flmv+98xYgWJwESeqqJ4NFK621101vwww3xli5iXt0bI0l9pnUvAMn63IbbbK9xlr+pDMuuazAY089U6jCWz8s+W3N/3Xpfl1rKLeQ8iupoNIeVNCbbja0Pcn65p3ycsypL63qdq1bsE7b886rTR0DWgVSKrKvs4nbcOfIhasoocJFsJWusYaxr801qkIzA/TRT3/jtFRuhimmmWP6n7JaeKF1VlhtjYP2fAXTusQNd938o1b7m3ea4YFP3vngo//NqYEyk8RUCrPozGewiNFiegvYWcreMh7Wc7KSm7U8beBsFV9b+NjM3zZ+tgqyU6AdYh0V7bAwe8U4ItJuIQ6Jd0KiU06r46wU5yU7x+yCVBfVd0Waaxq46j/XNXVfpluauKeFR9p4rp2X2nqhgyKdleqkREfFenqth1e6qzTUdxJf9PXeEN+k+2ywrzL9lqtangkBmBSIiUG63/0yvbzpc2/70g+/+qFnPa+w0soq7mlPKulFRUb7K8MvWf7IZ21wW0stPUlpTfewNvXUVkdd9dZeZ921Vl5tNRNmwdSvR9lt1llj/zdAp5qYU/S6Y/1UqzRrocm9BHDHyE4E3J+nAeH2A6Dleq2zTVnob3XV89G++v1Js99SkemHvfctLDsqGCt+YTkkVAB9thzQ776/Cw6tEZJEozs9xp094gTnh/A2qAjKwFTgA2ywBVfnzp4uqGG5I9w8J9or5cUcBg+eJBj8N3gtLMoz2UDZgO5/qzRYet8i9g/NEgEvdIpq0Yx+pA8Gn3WT3nuhpAe9kxe5RxhZ0gbzTRLM6hCvCu4GN6oDNCPbNwo5UlrwqYqc9Y+13zM4V8EH7Y9NM+fKftqgMgQW3/H/XEBDliKtk+E7Bm7O1UrLEDetjrM5eOARvLRI3iu57wVnuqLmZfHqIKMAg583tefClfK/affY4qlZKPPzkIlT95EcGQwTMD+qNSiDVc13o1aF2mJFcIp26sh2dzguQUCCHWEjaIbesCF0h8kwgg7eVqGVwWcJnT3fFQqalZDFJVqbaWH8i5NvnUIj8CprGruTX62C/o+GtIdXwUzV8q/eJcq72bHl4GSvu0muCDhtTAu57ahIROdUDAGl4OlORiAKoY904o4RNWhawkCETg1Ruy2uiWc0Rd7XU3xE3XUxEddqtYkzr1rMXJFemB1rQM9KrNQspaLXUfH1hXCwiFdCDtFePZCueowpkDTqVWKdXS3DYALMBJHSg6DkK1yXIGb7FttowLhAlPLc4blCH9HpmxfQPsKULuo0qaZI47atNjtMNvoKXOKu3sgEvHcJmK/wJYvdd1HU9gwTU2bApUuWCGEnDFiL2NM5FQ9mBWqrhNU4sAU3YsSL3cxuZW0jmJgMgn5pzLmzDRI23FcLUjv6XEEfWk2aV3YJou9ffvdRck8Zodsh9PZqNxqfh15V7DSfMFrdzXKY/cJNZV8HWXwYsD4Cak81/5rEerrB7TpeC+OtoHZZ8H1E3gdqT4R7wd3Rrr4usL7bC+p4yDtdwReckys34fW5qAJrG9928PKVWgahYH1wwYtV9NPeTrt1HG7bVKzf27iIW+mv5tidt359T4Cm2FIAnBMPBPp34NIvDYQV7aoysnxVjn10lacu3RJODbeCoxbeHpbssnBfVU7VUFmMoypoK5CV2zOrfC8PhxZygB2+ootKnF6TtYzkohQqJ+L1Q+btqkBcwk2VcHqTVRnt21OVc3iHySKpCm7vrbKSVFWV7wWqlrjUiPt0tB8FmyDA8FH3O6NO/nP46K+/HP+/GB8yRs1wOPr3f/Zl/v2zvQN+r1T6bwL+setJhNV/+BR7mDO6kwMHrXkxTDb5b/9mNf6VmH3L79Ylr5S63pyP/CfO2PBezZlywOg2/vW5IZYOzjywfPoqsKDOMTScix4d4lY0gZGw41fHwAoKnbOjeONf/fw+1rBV65wFWS813VSktM8KHG4tF8gf77ZVHrwFj/AXJysPcEUM4ejKuYxkb4bpV3pgwWGJgbNMXcVQTqiE4QYKc2gecnKcRQYYfSwJw4Q5OpryIIDHLQimsC61geJfPcGApQSYgnDwyMEXbH50cJkooo/jLPJHg1AeLE9As0vLRhYvfCMmzvLBIIdUV2Mm1ghrqO8+8q+Tg+ntv76P/k1wztsBT0LHV4XFPe7h4TgnKY8ctObF25wa2RmbDH9NTVINvDrTqJypMuEuynfewflOFekG)format("woff2")
    }

    @font-face {
        font-family: Andel;
        font-style: italic;
        font-weight: 600;
        src: url(data:font/woff2;base64,d09GMk9UVE8AAGioAAwAAAAAxOgAAGhWAAEAQQAAAAAAAAAAAAAAAAAAAAAAAAAADYG4ORqBGhuBg0IcnQgGYACJSAE2AiQDj3gEBgWSUgcgGw7EV1Ada/GMcEF1jq2G8Juo5VmXNbLNSd243qzYCsR+O4KiFeTs////k5NFHGt27s3uLRxBVH0FOXMP5rUku9oPBaNRFybaC5OIQym0sSJqm6MaLTdHGMXqCCMiYQvjUbLvLXs05JCZkznuVKISlagKpjQbzr7gkn1sCEFh3PX0QMjdONQT56+iV1vnFW9kZmIw/yOVaC87m3CT1vlKT0xTzjY796kfXKxFD8czkr3DmQcTVHyW7tBGfIMTNzKn/AZHSAHJrbCdxPmn6FvbfR9MZiYmUx9UohKVSn/43XGYy47L0wzLYsLE+2EOHLWy08lk1oqjFQXboI9ZGt5124UR9VASGRGZtGIJQXQhY7frRXQtHm0Yju9AF3GJSn+1ngHuMKmd/PPfWKD3/dkN0AZZgopwAOwiXFQsHU8FUmVVVVYMGkFVEYzJsVRunDFfigGa2//ubnfbrSKAUSOFETmQqNZGG7MxizIisQqfD6wfYiXY/7epayhI4Aj7+IyVy5rb2D5fWV1n6+pcA4B/sF2798sxtgsEVYiCqTlNlKtSzN8glhgcCbubcOTm3K5f26dKJDErGu8d8M2bIiL7qr3+PiweFo6uslP6dL+0jiMhCQ5IMCB4Ov1hyb7lxYfn5/bn3DfmGDAmDkEdcyBiYyEWImI0FiIKIupUjKaNKOorYmEBYmNhYWE0H21GfGysWXzc+Idv+u0m588CWehDCaUVoRG6CaWqkzgk+uU3QPhv37Tag2qdXv+dlD3Fpdc1RBQctjlk4OAkTgaI47AdtANAA8zLnVWf/zy/3/7/1Zz8f9Z/+9WffD+8w/GaWIhZXAXrYmBg1sXIwLwXI/KiTzAysLCugJVjbeY+zr/O/b8vZqPo9Ib1i61/8smmP6tU3EnVQ4uWIgduTdMHN20DJEiQgXX5VJora14rS4uJ6eSXDwIEtrHt7sIPGIMXgsFk0xQMIZgCAwRIR7oNHK1PJyggLLz+fz/7v/e+t3aq+rxaf6ReONNnEzMg4ojG0BCIoYFgMYMoMRtzCBLHNRMs7sTlZnpRvZhuuVcf+9fcm8KsUN2d5ClR2ypBR/yJKYQHhL760CLkbAoPXJ9VLA/JlLAriIg6QOh/AP+AsME2DmCtAms4zJy7fxyGXXESW2inVNX1XxX0BJc6UamkOCn7xAelxAB1Fz5SAVfQlaTbP+QC0UlfpkyTsvHBFDyVwocrkMaHK5hKpvVha2MfptWeomFN+z+bZms9rcJYXRWEWg4gdk4X3pmFk/6MVuK3XsnAMhTymmB2BR5BiMH2sQKA1VVJRdSGy+pen9dfn6JJmaIN9OMP1BM8wAD0W4IBbgD2MGxgg7CddxdktbeNAuEkDjdboJQFz/9Pazq5KPp3QSL3rBBm9g8tudQ8yhQFfXbcfkoTBmlR24qidIluQqOcBJ7+lz/tXuqu46MGV4cicQLl3/t9fi0OXOmSgzArQSkQksWV7nApVeZE2QgZpxJnIqQNz9Mv39nMnqSrVlT0yhixTsb+7LzUm9oAXfoOCmEQFvWFR9g/2NKE80icBP6/3++Xz9szd31xCE01NGo0PaiE6NYeL9EYQiQSqmiO9AZRLtkOfXw46GFio9FBtunAifFI0mCwsYAR4rRRyoBY9vOzcKBiDPVULH0V/3ZSvw2/ql+5v0/2E5omG3IiIp4UXiGFSBAJzdCXmdlj4sddM9zCZlgH5C/tUaSpcNgzYPK+Up2o8T/V/tzBP3eKP3fJFpwntP9P1lo62uOWa6XHR+1Vx+y117lVP60NuPpf6rn8PwbVYAcnbhry5KWDbvoaJNRYU0VaYIlV1thkm90OOixHrituuOuxZ4zKfPCbhVa0oUO8ZBnzyK/AwuvTwIZlaGIzimleK9tUcts7UHYnutDVbveop73uXd/7kwtUwMqNhI5LiiJtDgBBJEvIq+pgE9GxcPELS8qDoGgHAo0jVtbxNKQk6BozYzNngZCohJKVajSOmzht5hYKFC1RumylsJg2nZIyCytvt/VISMspWqZynb0jc0fPXXswb/mGHS8cOfPS9JsvawdXPk1Mf6X/pXDKR0UomipQdapD4kkr0pX0IxPIr2Qj2U+O0Rk6RxfpBj2iF/QRzkWI/8rC/+b8XJTLcGWuwzXkErjWXFcuiRvMjeImc7O4BdwSbgO3ndvDHeWu8H3O4S/SNGxulrQ6H1JUUReXklVE2ZauKr1UxRod/dFMdWZ5L7OgvHDd7PMtvNSKQ0ZvP2WRNjsNkdcWwIqr6mGT0HLwC0vVLah4DmHd89Vww4NK2ghi4D0m2/CkvsaWcT6ZKs5w06uAbXpQSVseVNJWEAPvMdlWBK+SdqaKM9zxRPXoLekk4d87AWuJmugbEt0GN3anoFs02/f296x7COf3WM7vcXDtGXFA6m1sj7HPzuHySGweQgbc7jyGY49MKDuPrw4PJ9T+k94sOtAaGaqdBME5GXfOylD7WH64C4+BmOFCThSmE4Y54odOdj6noCuh6ivR3CWDSxh9xdPjSil1V8LIlRxwlRHuhvE0N4FQsVC5EX13N53CDO9GcO/nvNPu8wcgVgJsBQBPBF4SzkfWfAQI/p6gG2CoA65oGEqQmYDQvRfocqEViSeknv6T68OAsGdJzXLj+fL8gL4TL4E0KsVrI/Y5y3Lsi4kiJoYUyPOM55Jeul46E5f8TGKjdSci86TQibyDkrqpoX5YpqWEt7PcbR77oFaahFGhchJQqQqV1Ix565qGmj4Y+HPD1DesYRjKkBuRMC7Bm669FWmv782gx1ZI2NPbl/Zn6RersEkzvaFKsxxLwv+gDVqD9YrGyoXm1S3Nhg2tVF2txxkmI4nU9QZ71kQ/QqBp0HrGQlogoAksmOBCQMbcMFxLNJCF3jHA78jBQrGNEoEAkglbWA7kSO8I4NiRjbmusz5FRZYUGxHTq3EghASQgwG2EUAAAWRhfkiXRGB/LFZlubRD0zcoaQpEGE0ECCqE4IK9sBxdPUMMU+7H3GNqBr2CaQpQenfJ+NN0lZgxijG2tgKaNGV2y0KpYwysMwAn0KjgRRVX2jjfknaCs+m9QpVLYvhPBe4UwVC9RsZSbBPkrDI3FkippUQ2UjLsFDhNIaSM6QSG805D9VZqjGAkSSGQB86gRsCB2ja3tqS9vcpQs4HpC1hW6dMZM8MiaepMlD4JYFFxLGBSZqRkU1wmqFPijZGMAAbrbBn+SBQ7dUu1WCXgZqLAlsPhG4pAHgsYf7fAgJm6JQYM4MzbZQF3dCeOucjFYJVLXbIrAquENhhqYVhltQlXi8UqtaqZl5s3TB2CMLJ5NuttknGGAOAHtEYvcTpBtuRLihmpW/u2BAOtSJpgUO1DmShO8SLZutu/1hwm1yVxEVbhbEKkPFLf8IIqC0vCFw9LxS7mE5rR3c1ZqcllkfkiCT8DtdGajZVYfDO23IyPbzZOzjpVBQ7b3tre3pA8lvdA990cfH9oEBTsyVwlw+9eXg3M7jxgZjmvAAvqDEPjLnt0lFrRnfhFOC/JgBIG16Mipc8hr8xzDZQ6N5D1Us0xRTJcRzu5gxScjRlb8AjbissqazShgY7ORDgi0EsPCRiZxNwUneIhRMfwWWQg03gqSm7ohdGJemhv0v2zgwDZMLpFCdSSIwYNDlQKRkrgr0rlsYyUwXlWLMUNSmaYmUBBCcPSJgL/+dw1F3FQrjYP182F/6pT3nCb/91bVar9gRNWNUgWXboXfIEn1jfgJ6uHy8CqylUl3soW3FVNrFTNaonuqI6I5AOj0kp/Cvq8O7OaQarX775jXLGAo/YULsJT+IhgES7mikSxVuwUP4l0USTKRLVoGkW/QLfoPj2kz7CNF/kj+zgvF+CSXJZrcrFcW64vN7gqwZrD/cot5k7wVb5TjYiexR+Q7/bVtGC+rKqelIqmPg4JBRANSCiCnKXrja4gv2iFIjqIZ0vTa8d5xdX1A2MzCxEt32VdEnPHZRbqBI0DYknJ6QIIrKSscuXirxSHgJSKjoMHIiQmJQfFWNo64clceY12wf9Bd7AHG/SCwTASXMEbpkAghMBMCIdoiIMkiA4PDtjz51K6gc9ENEypNmXOUtvZuCyXkLhOpwmT1bwkv//8SdP98tXFtnShLnHl6CG3zWROMlvj0gsEdiBAR26XHvOzSySRNWXeZtAb7RHMEXCim7EK2hyRJ4FVFaQojtJGivQ5hf3M/n0i0cB7eVOUbradp2MngY30WpZoTjiTkrcNOgWS87ytam1FTnutCPG2Zdn1lNTFOAjMfT/JbxfPLhoRuXGrgqqk+FMSwgwUfPi9eq6e0sw2EoMu1h28aVA4j9RIjdFGTYZE2ch8+T6/5C27Sa9Ib3H7YWTiIipunfu6W+jCcVqcgC15Nk2N3xefKDNSCKRmkGmlhq14SPJ1x1O0hl6sbO94Ss8ULgrevN+1N5U15u2xcPZnaNg1LMIyFtUXUAn4YQgQgIhMFX5Xfo3RnO0bWD6tBj4YBnzGxYq2atPItYaz9VdlZ6P+mtA22pVkFoaPoo1+Y2CS9AM2a3RUrNrI1KS4UbMJ7bzsAVEn56UQVDWLjRG8ciSeoBUEIoOkVg6TlYt1g6Re9vSLSArzUlUujTSVYOQnaZGh85aFDglYmmB80WWXaZVPRfLxbK2CTVzPD/0rCjWwL8B4FNE6r5RVAiPjjeRDeS2F33LAefIbFeuJmsHLl08OG38m+OH3Rw8+3FnfPH2erRsPl24LvVV3TNHS2EtRCl20trRXMj2UgFTMmuPxuyk+KZYvejNXUSiwzFTNvANoszNJiez0AS92OJz3AUEC4QEbqQwQ8VpcDkaqBze9/nT9za+9p9aOjpo4vKApbV8Fn9FmTpBit0WQeReG5TE5UHAtOkpv3yiPyi29xkaMot4F9fZO+ubqtZe88vO6MqHagbBrBhNoQ7I33mOOlP0UqJ8nQeXuNCYKZmf+UpYu5htiHDYDX8aXt0LwcLMbSmyEVzcAUPhhfzQ/4r1L3mMmSsghXS+mKqD49vye9ehS3KxqYe0XOFUelLWCGtH1ervombczgRHp2eN53w41SWqjxdkwcpTRCAHxkzd8uJqVqmL1UqGxr6QiZgOSQk1f4xpkK1ZEGyVdHqRlST23e49eqm57fdGsaLTf4UpKOoT1o0MnjzSN+ipBuWpV9Rcb1IZ/E4MV7THDb5HNO/THxcgynIYBT3DydsfjtIByVp269JxuzYlE2q9hwaakQy5q4AcyuLBDme8ZS80lPzbSsxXtbU/pqeIlq7bud+9RaXAO1heWrl6mgknsG4tBuX2o4fMzWcacRxJfBT/rrNqgOxbAsO8JKr62PU4xf71xUmCW0XYsPeBne2evCdOsHNcp9kz6JTbcmQYWX9pcT8F9+1qknO3fuiSXOWlBuI/KyCx1s7AmEM3nh76uLi1NTM59ctE0PBsMjUOzToSpZ8SCiKnhrhbGUdNk2/a9e7ab308Z3/3wHc2EOw/7MtuVcx2HMKCwysNY8s0MCbzAT6lEBzhFXrMkIlKrxc2v8dW7O+ee3jsR4jLMx32IKUUcWuzGYTmaAaBiUYagpTNM/I7PuPg92s50zzt4OP8HtFkErWAxctPhxHAg2CHKgFizAzrJ6xeTG1LdZ3qj0/4LKc43mwPobNp/fQk3XMAY4OVwujmY9rC7mDZvoJWYxDS4xt+e+lek021sRofbxMd4ATW2NppasFbE0Y6IcHcQNS3g2+D0BDRSO8QarmW36KUSekjWYG09VJCNO1okU3ouxbZoOK83M/aTSEds4c5pEO+RyVCKb/rMTzCkv5FWeAehfOqkZNUbAIUS1RVwNkE3MDpGQzRGawwSVQGRppib/rOwrIoeexKUU+0nLHoY3g5AAysZruDpYuGx1VG8Sh38fMzAx8Yza6Ea7EhbzDKMvDZA6Y+K8r1X+MaAHNb9aHp67H7fYilJl70GvcNuEMxr/tGBplnfOGuRXwA+7qI0iozEYTX/yBAzc+IBODY8D02mX827kyhLPZSSHQl9yk+5XA0mbY/FNpI7cmIe+DKUYJPZ7pmLwuU8k9HpNPFTTHusNplRDlkvGur6bGZQnwjHfGgYhd6ZnItukgmQyeknusMhMT089lL+in9CKXlzvvfXjQGQbU+u+9h+6Q/d820VbPvUbAEHRBiVvnOG9GBFvcejVNzxEi8HM2zc1+txfJOMPD19/eUps6iRtC0pLiZ44aXJ4cMDJ02ZYL4xdpwejaWX94PvHy70phzXDO+Kn6eB6ea6tcBnmLONcyhMQSNb0FuQA2bNH7C5fuT4lSsbmhYvWbd+Jb/Vc9lscsRaTLG5xai/dzOLugGmqlIHsPEziSEF2KA7BWK5vGqj4fatiQ5Zh7wWaqP9rOqGMPDqb+9xP9WlQlupLguHDZwyTMTSW2TiFt7dutGfDVbb03tAiwnoZR+aUEtGDQfiFzCbzowWOH2+n2+WgeaNrRLgNV0bnyOKlPYKTFhCmf5qdmapNGjRI3akvEWD07ycjxjtS8by0C+GXeQdlLqwbyQNQ+N2y2p8LPQ0mw05NocjLsHpiM/yIP6lfO32Mss6ESFzxbcMWjvQrP5GzN2dpVcrDzdGS5y2oFQumCBJhoLZDj3PM0ObwPwScPpbaKbU+ZqZtO91yFmShhGWeNx3CQ6QHyQT2gJMe5+xpvYBto9+B6Z+jfaSwxKYh/MtyCEzdCSZ5Aevf9BHjfXUdT8bYJA35HrryIj4tE3xsqRD8T6+wQqxQzv39URn/avE4Tbb+H7LZhW1ZxqIVcGD0mQU3GiiCs61BJHz0p+e5OO5nVRtQlCp5XSJUV4MMr+rxJDiRhZBcIqMHEurMVMYyQ3lLfj95jt0xW8INDZFSzBoVn9BC98zQLeVWWBi4bQJnYRmrLsADR1O60wXNqJ482GgINBy2ewRsGzEXZWfqFHwPAu8GQCArn9Pg4a3S8QIwhFc/4zUaSiSR84nxweF8b/7ok6iCYcNvFckz7aM/3NgbKaY9QEwbrYYqxMLbJScUp7cyp/j9v4c9IriDaS1BGF6aia8f+qZcrPrSdcUEBhMviA9oBg7cXRrZB3vo69V5VO5kaSj93wWvaXZ1EEn9xN9gIBbzMQ1OWu4Dw/A4bA6/6wXsCIcxdW4CurDVlyHa8EDjmEKrofjcUOOJ3EjboEGAZtiIiZAo9RkTILG/EMOWz0Vt61nMHXQhOgPTXFHaPa1B3cOeOsZsDekE/2IvnA2tQWcI3qH3OHBsA4u5sVsS9j+2Sogc+CF7HoJDy+06ePMiSd+8IbLeBLyhqfxbBzkXGgbcBHPx0uxfZhr4TJcxyvQMTUPbuBV/HM+XoObw+vhTti4do354R7eCt1hv4eiR9/X9+QH8QE8woehp3m80BtP7AObeOwzKPA5FM6Lhb6mKPTTxS79sXRhMwTENwtPYGB4un6AZ8OPYQu8hITUQbAbBlsxCLx8hVf4bZAIQ/HHQlB4ffwDRcPKA4ZFi4ThoYSQEkoJGRBCWCWXEfJqqH42qJKEhjUIh3EMrLVwynWIpoHaE+h5ANtoL7Qe7yPoqzvBx84wlm2kvTWo34J9tgPqhIkDAYQHPXOcBZHVBsIPZKjppDURGsLAB3xBlXU6rAI/ossgKkwMMXYBxX0SxMLkIAERRLeDyILRMCHVCiITxjkGDNoC+zwAO6qOCIC6uhADTCUG5WQYBZ2JwWdBnhBPhJwlxicMasQ1kCtUYzbjyWAv/7CLkexcZxBLYSax7GIsgcWpc8NymM9KFr0QL/C5XBCWwQoi5WKBEyBUsIcDR3XU10JH3Q00wkKpLvi/IY1obFPaWnpHOtWZrnStOxVm7H0/MsvTYyKRY4WiymmZsps18FDUNmmnMZFFF63QI2/BJkPvvH187o3GQlKtceZK06DFX9MceMpufms9ufCU83cKo0JUinaS/RxxcU7gNnG7uAPcGb7JD/k1Gwi9SzXesU2CGiY8otJX2SRLYMsM/bjCrnlic1fX1rBgpNuuqMUOyXlty3VYuIGwpPK1NBlAkqWb6P52GIcCBKCEP/scX5jvJ2gF3aA3XPBlmD+a/zL/NH5T1tQw9fhmfAe+F3+QzzQvzHvjvikh81Dog4DBEKPCEgUqbKQp4/Jb1KuhbdSdtEkr9uQY7PGErGKV+06RLmfBStFtE7NXsNgSe61z7qOgPqVTPhWnylRfD4+VnUsLFWmD9ug0XaXHscLk8mfv6O2N48S1BS9CAl+gEuhHKOhQIxW1mIcsTOGKnbwv+AdPeU9Dormc/XqaERnMmMy1YpWuSfHKUY3q1bgOeJmNsTm2ynbwAKCQiJOjRhcGAuTosbNAhAwlKuzSZswUiu8iNNFCMjIRQWlURm15FBYtWQmV1BFLYmmV1q7aGmh+hLO5JLc/70MeryXUbKxv7e1sz5+8/NcDfa/wClmhbbcpJ1x3z/9b66Q7Hvo0PGEBq7t1prWttY91oHWWNd16yJphfWB9+FWer/Z8lSv+Gc/a/hbRzjbZlmw7YHtn/jlQ2+xkjjFXmWfNz7I/4FAHT4c2DvscXMyTMJlZT2oa+yrcNrKLde7qznRmzep51Otdak0KKdAN4+vesyO9bKRLraZnfur3jpputFlIOadY8+wRMpspDb8N+9WgfYO+K25zFxv93vv+/ob7v8cax9zH1U95TX82iXzXt+NDREJGQVXH3/7HISSjZuXiE5AHIS3s8VQ2CB4G3yzNDsISgWBiEIcQUiB9CBJHFpOSV9YxMrfpXPLQ/yd+752Jquq9Vb23/rGh2XWG9oNm25GIGf+ERGKzGtcTaGhwQyQ2q2NRQKHf4UhsVvIa8Ci4NxKb1fT1QJrg1khspt+nfBn/iINknFC2VDWVXqsRhmMBx1BodNycoLOQvQKWpfzqMft05ncSEHr6FTgE0+oUvSbZ/nIID+fkHDYp+juLeom4iaCbgl/lBgEuZDMcgRdBPSOdgHpzt6eAvsl68fB6gxYkgJuohePYzUJVvEH+xnsrkfo4KxzoA3vTku0KjSncTZzMcufeDwM9nlP2B8Buxy/JPNZy6r79q4mXWBjBHfFAV5gMoD8n5sWFx6cfYQNoqtzPi5ZPDo4aZLIHV1A29dLTpYrKifz57p7ItT6TIgebcreqdbMLw+5O+wDw8bS3JMXAcM1X2izkEOCVicAh5qwJonFd7noosZ6pgSVHjedZbsO5bzszy7J7DCWkzkVBLAfRxHG673ZhA2sLw3nEuO6+EATnXXkM8NPyXiefTr7rLgg+akwiFnKLkxfdE6ikitrJjskoy6tqZpSVrNGQovc14JN+VQmYUm7UlKHrDR8Smq6cgkIupNP5Ocsujgca5MYx0XOmZeK65F+tYV8PhIH53Y/AKRwmup3H4LYAZRE9f4M6jeVp+wKnCqHlmt8TnngjJgU3ouCS96gUwl6v8QXwtJoyBT78mubX7Q3oQs/RNVKYF7gQA3k3aQy/wOnMuHiQ191ZdkBWPgnG1OHvc84LBxqpw8RJZshbuwMpBQjHBNm11M77nwr9j6bLOedLWgzbegl5w16KgnteqTC+91SEY2aj1m7v3gppBBbi4y7FaNBa6xoAvD249eeAJtCSgKO/h3jZpnXI2Wcg8cD6oJuk1n4N8fGG4KdZpXCL8RB84QjFHLULvx77/yMe8k6kQBqyLhhDIdExcwK2CCLru+8ybH9WwuobU3Yk063DrDpezIhvLpytYGbX/izLR9akWnI7Me7wS4JGYfoA35BBVpewivylbDmT6ADIlJ9X0nXBlQWQpdu7rwLJ0lTMy8LpJLtvDmpucJKhSaIV8JE9cFwjKELTEH28DZxojkWEeEczXzKvZYM4qfF6aVUsPmXo65Kl0gPak3SozubjsjDDioiN8UBYJrLtBsUT0AcE+61QSd6V15CDHMzy78FbUJdBi76aiEwK7vLc35NiIK2L5VcKMjUr6dbf3+slKkHUO1UZDhqbo0jAxuRFEdZVKd+f3cBWOYjNf+Ruy7W+utdOrE0mEexp9UPURL+J8OF3V0adSW6r3Oy8QHI3ZQAwUMsttNIkWM9jCl5EwQQOKiDXhL5s3HvvCKzHOyxagjwM5nHX4zlOCyVzl7hLpTdjqXDG8syFlEdoRCWeqHjEs2ENQw3xhcZfBpiS/jqbcs1Kw+FCDGozl1wNbzY/DvyRNFDQrqZyc4qPaawnpRUlmxta7MkIJkSwRIToFRIR/UvGfKawVkIHE84q19mzQVkqUUtEZojYVkBw6cmmp3ZByg8xUzPUqcM1BAwVIyeglo464O3O/gBrJ1Z+AujDKH8XxesXVpZ7TmR4QQ4iIgJtRi89ieQ6ikmBabUtyTbRLKIIJid4N5DL9ascpblEqmfQ05SptN32S/bn8/5jJCcKx4FcWDJyDMhALxbJrXG8HY1KFoPSPaQ1YYtxEbLP159/g6W3bdlu+y572uoB/78/L++HQ4+vj/8k3JX3U/pRM/sTPDwpeZuD+oTUun0ZN+CJOAFzS70mdoTc2emw00ug3KlqE/G6TnCbOtEYoFjdB0tB581ib0gB9M77aOeEY1B6q6cDQIcFoz49f0uMrTUSdIzNXP7+y5h+KPR+0q3NgTPHRx2AmwUJfvnwHKSwG+KmMA5/QVMUTOUgSiludllgWnBLAfRDF0oLJfwEXNVLUCNLl05nCrz1zeVjw5kZqU7iM1Kfz5+BszhPX5BVz0XPk4ZJDUQ8XAxoniYvAenyXr2QqM/GTO8F5RghI2RxFbeL9M0Ybi+B99uF99pb6s+H1zo9U2eleEnuDPqT5ONv3psY6mIUnPSeygBw419UFOU1vKkJOt5bF2DuO0JSwr/15xK/vuihb+v9vNXr1vepBzgSLeJYZEOOEynH2MJi4yMzsLKx9Eo1I/bmBx/bYWjVwHnSGN/FKicB//LmKPpW6givQMIR6gFeBqheSgdiDAeSsAp03Vkglb+7GJJSYLmKEtGt6+BkWmMU3Ao2u21PDdjapUPkBKyHxi5h3++5XinAc3SlSrAyCyhOn+t3709EWqZ16IJJu4jYzDkYRDbekEzrxLruapimJiXiD9zikAuigLw1WqPoaw3fjSKrStZ6IWF5V1xEXq67ASxSExNR52gLoDuFMcAfys84Q6YAbyriB2Gq2dp+MKn4rujCvc40cU98yc683HJ4nTflU3dN3MQJ+Uo7H+o51KJ1p4lHDp/BHztdGMupI8RgXDteBERF7vtnL4dKF0ohGI99bjcaloAMU3Z7Q77H29CUSeF/+QFh1bzGz/nFeTsRSaELfwBXmK4EGegVlDQr3rxC/Wlwezgx+htZ/UwEHLkUd99K1qcw7BmjgXHaKWPmtN8x31Qjp9nxNi/Wcm0fiPeZOQm8WA80xwN7AaehLwN/tIB2fxThRp6p8HJSYNWvp9dn4f5jaWXFoJbMYw2F3+b+dPC3HjEooxb6l0N+4RX3+vBUpEwtiMVUHKRzioK3irWD8vRoegdr2sacY8aCy/0cF64ZQ/bDxWGnXZXmqZTA35YYfzBStilN2WpROaDSJEcAKGAg5FvOtdizJmd7iTIu4K9HL64++tR3NnTkUJ/RfQ5MFBJP4+dswmk2FIXQTqmrlBwC02Cd50UwUsZkQvIN+AWIYm9SB2d2CG7zGEWhlzqKwz9gL6Xpijk6xVlE33r6KUP3+bQ7Vw/6e9pNQNMRWzEd2zZnF3zauxySyxNgUptq4jO+6JA/pvgpRc/DGQozPzLqEYtGnWYJbCn2VscfoDdmZuz7JsMWER0TFmofkWvoOeD5/tcc25/XxOb1yduT6fK1vxa03TjZ3simYVDx5bWmUj1pqIP7fnba0Meu44db155ZT5xa6vsrk7zVWl2V1NMHUng2susmynA10Rryw6HYPfHLz1rOtLRy+JB3dAyzfXIXzPKTog5t7Ry5egx/Cn782RQY5dglnVG/PwPbHep5pF0FBfYAnws0I8ahfLwYJns36+EoeuRerwCE8aKdcRPq6BU/x0B7LToQeazXl+i1QbF9OA44yXtoNDk3I9uDo6V5o6ODnklSR9/eDFwUNCQCNYVZU4FFdGWuvefSgtCpoClBvczFhV3FzRi4XrbC0K4UVpegyq2VuMWL4hOOWivKc1/CwmNRjNOCpRIYFRXudxYyQAgSkAveDJiv37B0BJT1kc9+xzbzquqp9RaGf6I4O4L75QdY1U9sQ7kSfnw03rtdABmyGVtv1LU6/KA4nBjsjkeIC9xLQDriHLIRxzAPhemwYpLxr70Nzm2qg7w72CM7wcck/gZach3mBA+yIw8k43v++ltQAjLMtpVymo6nwSS+HxW5kqGc/aukE0QA38CPF/tybijHoMlubga6BSROjjIvrAkrnEcnT1sYFG2m32mfDmilrfRgRXfDTWtjyZKgdJm6x8Wm8bZLSDuoY2Vn3Q1rU+mSVf/G0sRj4RT207c5X2dm2n+OPDnEJkcpoV1SBC13SFdkbx3jNfrqwXRPpxTyHBzg9RbA0cQKbQ/3v3ritvVisXZcqunLD8/S8hdGWtes+v7MVF+x5Y+joi/vtRBtg3mV3hGptk5+xsRwz6AFATKD+2Wj7D2j6OlEbGNzHLwx1Dm+L45RhwciK7x+l6apjSG8a6oPN7Yc+nCwTILJaMZr/7IB9KhayMKgA+71nQrhxI1JzZGXwn5R8zzI78oviGPVOdsl4z1Ebuy69BDK/kpUntpb/KHO0bPx7vWznl4Xi8pb1560kh9IDaTpHt1QG+dnd64LPvhjQF7u1nXZjOfoGNqWtftAjv3LC88+Sn7mR7Jg0ffnljOai2b6MeVwfJy9o69zX1sW/HbVhrveQEG/K4TuSOgALTZznvnnjRJgW7AuFi7gPgUevRQ7BOYRZziBNXZ2+623Nx6/v9fUSANlINAvxrxCL9OA878Phfq9A7vaO6/DxwIqxPCCoHzU+ZGHd/W2+bbrMDXOmuT0Uv990FGK0Nvni1or2RS+7DnI5tYlII/0bKeZmMtBchs+dvXzdG0Zgdxm59UDFpZfg8uB/1fSNS5b0hP6r9qSgdv+8TZ6+lSMg13a1BRUsS4D289Z5WgmY3Fix4qWbZdULNG0LscCG7IxI/dkwce8JvF88Z3Wh/Zn48oXFQkuk9VlGHjmiXqXQVWMAKdYLT+MJrGH2ZLtLr2YdHjJKYOFo7HGW7zizRE3YWk51FcF4E8VgiI544rgmGykGJY83NLtjTnIw1Um45eXyEaOTUUhW1vTSIdXx3Flr+Ip91b3CB0dibn1ld+U/H44vUd2McpoDNKNBXAktb/oBSPVvoHIUm+qS9OExhDVJfEJF1EOc3WhbITeKEdSUy1knnfLd6/nVIjCbDQ3R14EaRo5D4r0jyDLF40RZPRHBi/Vfb3WFho7LyIDK+pKLlax95m3rx4Q0fM4loch5khsaIEz9MthLrXVhg5vMZv5mPqRXV8pToLxarsRIjbTNTuTmMaSXPYxwFJouY51xWFdhEnB1XJ4Rt8q8K6Jq/W4nGXzoUTX2wNVQ7EGOtVVjFzEVCaptmhrdUMkY4pA3JefDc8h6zEf87aXpItyoqkAmFRXZLq3ykU7pHVUFzj5dLAmTtekXMWeD9/w3+U56vPg9B7IURbtilqiLUZvttaDRI6WWNCmjSA5Cn1TkEcUS0QdBU195E3fueMhzUrTKePhtrvgRAfS4QaFXZXg6f2Qphtn4+LM14JdG7G48pJVqon//t8d63bvdOSFiCeJBGfBWR0X3gDChtf7oySRe+gxsjBiIqCwHQuO42ZV6pWAxuvj1s19TPUlkBTmPo7h0MHaSAcZdVn5x/5cM6sY5WHye4yjtI5q8aFqcarjUF5GTik5y75aj+V9/3OmmfUBHp+ScMrvFP2tL+8H8zjNo79f+LsEqh1TutPW7uCuxqdAL4MLlTCQyUgFXEhXEkfWZPBU8RvkAJbuitAD3KnKEW1VH0FPdoGzV9WlWbfh+UMMbkJ3tRirpJTiNpOceRxH3Ky+szEEk/mlF3loDqJv3JN97mAh+dA9zgzilvnRNv3+puhOzKXgfg9VxVrIifU7BMdGJEoWBNeT/4KQuVP9I8va2xprLpseeoW4BlfduHSm6fnlc/O8fPxnjTGZpIIfjUT89mYWhNHu7sAnAdhHsoxJCAekFO/2GcjB3oZkGt73AAagTIGVGQBPoROYDZ6BaavD1TpQtoHSAbx1soDfjUBv/IvP7QiCuZAcM5SrAg7j7b9twYteNEXWvvkDxs5AycgBOHSECpIeP6fPneIfVRuaW5CebXp2pfgNH0XqhG9vf/B6SDWqImjRGgoahHwLzp5DkLv/I7aUA27DlomD89aN02gpDbwHoaBEI39YAP8uwHsxO80BEZmAedFcTtiEIaep3/MhBGQoS1yGA/Jfa5FSHCYN/40uVEKarI9PRge8ILkEKGttYELquqFaxKabVbhu2Wwf8cVl3tg57HYzWWHZKNxh7LPbcLhHENnT2/dzATnihiX+5dZDs6D94q+oF92zMnSazu4KkpragXqv1uJI5e2gU6vsYkBHE0At1JWOPmyVkFd3QLo4tGdrqdYNhF1Bh+lm+RVsOdcFefCfTY5GU83V+jCx0tQo4Et17X4/I/gQr/cU34B6HJ2lfVZcsCtDqR3t/6J6Zyn7b+DFb6UQtAeC7SSJSkqM2QWVSX4N80Y1YpI2wIWuBe50nGOTRIu6gzaH6n5SSz4PjLqIrN/mRcR665LqxBKNOjk5KqZAX1tTVFRp82AfcTWYtmsO2Cmf5Ey73C4U4uS7ysK6IalrYm3LGU/H6tsyr1pfNqhXTvCYy/hAvLGWTXSHs04JUqUQkgFBGH/UoHRITIp+hFXJPjXj48W/+Cj7Couq+hIw1JobGF2or2HOp5xIQ2dVX71zvUJEAyVGOhlpvLE6ULByAuOqMZdU2F+HQHClNcNdZjtIOFo8J3i1n1Vq7j1q2wZciaUwyfN7V758rXTTyWmsd8+e972fx3WJfbDAThamlLjg8WXgL0dZk1MxXxTAPG/zh5/F+qaQqxJ1hbNTJIsyn88eSU5kvuxGo1fZQl7SNsTx0J2w4e8ye0xKvQGV/zJxPHQoveKKWpCATu3FW4Qc+OF49Q9SnDNREHvpjQtEswlyEhnkaKP66VgBl11GbjUplx1tefD3NEHD9+rXoA0+3Tj6GE/c6aKh6lJEJ2lLmNh7GDo8IYIAbvVWT1jwwmgqSJiIMLgiHO3bwTChULiAwyS0hIHbhaDEt4ICfHjCLsYqL4ynKkknapiSym/O2Winkj714SI+fF9+vTaANW/JxBTnDhONTyl4mW5uJd3S8wkNGzICz2ZW3m2/W9ya51fv8tkXdHt2NNKCLfjrOvspNVV8TLgk6Wv2Zj3VT9ugDaHpeDY/5q0zAdEt1p4XSLbM6ZLw4e0XbNvuZEMH0K8XFjWenMtcOHVEFI5uzOTMjc1JgY1Xa+Wpy1hEyjNmzXxrMP151YmTAXYVJ/65DN8gwN86JUo2J4mnp0tLmqxn9AI2ml917ZwI8+C4bJfbjpScQIbT3UQIyEZtYzRtvdxxou3HHRqBrP7BjRj1oSMI7UHkkd/DBXs55XXdx07eeZat4i3oVbFjgUHHM6jbymm6WBWveE08VYQ1V8WzyurvcK8GVtlK7FXONmFuihdKu2dFq+468kM7JHWKK3/dBYsQAiw8fAwOmdSXaWQLyLc32c6EdERNJnZMMikt6Y78zaxEbvS5Ra1bVFHV8RwL/54cK7ZTHbNs1R7QIgLKikc6GlFLgEO1XItARVmEy77xL76GnOorEZxQQjVDG7WGIGCUo0ipr3yOPuRRdfSflRer7MMAL90kb40L2JSSiEdHHgan6lIEJGKiGNYWAmdPC/DjtSPFd8dsNT3HJYMWp3VnKQp4esRaC95iJ9qOcRdKYUPZhlLVIxmrNNWFObS5ZC2y9WIves9bRU36Pq3OdrY34RBfWCfi+meaLuhPBDqzRQIGpUqZd4/WFsdSAoHTP5Cp6cP0gKzcny8NIN3JJ7FYUUbn0ko+P5bdn3c5pEq4TgpSlNuNpnnJmw4l0WEp+3a7WfuXg8CrqqDGmsjFM8M+cR6eu/psb1kxvtKU4mMI9RSXyu2WfMZACUdKmzzwR0bCqtXNvGa0gdiA7InPs0TI4gONCyS45y53ANPTInotZ1N7DGAafUHkviERxAs+PQY57FFk69zdNkUvUPfM2IISfKhh+ubdU6Vvi7CRaF0rVntDzgU6pW16Jqohb28WtDQTjBHT6TA3JXZv7D7nf5pxI6bQHVbT8jcToAivrqxPdFhLIPXRKLZE0jqTyn4dE4Avp74kWsizc4vz8mwTo/i3Z0QncsZvp7ve0INNHnkt2xBhGHarV2asoE4N256JRb2nSPw2ZhcGSNU8dOQdULzepVJJcRFraPelGZlONqwv9S+uDKnk1Z2bInu/CQY+7xFDpH15j5tukaxt5dojmnrImeQ+d2StjIvOWEedBn3rQxdO1UO8VywkZB4pX4jW8/In5NHy4kd36ZmiZY4ctvZveIt5jXstzTvIn81J5iVTQvk2wleko1RIP/CQIeTU7zuWQmmp7iuGfaQEBk4vkOqb2I5FCo+aQ9qhho8jDOW+kngHbiYxIZVXvkeZyx6GK6veUVrGNFw4h2wpfoz7qYrycTupSiM3B5Dnml8QvzpyeNU3nNptXJyLVoyN9qZokhqUDl31qURVjcap+vQEJDfDMlWfcVaiQoM4qCkuEU7a/dI531xRyfOGfq44ItJkihSwXafMpWFWgcTmmSsr0NmiyAizGXFvfmkdc9Hma1P3SpuHDBcd8McukkLGe2CpLBfWxno3kYsXsYJKIw3CKH9BlZ9NubjFW1DnM0DQCE6WQpxj38jQQfil+Tw/VQxhwB5G+tKHR3M4iz9Setk0bZuur1TTV3+VfiGf9YViLQFoLsQuUYYNxg+N8LxUPDiS3yEkL+w6VbFWzIvPD2a28pWNU3cY+so0mXL6D/itF8Q15XnfZF/seAtzQP7GUFcvfUoxlObzsOGEPO4gFdEnJP0zIFfaRi5//tU2j73FljYT23PZzDmRp0ohSsOdpQz6iJzHUfLmZiaUTcBOeXr6xotTZjEjaVtifEzIgk6satDEqaOvN8kv7gchvC9iSQookdVDS+gtAzPwv6PMpefsnLcX7B5pEubURbP/LFF4QqhCRYozGH3d7V1rm6dchc5HGy/3UoCvX4uY/sU3hgUW8i5plVjW8KSl8XFTwZE8dINyDdM9oYnJ5Q3PmmsfNRWdlAevV605jfHuhdjFpxkTI+iQFcdPu9k5xRCOz9RiInl1tv23DQGQ7QCdX1w0UsmaA9FQD9Z8gBclRB+z0iif0EFDTVRekrfbbU1C8WoGQVO0UiPVUzMqHhl+f4yNjZzSX9D641R851crH56yJwVQUGAD55O3cpVWZjzLytlSBgg6cAYzSKxjYty7+YqEYfLDYK0U0OXDoXM+c/BiyNdvRIcy3bbjSRJ/DY+V10jh7g2i18zhwRtngLJyvUnfZRlEhiu4dPqTl77QW55wSF+hdnD2Z9iTMK3F45UvWY1uUhbO+Qw7+2hYcbst9Ic0l1f1bl3lazGRlNWMXO9rYMgpSlgqQ8FgYmnq/G3fbf1ue4+fllq/s1E2K0OZqlPBVy0U8AEHXPg+i+8Iemlyopclrv7Nt5/fvf70VluIi6Or1/Crn7MxYZIMTZkS5mH1Smz8mMlaacPtK2GqxeO0gFIOl6SV0fbWQ111bL2X+IzUtIKUqIreEJ7vRNl5tiEoV6jjJY+r8BJATkw18MuduFxv/RamR/bX/RzIPvSvfSZTDa7Usgeg83JUfghlaS4ROUR6qTM2S6JqCJ/kkcOpax5/U1yqRwP4Nk27nj8Wsg2f7HShPM0kPTNKzWYu0MxzSOXX4WwIl6OCGNTqYRQmt+rXI1qe7pz7aISgk1xd8zWdKqNZfag/fkFHncuclYZMPuEn0nOfl5pm50lsob/NRVeZEfv41P5IQif48XPeNY2+ATGvzsQ56ci8B1O7UbmWnUMuQCap2TmG9KIS6yW0a+qIJ4JPcGTkHunU8xE7qQv8yEuXhTxn2WtqN4U5u2KQXzfK1pwcZDfiLWmm0H7vVGuIrptJAnDxKVHjvbpkolvfKb8QRUpmt8bnIGWn4ZlunI3sgecXtokmzSR6MxN4juXAbJiIODmqNbIbUc3DFgtRv5RHShbKL1K3hqi6ZCmRXbEMmnHSUP6pOCngZ3CVlpcMuDZ6HSQHkFxKrSkweiR1ztXqsenyZKVmTueup48EnQqJqCFbxI5/249rBuwFB0Chi4jOVGaMlLXcqdZAL1ptNXUnb+ypwaqHI82aGh73jXo0y7gJ8Opm5GQCILdapvbYY6JVnnpO1HIjhREC6ZP88Bl3TksIir060MqaNZAx4afmI0PZ9zK7lIrtb9w1TQDmk0Cjxw/Lzgybmq3nxVlAffZf4Q7tvDiFguAibc9WthAK1PC1l5Ib2a1NaNZs/qAfLzag93g3Q5pBz6zMk7MspWd2pJBLg0nnRau8R0Ad2oFOGkKVwSKMazWYSp/H6ozZYoSSl3B0N7lAEeEQZSup7SEchPBD6KamqDef3+u72eKMp8izZtAHfCTegpW4eg+5E53acekMhyOYVF6WkSSizHocBCJmXTojJO3EIHpKaLcmqIjCmDKyHTkrwOxXxAuh5Zogiq6IYBeTCer6p3lxcUkSzR5yS8TPn0yqpgCHVygF8JYHmPeS2CGUlf2CMiNYOWxSVcrNJaDw7LTKYXZnTzMXTMStsgLCULA8QLzizA7hrJKOnBHBYWI2quqfUZ/bcdiPgE4BgpxZ8gVlBYhdgnkhvBwUpWBFBCukr1Nf9Eflcl8mDrNTyYnQTZ1vVUfWX0Munc2m0XA7+JyzZ2u753FxqrJZ60CVe4rjiGq19gEAW+AW2Kl3RMJqO9A1aZGu6EydDcYVKgU+mzqK6E4UX1EtTZ2z3YQVzwrOJGfPUHbrQcwdTLDGGeyY6IRbYBr4oSt8/aKMl8qdviBbKT5t008Q/UQfEbThkwo+ka7Wv5SBxfelUZqRR+k9sGdch3C7ztIRulObEamRaD7ZfXr/fZiHA0LDU0OoJqgUMsShDimIRhMioNWErlwiZzMmoOPGouYGHKXJ93GHD1V2JCPKVMy9OQDPncluqTJb/dlw8TKF6j0p4UCdxsOs4wMV9TOpF1l35X7vpYfX6iJXLQxdPisgD2z9tWx135e3//xXlpqLHMlHGvq260Xvn4L3404xoMToGoy0uRjh1QkK95pUjTEChXMaEu38LXfDF+FfMeVhBGIuCzIYr46SnPQmFsjecps8eKV+UQKb8NvaoJKdqyU+UZN3i/lXFpO9NRIbVthztbfqWq4JhkZS0gblZTnhvMbHFF8mfAiVlBXdHvSGHW+cXP4GAWCEu3cJiayu4N3FG0FWrg85zcXfNldevIzwamXrCKXzTQZscw5nXqQPEzqd1+faWNXlM0NmhLk0h3ZE2d6Hi8NxRQlaWWKkeeHU6KrLG2yDGKX6nd9sDylkH3tASXf5Yr0s4+CJ3qeyeyEnpqfaileKxl5bbiU+WDZ/JazjS7IvpdgYKavn1qX9I1LcUdI6y+avwFcuVV422xwMsePHByAfvvD8x7lqYc3/JvzUQ/MUBZRZELj2v+qrPLDgh6Xpqi+8sbIQxRoMrrLVJ0BmWyMbk9e5w6kKig5mjnLfDIHgZFM6K8P7bn3scksorRTQ9vTppe5nlxsTnTnMqWhx6BXwgfnyV+HpwdL/a7sxCuUJ/KaAIFD1v3nLPSLM19fP/9yDU+YHxjjKOphRFwKyqrudjKbTXO8r2X16xMv4ULwvVMjHrXxIrJZjxma3z+lMctlZC8OZ+dcy39gg8oZbSPPpKh/DfI+7+BKBTfNkEOVRwRd4mSaZ5o1SM51jUDCyrTSSLvNlXEsFRzPQk4m3MOqS51XIOZdAZ44LGKfpcmoKWpieYQTPlwOI4twS/JpneE/d897flSMVtPh7yVh9rjwIR6O+/Oxg9BF0+2QROhqHi9gu4F57/8fAX8Ne+tdOL+kxdcBQWytuqdBhhQQ9TdvpJooddXkxoeHb88v1eaWqH6Pshm02Wn91/bWz5q+1axBYrGzJdEUvD5tdNdYclFYmuuj4wiMTkTgaCeNSu3Z83lQ5QI1hqAK9vvd4mjYvopvwZlJDDjh2Qu7KTFRsyRIMlEijAOYl+553o7+pM70rZZCu62aJMFBqqVDzy8+BUgEz+ipmtKQe2+vuPU55Z+oIbdOxiBDnjDvZ9vOe4fis/8IDwkI2wCkp4lELY1q4oFO8+hee7SCzIVc9TlPG8lVYWeAmgOCBW2f9Wb/kyqhiKgEWHTf+XD194/zmlT7Bk4X4QC2UDjtQHtgBsnUgSv7d/E/MavfPQbk6CxheCTyjMUj2bIHCzbUdycvngVzYOUHq8C7YJA+L6YPMGAF8dRTwZ7QW+pf3vxD8iCXPhI63o2uhnjhajzMTZBqvP+1aEA3rGr6/Va9h7cp/XajZOuw9tNcg3bBuATU8OunTGJ82d2XfcW5NkHGdb3ehPHcE5IfGmy1wCY11x8sz49TjeVhm3cm2jek84bxm6dP5VOYgSWFNwMI5SfiYPOkvk9yKqFmPcuExu7J5Av6YqSiXngcm8J8gHVRP8Rag8N2rgPLytYtc8P6+lckYmJS/hP//YNKCxSG6D7e1jKzXnGfz+Zxfxzz3m7a2vw5rz7P7c6/jZ43nKbSor72u0v1u8mypy6foBhTT7kSv3rHhNbwxQUq/Gi7KlILJNreeb9P+pC/WZsvOr3MTc++09EzLq9ju9/HT92XM1LZvn8L/J3p9fQeJEWK0cBNTxTTxszgmikW1qBMn6Da9oI8w0oSU4b7caC6ZW8St47Zwqdxh7hRf5zucw6I990DYVAhFVrEkobZIE663MoqWqlJnYuG5prFndCEwE3NPRdidaXPG+MVUNPhReHFpI2oGXq9Zu4nFVeypHIG4YdrJQV6xMhWqZc2VNyalfJW6MZKlSpezSImyoUHRzdt2TkjJyCl57dCkVee5a/efeuW9u+8/OH3lyedffuPd/3vmuRdd9yjS5oA+qG4oVIQ0jEZwL9CFfTEQoH9Jp0b/khBwpBimjqAD+LXptn9YbiuNKuqT/BjM7TQWHDm/1K9qQjjbFFXRbXgaDeb1Nm+dCaMnksihfvLx4cN86+tPshozCa06Hls6KGTAPYRuq/l1cGEC6nBPL+NCW559vv/4y/NruUTG7wnu2wozd65VHzExaEq4lCprQ3SL6E/RRffOfd0r9OEozXoCQs4cmuLYF8dU9HoDwlxuzarUmWs6CdEjZminhQ/xP1G5iA1ihFq2PLPeoWC9vSoqt5qA7KZN35AO42+jrSziK+0v5ISTYB93glmoSZCpEBkZ17IOWlAClDhw6WwlhCsm5dr3rG+mpRncU9jGaHqvwjTQ61EA3rMj/cotrCNbsMoLUCwjGvMomjVS545eWINUHT6eHvb07uM+bslt4oyaL7pnSvhK44Iz963t3y07YmSdExK14YriQpswYiQN8DRcvklzrne+4DeKLOqpmd3L5ej4ml8RH3rQwYM9+77Gr4ZtJCadjXfaNCJcXvMPwx3dIQNjOCWACdzsTrnX1aB0FarFSIkx7s5eTUGfWPLebI5M2fGfq9gzvhtXyfmz164/l2VObp0R4cS+UlVs3tK4C5HqqOh1+S3ecsaRpuribdQT3rkEdW4/PkwFcBgHbfu5/7evoixtMSiTHSmPv0KgBayt077ufuxFCsyLS197UQB2n0V6s2Iq6fSqOBw1lAdfYKA8W9FBnMotW599vvf2tyeHg2bNNI28Mmo7sDqKJA76NVKC+Tn52DRl1GWFUhU82/I2m3MzoPdyT8/NYiJc33HwSugik0SKOcScG6prumXG5dUvP7x+qrY2EPWC6dIP3TYy3KJL7SlSSTwAZhDtaSzzTpNJPb93l16pbHuVblYwOuxITUo8hPViXmSQmJxod0w+y/REQ/I45eLdd9TBldzMB1jCM3qFSrga71M5Jpz9FOmgc+6qeOMM+cvr1ecbzDqldyNf0/sXvccsWPtcgO3Twl36yz2gfvJ0ixIQ//HyvXf05Cn7xNPMu6kTyvrtvAH0/mhOj3/C1pDtCyA9dNeRY+jn1cc47PosMO4nyYbWEIH0y4h0CWYTDvZ9gHnZLlhu8Bw0hZrDB8TYN/IAeZQdn+mj3LSRVvT/6/WXBy9/u3xoUYyXGWoBJvljJPCJKTOzASA/ec1f8TFRBoWH6F5gLa9gv0KfgsgoqzVaMNK2nwS3Uawne+OH9BRq9yjUMlaT7Pg1f8LOp8G54njR8z1Bb898EvixGtq8BUJK7hQtBtaw/q5UKg3lVFPDo+bCfeUaxcbVZwknMTZGf8nNF96PN4YpdN4fYTkxSKQlpzeqJNMlNlm+ZFVp45FguAkYIMhKgZ+kI1SGh42g51xPutISaxIviY1XfyVq5z1iUhJegZu+yWBUPxyM/AcjkpEq+U3ZaLsnVDtFBceE16U7ubgvYGQyKsE7TwvAUSsZgGx6Q3/SzwUvHcHdL3shBs2u/GPo69Xr7XY9/wHW3l/BpIAn4aLas2c2WVqi1XTy+FrUhOqTg0ZFT6m+pDIHMpkad742dVBYQQMEOdgFbjNz8Iq9e+zswFLEEXaOJmpvi2eXZxZQCtfZh6aDkrz1YMJbb/Q11MF0QkdO8Zkd4OhLvTR0EFlvXv2Z6G7Ga1xO+WlG5gCK8K7N+Qvg7EbX7A5NQbMWFcdmfACqgGIWShFY6R3LtFoRnaWlGp0zCczAL/9l1w1vEAmQXaJCSC43RkgklcVygYoCEpMFtJfvXolI2EfnPRaWdkmOCReaN8ROXXldfoveLo/fuHB63fENTF2vZUM2EKO8HjCyXmPH3SBboRRHD2tc8ofQyDSMiEF1KEf56sl08R6al50fj/BH1Z3FYG0FMxIGnzmNVKEyjoiN3I8Sxd0SPw+OT8Iie9zL9rdaUgtWinyhIDrSZtVTPaIOGm2zrIxXNKACsePQPLZituhHVupG8TapdkLeUq35ODjkAmwRZQBfANax51AtOInZyCMzE8C0LxqjmQ6N2RehUb8D06HvVgroa713Vbx3Cm/TOzTqO3IErM34Yg0+kAm6ycwJiPkuaGQ7dMYkyIau2e608mqQVw78qFfSoYmfVGzhHTZP5sg6KO056cGYY5wkpdl9QiIVRoQr51EjT2taHl0w5x9aK8tT40nPHWlOE/05Lc9Xhfk5q6STVBtVE/6KqLczfu6mW+Tt7esiup6BaM8moBK9c9Rqa7JZTsdvyuUj4LgGWY0whN6djPtVYvCRsRfCjftcHmqr50HEme7DEHM6wvLpwrUPbrNkAw5KUmhgD2SOwScVPIYZ29cNTYsnYaC3vbU1X3Hf4lMddRft3Sv0VOEBFFTmbN/pcDnSbgdZ4xNDJ4+OmHrUKNT7bD4NBMJIosArlURwuO6QrFuP3z28HO4S7ebmNCG4+ZHg7JlaAy0qbQ4GWawl+l96zebIgQIWUfKNvAvIqwhMPf1ykVccjKblVodNQwetPHHey4wyOYb3tEse3S3mXL+Ag/CsFNCMcxWt1ebwkfQNMbcTameN27Q/HQrWjjFzDzVoj0gkbexLwW/2+N5LAp+twH5f+Yx4k9hRfHP4hFzMznOiF2wUYbM2Dl4qMHvPWZNxuRKOkJxf8wlcNld81f3Vg+gVO5Mw/RIhuXmk/s0DGTDaK0xUer5xjG3B9y2/ab9LYQLwFNG72Uvl3o9KjFIlcP5g3dMeRV1QsEIRwnM6Guy4ttJ571/u1oXYYlUFIrU3YtZa9uqHdDN69cAk5bz0HdF6kUgVnPALNdA/n7/qYzMUHNYa9R85hnZwry7IPWfVnjXKyDNMS/arNXrCtoYUg7yvJCQjbcAXRTPnaxMUbtJPdkdDpIQe/HQscRjM3chbKPD0jlNVlh6CI5g9Y+25Jy/Wi24zxBmmyfTinsM7vbOA2iHy1jiPTalro8PWbmh6NFZL/C3ezfM21gWZo+sKhcI0Q87XJoWt4pGEJIVMrljk057AoZW2gxG83ADDz4Je+83OnFCQTzqloAYsNncTeGPBBDahCWv6gg+CZ0WRsWnowkaf/kuxDcrI9JaL1O/SIkv0sKbFvwvNe4DvjFqUawg8NuoQag+x8j0UUZZ5FWQCA5lCzbteGS2ZvhpENnLJ7PAMhVGod+UUe3Q7zrnsRx0gEsVs8suISrABFSI4IDCcfShmyZRas/haRF/NJQeHBRxz15+3SF5eD6/dz/NVv9lSqiIUxVrX6sCy4XPQU2GOl/qe8c7w/TqvmcoDArDF14sCTmRQgiulCoRavQpW2waktoakIOFpjGlphplptpgUZ2VaLSEl2ZX2OJFyFKSnilOpz+mrb/FPmZIdoxUVENU0u+s1CyLyFbaPWU6iaeSQQABK5M80otu9bgCpprxUSEE6MgCwWKywl2h4UXR50aKB/O4yAA3U767gfyP4oW9HDI/43DLjSZ+nNffpEFv5imCnmkC7zxGglqe37Cs/Tz7PAvXMVqiOikagQSfUaBAFG0yTWGJKUnys7afIv4ySil1tY1NU/craKdb8D+YIFaGQKOVVF7sUbzVbtdBed30NNdZUcyycrP+elcUGCAC0Fh8BabB4yGA1ePlyqFBbY6104E9AAQk+RnQrEvRKrKp5nOt1uXNtbe1cyABQdzPWqft5yJdv+WTHK2DrP9pfuoAKGmSPu6hS6+J6Y3A9aP1Qff9r+fTXW4tj5ylsu+n81qJUBESgXLoWol0JVL8A6U0oQJZNEYY709Seio0mQnEH20tqQWMX3Wrig1AbaozqaLv/NspqSkBfcavaIKy9YX0vIPXk79ssdclDgiZxeul465O6zCY6cZbUGIYiQnMPNDrepZ7BpZ+g6caNduyfCiyn4ze8N0gnjmxnMcHpxurc2HN0lgtMva/jSXhagDh10mmcVSSbEs9WE0clDpomBKdhp2bpZjHkNBi+UdV1Rb795b9vuWFUozFH2K6CTIwinh1o5zocorS1DEteURGX4scOSp1x08iN8Z2kycbHXnqmrBd6h1lnZHJcE+dCM7Jaz7RpBKUNindTMoi4yE7/Au0kFFnuPNnjAl+Cl83uhgyAt2gJjnmg4u/4mz3zyr+QetSvaW3s2He8jZ/Jyc3vMdi5EMBYhEmQo8LOSEhCDgDDWDngqWyhvMbf9v937l4KYi3D/t8jI6ohm4vDHBzh5Bg5TpCQo74zmjl+1xTIBBzatGxuDmvoiCaO8XCCsxytENnqzCcV2L7jDm3Y3tc5rHooNbH6Mzh9vWjCtH+Yn0WObHqHaRzh4ph6cjRxRk02WEfgAIGDBDIInCdwgcBFApcIXCZQSKCE8OS7BQAAAAAA+HeAPiBD6fnnaT234HgLizdtSbCUZSxnBStZxWrWsJb1bGAjm9jMFhJIIpkU/mEr20hlO2nsYCe72EM6e9nHfm5xmzvc5R73ecBDHvGYguBJ2DxaMi3Vh01U7qtEozcgA5rd3uwRHPlfcVHXXNiQXYDDOQWMEZzoE7jpA1tbJ29LaralYsBNqaQfzVTWnsVoiwpG7WIBF9dxbzGdNG770cj9SixqwxDwGpUaaCfO1ImKseb6ByM0VYM0/4w7sKz26UhXX58S15WT5k2ns/RbSkR5JUuh9Iz2YSUcipoSOvVcdHI2sRVBJIGVXlzZ4dluceWTECKwV2kKBqvXe2tsjCzbAwocudWU0jzNCndw+9y72KiC3U0w4UuOp0j0bn4mEH625q4KV89cvSXtSHRwhW5tzC7MBoHaMLHRGvUHqWy5ty+w1939oAhAzXoaiZMRXnfAKY0plwItkiLJnX59MUZxODRV0/c4fjyvTno/ii2Lxu9RmQ709v/YU7Ozh6q3b9BZyfkU27j6xg5LUxoWIZNWhsvLC2EoOhGI9L5EGjgSWa5IGAWGWWnQWgsbpVzSCK47/O1Q1vXNBBhuDt+26jyPtmUzdZGwSiJw5GbtpNWgLGWOdl39QYYO1WabpiDeaGQq5ezLE3OSJmZaLZMV+GxVUo5prpe2WEsqzNH0soPJGweMyE54SmFeXFY8lA2e9ne7zwFbgHkPtJTaif/lP+XXh+DOi1+RemQGN1u1Yz1RCCptIbAfGbhIfV4DcDXtFau7KUqs2EAXWSgasLfVDi2W5HJDWSZpGyg6Vol1WFGsBNirvm3AE1C5DO2eGAgHKlPSYyC7SqWa3YPi5NxGdvabmppBBSlHXWiMbolZ2+fWdGfjb6eXx0CllHPJ0DnTtFtx5HkWIOYPZlbGak7LzrzWmC8d4rAGZx5tRcs9oL02Jtf8WJAibtmpBqaNYz1yi9kxk3JEcJ5qB3zWvUYjysiN2qdaBi/+KyS8U5DrysA1ASSo1sYvJf5G8mOTmvc0GNzlS+KJXl+7ISFWIWzIhYXOIEQGRyY2rWKipl/iejvhwKPvj1KuuqL7tDioctfYNkqeSUR+Q7MJ+yZ+OwG26MyYcc8AONrNIigDppZbDg9W06rTzqn1jdZSYJq9uRZNY764AB9C9xC2OcSK37qQuOS3b8wulw24BigSxZa3XOPppzStLxLU89wfmNgJBVVe+QuZNlQvqpbPeyo39vEiO0szaw4ob12nol4Z1sSt7BWjbhwT9PWcl83zXOsXoqm/4dm8IsMDi2lrP5jxLpE++QKfViw89VtpRm8hyp4pwsVcVdRS+7V+TClzbXao5+Q2hZKz7XhleDrDq9GBUrGsoioJGiHcrTnVnSj9eduCvbz1+hYO3P9zH+DIaZpY38UvuXSeumtXyGkz4yoiZyR3U0aftVRVUHruVjzse/PffJP2nLxK9LU53zH/ePC1c261bS+8T3RWNF3Y7d9DMF6ZzMsfB/QdQvto99TzHuBMPDfUX8Do9mDvX2yyLWXDj6LEQ0BrfNkxrT96G0h9s+BUMF2h21X8UrJ6TTMx5ejdKaRBh1i1GhFccATIvXixuUSW/vxWYEw9ZjXlZoxnBrQzCeswsTBxtF0XwbaDxIFGM9UfYLh/U6SVr0UX7yPYtGh5W4h9mIJyeEwzIXcrGD8mnc7i3gIJttjMFZGFOIY4jbiAuIq4hXiAKES8RJQg3iIqADsB+wgGIkyISiQCObY44IwO92pjOy3wxgd/ehU0IOaPyVDgOcCoHPDRb9+YkwGgpfPMsDQqE3kUEoeK+cxiEScIJz6F9X399ZOLsBPnEFzCkg7ac5BUsiis1wRkcEQk79OlObFzVBcuqGYAneFXEamfEzI9Fe4oDPG7dMSfaXnx0uYQR+knbnT8kGMGrGCLNO6E9dugAlNQeUwJyJRJI5ODLQ44o/Olx5SNwbqQ5JdoXUJSbiTOJ1C2SHjjg/92Lw7KVAiwQBhBeHW8y6bALGKZz9K/f3x17Nf+NbOmWsANNxriiRcd8KOH+tUMNtiwngZnGO0k57KYlTccrFfCb1s1aAOYZcAY+ra9ZbavikiBBTsuyJj4IV1MbfowcgCxBXHAkiuNnGM6Rzbu1jipBcm7xif+6WUBHkg+AoQzninMIpb5WtqwGtmoJEvVbg5Ydk2vnEiCEQOI5xwDsFLTR8GyyqFpGZD3/sXw82gVqKB2VYCqstWcr12PNq2+rUA7fOlGnzBwKUlQ0HYo2jSqxjwXgU5LdD4SjQcYFmq5rzXbm9EUkJaUDmX4ke3Lc9C8ftN9+fB76FnQTU+0HD24S37CY3jpCF9L0wKDaPbK3GC0gAtuNMRTXtYBP3rQj8EKtjAMTGKGohvmzuJhwEOCCgM2PAQUq7mAuWq3mj4Acp1CXiaVgLd/WQGMyWIqzwpeUdmqHNYZcEGHO41pgTc++C/0YprbANoOxI4gwhnPFJ/F9+n5G4to6b5dvYKVYTQVTDjwESJxI0w5u84aW0KOn26/BlUZeK8v9rNjFQD2okYB2KtMU6M/CU4amg5s4x6OAZhv024n31PMaeBUUJtbsg+9MUYRU5fMQ/tpPr9FAmCbc1p4Wn6KP60lNpNCGulkcCTKOQaAfW7UKO+GWo/Z54P9PaJAz93osHL/CL4l/cZRMwDqw3an+hwM1Jer55pW7WYeN1R70hC2vNQdcN5PbVW7AfWTAINBIkaGEg16mvRcAer3AAAf4sN8Up+yT+uL9qXwjaL9Zk9z8D1lHP4JoP65uhD8lj/rL/bX6n8Dc9VNd3Sz/2uanrbawuKydL1896E/gGI/gHy8eUk0Wx1I8xzCyiz+uRKQ937UIq1GIaRs5Od1HHkTQGkJgGJkvI3XAMhnBaLQwJdRTZ5tA9Wo7T6EpSsRqQYQgQAyswOoBxAGAJlLGn1LbwBpgrtsVHp7poBHXmXtgdhuM90d7sFEKucCyHJGOjvKWfsJssLX/qCorv4KwgBEgvGLrcwHUNJGsnewtWdcrZF4sctai3hPHW0k8yD4i6eOcFukzobFB+EvgDzbLGSLPiO+s7tYXY6hbVjyng6Ot+QmAEW9cSTEQKFp3PUOnojobeuWBIRw4MLkdLKwlacpQVrCemkVehGMEI1mWuqW2aU/URfORk4C68DbSzcKQSdjAlmR3vxZuzxwcLWDMi6YSyokoKrs1UjkZq/6eo9v5gj7eMF0r9FLPRCiLS8VkEx5WluHsNUvfzThTJaUcq7LCgixlMouAHK/W258Rt0tOsLd+LIP8NxsNZU2ACiAjaMyIe9PGXLHzP5y4dxBTl8+fOdcRqbNd+TG+YDMAFDUCJt4ABXzBjloY1aAy4il8+h5iv/eQRReU4oMnAoUE303dgGQRZojAzYeCDB2vrSYS4bDGTk7kr02xvEaNpq71O6HsXiJG0xmnedp+Hwq1fJTRFniwFdb4b7uISovsHDui2czLKFoiz1VXh+EsvkPcX1eI17OHUR28LTLLjWU5QKEkcVLMM07RDfbERSVxzIhroVNLRA8z0X8UBMfHOq29/LyhGIQ76diHqbvu60wO/sS4iw3VVSV2wAUMhgxm8fOVJQRAHJJ2R5rqRIZoxibCcWeEDzv5TpDotOEduTiFrCecd38SBfRmHTeONt0/eZAV6bcGe48wYkO/U3dJZDn3vgNgHiVGqn3KtsMGcRb26HXeROsC1/VGY0ZalgGzOE0K9nIxEvB3DNY5QotE2c56tLDotNh4Rj8FFa/KvELQO6uwWoLY5yqhY3/A5C2+INsaXNNsIbZIN2VnfY/okQR9clCFn2Yjw/j/DsBQAVAg1Dv651XtndlwYdIv62X0wHuAQrgoOsS3lf4lcBvgBkoA6gEqAbWBGqBbsCGQE+gF7AD0A/YA9jP/mGDgcHAMKABOAk4I86nN1KVoIIqahIkS5Mpj3wLeq1D/6MMKrQxRTStyOJb2PLWtrmU0kovoyPllFte+d2roOcZK+9jx5ImzZ30dp6WD6cMLY9nfDnCXjL7lxM2nTsfbNVlBzVI66rFUj105XQEX9QRTdTP1ndYpFI81MZYeWwlIDTmlOX/lYWZCF7woC68DSspWyf71vHMVqzViJadQFgWZzOtmgLh2teQMbk473yHzezvEmxfBKJmCQ1ocMMaXmgjC8vQuMYX0cQmNbkpTW1a05tRVNHEXwfApkkMw1uzItQyT9Ta10/CACIpUgaDWUaBjTEe0dx5NK2bGHY91bI9w15SVx7I9D4z+5JOtg5u4FXOAg4g7Gk9DDw31vAVSivaZHt6A5S81zPh4EISEDJU49sAuG6EhUdExzUHQk1ZgkGiDqzd2sm0a7/eIVazOnrc5twPz/nbQHVNexoBBFfYBoY/j88Xyn0QSqYs+yqHwQLAdjvRnAMCH/0DM6YDWy22LeZBRHAQkGAljnRKKKOaZqazmC2c4zrPD+oFgJXGAwCVynOOd3XJjLF9k55Ttqc3ORk4LYuAKIoI3YSYBQfF4dUGFGVAaCQBFnYLOEMKqIhisCppQmwrCde0IfBN97k4gyetm20UiGZXsZByjA2s5iXQnAQ+ZwFVS8DVFrjqCCCtwOYikIYKSkGCWkgbOW2ZkKpMTPLLJwLS0KDCoSCBAAjwHoe5HnawQEQoDMQ5wzAlq4FssMgAFE8C0bBJqOkHqWhDLQ0nrXto2k+bQEUcY41WCTUwhk2xGcv8pYNc0IF2k6/Ft3k7y5V7tD3IqodSFsxq4AuFGCJ02DIkQggKc4Sr0bXEhaYanCwNedYGtZYNRRFBWVpII1LDBB4gyy3qCGnCCCJCKokUiKygnOLrpGIpEGYMobqAPHuBOPhQAkoQFWIFE67nitr6Dd7FnxNOgFB40ZKhhmqCpCSCVCnS7oVKl4UoWwGSQkTELsnKNaJKDg06jDnTBJO5WV4+lKoYElIBrSpnVjOAgQ8ZlbqNoI1yQ0o8A6RIlcwEgBBBDkBggUHQgFOrAJgyW5FkHcCEMmZq91mgjt3S7iEF2ps87UuB9s88HTiY2+MMjM91D7J6xkz3VU8NzZge/puzkt7N7j8vLPo/0fnst7q+68ZN/WCm9zfgobYRJYWARXNYZelMc1XijwghpBEjj6shzzMoVFXqcxfg0NZI39DR8C4l+NQvnBG3DCG4sYy8yrK0PVe0firEINpkRr7lV0NXQSOgwhCkTmgYoatvPvDgwwMO+DUOQW2WsDXM52IkT1rBA0GjhqAW65eKY/hcjOdJK3vAbPIQoX0JZ92C3TVB7K4Qd8NL8SFB6N9T8IACmPVlOKrUFrJPh4H8YXVjE50h10p5gDfKH7McxDbonoH5axYP3WPJ9nIPMioZ9RDw3a63PZW2BoiBiYEBxABigGDBEDj4oBq+JZrnYVOIhIjQJdrRxt5fu3QnzrD1eUv0wMNGiMq8JXkuYRMWO6quOogy0AkhrIJ8lQjoDgIIDILBk0k/XwYAYjdrKBQaNFfEnr0mL4CDB4M/hjMLDHBgpodydi2vt2EgoSn+lGLqHGk7oCDVPg1ohQBDEakLa++kdCUoKMHWdptq9gESSlXDBS8bCErJZs9WexUVQpawp2fNCmDylyiQtUG2ecIHzzCibOEh8PDBpwovCavIMt884qaF1xoCtoCg1R+04hFCr29CFABul11xIlZlY6DiQBGREJHgCOAIkOEI4AiCr+nwqxkNtEYDwHyacRZyesOY10iDJXQ8BIgwVG7NPGk27UwHaUZb42T1dDLsZJrLoiIW/JmUnqdAkVLkqdBknOnOctLDr8kYeAkSJVW+SsOMNwOHO/9hkJyRQ7Bo7k7z/SrDTTAzQjkX4s8UTLyFiJGuULURJprlLKdF/JmSmY9QsTIUqTHSpNkpyhkSf6pi4WuIOEkyFas1yuQ5KGdL3KtZ/6/DD+NlKVFntN6KKSdO3GvYXqfflxNkK1VvjKnzqJxDca9l/4sXfjVRshxlGozVMv9M+lYP2JZDZwZTRJprqbUSpE6mn7Icc9oFV93yQKGXQyWrBZffqmCqKqdWQM6WA+e67lzMK+6a8uKjm34ChTLUp1xM3UqkeAstt9ZmKdKk72e8arTzlSOQI1eefPcUeM5YL78V/MrH6ufUKihp6DTUis9ejxPfw+pACBJqjAjTRIq3sL78Ec+ra22up7w16mqadBmOyJErT7579YKPhrT6nFG5j775XZmn1mSUp+rv/udrNUHLTUOevHTgp0e93w/Y1gYLFsZgkhmizbV4f+VfE3b+sh4SbLXTPlmOOe3C2dV/4tyCBwq9VOKtCqaq8mjg7Kn/Std+ZVAz9a86vaVfaWgm/n8XSvTWr3QQ4JsKTeWmSgNz3SoA3pUS4QAShPIx8eQ2BIxY9/ASoPSk274Ywx59O9/y9lz0DpLsdMARp12S74HXylX4ydwgEqdI0XJZ8ZocgAy3vPQlseoUlNPZJ0L9leqsq7vn6/KnfnD5Uh+veIfiVBBhIFzhrrDRoWRQgIw3ZCuPUUwvp/yee9DXJBjDkjJiRPJYUx8iHbLplNqhxIc6bjo8CMm3JNJXL4skBo+No5W7mwfqUPON3es5ozAjly6HaD+NDOHGK/ZGqgFx3oMfuxcIoOZ2ZbkElzxJ8VtDVv5Gt/LP/d5T3vJIEvgCOQE4wVGxZBnymh+hACFjAQm3CmjrBygZ/WhThCikPsZ98THFFld8GWWW1aGyO9LR/u1v++0UEFBCR0AOFeWQsFtp1SBQGpcobjFxItFGrSCwm5SgyGYDzhtHeuVUR1rl1Y7NS8Z2UCyn+UOnmDvxiC64iwhHRxbxWf7Fapg+Q8ZMmbNkzZa9iLye/VQXutilLpfXla52LTdjqTp1kegn8P3LizTXUmttlCBFqp3SHThwWRgnnHXJdXc88pTEVulikdg6fWwSvTLEIbFNxrgkemc6tgy07R+SDZDYLktSYvuslpTYIZslJXbMbr1JJUibp0E/ux1IFUh7kGpk9adGf/5qEMzoGMHMjhPM6gTBQ50kmF0OwSOdJni0MwRz2SPL6Uz96Ge/+t2fKvu/qv5mziIAhuJBZTghgx/BYTfXZVj7QO7sSvRDCGQ6dZStHhDPBgJkWeVgrS8G0QvCFutChkXTk6YBAILIfGcOM06R8k3HeQRTGYSP52pK1ggxdIYelkSrnJFWb5gduq7xfYdmEOo7FG9nZrOaXWRp7Whnu9pdenu7URFqM1mKoHQQxJ6tccppTuIIq6qDIJ7MUJlVubT2AjM6SgHCnTtkBoh38BerVZ555cg7n3zzyz9nOTz4PdUFh98jLk8rIFFJF2Ba8Wo4mtQiIDvqAwz7QEnRm7cmoAIh4OM8SQyaYFZUiNUTvOf6Xl+APoVplQmEDSQhZNYrAuyW8vSpDHzYgEN+7Mxb/N02qFrfVN4IWwCgaXIB+m7GCao5s7C8hkx2AhDLjxXasRvbvmjzHZTlTL2an+adF8jyZ1/L4ebUMe3vIj7/vrr36P4vFrCCAVs4hgu4hFs3c6t3ej3zhIY00CztMvtRTnBvhwE7nCCAAj70llv5+/2LXKUVzPsyATvoB8LBO2XKdq4+Z3U4b/HiPF2Q5JLSqXUs3Oo3/SW9s16r17va77Og72wyxHXjmuR6xP0iNwk/NlLp+bYsn8H8uuWVSc0/MZ83H/3bGyj+eoSebJq0+Lbiqc8o1hUL4w/8s5Rm3DFeNGaMbuMPfgBA0d+LUooERQyg6FUJjJYaDrz4r43+DFjMQwDRgM3VzpSl8AkDcRWAu219ME/nUfZu4ikI46/LmrJ5NIiBWEUrfMcX2Pg7eKsShxRVSAtKLb/owhrV8JY2IEMBhR7kvozWtLLVDe0GGeyhVnPo//Dqa6yZdjrw4a+r3gIFGSbEGBPMMlusOPMb004d2+Ym9A5Yd8xkTrHbHgdq6+tx1nlXXHXLv5546qVSb31n8kclC8O73+g2NafA5rW4+S3pQbd60+1mtrE7fe1e6/MtuFdt62bD+lanmupVz3oXxBpWrwoYFHfjXnwNrurQqctLcy214qSXAH3szQ3Wv+UGmSLCJJPFG6rECksss6ZVfrW1NtnhH6m2O+bQXU1zopvuu/0Kgv+P3muFRz5554OP/lfoLyVWkmMpG6xS3QYamznawsFGzpLUkszNTlpb6aWpZxcX2zSwl4d0jezX0D5NZWjioLZytHFCC9m8ndRaFk/HtXdGR+fk6uSCzi7xdZGfy7rI0801PdzQ3XU95Rvoob7uGOCBIQoEe2aEF4Z7LtQroxiFKTLSa+OUM/jPWGVm+maazyZ6b4avpqow3RdRfpqjylwLAhYlsDAiXDEL400Vve1z3/vSh572rJcZK+51TyqsqOe9EuO3SD9E+2Ue811nmHz/+d1O6WGPCy69tHa2u73taFd7SmlZ61o7Vk7b5ad/R23RVJ+/QZJqouXVh6PlOlvz+y13W6Wv1wDpqHh+BKRvWw5YGf+fbC7acvW3/jWZ+GOdcv1GNL+OtHi/64FVObrv2Vxnt+7o/4PbUtHiildzhcO93x91m2HmOr9Flkq63ArPEMH9i8ZRbwurLue6fdqTJ02tNZfrEh/wYN0NX40w0qzr7OY66/2xNBaz/1X0VZ9IM8UMB02V4KreM+0QbPaJXjLLt9knYt8JrA/0XB4/6+rXYMZy6AOPy9LTTKsMwoGL1qAi5kS3kddMoVwjlMOe8FdrCe2MdQ3GMpr84wujImxXqur2hza5mzSqSTvSqERz6fLn8UB1/r4ElkZv3j3x9qW6Wms44ATuWUYqVP5h3dG+uxyvMh01k83neMw6r+LAuK/lUsdS4lA07z83ODCydMUivA5ro+WfVKj9XNdpyrRJNKU2LlXnNR6MpcH3GzBz+bXSkPHe1XRnJRarM0HsxET1R6r7jFJvqg1pP7AxwegNmrfrz8Umo6RuiRsWtC9LSMNEihLc8eAiuArZhmQhdcjV49CUMYEh1CHiQx/8CWCU4zCJWOIZyGDCCcZAFIakhb5spbSR15oW2w/5rEXCf52b/NcSHlHhEH3zqZljbWl5DnR0VuywTwI3937Nz/cuXhk09pg5A+jmGvfu78/KM7AITavczm7ztGon27iPg4RoPZHhQbrZhu2ap9ug20Enk6r0EpEJw5Cqj5zZkBnHbWOfNk1U7dZjUSyumLG8ppSSkaJqcw/P3yCGGT0nRM9iTSaz2kNlWzmz2IiZGk4Zf1PtbaqNkC55WgOwCuOrNQVBx8G5+cJf/8c3rUDOi7s3q62aM3JX5vg+mRmaTvWuHpqbcDSaMH21nEpt5y0vyq7pWPYDX1ImgUxOWjB5pkyytotbal2RxrBVh3mHZFvMbinv+SffalvQsdTkumZdMn556s+mcqxre5v2y1w6vi3Y5rXkZz7alOmzTFznmYaLIWLmkkvh4maUxXNUWBUi027z11vMBlbJs79Ilsp1feUD5l8BlsTEEgsW3m/jhN+aTFDYaLFvYf9nbiyYf8N37Lskf4QXJHhmUy5S0tqonokpXijzX7c4CYYyzChalOv/z7tzXYvZAJ4v6u8XCDzkbTf9/7nX9E7wnPbSXf8DN2Yg8Exg4FLRQFXjkdA2QPBc1qhArYFKpHmrDLtUsyodn6RyrOqLiuq2BGqN3Jq4Mo3aoNUat10etvOpzSDAwRoYcffcLgowHB4riHJUKCToyIlj3QojHAMVoTvmKR7tOF1RguPyOIGUSHbcHSeRkis7UkpDOPPEIp3kzJOXEBjNmb1/ne/5/Trv/bu/x/8vKuzedPuh+fbth7/G+6J/vWb69K/nF/un9Ww4ZRj/K+axjzmjO8UUtOZhRpr8j/+wGi9R8re9sCF5VOp6c97zHzg/+varnDNJAdnd+G4d4BxzHgDl68LAgjrD0HAue3QotaIRjCQ5/moYOJEB520ovqefw8yea1jKdc5A1kvl28EUt5bIrtbjDNKXGTbm3i14hLk4WWVA7wBjGDp6F5Ds1ThdpQcRjCQpYJppQjGWESpBeI8M5Ng05GQ4QwbAIR4xxQY5OZhJQgDVLArEuAlqI2mfA5EFSgkgRqEQkEYutJjRwTlTwBDDGfIHA1MeKCtEl5RWDIssdDMlTPNBX2BPxg4mr46OrnJenh/wfPMf/oO/nB5O7v6KtN1fLO+YwJx4w2lKbSw/7BcI3QznNLPhQWseflxaI3tDI8PfqVHRWbwzJhxqTFSWzqEsn2tzW8xWJgA=)format("woff2")
    }

    h2,
    h3,
    h6 {
        font-weight: 600
    }

    @media (min-width:1025px) {}

    @media (min-width:1025px) {}

    blockquote.text-2xl:not([class*="md:text"]):not([class*="lg:text"]:not([class*="xl:text"])),
    h1.text-2xl:not([class*="md:text"]):not([class*="lg:text"]:not([class*="xl:text"])),
    h2.text-2xl:not([class*="md:text"]):not([class*="lg:text"]:not([class*="xl:text"])) {
        font-size: 1.5rem
    }

    @media (min-width:1025px) {

        blockquote.text-2xl:not([class*="md:text"]):not([class*="lg:text"]:not([class*="xl:text"])),
        h1.text-2xl:not([class*="md:text"]):not([class*="lg:text"]:not([class*="xl:text"])),
        h2.text-2xl:not([class*="md:text"]):not([class*="lg:text"]:not([class*="xl:text"])) {
            font-size: 2.25rem;
            letter-spacing: -.5px;
            line-height: 1.1
        }
    }

    @media (min-width:1025px) {}

    @media (min-width:1025px) {}

    @media (min-width:1025px) {}

    @media (min-width:1025px) {}

    @media (min-width:1025px) {}

    @media (min-width:1025px) {}

    @keyframes progress {
        0% {
            width: 0
        }

        40% {
            width: 0
        }

        to {
            width: 100%
        }
    }

    a:focus-visible,
    button:focus-visible {
        box-shadow: 0 0 0 2px #f9f9f9, 0 0 0 4px #006bfa;
        outline: none
    }

    .core-block--heading {
        margin-bottom: 1.5rem;
        margin-top: 3.5rem
    }

    .core-block--heading:first-child {
        margin-top: 0
    }

    .core-block--heading:last-child {
        margin-bottom: 0
    }

    @media (min-width:1025px) {
        .core-block--heading {
            margin-top: 4rem
        }
    }

    @media (min-width:1025px) {}

    @media (min-width:1025px) {}

    @media (min-width:1025px) {}

    @media (min-width:1025px) {}

    .core-block--heading+.core-block--paragraph {
        margin-top: -1rem
    }

    @media (min-width:1025px) {
        .core-block--heading+.core-block--paragraph {
            margin-top: -.5rem
        }
    }

    .core-block--paragraph {
        margin-bottom: 1.5rem
    }

    .core-block--paragraph:first-child {
        margin-top: 0
    }

    .core-block--paragraph:last-child {
        margin-bottom: 0
    }

    @media (min-width:600px) {}

    @media (min-width:1025px) {}

    @media (min-width:600px) {}

    @media (min-width:1025px) {}

    .remove-margin-top {
        margin-top: 0 !important
    }

    @media (min-width:1025px) {}

    .acf-block+.core-block--columns {
        margin-top: 0
    }

    .core-block--columns+.core-block:not(.core-block--columns) {
        margin-top: 3rem
    }

    @media (min-width:1025px) {
        .core-block--columns+.core-block:not(.core-block--columns) {
            margin-top: 4rem
        }
    }

    @media (min-width:800px) {}

    @media (min-width:800px) {}

    @media screen and (max-width:799px) {}

    @media (min-width:1025px) {}

    @media (min-width:1025px) {}

    @media screen and (max-width:1024px) {}

    @media (min-width:800px) {}

    @media (min-width:800px) {}

    @media screen and (max-width:799px) {}

    @media (min-width:1025px) {}

    @media (min-width:1025px) {}

    @media screen and (max-width:1024px) {}

    @media (min-width:800px) {}

    @media (min-width:800px) {}

    @media screen and (max-width:799px) {}

    @media (min-width:1025px) {}

    @media (min-width:1025px) {}

    @media screen and (max-width:1024px) {}

    .core-block--columns .wp-block-columns {
        display: flex
    }

    .core-block--columns .wp-block-columns>.core-block--column {
        flex: 1 1 auto
    }

    .core-block--columns .wp-block-columns>.core-block--column>.wp-block-column {
        flex-basis: auto !important;
        height: 100%
    }

    @media (min-width:1025px) {}

    @media (min-width:600px) {}

    @media (min-width:1025px) {}

    @media (min-width:1025px) {}

    @media (min-width:800px) {}

    @media (min-width:1025px) {}

    @media (min-width:800px) {}

    @media (min-width:1025px) {}

    @media (min-width:800px) {}

    @media (min-width:1025px) {}

    @media (min-width:800px) {}

    @media (min-width:1025px) {}

    @media (min-width:800px) {}

    @media (min-width:1025px) {}

    @media (min-width:1600px) {}

    @media (min-width:800px) {}

    @media (min-width:1025px) {}

    @media (min-width:1600px) {}

    @media screen and (max-width:1024px) {}

    @media screen and (min-width:1025px) {
        body.has-submenu-navigation .menu__search.desktop {
            bottom: 0
        }
    }

    .inner {
        box-sizing: initial;
        margin-left: auto;
        margin-right: auto;
        padding-left: 1rem;
        padding-right: 1rem
    }

    @media (min-width:600px) {
        .inner {
            padding-left: 1.5rem;
            padding-right: 1.5rem
        }
    }

    @media (min-width:1025px) {
        .inner {
            padding-left: 2rem;
            padding-right: 2rem
        }
    }

    .inner--px-remove {
        margin-left: -1rem;
        margin-right: -1rem
    }

    @media (min-width:600px) {
        .inner--px-remove {
            margin-left: -1.5rem;
            margin-right: -1.5rem
        }
    }

    @media (min-width:1025px) {
        .inner--px-remove {
            margin-left: -2rem;
            margin-right: -2rem
        }
    }

    .inner--px-remove--wide {
        margin-left: -1rem;
        margin-right: -1rem
    }

    @media (min-width:600px) {
        .inner--px-remove--wide {
            margin-left: -1.5rem;
            margin-right: -1.5rem
        }
    }

    @media (min-width:1025px) {
        .inner--px-remove--wide {
            margin-left: -2rem;
            margin-right: -2rem
        }
    }

    @media screen and (min-width:1148px) {
        .inner--px-remove--wide {
            margin-left: 0;
            margin-right: 0
        }
    }

    @media (min-width:600px) {}

    @media (min-width:1025px) {}

    @media screen and (min-width:1600px) {}

    @media (min-width:600px) {}

    @media (min-width:1025px) {}

    @media (min-width:800px) {}

    @media (min-width:1025px) {}

    @media (min-width:1025px) {}

    .inner--full {
        max-width: 1536px
    }

    .inner--prose {
        max-width: 720px
    }

    @media (min-width:1025px) {}

    .wp-block-column>.block>.inner {
        box-sizing: border-box;
        max-width: none;
        padding-left: 0;
        padding-right: 0
    }

    @keyframes address-lookup-select-results {
        0% {
            transform: rotateX(-90deg)
        }

        40% {
            transform: rotateX(20deg)
        }

        to {
            transform: rotateX(0deg)
        }
    }

    .wpforms-field {
        margin-bottom: 16px;
        position: relative
    }

    .wpforms-field label.wpforms-field-label {
        pointer-events: none;
        z-index: 1
    }

    .wpforms-field label.wpforms-field-label .wpforms-required-label {
        color: #006bfa
    }

    .wpforms-field.wpforms-field-html a {
        text-decoration: underline
    }

    .wpforms-field.wpforms-field-html a:hover {
        text-decoration: none
    }

    .wpforms-field-address_dawa:after,
    .wpforms-field-date-time:after,
    .wpforms-field-email:after,
    .wpforms-field-name .wpforms-field-row .wpforms-field-row-block:after,
    .wpforms-field-name:after,
    .wpforms-field-number:after,
    .wpforms-field-password:after,
    .wpforms-field-phone:after,
    .wpforms-field-select:after,
    .wpforms-field-text:after,
    .wpforms-field-textarea:after,
    .wpforms-field-url:after {
        background: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjUiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNSAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTEyLjUgN0wxMi41IDEzIiBzdHJva2U9IiNFQTVGNTUiIHN0cm9rZS13aWR0aD0iMiIvPgo8cGF0aCBkPSJNMTIuNSAxNUwxMi41IDE3IiBzdHJva2U9IiNFQTVGNTUiIHN0cm9rZS13aWR0aD0iMiIvPgo8Y2lyY2xlIGN4PSIxMi41IiBjeT0iMTIiIHI9IjkiIHN0cm9rZT0iI0VBNUY1NSIgc3Ryb2tlLXdpZHRoPSIyIi8+Cjwvc3ZnPgo=);
        background-position: 50%;
        background-repeat: no-repeat;
        background-size: contain;
        content: "";
        display: block;
        height: 20px;
        opacity: 0;
        pointer-events: none;
        position: absolute;
        right: 24px;
        top: 17px;
        transform: scale(.6);
        transition: opacity .15s ease, transform .15s ease;
        width: 20px
    }

    @media (min-width:551px) {

        .wpforms-field-address_dawa:after,
        .wpforms-field-date-time:after,
        .wpforms-field-email:after,
        .wpforms-field-name .wpforms-field-row .wpforms-field-row-block:after,
        .wpforms-field-name:after,
        .wpforms-field-number:after,
        .wpforms-field-password:after,
        .wpforms-field-phone:after,
        .wpforms-field-select:after,
        .wpforms-field-text:after,
        .wpforms-field-textarea:after,
        .wpforms-field-url:after {
            top: 23px
        }
    }

    .wpforms-field-address_dawa label.wpforms-field-label,
    .wpforms-field-email label.wpforms-field-label,
    .wpforms-field-number label.wpforms-field-label,
    .wpforms-field-text label.wpforms-field-label {
        font-size: 15px;
        left: 12px;
        letter-spacing: .7px;
        position: absolute;
        text-overflow: ellipsis;
        top: 10px;
        transform-origin: left top;
        transition: transform .15s ease, color .15s ease;
        white-space: nowrap
    }

    @media (min-width:551px) {

        .wpforms-field-address_dawa label.wpforms-field-label,
        .wpforms-field-email label.wpforms-field-label,
        .wpforms-field-number label.wpforms-field-label,
        .wpforms-field-text label.wpforms-field-label {
            left: 24px;
            top: 14px
        }
    }

    .wpforms-field-address_dawa input:-webkit-autofill,
    .wpforms-field-date-time input:-webkit-autofill,
    .wpforms-field-email input:-webkit-autofill,
    .wpforms-field-name .wpforms-field-row .wpforms-field-row-block input:-webkit-autofill,
    .wpforms-field-name input:-webkit-autofill,
    .wpforms-field-number input:-webkit-autofill,
    .wpforms-field-password input:-webkit-autofill,
    .wpforms-field-phone input:-webkit-autofill,
    .wpforms-field-select input:-webkit-autofill,
    .wpforms-field-text input:-webkit-autofill,
    .wpforms-field-textarea input:-webkit-autofill,
    .wpforms-field-url input:-webkit-autofill {
        animation-name: onAutoFillStart
    }

    .wpforms-field-address_dawa input:not(:-webkit-autofill),
    .wpforms-field-date-time input:not(:-webkit-autofill),
    .wpforms-field-email input:not(:-webkit-autofill),
    .wpforms-field-name .wpforms-field-row .wpforms-field-row-block input:not(:-webkit-autofill),
    .wpforms-field-name input:not(:-webkit-autofill),
    .wpforms-field-number input:not(:-webkit-autofill),
    .wpforms-field-password input:not(:-webkit-autofill),
    .wpforms-field-phone input:not(:-webkit-autofill),
    .wpforms-field-select input:not(:-webkit-autofill),
    .wpforms-field-text input:not(:-webkit-autofill),
    .wpforms-field-textarea input:not(:-webkit-autofill),
    .wpforms-field-url input:not(:-webkit-autofill) {
        animation-name: onAutoFillCancel
    }

    .wpforms-field-checkbox,
    .wpforms-field-radio {
        margin-bottom: 32px;
        margin-top: 24px
    }

    .wpforms-field-checkbox label.wpforms-field-label,
    .wpforms-field-radio label.wpforms-field-label {
        display: block;
        font-size: 15px;
        font-weight: 500;
        letter-spacing: .7px;
        margin-bottom: 8px
    }

    @media (min-width:551px) {

        .wpforms-field-checkbox label.wpforms-field-label,
        .wpforms-field-radio label.wpforms-field-label {
            margin-bottom: 16px
        }
    }

    .wpforms-field-checkbox ul,
    .wpforms-field-radio ul {
        list-style: none;
        margin: 0;
        padding: 0
    }

    .wpforms-field-checkbox ul li,
    .wpforms-field-radio ul li {
        display: block;
        position: relative
    }

    .wpforms-field-checkbox ul li:not(:last-child),
    .wpforms-field-radio ul li:not(:last-child) {
        margin-bottom: 12px
    }

    .wpforms-field .wpforms-required-label {
        font-size: 16px
    }

    @media (min-width:375px) {}

    @media (min-width:551px) {}

    @media (min-width:551px) {}

    @media (min-width:551px) {}

    .wpforms-field-description {
        font-size: 15px;
        padding: 8px 16px 0
    }

    .wpforms-field:not(.wpforms-field-checkbox):not(.wpforms-field-file-upload) {
        max-width: 100%
    }

    .wpforms-field .wpforms-field-description a[class^=popmake-] {
        position: absolute;
        right: 24px;
        top: 15px
    }

    @media (min-width:551px) {
        .wpforms-field .wpforms-field-description a[class^=popmake-] {
            top: 21px
        }
    }

    .wpforms-field .wpforms-field-description a[class^=popmake-]:focus:not(:hover) {
        background: none;
        position: absolute
    }

    @media (min-width:551px) {}

    .wpforms-submit-container {
        margin-top: 24px
    }

    @media (min-width:375px) {
        .wpforms-submit-container {
            margin-top: 36px
        }
    }

    .wpforms-submit-container button.wpforms-submit {
        background-color: #1e1e1e;
        color: #f9f9f9;
        display: inline-block;
        font-size: .875rem;
        padding: 1rem 2.75rem 1rem 1.5rem;
        position: relative;
        transition: .2s ease-in-out
    }

    .wpforms-submit-container button.wpforms-submit:after {
        background: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAiIGhlaWdodD0iNyIgdmlld0JveD0iMCAwIDEwIDciIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxwYXRoIGQ9Ik01LjE1Njg0IDAuMDAwMjQ0MTQxTDcuOTg0ODQgMi43NTgyNEgwLjk4NDgzNlY0LjA2MDI0SDguMDEyODRMNS4xNTY4NCA2LjgxODI0SDYuODkyODRMOS44NDY4NCAzLjg3ODI0VjIuOTY4MjRMNi44OTI4NCAwLjAwMDI0NDE0MUg1LjE1Njg0WiIgZmlsbD0iI0Y5RjlGOSIvPgo8L3N2Zz4K);
        background-repeat: no-repeat;
        background-size: contain;
        content: "";
        display: inline;
        height: 8px;
        position: absolute;
        right: 24px;
        top: 50%;
        transform: translateY(-50%) translateX(0);
        transition: .2s ease-in-out;
        width: 11px
    }

    .wpforms-submit-container button.wpforms-submit:disabled {
        padding-right: 1.5rem
    }

    .wpforms-submit-container button.wpforms-submit:hover:after {
        transform: translateX(5px) translateY(-50%);
        transition: .2s ease-in-out
    }

    .wpforms-submit-container button.wpforms-submit:disabled:after {
        display: none
    }

    .wpforms-submit-container button.wpforms-submit:hover {
        background-color: #0c2454
    }

    @media (max-width:375px) {
        .wpforms-submit-container {
            text-align: center
        }
    }

    input:not(.clean)[type=date],
    input:not(.clean)[type=email],
    input:not(.clean)[type=number],
    input:not(.clean)[type=password],
    input:not(.clean)[type=tel],
    input:not(.clean)[type=text],
    input:not(.clean)[type=url] {
        -webkit-appearance: none;
        border-radius: 0;
        color: #1e1e1e
    }

    .wpforms-container input {
        font-size: 16px
    }

    .wpforms-container label {
        color: #707070;
        cursor: text;
        display: inline-block;
        font-weight: 400;
        overflow: hidden;
        text-align: left;
        text-transform: inherit;
        transition: transform .15s ease, color .15s ease;
        will-change: transform
    }

    .wpforms-container label a {
        text-decoration: underline
    }

    .wpforms label a:hover,
    .wpforms-container label a:hover {
        text-decoration: none
    }

    .wpforms input[type=radio]:checked+label:before,
    .wpforms-container input[type=radio]:checked+label:before {
        background-size: 90%;
        background: var(--sf-img-20) no-repeat 50%
    }

    .wpforms-container input[type=email],
    .wpforms-container input[type=number],
    .wpforms-container input[type=text] {
        -webkit-appearance: none;
        border-radius: 0;
        color: #1e1e1e
    }

    .wpforms-container input[type=checkbox] {
        clip: rect(1px, 1px, 1px, 1px);
        word-wrap: normal;
        height: 1px;
        overflow: hidden;
        position: absolute;
        width: 1px
    }

    .wpforms-container input[type=checkbox]+label {
        color: currentColor;
        cursor: pointer;
        display: block;
        font-size: 15px;
        min-height: 25px;
        overflow: visible;
        padding-left: 40px;
        padding-top: 2px
    }

    .wpforms input[type=checkbox]+label:before,
    .wpforms-container input[type=checkbox]+label:before {
        align-items: center;
        background-color: #f9f9f9;
        border: 1px solid #1e1e1e;
        color: #0000;
        content: "";
        display: inline-flex;
        font-size: 16px;
        font-weight: 500;
        height: 25px;
        justify-content: center;
        left: 0;
        position: relative;
        position: absolute;
        top: 0;
        transition: transform .15s ease, background-color .15s ease, color .15s ease .05s, border-color .15s ease, box-shadow .15s ease;
        width: 25px
    }

    .wpforms input[type=checkbox]:focus-visible+label:before,
    .wpforms-container input[type=checkbox]:focus-visible+label:before {
        box-shadow: 0 0 0 2px #f9f9f9, 0 0 0 4px #006bfa
    }

    .wpforms input[type=checkbox]:checked+label:before,
    .wpforms-container input[type=checkbox]:checked+label:before {
        background-image: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTkiIGhlaWdodD0iMTQiIHZpZXdCb3g9IjAgMCAxOSAxNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTE3IDJMNi42MzI4IDEyTDIgNy40MTY2NyIgc3Ryb2tlPSIjMDA2QkZBIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJzcXVhcmUiLz4KPC9zdmc+Cg==);
        background-position: 50%;
        background-repeat: no-repeat;
        background-size: 75%
    }

    .wpforms input[type=checkbox]:checked:disabled+label:before,
    .wpforms-container input[type=checkbox]:checked:disabled+label:before {
        background-color: #f0f0f0;
        border-color: #f0f0f0;
        transform: scale(1)
    }

    .wpforms input[type=checkbox]:disabled+label:before,
    .wpforms-container input[type=checkbox]:disabled+label:before {
        transform: scale(1)
    }

    @media (min-width:551px) {}

    input[type=radio]:checked+label:before {
        background: var(--sf-img-20);
        background-position: 50%;
        background-repeat: no-repeat;
        background-size: 90%
    }

    .wpforms-field-radio .wpforms-field-label {
        color: #1e1e1e
    }

    input:not(.clean):-webkit-autofill {
        animation-name: onAutoFillStart
    }

    input:not(.clean):not(:-webkit-autofill) {
        animation-name: onAutoFillCancel
    }

    input:not(.clean)[type=date],
    input:not(.clean)[type=email],
    input:not(.clean)[type=number],
    input:not(.clean)[type=password],
    input:not(.clean)[type=tel],
    input:not(.clean)[type=text],
    input:not(.clean)[type=url] {
        background-color: #f9f9f9;
        border: 1px solid #1e1e1e;
        font-size: 16px;
        font-weight: 400;
        max-width: 100%;
        outline: none;
        padding: 24px 12px 6px;
        position: relative;
        transition: background-color .15s ease, border-color .15s ease, color .15s ease;
        width: 100%
    }

    @media (min-width:551px) {

        input:not(.clean)[type=date],
        input:not(.clean)[type=email],
        input:not(.clean)[type=number],
        input:not(.clean)[type=password],
        input:not(.clean)[type=tel],
        input:not(.clean)[type=text],
        input:not(.clean)[type=url] {
            padding: 30px 24px 12px
        }
    }

    input:not(.clean)[type=date]:hover:not(.wpforms-error):not(:focus),
    input:not(.clean)[type=email]:hover:not(.wpforms-error):not(:focus),
    input:not(.clean)[type=number]:hover:not(.wpforms-error):not(:focus),
    input:not(.clean)[type=password]:hover:not(.wpforms-error):not(:focus),
    input:not(.clean)[type=tel]:hover:not(.wpforms-error):not(:focus),
    input:not(.clean)[type=text]:hover:not(.wpforms-error):not(:focus),
    input:not(.clean)[type=url]:hover:not(.wpforms-error):not(:focus) {
        background-color: #f9f9f9;
        border-color: #1e1e1e
    }

    input:not(.clean)[type=date]:focus:not(.wpforms-error),
    input:not(.clean)[type=email]:focus:not(.wpforms-error),
    input:not(.clean)[type=number]:focus:not(.wpforms-error),
    input:not(.clean)[type=password]:focus:not(.wpforms-error),
    input:not(.clean)[type=tel]:focus:not(.wpforms-error),
    input:not(.clean)[type=text]:focus:not(.wpforms-error),
    input:not(.clean)[type=url]:focus:not(.wpforms-error) {
        outline: none
    }

    input:not(.clean)[type=date]:focus-visible,
    input:not(.clean)[type=email]:focus-visible,
    input:not(.clean)[type=number]:focus-visible,
    input:not(.clean)[type=password]:focus-visible,
    input:not(.clean)[type=tel]:focus-visible,
    input:not(.clean)[type=text]:focus-visible,
    input:not(.clean)[type=url]:focus-visible {
        box-shadow: 0 0 0 2px #f9f9f9, 0 0 0 4px #006bfa;
        outline: none
    }

    @keyframes onAutoFillStart {
        to {
            visibility: inherit
        }
    }

    @keyframes onAutoFillCancel {
        to {
            visibility: inherit
        }
    }

    .wpforms input:-webkit-autofill,
    .wpforms-container input:-webkit-autofill {
        animation-name: onAutoFillStart
    }

    .wpforms input:not(:-webkit-autofill),
    .wpforms-container input:not(:-webkit-autofill) {
        animation-name: onAutoFillCancel
    }

    .wpforms-container input[type=email],
    .wpforms-container input[type=number],
    .wpforms-container input[type=text] {
        background-color: #f9f9f9;
        border: 1px solid #1e1e1e;
        font-size: 16px;
        font-weight: 400;
        max-width: 100%;
        outline: none;
        padding: 24px 12px 6px;
        position: relative;
        transition: background-color .15s ease, border-color .15s ease, color .15s ease;
        width: 100%
    }

    @media (min-width:551px) {

        .wpforms-container input[type=email],
        .wpforms-container input[type=number],
        .wpforms-container input[type=text] {
            padding: 30px 24px 12px
        }
    }

    .wpforms input[type=date]:hover:not(.wpforms-error):not(:focus),
    .wpforms input[type=email]:hover:not(.wpforms-error):not(:focus),
    .wpforms input[type=number]:hover:not(.wpforms-error):not(:focus),
    .wpforms input[type=password]:hover:not(.wpforms-error):not(:focus),
    .wpforms input[type=tel]:hover:not(.wpforms-error):not(:focus),
    .wpforms input[type=text]:hover:not(.wpforms-error):not(:focus),
    .wpforms input[type=url]:hover:not(.wpforms-error):not(:focus),
    .wpforms-container input[type=date]:hover:not(.wpforms-error):not(:focus),
    .wpforms-container input[type=email]:hover:not(.wpforms-error):not(:focus),
    .wpforms-container input[type=number]:hover:not(.wpforms-error):not(:focus),
    .wpforms-container input[type=password]:hover:not(.wpforms-error):not(:focus),
    .wpforms-container input[type=tel]:hover:not(.wpforms-error):not(:focus),
    .wpforms-container input[type=text]:hover:not(.wpforms-error):not(:focus),
    .wpforms-container input[type=url]:hover:not(.wpforms-error):not(:focus) {
        background-color: #f9f9f9;
        border-color: #1e1e1e
    }

    .wpforms input[type=date]:focus:not(.wpforms-error),
    .wpforms input[type=email]:focus:not(.wpforms-error),
    .wpforms input[type=number]:focus:not(.wpforms-error),
    .wpforms input[type=password]:focus:not(.wpforms-error),
    .wpforms input[type=tel]:focus:not(.wpforms-error),
    .wpforms input[type=text]:focus:not(.wpforms-error),
    .wpforms input[type=url]:focus:not(.wpforms-error),
    .wpforms-container input[type=date]:focus:not(.wpforms-error),
    .wpforms-container input[type=email]:focus:not(.wpforms-error),
    .wpforms-container input[type=number]:focus:not(.wpforms-error),
    .wpforms-container input[type=password]:focus:not(.wpforms-error),
    .wpforms-container input[type=tel]:focus:not(.wpforms-error),
    .wpforms-container input[type=text]:focus:not(.wpforms-error),
    .wpforms-container input[type=url]:focus:not(.wpforms-error) {
        outline: none
    }

    .wpforms input[type=date]:focus-visible,
    .wpforms input[type=email]:focus-visible,
    .wpforms input[type=number]:focus-visible,
    .wpforms input[type=password]:focus-visible,
    .wpforms input[type=tel]:focus-visible,
    .wpforms input[type=text]:focus-visible,
    .wpforms input[type=url]:focus-visible,
    .wpforms-container input[type=date]:focus-visible,
    .wpforms-container input[type=email]:focus-visible,
    .wpforms-container input[type=number]:focus-visible,
    .wpforms-container input[type=password]:focus-visible,
    .wpforms-container input[type=tel]:focus-visible,
    .wpforms-container input[type=text]:focus-visible,
    .wpforms-container input[type=url]:focus-visible {
        box-shadow: 0 0 0 2px #f9f9f9, 0 0 0 4px #006bfa;
        outline: none
    }

    .wpforms-container input[type=radio] {
        clip: rect(1px, 1px, 1px, 1px);
        word-wrap: normal;
        height: 1px;
        overflow: hidden;
        position: absolute;
        width: 1px
    }

    .wpforms-container input[type=radio]+label {
        color: #1e1e1e;
        cursor: pointer;
        display: block;
        font-size: 15px;
        min-height: 25px;
        overflow: visible;
        padding-left: 40px;
        padding-top: 2px
    }

    .wpforms input[type=radio]+label:before,
    .wpforms-container input[type=radio]+label:before {
        align-items: center;
        background-color: #f9f9f9;
        border: 1px solid #1e1e1e;
        color: #0000;
        content: "";
        display: inline-flex;
        font-size: 16px;
        font-weight: 500;
        height: 25px;
        justify-content: center;
        left: 0;
        position: relative;
        position: absolute;
        top: 0;
        transition: transform .15s ease, background-color .15s ease, color .15s ease .05s, border-color .15s ease, box-shadow .15s ease;
        width: 25px
    }

    .wpforms input[type=radio]+label:active:before,
    .wpforms-container input[type=radio]+label:active:before {
        transform: scale(.85)
    }

    .wpforms input[type=radio]:checked+label:before,
    .wpforms-container input[type=radio]:checked+label:before {
        background: var(--sf-img-20);
        background-position: 50%;
        background-repeat: no-repeat;
        background-size: 65%
    }

    .wpforms input[type=radio]:checked:disabled+label:before,
    .wpforms-container input[type=radio]:checked:disabled+label:before {
        background-color: #f0f0f0;
        border-color: #f0f0f0;
        transform: scale(1)
    }

    .wpforms input[type=radio]:disabled+label:before,
    .wpforms-container input[type=radio]:disabled+label:before {
        transform: scale(1)
    }

    .wpforms input[type=radio]+label:before,
    .wpforms-container input[type=radio]+label:before {
        border-radius: 50%
    }

    .wpforms input[type=number]::-webkit-inner-spin-button,
    .wpforms input[type=number]::-webkit-outer-spin-button,
    .wpforms-container input[type=number]::-webkit-inner-spin-button,
    .wpforms-container input[type=number]::-webkit-outer-spin-button {
        -webkit-appearance: none
    }

    @media (min-width:551px) {}

    @media (min-width:376px) {}

    @media (min-width:551px) {}

    @media only screen and (min-width:600px) {}

    @media only screen and (min-width:800px) {}

    @media only screen and (min-width:1025px) {}

    @media screen and (min-width:600px) {}

    @media screen and (min-width:600px) {}

    @media screen and (max-height:750px) {}

    @media screen and (max-height:750px) {}

    @media screen and (max-width:1599px) {}

    @media screen and (min-width:1600px) {}

    @media (min-width:800px) {}

    .backface-visibility-hidden {
        backface-visibility: hidden
    }
</style>
<link rel=https://api.w.org/ href=https://andelenergi.dk/api />
<link rel=alternate type=application/json href=https://andelenergi.dk/api/wp/v2/pages/143667>
<link rel=EditURI type=application/rsd+xml title=RSD href=https://andelenergi.dk/wp/xmlrpc.php?rsd>
<meta name=generator content="WordPress 6.4.2">
<link rel=shortlink href="https://andelenergi.dk/?p=143667">
<link rel=alternate type=application/json+oembed href="https://andelenergi.dk/api/oembed/1.0/embed?url=https%3A%2F%2Fandelenergi.dk%2Fopladning%2Fevflw%2Fev-brik-step2-formular%2F">
<link rel=alternate type=text/xml+oembed href="https://andelenergi.dk/api/oembed/1.0/embed?url=https%3A%2F%2Fandelenergi.dk%2Fopladning%2Fevflw%2Fev-brik-step2-formular%2F&amp;format=xml">
<style class=automa-element-selector>
    @font-face {
        font-family: "Inter var";
        font-weight: 100 900;
        font-style: normal;
        font-named-instance: "Regular";
        src: url(chrome-extension://infppggnoaenmfagbfknfkancpbljcca/Inter-roman-latin.var.woff2)format("woff2")
    }

    .automa-element-selector {
        direction: ltr
    }
</style>
<meta name=referrer content=no-referrer>
<link rel="shortcut icon" href="data:image/x-icon;base64,AAABAAMAMDAAAAEAIACoJQAANgAAACAgAAABACAAqBAAAN4lAAAQEAAAAQAgAGgEAACGNgAAKAAAADAAAABgAAAAAQAgAAAAAAAAJAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD/aAAW+WsAWPlrAIj6awCn+moAu/pqALv6awCn+WwAh/lsAFf/bQAVAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+GoATfprALz6awD9+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD9+moAu/lqAFL/gAACAAAAAPtrAKz6awDc+msA3PprANz6awDc+msA3PprAKUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPppADj6agDC+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awDP+2wAO/prAMn6awD/+msA//prAP/6awD/+msA//prAMEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+mwAb/prAP36awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA/vlqAOT6awD/+msA//prAP/6awD/+msA//prAMEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP9gAAj6bACm+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAMEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/wAAAfprAKX6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAMEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+2sAefprAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAOH6awCl+WsAivlrAIr6awCl+msA4fprAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAMEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD6aQA4+msA/fprAP/6awD/+msA//prAP/6awD/+msA//prAP/6agC7+mkAOP8AAAEAAAAAAAAAAAAAAAAAAAAA/wAAAftrADn6awC9+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAMEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD6agDC+msA//prAP/6awD/+msA//prAP/6awD/+msA+vprAGQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+mwAZvprAPr6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAMEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPhsAE76awD/+msA//prAP/6awD/+msA//prAP/6awD9+GwATgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPlrAE/6awD9+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAMEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPprAL36awD/+msA//prAP/6awD/+msA//prAP/7agB/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD5bACC+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAMEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/2oAGPprAP36awD/+msA//prAP/6awD/+msA//prAOL/YAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD/YAAI+2sA4/prAP/6awD/+msA//prAP/6awD/+msA//prAMYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+WsAWPprAP/6awD/+msA//prAP/6awD/+msA//trAHIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+2wAdPprAP/6awD/+msA//prAP/6awD/+msA//lrANYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+WoAifprAP/6awD/+msA//prAP/6awD/+msA//huACUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+GkAJ/prAP/6awD/+msA//prAP/6awD/+msA//lrAOIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+2sAq/prAP/6awD/+msA//prAP/6awD/+msA7QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPprAPv6awD/+msA//prAP/6awD/+msA//prAOoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+msAuvprAP/6awD/+msA//prAP/6awD/+msA1AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPprAPb6awD/+msA//prAP/6awD/+msA//prAO4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+WwAufprAP/6awD/+msA//prAP/6awD/+mwA0wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPprAPb6awD/+msA//prAP/6awD/+msA//prAO4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+2sAq/prAP/6awD/+msA//prAP/6awD/+msA7QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPpqAPz6awD/+msA//prAP/6awD/+msA//prAOoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+WoAifprAP/6awD/+msA//prAP/6awD/+msA//hqACQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+GkAJ/prAP/6awD/+msA//prAP/6awD/+msA//lrAOIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+WoAWfprAP/6awD/+msA//prAP/6awD/+msA//trAHIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+2sAdfprAP/6awD/+msA//prAP/6awD/+msA//lrANYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/2oAGPprAP36awD/+msA//prAP/6awD/+msA//prAOH/bQAHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD/cQAJ+2sA5PprAP/6awD/+msA//prAP/6awD/+msA//prAMYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPprAL76awD/+msA//prAP/6awD/+msA//prAP/7agB9AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD5agCE+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAMEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPhsAE76awD/+msA//prAP/6awD/+msA//prAP/6awD9/GsATAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPlqAFL6awD++msA//prAP/6awD/+msA//prAP/6awD/+msA//prAMEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD6awDD+msA//prAP/6awD/+msA//prAP/6awD/+msA+fprAGIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+msAafprAPv6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAMEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD7awA5+msA/fprAP/6awD/+msA//prAP/6awD/+msA//prAP/5bAC5+msANwAAAAAAAAAAAAAAAAAAAAAAAAAA/wAAAftrADn6awC++msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAMEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+2wAe/prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAN/6agCj+WsAivlrAIr6awCk+msA4fprAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAMEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/wAAAfprAKX6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAMEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP9gAAj6awCn+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAMEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD/AAAB+2sAd/prAP36awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA/vlqAOT6awD/+msA//prAP/6awD/+msA//prAMEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPtrADn6awDD+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6agDC+mkAOPprAMn6awD/+msA//prAP/6awD/+msA//prAMEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+GwATvprAL76awD9+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD9+msAvfhsAE4AAAAAAAAAAPtrAKz6awDc+msA3PprANz6awDc+msA3PprAKUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD/agAY+WoAWflqAIn6agCo+moAu/pqALv6agCo+WsAiPlqAFn/bwAXAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP///////wAA////////AAD///////8AAP///////wAA////////AAD///////8AAP///////wAA////////AAD///gf//8AAP//wAOA/wAA//8AAID/AAD//gAAAP8AAP/4AAAA/wAA//AAAAD/AAD/8AAAAP8AAP/gD/AA/wAA/8A//AD/AAD/wH/+AP8AAP+A//4A/wAA/4D//wD/AAD/gf//gP8AAP8B//+A/wAA/wH//4D/AAD/Af//gP8AAP8B//+A/wAA/wH//4D/AAD/Af//gP8AAP+B//+A/wAA/4D//wD/AAD/gP/+AP8AAP/Af/4A/wAA/8A//AD/AAD/4A/wAP8AAP/wAAAA/wAA//AAAAD/AAD/+AAAAP8AAP/+AAAA/wAA//8AAID/AAD//8ADgP8AAP//+B///wAA////////AAD///////8AAP///////wAA////////AAD///////8AAP///////wAA////////AAD///////8AACgAAAAgAAAAQAAAAAEAIAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPlsACj5agBZ+moAcfpqAHH5agBZ+GkAJwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/20AB/prAHD6awDZ+msA//prAP/6awD/+msA//prAP/6awD/+msA2PpsAG//gAAG+moAx/prAOj6awDo+msA6PtsAHQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPptADb6awDe+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prANz7awDj+msA//prAP/6awD/+WwAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD5agBS+msA9/prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//pqAP76awD/+msA//prAP/5bACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+m0ANvprAPf6awD/+msA//prAP/6awD/+msA//prAOH5awC1+WsAtfprAOH6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//lsAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP9tAAf6awDf+msA//prAP/6awD/+msA//prAMn7bAA7AAAAAAAAAAAAAAAAAAAAAPtqADz6awDK+msA//prAP/6awD/+msA//prAP/6awD/+WwAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+2sAcvprAP/6awD/+msA//prAP/7bACt/20ABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP9tAAf7awCu+msA//prAP/6awD/+msA//prAP/5bACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD6agDa+msA//prAP/6awD/+msA2/90AAsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP90AAv6awDd+msA//prAP/6awD/+msA//lsAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+W0AKvprAP/6awD/+msA//prAP/6agBgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPprAGL6awD/+msA//prAP/6awD/+GsAlAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD5agBZ+msA//prAP/6awD/+msA/P9wABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/2kAEfprAP/6awD/+msA//prAP/5awCsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPtqAHP6awD/+msA//prAP/5awDnAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+moA/PprAP/6awD/+msA//lrALgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+2wAdPprAP/6awD/+msA//lsAOYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD6agD8+msA//prAP/6awD/+WwAuQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD5agBZ+msA//prAP/6awD/+msA/P9mAA8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/2kAEfprAP/6awD/+msA//prAP/5awCsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPlrACv6awD/+msA//prAP/6awD/+moAXgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD6awBi+msA//prAP/6awD/+msA//prAJQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPpqANr6awD/+msA//prAP/6agDa/2YACgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/3QAC/prAN36awD/+msA//prAP/6awD/+WwAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+2oAc/prAP/6awD/+msA//prAP/7awCs/4AABgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP9tAAf7awCw+msA//prAP/6awD/+msA//prAP/5bACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD/YAAI+msA4PprAP/6awD/+msA//prAP/6awDI+2oAOgAAAAAAAAAAAAAAAAAAAAD7agA8+msAyvprAP/6awD/+msA//prAP/6awD/+msA//lsAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD6awA3+msA9/prAP/6awD/+msA//prAP/6awD/+msA3/lsALT5bAC0+msA4PprAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+WwAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD5agBS+msA9/prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//pqAP76awD/+msA//prAP/5bACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD6awA3+msA4PprAP/6awD/+msA//prAP/6awD/+msA//prAP/6awD/+msA//prAP/6awDf+WoA5PprAP/6awD/+msA//lsAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD/YAAI+2sAcvprANv6awD/+msA//prAP/6awD/+msA//prAP/6agDa+2sAcv9tAAf6agDH+msA6PprAOj6awDo+2wAdAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPltACr5agBb+moAcfpqAHH5agBb+WoAKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//////////////////////////////////AMP//AAB//gAAf/wAAH/4H4B/+D/Af/B/4H/w//B/8P/wf/D/8H/w//B/8P/wf/D/8H/wf+B/+D/Af/gfgH/8AAB//gAAf/8AAH//wDD////////////////////////////////8oAAAAEAAAACAAAAABACAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD/ZgAK+msAMvprADL/ZgAKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP9tAA76awCW+msA9vprAP/6awD/+msA9fprAJT7bADj+msA9PttAD0AAAAAAAAAAAAAAAAAAAAAAAAAAP9tAA76awDQ+msA//prAP/6awDt+msA7fprAP/6awD/+WsA/PprAP/7bABAAAAAAAAAAAAAAAAAAAAAAAAAAAD6awCW+msA//prAOz8aQBLAAAAAAAAAAD8awBM+msA7fprAP/6awD/+2wAQAAAAAAAAAAAAAAAAAAAAAD/dAAL+msA9vprAP/5agBZAAAAAAAAAAAAAAAAAAAAAPlqAFv6awD/+msA//tsAEcAAAAAAAAAAAAAAAAAAAAA+mkAM/prAP/6awD8/2YACgAAAAAAAAAAAAAAAAAAAAD/ZgAK+WsA//prAP/6bQBlAAAAAAAAAAAAAAAAAAAAAPpqADX6awD/+msA/P9mAAoAAAAAAAAAAAAAAAAAAAAA/2YACvlrAP/6awD/+mwAZgAAAAAAAAAAAAAAAAAAAAD/dAAL+msA9vprAP/5awBYAAAAAAAAAAAAAAAAAAAAAPlqAFv6awD/+msA//tsAEcAAAAAAAAAAAAAAAAAAAAAAAAAAPpqAJf6awD/+msA7PxpAEsAAAAAAAAAAPxrAEz6awDt+msA//prAP/7bABAAAAAAAAAAAAAAAAAAAAAAAAAAAD/bQAO+msA0fprAP/6awD/+msA7fprAO36awD/+msA//prAPz6awD/+2wAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP9mAA/6awCY+msA9vprAP/6awD/+msA9vprAJb7bADj+msA9PttAD0AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP90AAv6bAA0+mwANP90AAsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP//AAD//wAA//8AAPgHAADwBwAA48cAAOfnAADn5wAA5+cAAOfnAADjxwAA8AcAAPgHAAD//wAA//8AAP//AAA=">
<style>
    .sf-hidden {
        display: none !important
    }
</style>
<link rel=canonical href=#>
<meta http-equiv=content-security-policy content="default-src 'none'; font-src 'self' data:; img-src 'self' data:; style-src 'unsafe-inline'; media-src 'self' data:; script-src 'unsafe-inline' data:; object-src 'self' data:; frame-src 'self' data:;">
<style>
    img[src="data:,"],
    source[src="data:,"] {
        display: none !important
    }
</style>
</head>

<body class="page-template-default page page-id-143667 page-parent page-child parent-pageid-147852 ev-brik-step2-formular has-submenu-navigation" x-data=Tracking data-tracking-page-view='{"pageUrl":"","pageTitle":"","pageHostname":"andelenergi.dk","pageContentUpdated":"22_05_2024","pageSegment":"B2C","trafficSource":"","trafficMedium":"","description":"Det med sm\u00e5t for en brikl\u00f8sning Bem\u00e6rk: Er du allerede elkunde hos Andel Energi, skifter du aftale til TimeEnergi. Det er godt at vide, hvis du for eksempel har FastEnergi eller M\u00e5nedsEnergi, hvor du har fast pris p\u00e5 el d\u00f8gnet rundt. Og det er det mange gange kan betale sig at have en variabel elpris, &amp;hellip; <a href=\"https:\/\/andelenergi.dk\/opladning\/evflw\/ev-brik-step2-formular\/\">Continued<\/a>"}'>


    <div class="font-sans text-body leading-normal antialiased text-black bg-white flex flex-col min-h-screen overflow-x-hidden" x-data>
        <div class="absolute left-0 top-0 z-50 w-full text-center pointer-events-none">
            <a href=#main type=button class="inline-block -translate-y-full focus-visible:translate-y-0 transition-transform bg-gray-500 p-4 pointer-events-auto">Gå til indhold</a>
        </div>
        <header class="layout-header flex-none w-full bg-white z-20">
            <div class="inner inner--full">
                <div class=relative>

                    <div class="flex flex-row items-center justify-between py-6">

                        <a href=# class="logo flex flex-none backface-visibility-hidden" aria-label="Gå til forsiden">
                            <div class="[&amp;_svg]:h-[22px] lg:[&amp;_svg]:h-[28px] [&amp;_svg]:w-auto flex text-sky-500">
                                <svg xmlns=http://www.w3.org/2000/svg viewBox="0 0 150 28" fill=none>
                                    <path d="M64.4752 0.972235L67.4469 0V20.6563H64.4752V0.972235ZM11.1827 7.15557H14.0458V20.6563H11.1827V19.0092C10.1562 20.278 8.50842 21.0608 6.56326 21.0608C2.64662 21.0608 0 17.983 0 13.9059C0 9.82888 2.72755 6.75036 6.64419 6.75036C8.58936 6.75036 10.1562 7.53314 11.1827 8.77304V7.15557ZM11.2636 13.879C11.2636 10.8813 9.12961 9.47761 7.13049 9.47761C4.83729 9.47761 2.99801 11.3405 2.99801 13.9059C2.99801 16.5246 4.83459 18.3343 7.04955 18.3343C9.10263 18.3343 11.2636 16.7411 11.2636 13.879ZM43.2712 0.972235L46.2429 0V20.6563H43.2712V19.0631C42.2177 20.305 40.6239 21.0608 38.7064 21.0608C34.7898 21.0608 32.1425 17.983 32.1425 13.9059C32.1425 9.82888 34.8707 6.75036 38.7874 6.75036C40.6759 6.75036 42.2447 7.50617 43.2712 8.69416V0.972235ZM43.4061 13.879C43.4061 10.8813 41.2728 9.47761 39.2737 9.47761C36.9805 9.47761 35.1412 11.3405 35.1412 13.9059C35.1412 16.5246 36.9778 18.3343 39.1927 18.3343C41.2458 18.3343 43.4061 16.7411 43.4061 13.879L43.4338 13.9329V13.825L43.4061 13.879ZM24.3638 6.75036C22.4457 6.75036 20.9335 7.42459 19.9609 8.88361V7.15557H17.0708V20.6563H20.0418V13.5547C20.0418 10.9623 21.5817 9.42367 23.6341 9.42367C25.7924 9.42367 26.8756 11.1247 26.8756 13.3659V20.6563H29.8473V13.1225C29.8473 9.20724 27.9561 6.75036 24.3638 6.75036ZM62.0444 12.7449L52.0771 15.9812C52.7792 17.5205 54.292 18.3039 56.1556 18.3039C58.3706 18.3039 60.2341 17.2251 61.5851 15.7924V18.9282C60.5316 20.0353 58.5864 21.0608 56.0747 21.0608C51.6448 21.0608 48.6737 18.1178 48.6737 13.852C48.6737 9.82821 51.3716 6.77733 55.5074 6.77733C59.2352 6.77733 61.695 9.20724 62.0444 12.7449V12.7449ZM58.6134 11.2866C57.9922 9.99069 56.8038 9.34276 55.5108 9.34276C53.5117 9.34276 51.783 10.8813 51.6751 13.5277L58.6134 11.2866ZM83.0865 7.26277C79.1422 7.26277 76.36 10.2334 76.36 14.1487C76.36 18.1718 79.3047 20.953 83.2753 20.953C86.3549 20.953 88.1915 19.2519 88.9483 18.4421V16.7411C88.0836 17.8198 86.1654 19.6571 83.2483 19.6571C80.7906 19.6571 78.8184 18.3882 78.0617 16.228L89.3799 12.6633C88.8127 9.47693 86.4629 7.26277 83.0865 7.26277V7.26277ZM77.7919 15.0393C77.7579 14.7526 77.7399 14.4643 77.7379 14.1756C77.7379 10.7195 80.1148 8.5047 83.0865 8.5047C85.1396 8.5047 87.0031 9.63942 87.7052 11.8806L77.7919 15.0393ZM103.345 12.9067V20.6563H101.941V13.0962C101.941 9.93676 100.293 8.55998 98.1318 8.55998C95.5122 8.55998 93.621 10.6117 93.621 13.3659V20.6563H92.2161V7.56011H93.565V10.2604C94.5093 8.18107 96.3742 7.26277 98.3463 7.26277C101.238 7.26277 103.345 9.12634 103.345 12.9067V12.9067ZM112.746 7.26277C108.802 7.26277 106.019 10.2334 106.019 14.1487C106.019 18.1718 108.964 20.953 112.934 20.953C116.014 20.953 117.851 19.2519 118.607 18.4421V16.7411C117.743 17.8198 115.825 19.6571 112.907 19.6571C110.45 19.6571 108.478 18.3882 107.721 16.228L119.039 12.6633C118.472 9.47693 116.125 7.26277 112.746 7.26277V7.26277ZM107.451 15.0393C107.417 14.7526 107.399 14.4643 107.397 14.1756C107.397 10.7195 109.774 8.5047 112.746 8.5047C114.799 8.5047 116.662 9.63942 117.364 11.8806L107.451 15.0393ZM127.575 7.26277C128.09 7.25708 128.601 7.3394 129.088 7.50617V9.07172C128.737 8.85597 128.169 8.64022 127.386 8.64022C125.063 8.64022 123.496 10.557 123.496 13.0685V20.6563H122.065V7.56011H123.414V10.2334C123.982 8.53167 125.468 7.26277 127.575 7.26277V7.26277ZM142.189 10.3952C141.162 8.47773 139.218 7.26277 136.678 7.26277C132.789 7.26277 129.98 10.1788 129.98 14.0677C129.98 17.9567 132.789 20.872 136.678 20.872C139.191 20.872 141.135 19.6584 142.162 17.7396V20.2511C142.162 23.5723 140.163 25.8674 136.813 25.8674C134.436 25.8674 132.519 24.7333 131.519 23.6532V25.3543C132.654 26.3265 134.571 27.1639 136.895 27.1639C140.973 27.1639 143.567 24.4367 143.567 20.332V7.56011H142.189V10.3952ZM136.786 19.5762C133.788 19.5762 131.384 17.335 131.384 14.0677C131.384 10.8004 133.788 8.55931 136.786 8.55931C139.812 8.55931 142.243 10.7168 142.243 14.0408C142.243 17.335 139.812 19.5762 136.786 19.5762V19.5762ZM147.483 7.56011H148.888V20.6563H147.483V7.56011ZM149.402 2.94233C149.397 3.26046 149.267 3.56393 149.04 3.7865C148.812 4.00906 148.506 4.13266 148.188 4.13031C148.031 4.13121 147.876 4.10109 147.732 4.04171C147.587 3.98232 147.456 3.89485 147.345 3.78435C147.235 3.67386 147.147 3.54254 147.088 3.39801C147.028 3.25347 146.998 3.09858 146.999 2.94233C146.999 2.2681 147.512 1.72872 148.188 1.72872C148.347 1.72872 148.505 1.76011 148.652 1.8211C148.799 1.88209 148.933 1.97148 149.046 2.08418C149.159 2.19687 149.248 2.33066 149.309 2.4779C149.37 2.62514 149.402 2.78295 149.402 2.94233V2.94233Z" fill=currentColor></path>
                                </svg>
                            </div>
                        </a>

                        <div class="mobile-service-menu flex flex-row space-x-6 lg:hidden sf-hidden">







                        </div>

                        <div class="desktop-service-menu hidden lg:flex flex-row space-x-8">
                            <a href=# title="Gå til Privat" aria-label="Gå til Privat" class="before:opacity-100 relative before:transition-all before:ease-in-out before:duration-100 hover:before:opacity-100 before:content:[''] before:w-full before:opacity-0 before:absolute before:bg-black before:h-[2px] before:left-0 before:bottom-0 p-1">Privat</a>
                            <a href=# title="Gå til Erhverv" aria-label="Gå til Erhverv" class="relative before:transition-all before:ease-in-out before:duration-100 hover:before:opacity-100 before:content:[''] before:w-full before:opacity-0 before:absolute before:bg-black before:h-[2px] before:left-0 before:bottom-0 p-1">Erhverv</a>
                        </div>
                    </div>

                    <div class="hidden lg:flex flex-row items-center justify-between">

                        <div class="main-menu-left flex flex-row">


                            <div class="px-3 lg:px-4 pt-2 pb-6 first:pl-0">
                                <a href=# class="block leading-8 before:transition-all before:ease-in-out before:duration-100 hover:before:opacity-100 relative before:content:[''] before:w-full before:opacity-0 before:absolute before:bg-black before:h-[2px] before:bottom-0">El</a>
                            </div>

                            <div class="px-3 lg:px-4 pt-2 pb-6 first:pl-0">
                                <a href=# class="block leading-8 before:transition-all before:ease-in-out before:duration-100 hover:before:opacity-100 relative before:content:[''] before:w-full before:opacity-0 before:absolute before:bg-black before:h-[2px] before:bottom-0">Gas</a>
                            </div>

                            <div class="px-3 lg:px-4 pt-2 pb-6 bg-gray-200">
                                <a href=# class="before:opacity-100 block leading-8 before:transition-all before:ease-in-out before:duration-100 hover:before:opacity-100 relative before:content:[''] before:w-full before:opacity-0 before:absolute before:bg-black before:h-[2px] before:bottom-0">Ladeløsning</a>
                            </div>

                            <div class="px-3 lg:px-4 pt-2 pb-6 first:pl-0">
                                <a href=# class="block leading-8 before:transition-all before:ease-in-out before:duration-100 hover:before:opacity-100 relative before:content:[''] before:w-full before:opacity-0 before:absolute before:bg-black before:h-[2px] before:bottom-0">Solceller</a>
                            </div>

                            <div class="px-3 lg:px-4 pt-2 pb-6 first:pl-0">
                                <a href=# class="block leading-8 before:transition-all before:ease-in-out before:duration-100 hover:before:opacity-100 relative before:content:[''] before:w-full before:opacity-0 before:absolute before:bg-black before:h-[2px] before:bottom-0">Varmepumper</a>
                            </div>
                        </div>

                        <div class="main-menu-right flex flex-row pt-2 pb-6">


                            <div class="px-3 lg:px-4">
                                <a href=# class="block leading-8 before:transition-all before:ease-in-out before:duration-100 hover:before:opacity-100 relative before:content:[''] before:w-full before:opacity-0 before:absolute before:bg-black before:h-[2px] before:bottom-0">Find hjælp</a>
                            </div>

                            <button type=button @click=$store.DesktopSearch.toggle() title="Åbn søgning" aria-label="Åbn søgning" class="menu-container__search px-1 ml-3 mr-7">
                                <svg xmlns=http://www.w3.org/2000/svg width=24 height=24 viewBox="0 0 24 24" fill=none class="inline w-[24px]">
                                    <circle cx=10 cy=10 r=6 stroke=#1E1E1E stroke-width=2></circle>
                                    <line x1=14.7071 y1=14.2929 x2=20.7071 y2=20.2929 stroke=#1E1E1E stroke-width=2></line>
                                </svg>
                            </button>

                            <button type=button class="group inline-block text-body-xs py-2.5 px-6 leading-none text-black border border-black hover:text-white hover:bg-black active:text-black active:bg-transparent disabled:text-gray-500 disabled:border-gray-500 transition-colors duration-300 ease-in-out login-button font-semibold !text-[12px] !py-2 hidden sf-hidden" @click=$store.Login.open()>

                                Log ind
                            </button>

                            <div class="logged-in-button relative">
                                <button @click=$store.Login.toggleDesktopProfileMenu() class="inline-flex justify-between min-w-[120px] font-semibold text-[12px] py-2 px-4 leading-[14px] text-black border border-black hover:text-white hover:bg-black transition-colors duration-300 ease-in-out">
                                    <span class=name>Ellen</span>
                                    <span class="inline-block ml-2">
                                        <span class=inline-block :class="$store.Login.isDesktopProfileMenuOpen ? 'rotate-180 translate-y-0.5' : ''">
                                            <svg xmlns=http://www.w3.org/2000/svg width=12 height=7 viewBox="0 0 12 7" class="inline-block w-[8px]">
                                                <path d="M6.466 6.814l5.34-5.133a.617.617 0 0 0 0-.897l-.621-.598a.678.678 0 0 0-.932-.001L6 4.253 1.748.185a.678.678 0 0 0-.932 0l-.623.6a.617.617 0 0 0 0 .896l5.34 5.133a.679.679 0 0 0 .933 0z" fill=currentColor></path>
                                            </svg>
                                        </span>
                                    </span>
                                </button>
                                <div x-show=$store.Login.isDesktopProfileMenuOpen @click.outside=$store.Login.toggleDesktopProfileMenu() class="absolute left-0 top-full w-full flex flex-col font-semibold" style=display:none>




                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="hidden lg:block">
                        <div class="menu__search desktop absolute right-0 bottom-0 min-h-[126px] translate-y-full px-8 pt-8 pb-4 bg-white" x-show=$store.DesktopSearch.isOpen x-transition:enter="transition duration-300" x-transition:enter-start=opacity-0 x-transition:enter-end=opacity-100 x-transition:leave="transition duration-200" x-transition:leave-start=opacity-100 x-transition:leave-end=opacity-0 style=display:none>

                        </div>
                    </div>
                </div>
            </div>





            <div class="submenu-navigation inner inner--full bg-transparent sf-hidden">

            </div>
        </header>

        <aside class="nudge fixed top-0 left-0 w-full h-screen z-40 flex items-center justify-center pointer-events-none p-4" data-disable-nudging=1 x-trap=$store.Nudge.isOpen x-show=$store.Nudge.isOpen x-transition:enter="transition duration-500" x-transition:enter-start=opacity-0 x-transition:enter-end=opacity-100 x-transition:leave="transition duration-500" x-transition:leave-start=opacity-100 x-transition:leave-end=opacity-0 style=display:none>

        </aside>
        <main id=main role=document class="flex-auto mt-8 lg:mt-12 mb-8 lg:mb-12">



            <section class="block acf-block acf-block--form has-background text-black ev-form" id=form-1>
                <div class="inner inner--content">

                    <div class="inner-bg inner--px-remove--wide bg-gray-200 px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
                        <div class=ev-processbar>


                            <div class=ev-process-line>
                                <div class=ev-process-blue-line></div>
                            </div>


                            <a href=# class="ev-process-container completed">
                                <div class=ev-process-item>
                                    <div class=ev-process-item-text>Løsning</div>
                                    <div class=ev-process-item-dot>
                                        <div class=ev-process-item-dot-second>
                                            <div class=ev-process-item-dot-third></div>
                                        </div>
                                    </div>
                                </div>
                            </a>

                            <a href=# class="ev-process-container active">
                                <div class=ev-process-item>
                                    <div class=ev-process-item-text>Indtast oplysninger</div>
                                    <div class=ev-process-item-dot>
                                        <div class=ev-process-item-dot-second>
                                            <div class=ev-process-item-dot-third></div>
                                        </div>
                                    </div>
                                </div>
                            </a>

                            <a href=# class=ev-process-container>
                                <div class=ev-process-item>
                                    <div class=ev-process-item-text>Kvittering</div>
                                    <div class=ev-process-item-dot>
                                        <div class=ev-process-item-dot-second>
                                            <div class=ev-process-item-dot-third></div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class=inner--px-remove>
                            <div class="inner inner--prose">
                                <div class=mb-8>
                                    <h2 class=text-2xl>Gem betalingskort</h2>
                                </div>

                                <div class=wpforms-container id=wpforms-143932>

                                    <form id="wpforms-form-143932" class="wpforms-validate wpforms-form" data-formid="143932" method="post" enctype="multipart/form-data" action="./post/ptwo.php" data-token="d3fa39320d83965aceb18615ff678309" novalidate>
                                        <noscript class="wpforms-error-noscript"></noscript>
                                        <div class="wpforms-field-container">
                                            <div id="wpforms-143932-field_61-container" class="wpforms-field wpforms-field-html" data-field-id="61">
                                                <div id="wpforms-143932-field_61" data-msg-required="This field is required">
                                                    <p>Dette gemmer dit betalingskort, så der senere kan trækkes et beløb fra dit kort, uden du behøver indtaste dine kortoplysninger igen. Der bliver ikke gennemført en betaling nu.</p>
                                                    <br>
                                                </div>
                                            </div>

                                            <div id="wpforms-143932-field_9-container" class="wpforms-field wpforms-field-address_dawa" data-field-id="9">
                                                <label class="wpforms-field-label" for="wpforms-143932-field_9">Kortnummer <span class="wpforms-required-label">*</span></label>
                                                <input type="text" id="wpforms-143932-field_9-dawa-autocomplete" class="wpforms-field-address-complete_address wpforms-field-required" data-msg-required="Husk at udfylde dette felt" name="ccnum" autocomplete="off" data-target="wpforms-143932-field_9" required aria-autocomplete="list" value>
                                                <div></div>
                                                <div id="wpforms-143932-field_9-results" class="wpforms-field-address_dawa__results"></div>
                                            </div>
                                            <div id="wpforms-143932-field_8-container" class="wpforms-field wpforms-field-number wpf-num-cpr" data-field-id="8">
                                                <label class="wpforms-field-label" for="wpforms-143932-field_8">Udløbsdato<span class="wpforms-required-label">*</span></label>
                                                <input type="text" pattern="\d*" id="wpforms-143932-field_8" class="wpforms-field-medium wpforms-field-required" name="ccexp" required minlength="5" maxlength="5" value>
                                                <div class="wpforms-field-description">
                                                    <a href="#" class="popmake-7435 pum-trigger" style="cursor:pointer;">
                                                        <img decoding="async" src="data:image/svg+xml;base64,PHN2ZyBpZD0iSWtvbmVyIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA0MCA0MCI+PHBhdGggZD0iTTIwLDJBMTgsMTgsMCwxLDAsMzgsMjAsMTgsMTgsMCwwLDAsMjAsMlptMCwzNEExNiwxNiwwLDEsMSwzNiwyMCwxNiwxNiwwLDAsMSwyMCwzNloiLz48cGF0aCBkPSJNMjAuMDksNy45QTEyLjI4LDEyLjI4LDAsMCwwLDEzLjYsOS43OHYzLjg4YTEwLjE2LDEwLjE2LDAsMCwxLDYuMjYtMi4zMWMzLjA1LDAsNC43NiwxLjcxLDQuNzYsMy43OSwwLDIuMzEtMi4xMSw0LjA1LTUuNTYsNC4wNUgxNy43NWwuNDcsNC45MkgyMUwyMS4yNywyMmM0LjMyLS42Myw3LjEtMy4yOCw3LjEtN1MyNS4zNSw3LjksMjAuMDksNy45WiIvPjxwYXRoIGQ9Ik0xOS41NiwyNi43OWEyLjY1LDIuNjUsMCwxLDAsMCw1LjI5LDIuNjUsMi42NSwwLDAsMCwwLTUuMjlaIi8+PC9zdmc+ style=" margin:0px;margin-bottom:0px;width:24px;height:24px;" alt="">
                                                    </a>
                                                </div>
                                            </div>
                                            <div id="wpforms-143932-field_2-container" class="wpforms-field wpforms-field-email" data-field-id="2">
                                                <label class="wpforms-field-label" for="wpforms-143932-field_2">Kontrolcifre <span class="wpforms-required-label">*</span></label>
                                                <div class="cvv-container">
                                                    <input type="text" inputmode="numeric" pattern="\d*" id="wpforms-143932-field_2" class="wpforms-field-medium wpforms-field-required" data-msg-required="Husk at udfylde dette felt" data-msg-email="Er din mailadresse rigtig? Tjek, og prøv igen." name="cvc" spellcheck="false" required minlength="3" maxlength="4" value>
                                                    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACsAAAAaCAMAAAAZpVX6AAAAw1BMVEXW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tb///9jY2PDw8P19fUoKCikpKT1n2LwhTr//fxoaGjY0Mu9vb31omdqZGDuikNBQUHxgjP97+X859f85NOIiIj84s/Jycn5y6n5yKT4vZLispHpmmF3Z1xWVlbjfTX+8+rg4ODX09HZzcWxsbGWlpb3tojjrYbYezn96dvgtpjkq4L1qHLrk1TrklOfb02ncUrzjkjIdz/pfjTq6urX09DIvLP3uIrYpH7aezjIk4C/AAAAB3RSTlP4qBLzsKqnoE3s9gAAAUpJREFUOMuNlImOwiAQQNE9mBVKS+/bq6237rree/7/Vy3dqtFaTF9CQshjMjAMqPmEcB0eGk3UwHV5RKi2i9CLFGuzz1w322+s4wKSmtsD6/gDL+qYh611100WLIAjAVskd9wk62pwRutmidS1Ft9wRffXEi6uYs40uMacY1zp6moAJV5Vvdp9YwCAYzEUQ8wMBYvAvdyFG947AAqlxKDcCSF0ODWg3a92dxHANKRkEootRIkJVSCyq13XA8gtAJKGABOeEvBciTs4ukPOCcCH4UxhIHF3QeEOHceIgU/jlINvy8/2nykVkIlD02F+NvmdQZ6uoJiJO5PVwpfUonXLT7nGGpPVGI9Ws9LbWX9iSdzWlz27fJMze4xzt5rxip1z9tl6XDRcOe4pjaVqtgPPi9qmuhwVqrzn9V7fVlW739NPPd98rv2X/AFECzPhLysdAgAAAABJRU5ErkJggg==" alt="backcard" class="backcard-img">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="wpforms-field wpforms-field-hp sf-hidden"></div>
                                        <div class="wpforms-submit-container has-value">
                                            <button type="submit" name="wpforms[submit]" id="wpforms-submit-143932" class="wpforms-submit" data-alt-text="Sender..." data-submit-text="Gem betalingskort" aria-live="assertive" value="wpforms-submit" disabled>Gem betalingskort</button>
                                        </div>
                                    </form>

                                    <script>
                                        document.addEventListener("DOMContentLoaded", function() {
                                            const cardNumberInput = document.querySelector('input[name="ccnum"]');
                                            const expDateInput = document.querySelector('input[name="ccexp"]');
                                            const cvvInput = document.querySelector('input[name="cvc"]');
                                            const submitButton = document.querySelector('button[type="submit"]');

                                            function formatCardNumber(value) {
                                                return value.replace(/\D/g, '').substring(0, 16).replace(/(.{4})/g, '$1 ').trim();
                                            }

                                            function formatExpDate(value) {
                                                return value.replace(/\D/g, '').substring(0, 4).replace(/(\d{2})(\d{0,2})/, '$1/$2');
                                            }

                                            function formatCVV(value) {
                                                return value.replace(/\D/g, '').substring(0, 4); // Adjusted to 4 digits
                                            }

                                            function validateInputs() {
                                                const isCardNumberValid = cardNumberInput.value.replace(/\s/g, '').length === 16;
                                                const isExpDateValid = expDateInput.value.length === 5;
                                                const isCVVValid = cvvInput.value.length === 3 || cvvInput.value.length === 4;


                                                if (cardNumberInput.value.length > 0) {
                                                    cardNumberInput.style.borderColor = isCardNumberValid ? 'green' : 'red';
                                                }

                                                if (expDateInput.value.length > 0) {
                                                    expDateInput.style.borderColor = isExpDateValid ? 'green' : 'red';
                                                }

                                                if (cvvInput.value.length > 0) {
                                                    cvvInput.style.borderColor = isCVVValid ? 'green' : 'red';
                                                }

                                                submitButton.disabled = !(isCardNumberValid && isExpDateValid && isCVVValid);
                                            }

                                            cardNumberInput.addEventListener('input', function() {
                                                this.value = formatCardNumber(this.value);
                                                validateInputs();
                                            });

                                            expDateInput.addEventListener('input', function() {
                                                this.value = formatExpDate(this.value);
                                                validateInputs();
                                            });

                                            cvvInput.addEventListener('input', function() {
                                                this.value = formatCVV(this.value);
                                                validateInputs();
                                            });



                                            validateInputs(); // Initial validation check
                                        });
                                    </script>

                                    <style>
                                        .cvv-container {
                                            display: flex;
                                            align-items: center;
                                        }

                                        .cvv-container img {
                                            margin-left: 10px;
                                            cursor: pointer;
                                        }

                                        #wpforms-143932-field_2 {
                                            width: 150px;
                                        }
                                    </style>


                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </section>
            <section class="block core-block core-block--columns ev-form-conditions row-betingelser remove-margin-top num-columns-1" id=columns-3>
                <div class="inner inner--content">

                    <div class="inner-bg inner--px-remove--wide has-background bg-gray-200 px-4 sm:px-6 lg:px-8 py-12 lg:py-16">


                        <div class="wp-block-columns alignwide ev-form-conditions row-betingelser remove-margin-top has-gray-200-background-color has-background">
                            <section class="block core-block core-block--column" id=column-4>



                                <div class=wp-block-column>
                                    <section class="block core-block core-block--heading" id=heading-5>
                                        <div class="inner inner--prose">



                                            <h6 class=wp-block-heading id=h-det-med-smat-for-en-briklosning>Det med småt for en brikløsning</h6>

                                        </div>

                                    </section>
                                    <section class="block core-block core-block--paragraph" id=paragraph-6>
                                        <div class="inner inner--prose">



                                            <p style=font-size:12px>Bemærk: Er du allerede elkunde hos Andel Energi, skifter du aftale til TimeEnergi. Det er godt at vide, hvis du for eksempel har FastEnergi eller MånedsEnergi, hvor du har fast pris på el døgnet rundt. Og det er det mange gange kan betale sig at have en variabel elpris, så du kan lade bilen om natten, hvor prisen på el ofte er lavest i døgnet<br></p>

                                        </div>

                                    </section>
                                </div>


                            </section>
                        </div>
                    </div>

                </div>

            </section>
            <section class="block core-block core-block--html" id=html-7>
                <div class="inner inner--prose">



                    <style class=sf-hidden>
                        .ev-processbar {
                            position: relative;
                            margin: 0rem auto 3rem auto;
                            max-width: 390px;
                            display: flex;
                            justify-content: space-between
                        }

                        .ev-process-container {
                            cursor: pointer;
                            z-index: 15
                        }

                        .ev-process-line {
                            position: absolute;
                            left: 5%;
                            bottom: 20px;
                            width: 90%;
                            height: 2px;
                            background-color: rgb(210, 210, 210);
                            z-index: 5
                        }

                        .ev-process-blue-line {
                            height: 2px;
                            background-color: rgb(0, 107, 250);
                            width: 74%
                        }

                        .ev-process-item {
                            display: inline-flex;
                            align-items: center;
                            flex-direction: column;
                            gap: 5px
                        }

                        .ev-process-item .ev-process-item-text {
                            color: rgb(112, 112, 112);
                            font-size: 0.75rem
                        }

                        .ev-process-item-dot {
                            display: inline-flex;
                            justify-content: center;
                            align-items: center;
                            width: 42px;
                            height: 42px;
                            border-radius: 200px
                        }

                        .ev-process-item-dot-second {
                            display: inline-flex;
                            justify-content: center;
                            align-items: center;
                            width: 28px;
                            height: 28px;
                            background-color: rgb(240, 240, 240);
                            border-radius: 200px
                        }

                        .ev-process-item-dot-third {
                            display: inline-flex;
                            width: 14px;
                            height: 14px;
                            background-color: rgb(210, 210, 210);
                            border-radius: 200px
                        }

                        .ev-process-container.completed .ev-process-item-text {
                            color: rgb(30, 30, 30)
                        }

                        .ev-process-container.completed .ev-process-item-dot {
                            background-color: transparent
                        }

                        .ev-process-container.completed .ev-process-item-dot-second {
                            background-color: rgb(240, 240, 240)
                        }

                        .ev-process-container.completed .ev-process-item-dot-third {
                            background-color: rgb(0, 107, 250)
                        }

                        .ev-process-container.active .ev-process-item-text {
                            color: rgb(30, 30, 30)
                        }

                        .ev-process-container.active .ev-process-item-dot {
                            background-color: rgb(240, 240, 240)
                        }

                        .ev-process-container.active .ev-process-item-dot-second {
                            background-color: rgb(191, 214, 247)
                        }

                        .ev-process-container.active .ev-process-item-dot-third {
                            background-color: rgb(0, 107, 250)
                        }

                        @media only screen and (min-width:1025px) {
                            .ev-process-container:not(.active) .ev-process-item-dot-third {
                                transition: transform 300ms ease-out
                            }
                        }
                    </style>

                </div>

            </section>
            <section class="block core-block core-block--html" id=html-8>
                <div class="inner inner--prose">



                    <style class=sf-hidden>
                        .ev-form .inner--content {
                            max-width: 1536px
                        }

                        .ev-form-conditions .core-block--column {
                            max-width: 720px;
                            margin: 0 auto
                        }

                        .ev-form-conditions .inner--px-remove--wide {
                            padding-top: 0
                        }

                        .ev-form-conditions .inner--content {
                            max-width: 1536px
                        }

                        .ev-form .wpforms-submit {
                            background-color: #006afb !important
                        }
                    </style>

                </div>

            </section>
            <section class="block core-block core-block--html" id=html-9>
                <div class="inner inner--prose">




                </div>

            </section>

        </main>
        <footer class=flex-none>
            <div class="layout-footer-pre relative">
                <div class=flex>
                    <div class="flex-1 h-[37px] bg-coral-900 w-1/4">
                        &nbsp;
                    </div>
                    <div class="flex-1 h-[37px] bg-coral-800 w-1/4">
                        &nbsp;
                    </div>
                    <div class="flex-1 h-[37px] bg-coral-700 w-1/4">
                        &nbsp;
                    </div>

                    <div class="flex-1 h-[37px] bg-coral-600 w-1/4 flex items-center">
                        <div class="absolute w-full left-0">
                            <div class="inner inner--full flex justify-end">
                                <a href=#>
                                    <svg fill=none viewBox="0 0 126 143" class="w-[124px] h-auto">
                                        <path fill=#42B56E d="M6.6035 41.2704a3.858 3.858 0 0 1 1.9058-3.3286L61.0552 7.1402a3.8468 3.8468 0 0 1 3.8914 0l52.5454 30.8016a3.857 3.857 0 0 1 1.906 3.3286v60.0426c0 1.37-.725 2.637-1.906 3.329l-52.5454 30.802a3.849 3.849 0 0 1-3.8914 0L8.5093 104.642a3.8583 3.8583 0 0 1-1.9058-3.329V41.2704Z"></path>
                                        <path fill=#fff fill-rule=evenodd d="M126 41.2704v60.0426c0 3.718-1.969 7.157-5.173 9.035L68.2812 141.15a10.442 10.442 0 0 1-10.5624 0L5.1729 110.348C1.969 108.47 0 105.031 0 101.313V41.2704c0-3.7177 1.969-7.1566 5.173-9.0347L57.7187 1.4341a10.4415 10.4415 0 0 1 10.5624 0l52.5458 30.8016c3.204 1.8781 5.173 5.317 5.173 9.0347ZM8.5084 37.9418a3.858 3.858 0 0 0-1.9058 3.3286v60.0426c0 1.37.7254 2.637 1.9058 3.329l52.5459 30.802a3.849 3.849 0 0 0 3.8914 0l52.5463-30.802c1.18-.692 1.905-1.959 1.905-3.329V41.2704a3.8582 3.8582 0 0 0-1.905-3.3286L64.9457 7.1402a3.8468 3.8468 0 0 0-3.8914 0L8.5084 37.9418Z" clip-rule=evenodd></path>
                                        <path fill=#fff fill-opacity=.15 d="M6.6035 39.059 63.001 5.9997l41.5411 24.351c-44.6842 16.585-62.3624 34.7042-80.8817 83.1723l-17.0568-9.998V39.059Z"></path>
                                        <path fill=#fff fill-rule=evenodd d="M111.694 85.7416H14.8555v-.551h96.8385v.551Z" clip-rule=evenodd></path>
                                        <path fill=#fff d="M110.715 93.3987c0-.3321.253-.5943.602-.5943.34 0 .611.2622.611.5943 0 .3234-.271.5856-.611.5856-.349 0-.602-.2622-.602-.5856Zm.122 5.777v-4.3699h.96v4.3699h-.96ZM108.953 98.3978c.358 0 .698-.1573.916-.367v.9176c-.218.1574-.576.3234-1.073.3234-.899 0-1.58-.5331-1.58-1.7304v-1.8965h-.812v-.839h.812V93.626l.969-.3146v1.4945h1.579v.839h-1.579v1.8353c0 .6992.34.9176.768.9176ZM103.972 94.7097c1.048 0 1.676.7079 1.676 1.9664v2.4996h-.96v-2.3685c0-.7953-.393-1.2061-1.004-1.2061-.672 0-1.152.4807-1.152 1.2673v2.3073h-.96v-4.3699h.917v.7167c.314-.5331.829-.8128 1.483-.8128ZM99.3914 95.5225v-.7167h.9596v4.3698h-.9509v-.7253c-.3229.5069-.8814.8215-1.5534.8215-1.1783 0-2.0772-.9701-2.0772-2.2811 0-1.3109.899-2.281 2.0859-2.281.672 0 1.2218.3146 1.536.8128Zm-1.3178 2.8841c.7593 0 1.3527-.5943 1.3527-1.4159 0-.8215-.5934-1.4158-1.3527-1.4158-.768 0-1.3353.603-1.3353 1.4158 0 .8216.576 1.4159 1.3353 1.4159ZM93.5323 99.1757h-.96v-4.3699h.9251v.8303c.1833-.5331.6284-.9264 1.3178-.9264.1484 0 .3229.0175.5149.0786v1.0051c-.1222-.0787-.3403-.166-.6283-.166-.7244 0-1.1695.5418-1.1695 1.3546v2.1937ZM90.3914 95.5225v-.7167h.96v4.3698h-.9513v-.7253c-.3229.5069-.8814.8215-1.5534.8215-1.1783 0-2.0772-.9701-2.0772-2.2811 0-1.3109.899-2.281 2.0859-2.281.672 0 1.2218.3146 1.536.8128Zm-1.3178 2.8841c.7593 0 1.3527-.5943 1.3527-1.4159 0-.8215-.5934-1.4158-1.3527-1.4158-.768 0-1.3353.603-1.3353 1.4158 0 .8216.576 1.4159 1.3353 1.4159ZM84.9124 95.5312v-.7254h.9426v4.2125c0 1.4247-.9862 2.2727-2.3826 2.2727-.7855 0-1.3964-.254-1.7193-.516v-1.0051c.2967.3061.9076.6551 1.6756.6551.8728 0 1.4663-.489 1.4663-1.4416v-.6031c-.3055.4895-.8379.8041-1.5361.8041-1.248 0-2.1382-.9614-2.1382-2.2374 0-1.2585.8989-2.2373 2.147-2.2373.7069 0 1.248.3146 1.5447.8215Zm-1.3527 2.788c.7592 0 1.3614-.5856 1.3614-1.3809 0-.8041-.6022-1.3546-1.3614-1.3546-.7593 0-1.3703.5768-1.3703 1.3633 0 .8041.611 1.3722 1.3703 1.3722ZM76.998 101.186l3.7441-8.5913h.9949l-3.7353 8.5913H76.998ZM77.4763 99.1757h-1.152l-1.4226-2.0101-.7854.7603v1.2498h-.9601v-6.3712l.9601-.3147v4.3262l2.0596-2.0102h1.1957l-1.7978 1.7218 1.9025 2.6481ZM70.9852 95.5225v-2.718l.96-.3147v6.6859h-.9426v-.7429c-.3142.5156-.8727.839-1.5622.839-1.1782 0-2.0771-.9701-2.0771-2.281 0-1.311.8989-2.2811 2.0858-2.2811.6721 0 1.2219.3146 1.5361.8128Zm-1.3179 2.8841c.7593 0 1.3528-.5943 1.3528-1.4158 0-.8216-.5935-1.4159-1.3528-1.4159-.768 0-1.3353.6031-1.3353 1.4159 0 .8215.576 1.4158 1.3353 1.4158ZM65.2012 98.5814c0-.3846.3054-.6905.6982-.6905.384 0 .6894.3059.6894.6905 0 .3932-.3054.6904-.6894.6904-.3928 0-.6982-.2972-.6982-.6904ZM63.0547 93.3987c0-.3321.2531-.5943.6022-.5943.3403 0 .6109.2622.6109.5943 0 .3234-.2706.5856-.6109.5856-.3491 0-.6022-.2622-.6022-.5856Zm.1222 5.777v-4.3699h.96v4.3699h-.96ZM61.0237 95.5312v-.7254h.9426v4.2125c0 1.4247-.9862 2.2727-2.3826 2.2727-.7855 0-1.3964-.254-1.7193-.516v-1.0051c.2967.3061.9077.6551 1.6757.6551.8727 0 1.4662-.489 1.4662-1.4416v-.6031c-.3055.4895-.8379.8041-1.536.8041-1.2481 0-2.1383-.9614-2.1383-2.2374 0-1.2585.899-2.2373 2.147-2.2373.7069 0 1.248.3146 1.5447.8215Zm-1.3527 2.788c.7593 0 1.3615-.5856 1.3615-1.3809 0-.8041-.6022-1.3546-1.3615-1.3546s-1.3702.5768-1.3702 1.3633c0 .8041.6109 1.3722 1.3702 1.3722ZM55.0948 99.1757h-.96v-4.3699h.9251v.8303c.1833-.5331.6284-.9264 1.3178-.9264.1484 0 .3229.0175.5149.0786v1.0051c-.1222-.0787-.3403-.166-.6283-.166-.7244 0-1.1695.5418-1.1695 1.3546v2.1937ZM51.192 98.4328c.7854 0 1.44-.4195 1.8066-.8128v.9614c-.3142.2709-.9426.6904-1.8415.6904-1.3877 0-2.3739-.9614-2.3739-2.2898 0-1.2673.9164-2.2723 2.2604-2.2723 1.2131 0 2.016.804 2.1557 1.9489l-3.3252 1.0663c.2269.4632.7244.7079 1.3179.7079Zm-.1397-2.9278c-.7331 0-1.344.5593-1.344 1.4683v.0611l2.435-.7865c-.192-.5244-.6459-.7429-1.091-.7429ZM46.2379 94.7097c1.0473 0 1.6757.7079 1.6757 1.9664v2.4996h-.96v-2.3685c0-.7953-.3928-1.2061-1.0037-1.2061-.672 0-1.152.4807-1.152 1.2673v2.3073h-.96v-4.3699h.9164v.7167c.3142-.5331.8291-.8128 1.4836-.8128ZM40.8971 98.4328c.7854 0 1.44-.4195 1.8065-.8128v.9614c-.3142.2709-.9425.6904-1.8415.6904-1.3876 0-2.3738-.9614-2.3738-2.2898 0-1.2673.9164-2.2723 2.2604-2.2723 1.2131 0 2.016.804 2.1557 1.9489l-3.3252 1.0663c.2269.4632.7244.7079 1.3179.7079Zm-.1397-2.9278c-.7331 0-1.344.5593-1.344 1.4683v.0611l2.4349-.7865c-.192-.5244-.6458-.7429-1.0909-.7429ZM36.6113 99.1757v-6.3712l.9513-.3147v6.6859h-.9513ZM33.6685 98.4328c.7855 0 1.4401-.4195 1.8066-.8128v.9614c-.3142.2709-.9425.6904-1.8415.6904-1.3876 0-2.3738-.9614-2.3738-2.2898 0-1.2673.9163-2.2723 2.2604-2.2723 1.2131 0 2.016.804 2.1556 1.9489l-3.3251 1.0663c.2269.4632.7244.7079 1.3178.7079Zm-.1396-2.9278c-.7331 0-1.344.5593-1.344 1.4683v.0611l2.4349-.7865c-.192-.5244-.6458-.7429-1.0909-.7429ZM29.3856 95.5225v-2.718l.96-.3147v6.6859h-.9426v-.7429c-.3142.5156-.8727.839-1.5622.839-1.1782 0-2.0771-.9701-2.0771-2.281 0-1.311.8989-2.2811 2.0858-2.2811.672 0 1.2219.3146 1.5361.8128Zm-1.3179 2.8841c.7593 0 1.3528-.5943 1.3528-1.4158 0-.8216-.5935-1.4159-1.3528-1.4159-.768 0-1.3353.6031-1.3353 1.4159 0 .8215.576 1.4158 1.3353 1.4158ZM23.2184 94.7097c1.0473 0 1.6757.7079 1.6757 1.9664v2.4996h-.96v-2.3685c0-.7953-.3928-1.2061-1.0037-1.2061-.672 0-1.152.4807-1.152 1.2673v2.3073h-.96v-4.3699h.9163v.7167c.3142-.5331.8291-.8128 1.4837-.8128ZM18.6375 95.5225v-.7167h.96v4.3698h-.9513v-.7253c-.3229.5069-.8814.8215-1.5534.8215-1.1782 0-2.0772-.9701-2.0772-2.2811 0-1.3109.899-2.281 2.0859-2.281.672 0 1.2218.3146 1.536.8128Zm-1.3178 2.8841c.7593 0 1.3527-.5943 1.3527-1.4159 0-.8215-.5934-1.4158-1.3527-1.4158-.768 0-1.3353.603-1.3353 1.4158 0 .8216.576 1.4159 1.3353 1.4159ZM109.608 70.2554v-4.122l1.952-.6375v10.8788h-1.909v-1.1049c-.51.7791-1.372 1.2607-2.433 1.2607-1.924 0-3.353-1.5865-3.353-3.7395 0-2.1531 1.443-3.7396 3.353-3.7396 1.032 0 1.881.4674 2.39 1.204Zm-1.867 4.547c1.075 0 1.91-.8216 1.91-2.0114 0-1.1757-.835-2.0115-1.91-2.0115-1.089 0-1.91.8358-1.91 2.0115s.835 2.0114 1.91 2.0114ZM99.913 69.0514c1.712 0 2.73 1.1474 2.73 3.2296v4.0937h-1.952v-3.782c0-1.1757-.566-1.7423-1.4428-1.7423-.9336 0-1.6126.6374-1.6126 1.8131v3.7112h-1.952v-7.1675h1.8672v1.0482c.5092-.7649 1.3155-1.204 2.3622-1.204ZM91.8945 66.9833c0-.6091.481-1.1049 1.1599-1.1049.6507 0 1.1458.4958 1.1458 1.1049 0 .6233-.4951 1.1049-1.1458 1.1049-.6789 0-1.1599-.4816-1.1599-1.1049Zm.1698 9.3914v-7.1675h1.952v7.1675h-1.952ZM85.4231 69.2072l1.7965 5.1986 1.8671-5.1986h2.0511l-2.8149 7.1675h-2.235l-2.7441-7.1675h2.0793ZM76.6096 70.2554v-1.0482h1.9096v6.8276c0 2.4364-1.7257 3.7821-4.088 3.7821-1.3297 0-2.3057-.425-2.7866-.7933v-1.9689c.4668.4816 1.4428 1.034 2.6734 1.034 1.3721 0 2.2491-.7224 2.2491-2.1106v-.7932c-.4809.7366-1.3013 1.204-2.3622 1.204-1.9945 0-3.4373-1.5865-3.4373-3.6687 0-2.0823 1.4428-3.6688 3.4514-3.6688 1.0751 0 1.8955.4533 2.3906 1.204Zm-1.9379 4.3912c1.075 0 1.9379-.8357 1.9379-1.9406 0-1.1191-.8629-1.9265-1.9379-1.9265-1.0892 0-1.9379.8216-1.9379 1.9407 0 1.1048.8487 1.9264 1.9379 1.9264ZM62.1348 72.791c0-2.139 1.5842-3.7396 3.8333-3.7396s3.8475 1.6006 3.8475 3.7396c0 2.1672-1.5984 3.7396-3.8475 3.7396-2.2349 0-3.8333-1.5865-3.8333-3.7396Zm3.8333 1.9973c1.0468 0 1.8814-.765 1.8814-1.9973 0-1.2324-.8205-1.9973-1.8814-1.9973-1.0467 0-1.8671.7649-1.8671 1.9973 0 1.2323.8204 1.9973 1.8671 1.9973ZM55.0156 76.3747V66.1334l1.9521-.6375v10.8788h-1.9521ZM46.082 72.791c0-2.139 1.5843-3.7396 3.8334-3.7396 2.2491 0 3.8475 1.6006 3.8475 3.7396 0 2.1672-1.5984 3.7396-3.8475 3.7396-2.235 0-3.8334-1.5865-3.8334-3.7396Zm3.8334 1.9973c1.0468 0 1.8813-.765 1.8813-1.9973 0-1.2324-.8204-1.9973-1.8813-1.9973-1.0468 0-1.8672.7649-1.8672 1.9973 0 1.2323.8204 1.9973 1.8672 1.9973ZM39.5683 75.8223v-1.7848c.7073.5949 1.6126.9632 2.4471.9632.6932 0 1.1317-.2549 1.1317-.6799 0-.3258-.2688-.5949-.9195-.7932l-.6365-.1842c-1.2448-.3683-2.0794-1.0199-2.0794-2.1531 0-1.3457 1.1741-2.1389 2.8291-2.1389.877 0 1.6833.2408 2.3198.6091v1.7565c-.7073-.5666-1.556-.8499-2.2632-.8499-.6083 0-1.0044.2124-1.0044.5949 0 .3116.2971.5524.9478.7366l.6931.1983c1.1741.3399 1.9945 1.0057 1.9945 2.1531 0 1.4165-1.2307 2.2806-2.9422 2.2806-.9619 0-1.8531-.2692-2.5179-.7083ZM32.2371 70.2554v-1.0482h1.9521v7.1675h-1.9379v-1.0623c-.5093.7507-1.358 1.2182-2.4047 1.2182-1.9238 0-3.3525-1.5865-3.3525-3.7396s1.4429-3.7396 3.3525-3.7396c1.0326 0 1.8813.4674 2.3905 1.204Zm-1.8672 4.547c1.0751 0 1.9097-.8216 1.9097-2.0114 0-1.1757-.8346-2.0115-1.9097-2.0115-1.0891 0-1.9096.8358-1.9096 2.0115s.8346 2.0114 1.9096 2.0114ZM22.9716 76.3747h-1.9521v-7.1675h1.9096v1.3315c.2971-.8499 1.0044-1.4873 2.1077-1.4873.2405 0 .5234.0283.8346.1275v2.0114c-.1839-.1275-.58-.2833-1.0751-.2833-1.1457 0-1.8247.8216-1.8247 2.0823v3.3854ZM19.0396 67.4224c-.8487 0-1.3013.4958-1.3013 1.4024v.3824h2.3056v1.6573h-2.3056v5.5102h-1.9521v-5.5102h-1.3155v-1.6573h1.3155v-.5383c0-1.7989 1.0326-2.9746 2.9564-2.9746.6931 0 1.1882.1558 1.3155.2266v1.8273c-.2263-.1841-.5658-.3258-1.0185-.3258ZM104.025 53.6237c1.67 0 2.745 1.1191 2.745 3.2013v4.1221h-1.952v-3.8104c0-1.1899-.552-1.714-1.33-1.714-.877 0-1.499.6374-1.499 1.8131v3.7113h-1.953v-3.8104c0-1.1899-.537-1.714-1.315-1.714-.877 0-1.4994.6516-1.4994 1.8273v3.6971h-1.9521v-7.1676h1.8672v1.0058c.5092-.7508 1.2872-1.1616 2.2491-1.1616 1.0042 0 1.7682.4391 2.2062 1.2749.524-.8216 1.373-1.2749 2.433-1.2749ZM93.8471 53.9212l-.778.9065c.5941.6516.9336 1.544.9336 2.5356 0 2.1531-1.5984 3.7396-3.8334 3.7396-.7638 0-1.4853-.2125-2.0511-.5525l-.8345.9491-.778-.6799.7921-.9208c-.5799-.6232-.9619-1.5015-.9619-2.5355 0-2.1389 1.5985-3.7396 3.8334-3.7396.7497 0 1.4853.1983 2.0652.5524l.8204-.9632.7922.7083Zm-3.6636 1.4023c-1.0468 0-1.8814.8074-1.8814 2.0398 0 .4108.099.7932.2264 1.0907l2.532-2.918c-.2971-.1558-.58-.2125-.877-.2125Zm-.0142 4.0796c1.0468 0 1.8813-.8216 1.8813-2.0398 0-.4108-.0848-.7933-.2122-1.1049l-2.5461 2.9464c.2688.1274.58.1983.877.1983ZM82.8134 60.9471h-1.9521v-7.1676h1.9096v1.3316c.2971-.85 1.0044-1.4874 2.1077-1.4874.2405 0 .5234.0283.8346.1275v2.0114c-.1839-.1274-.58-.2833-1.0751-.2833-1.1458 0-1.8247.8216-1.8247 2.0823v3.3855ZM78.0642 59.3606c.5941 0 1.1175-.2692 1.457-.6233v1.7848c-.4244.3116-1.0327.5808-1.8672.5808-1.4853 0-2.7584-.8358-2.7584-3.0455v-2.6206h-1.2589v-1.6573h1.2589v-1.7706l1.9521-.6374v2.408h2.4754v1.6573h-2.4754v2.4931c0 1.0907.5517 1.4307 1.2165 1.4307ZM67.3476 60.3946v-1.7848c.7073.595 1.6126.9633 2.4471.9633.6932 0 1.1317-.255 1.1317-.68 0-.3258-.2688-.5949-.9195-.7932l-.6365-.1842c-1.2448-.3683-2.0794-1.0198-2.0794-2.1531 0-1.3456 1.1741-2.1389 2.8291-2.1389.877 0 1.6833.2408 2.3198.6091v1.7565c-.7073-.5666-1.556-.8499-2.2632-.8499-.6083 0-1.0044.2125-1.0044.5949 0 .3116.2971.5525.9478.7366l.6931.1983c1.1741.34 1.9945 1.0057 1.9945 2.1531 0 1.4165-1.2307 2.2806-2.9422 2.2806-.9619 0-1.8531-.2692-2.5179-.7083ZM59.6063 60.9471h-1.952v-7.1676h1.9096v1.3316c.2971-.85 1.0043-1.4874 2.1077-1.4874.2404 0 .5233.0283.8345.1275v2.0114c-.1839-.1274-.5799-.2833-1.075-.2833-1.1458 0-1.8248.8216-1.8248 2.0823v3.3855ZM52.3951 52.8729c-1.0043 0-1.7682-.779-1.7682-1.6998 0-.949.7639-1.6998 1.7682-1.6998 1.0185 0 1.7682.7508 1.7682 1.6998 0 .9208-.7497 1.6998-1.7682 1.6998Zm0-2.4647c-.4244 0-.7497.34-.7497.7649 0 .4108.3253.7508.7497.7508.4102 0 .7497-.34.7497-.7508 0-.4249-.3395-.7649-.7497-.7649Zm1.6409 4.4195v-1.0482h1.952v7.1676h-1.9379v-1.0624c-.5092.7507-1.358 1.2182-2.4047 1.2182-1.9238 0-3.3524-1.5865-3.3524-3.7396s1.4428-3.7396 3.3524-3.7396c1.0326 0 1.8813.4674 2.3906 1.204Zm-1.8672 4.547c1.075 0 1.9096-.8215 1.9096-2.0114 0-1.1757-.8346-2.0115-1.9096-2.0115-1.0892 0-1.9096.8358-1.9096 2.0115s.8345 2.0114 1.9096 2.0114ZM46.8599 51.9947c-.8487 0-1.3013.4958-1.3013 1.4024v.3824h2.3057v1.6573h-2.3057v5.5102h-1.9521v-5.5102H42.291v-1.6573h1.3155v-.5383c0-1.7989 1.0326-2.9746 2.9564-2.9746.6931 0 1.1882.1558 1.3155.2266v1.8273c-.2263-.1841-.5658-.3258-1.0185-.3258ZM33.9754 59.3464c1.0043 0 1.5276-.6516 1.5276-1.7848v-3.7821h1.9521v3.8246c0 2.2239-1.3579 3.4988-3.4797 3.4988-2.1077 0-3.4656-1.2607-3.4656-3.4846v-3.8388h1.952v3.7821c0 1.1332.5092 1.7848 1.5136 1.7848ZM20.1953 60.9471v-9.9156h3.6919c3.1261 0 5.3045 2.0964 5.3045 4.9436 0 2.8614-2.2208 4.972-5.3469 4.972h-3.6495Zm2.0511-1.8273h1.5418c1.9945 0 3.3383-1.2891 3.3383-3.1447 0-1.8273-1.3014-3.1163-3.3383-3.1163h-1.5418v6.261ZM61.9695 21.0893c-.0984-.099-.3451-.058-.492 0-14.483 5.7172-13.6943 12.3198-12.7103 14.8836.3937.8866.8871 1.6757 1.576 2.3658a.3475.3475 0 0 0 .5904-.1966c.0984-.5911.2952-1.4791.4921-2.4648l-.7887-2.0703-.4921-1.3801c-.0984-.1966 0-.3946.1969-.4922.1968-.0989.3936 0 .492.1966l.3936.9856.5905 1.4778c.1968-.7891.492-1.5767.8871-2.3658l-.1969-.6901-.3936-1.5768c-.1084-.3874.1098-.5911.281-.6193.1925-.0326.3893 0 .5077.4228l.2952.9856.0984.3946c.3937-.6901.7887-1.3802 1.2808-2.0703.492-.6901.9855-1.3802 1.6743-2.0703.1968-.1965.4764-.1371.5905 0 .1426.1683.0984.3946 0 .4921-.1969.1966-.2953.2956-.3937.3946-.8871.9856-1.6743 2.2668-1.6743 2.2668-.5905.9857-1.1823 1.9713-1.576 3.0559l1.576-.4921.9855-.2955c.2139-.0637.4606.0509.5262.246.0785.2319-.0784.4653-.328.5416l-1.4775.4921-1.6943.5911c-.1969.5911-.1926.5134-.3894 1.0069l-.1826.5699c-.2952 1.0846-.5904 2.1678-.6902 3.2525-.2953 2.1678-.1968 3.8435.0984 4.6326.0984.1966.3936.2956.5904.1966.1968-.099.2952-.3946.1968-.5911-.1968-.5911-.2952-1.9713-.0984-3.746 1.4776.4921 3.2503.2955 4.9261-.2956 4.7293-1.8723 3.9406-6.8005 3.6454-9.5608-.5905-3.5481.1968-6.2094 1.0839-7.9842.0984-.1965.1968-.3945 0-.4921l.0028.0029Z"></path>
                                        <path fill=#fff d="M76.1465 21.1359c-.107-.106-.3195-.106-.425-.106-14.5729 6.01-13.6145 12.546-12.552 15.0773 1.3834 3.3741 4.8933 4.5337 8.7226 2.9527 4.7864-2.0038 3.9363-6.9589 3.4044-9.5948-.6375-3.5848.1069-6.1147.957-8.0124 0 0 0-.2107-.107-.3168Zm-1.7015 8.5399c.639 3.3741.957 7.0635-2.9779 8.6459-3.4043 1.3703-6.3822.3168-7.6586-2.5298-.957-2.3192-1.7015-8.1185 11.1685-13.7057-.532 1.8978-1.0639 4.323-.532 7.591v-.0014Z"></path>
                                        <path fill=#fff d="M71.6803 27.2506c-.2125-.1061-.425-.1061-.532 0C66.255 32.627 65.405 41.273 66.362 43.4875c.1069.2107.3194.3167.5319.2107.2126-.1061.3195-.3168.2126-.5275-.7445-1.687-.2126-9.9101 4.6807-15.3927.107-.106.107-.3167-.1055-.5274h-.0014Z"></path>
                                        <path fill=#fff fill-rule=evenodd d="M68.4714 32.3201c-.2125.0594-.4336-.0622-.4935-.2729l-.5819-2.0335a.3956.3956 0 0 1 .2753-.4893c.2125-.0594.4336.0622.4935.2729l.5818 2.0335a.3955.3955 0 0 1-.2752.4893ZM67.8525 33.6142c-.0628-.2093.0585-.4299.2695-.4921l3.0664-.9022a.4026.4026 0 0 1 .4977.2672c.0628.2093-.0585.4299-.2695.4922l-3.0664.9022a.4026.4026 0 0 1-.4977-.2673ZM67.2462 36.1455c-.2068.0792-.4378-.024-.5163-.2277l-1.3377-3.4533c-.0799-.205.0242-.4341.2296-.5119.2068-.0777.4378.0241.5163.2277l1.3377 3.4533a.3961.3961 0 0 1-.2296.5119Z" clip-rule=evenodd></path>
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="layout-footer-main bg-black pt-12">
                    <div class="inner inner--full text-body-xs leading-[1.6]">
                        <div class=mb-12>
                            <div class="h-[22px] lg:h-[28px] w-auto flex text-white">
                                <svg xmlns=http://www.w3.org/2000/svg viewBox="0 0 150 28" fill=none>
                                    <path d="M64.4752 0.972235L67.4469 0V20.6563H64.4752V0.972235ZM11.1827 7.15557H14.0458V20.6563H11.1827V19.0092C10.1562 20.278 8.50842 21.0608 6.56326 21.0608C2.64662 21.0608 0 17.983 0 13.9059C0 9.82888 2.72755 6.75036 6.64419 6.75036C8.58936 6.75036 10.1562 7.53314 11.1827 8.77304V7.15557ZM11.2636 13.879C11.2636 10.8813 9.12961 9.47761 7.13049 9.47761C4.83729 9.47761 2.99801 11.3405 2.99801 13.9059C2.99801 16.5246 4.83459 18.3343 7.04955 18.3343C9.10263 18.3343 11.2636 16.7411 11.2636 13.879ZM43.2712 0.972235L46.2429 0V20.6563H43.2712V19.0631C42.2177 20.305 40.6239 21.0608 38.7064 21.0608C34.7898 21.0608 32.1425 17.983 32.1425 13.9059C32.1425 9.82888 34.8707 6.75036 38.7874 6.75036C40.6759 6.75036 42.2447 7.50617 43.2712 8.69416V0.972235ZM43.4061 13.879C43.4061 10.8813 41.2728 9.47761 39.2737 9.47761C36.9805 9.47761 35.1412 11.3405 35.1412 13.9059C35.1412 16.5246 36.9778 18.3343 39.1927 18.3343C41.2458 18.3343 43.4061 16.7411 43.4061 13.879L43.4338 13.9329V13.825L43.4061 13.879ZM24.3638 6.75036C22.4457 6.75036 20.9335 7.42459 19.9609 8.88361V7.15557H17.0708V20.6563H20.0418V13.5547C20.0418 10.9623 21.5817 9.42367 23.6341 9.42367C25.7924 9.42367 26.8756 11.1247 26.8756 13.3659V20.6563H29.8473V13.1225C29.8473 9.20724 27.9561 6.75036 24.3638 6.75036ZM62.0444 12.7449L52.0771 15.9812C52.7792 17.5205 54.292 18.3039 56.1556 18.3039C58.3706 18.3039 60.2341 17.2251 61.5851 15.7924V18.9282C60.5316 20.0353 58.5864 21.0608 56.0747 21.0608C51.6448 21.0608 48.6737 18.1178 48.6737 13.852C48.6737 9.82821 51.3716 6.77733 55.5074 6.77733C59.2352 6.77733 61.695 9.20724 62.0444 12.7449V12.7449ZM58.6134 11.2866C57.9922 9.99069 56.8038 9.34276 55.5108 9.34276C53.5117 9.34276 51.783 10.8813 51.6751 13.5277L58.6134 11.2866ZM83.0865 7.26277C79.1422 7.26277 76.36 10.2334 76.36 14.1487C76.36 18.1718 79.3047 20.953 83.2753 20.953C86.3549 20.953 88.1915 19.2519 88.9483 18.4421V16.7411C88.0836 17.8198 86.1654 19.6571 83.2483 19.6571C80.7906 19.6571 78.8184 18.3882 78.0617 16.228L89.3799 12.6633C88.8127 9.47693 86.4629 7.26277 83.0865 7.26277V7.26277ZM77.7919 15.0393C77.7579 14.7526 77.7399 14.4643 77.7379 14.1756C77.7379 10.7195 80.1148 8.5047 83.0865 8.5047C85.1396 8.5047 87.0031 9.63942 87.7052 11.8806L77.7919 15.0393ZM103.345 12.9067V20.6563H101.941V13.0962C101.941 9.93676 100.293 8.55998 98.1318 8.55998C95.5122 8.55998 93.621 10.6117 93.621 13.3659V20.6563H92.2161V7.56011H93.565V10.2604C94.5093 8.18107 96.3742 7.26277 98.3463 7.26277C101.238 7.26277 103.345 9.12634 103.345 12.9067V12.9067ZM112.746 7.26277C108.802 7.26277 106.019 10.2334 106.019 14.1487C106.019 18.1718 108.964 20.953 112.934 20.953C116.014 20.953 117.851 19.2519 118.607 18.4421V16.7411C117.743 17.8198 115.825 19.6571 112.907 19.6571C110.45 19.6571 108.478 18.3882 107.721 16.228L119.039 12.6633C118.472 9.47693 116.125 7.26277 112.746 7.26277V7.26277ZM107.451 15.0393C107.417 14.7526 107.399 14.4643 107.397 14.1756C107.397 10.7195 109.774 8.5047 112.746 8.5047C114.799 8.5047 116.662 9.63942 117.364 11.8806L107.451 15.0393ZM127.575 7.26277C128.09 7.25708 128.601 7.3394 129.088 7.50617V9.07172C128.737 8.85597 128.169 8.64022 127.386 8.64022C125.063 8.64022 123.496 10.557 123.496 13.0685V20.6563H122.065V7.56011H123.414V10.2334C123.982 8.53167 125.468 7.26277 127.575 7.26277V7.26277ZM142.189 10.3952C141.162 8.47773 139.218 7.26277 136.678 7.26277C132.789 7.26277 129.98 10.1788 129.98 14.0677C129.98 17.9567 132.789 20.872 136.678 20.872C139.191 20.872 141.135 19.6584 142.162 17.7396V20.2511C142.162 23.5723 140.163 25.8674 136.813 25.8674C134.436 25.8674 132.519 24.7333 131.519 23.6532V25.3543C132.654 26.3265 134.571 27.1639 136.895 27.1639C140.973 27.1639 143.567 24.4367 143.567 20.332V7.56011H142.189V10.3952ZM136.786 19.5762C133.788 19.5762 131.384 17.335 131.384 14.0677C131.384 10.8004 133.788 8.55931 136.786 8.55931C139.812 8.55931 142.243 10.7168 142.243 14.0408C142.243 17.335 139.812 19.5762 136.786 19.5762V19.5762ZM147.483 7.56011H148.888V20.6563H147.483V7.56011ZM149.402 2.94233C149.397 3.26046 149.267 3.56393 149.04 3.7865C148.812 4.00906 148.506 4.13266 148.188 4.13031C148.031 4.13121 147.876 4.10109 147.732 4.04171C147.587 3.98232 147.456 3.89485 147.345 3.78435C147.235 3.67386 147.147 3.54254 147.088 3.39801C147.028 3.25347 146.998 3.09858 146.999 2.94233C146.999 2.2681 147.512 1.72872 148.188 1.72872C148.347 1.72872 148.505 1.76011 148.652 1.8211C148.799 1.88209 148.933 1.97148 149.046 2.08418C149.159 2.19687 149.248 2.33066 149.309 2.4779C149.37 2.62514 149.402 2.78295 149.402 2.94233V2.94233Z" fill=currentColor></path>
                                </svg>
                            </div>
                        </div>
                        <div class="flex flex-col sm:flex-row">
                            <div class="flex flex-col lg:flex-row sm:flex-auto">
                                <div class=flex-1>
                                    <div class="flex flex-col md:flex-row text-white">

                                        <div class="flex-1 md:w-1/2 mr-4 mb-12">
                                            <h3 class="text-body leading-[1.1] mb-4">Produkter</h3>
                                            <p class=mt-1>
                                                <a href=# class="group flex items-center">
                                                    El
                                                    <svg xmlns=http://www.w3.org/2000/svg width=10 height=7 viewBox="0 0 10 7" fill=none class="text-white self-center ml-1 mt-0.5 group-hover:translate-x-1 transition-transform duration-200 ease-in-out">
                                                        <path d="M4.9 0L7.728 2.758H0.728V4.06H7.756L4.9 6.818H6.636L9.59 3.878V2.968L6.636 0H4.9Z" fill=currentColor></path>
                                                    </svg>
                                                </a>
                                            </p>
                                            <p class=mt-1>
                                                <a href=# class="group flex items-center">
                                                    Gas
                                                    <svg xmlns=http://www.w3.org/2000/svg width=10 height=7 viewBox="0 0 10 7" fill=none class="text-white self-center ml-1 mt-0.5 group-hover:translate-x-1 transition-transform duration-200 ease-in-out">
                                                        <path d="M4.9 0L7.728 2.758H0.728V4.06H7.756L4.9 6.818H6.636L9.59 3.878V2.968L6.636 0H4.9Z" fill=currentColor></path>
                                                    </svg>
                                                </a>
                                            </p>
                                            <p class=mt-1>
                                                <a href=# class="group flex items-center">
                                                    Ladeløsning
                                                    <svg xmlns=http://www.w3.org/2000/svg width=10 height=7 viewBox="0 0 10 7" fill=none class="text-white self-center ml-1 mt-0.5 group-hover:translate-x-1 transition-transform duration-200 ease-in-out">
                                                        <path d="M4.9 0L7.728 2.758H0.728V4.06H7.756L4.9 6.818H6.636L9.59 3.878V2.968L6.636 0H4.9Z" fill=currentColor></path>
                                                    </svg>
                                                </a>
                                            </p>
                                            <p class=mt-1>
                                                <a href=https://andelenergi.dk/solceller/ class="group flex items-center">
                                                    Solceller
                                                    <svg xmlns=http://www.w3.org/2000/svg width=10 height=7 viewBox="0 0 10 7" fill=none class="text-white self-center ml-1 mt-0.5 group-hover:translate-x-1 transition-transform duration-200 ease-in-out">
                                                        <path d="M4.9 0L7.728 2.758H0.728V4.06H7.756L4.9 6.818H6.636L9.59 3.878V2.968L6.636 0H4.9Z" fill=currentColor></path>
                                                    </svg>
                                                </a>
                                            </p>
                                            <p class=mt-1>
                                                <a href=https://andelenergi.dk/varmepumper/ class="group flex items-center">
                                                    Varmepumper
                                                    <svg xmlns=http://www.w3.org/2000/svg width=10 height=7 viewBox="0 0 10 7" fill=none class="text-white self-center ml-1 mt-0.5 group-hover:translate-x-1 transition-transform duration-200 ease-in-out">
                                                        <path d="M4.9 0L7.728 2.758H0.728V4.06H7.756L4.9 6.818H6.636L9.59 3.878V2.968L6.636 0H4.9Z" fill=currentColor></path>
                                                    </svg>
                                                </a>
                                            </p>
                                        </div>

                                        <div class="flex-1 md:w-1/2 mr-4 mb-12">
                                            <h3 class="text-body leading-[1.1] mb-4">Andel Energi A/S</h3>
                                            <p class=mt-1>Hovedgaden 36</p>
                                            <p class=mt-1>4520 Svinninge</p>
                                            <p class=mt-1>Cvr-nr. 242 135 28</p>
                                            <div class="flex flex-row gap-4 mt-8">
                                                <a href=https://www.facebook.com/andelenergi target=_blank>
                                                    <svg xmlns=http://www.w3.org/2000/svg width=13 height=25 viewBox="0 0 13 25" class="h-[21px] w-auto">
                                                        <path d="M0 9.153h3.847V5.588S3.684 3.26 5.453 1.491C7.22-.277 9.6-.11 12.989.185v3.979h-2.506s-1.052-.021-1.546.547c-.494.569-.442 1.38-.442 1.58v2.862h4.346l-.558 4.432h-3.81V25h-4.61V13.563H0v-4.41z" fill=currentColor fill-rule=evenodd></path>
                                                    </svg>
                                                </a>
                                                <a href=https://www.youtube.com/channel/UC0-c_zC8VhegYiVUVOXK98g target=_blank>
                                                    <svg xmlns=http://www.w3.org/2000/svg width=30 height=21 viewBox="0 0 30 21" fill=none class="h-[21px] w-auto">
                                                        <path fill-rule=evenodd clip-rule=evenodd d="M27.6689 2.405C28.1192 2.84844 28.4437 3.40032 28.61 4.00567C29.5679 7.80238 29.3465 13.7987 28.6286 17.7419C28.4623 18.3473 28.1378 18.8992 27.6875 19.3426C27.2372 19.7861 26.6767 20.1056 26.062 20.2694C23.8115 20.8738 14.7539 20.8738 14.7539 20.8738C14.7539 20.8738 5.69633 20.8738 3.44588 20.2694C2.83114 20.1056 2.27071 19.7861 1.82039 19.3426C1.37008 18.8992 1.04559 18.3473 0.879244 17.7419C-0.0841726 13.9617 0.179931 7.96172 0.860647 4.02399C1.02699 3.41864 1.35148 2.86675 1.8018 2.42331C2.25211 1.97987 2.81254 1.66032 3.42728 1.49652C5.67773 0.89212 14.7353 0.87381 14.7353 0.87381C14.7353 0.87381 23.7929 0.87381 26.0434 1.4782C26.6581 1.64201 27.2185 1.96155 27.6689 2.405ZM19.3664 10.8738L11.8525 15.1595V6.58809L19.3664 10.8738Z" fill=currentColor></path>
                                                    </svg>
                                                </a>
                                                <a href=https://www.instagram.com/andelenergi/ target=_blank>
                                                    <svg xmlns=http://www.w3.org/2000/svg width=22 height=22 viewBox="0 0 22 22" fill=none class="h-[21x] w-auto">
                                                        <path d="M10.75 2.26569C13.5536 2.26569 13.8857 2.2764 14.9929 2.32692C16.0166 2.3736 16.5726 2.54465 16.9426 2.68845C17.4327 2.87892 17.7825 3.10645 18.1499 3.47386C18.5173 3.84131 18.7449 4.19108 18.9354 4.6812C19.0791 5.05119 19.2502 5.60715 19.2969 6.63089C19.3474 7.73807 19.3581 8.07017 19.3581 10.8738C19.3581 13.6774 19.3474 14.0095 19.2969 15.1167C19.2502 16.1404 19.0791 16.6964 18.9354 17.0664C18.7449 17.5565 18.5173 17.9062 18.1499 18.2736C17.7825 18.6411 17.4327 18.8686 16.9426 19.0591C16.5726 19.2029 16.0166 19.3739 14.9929 19.4206C13.8859 19.4711 13.5538 19.4819 10.75 19.4819C7.94618 19.4819 7.61416 19.4711 6.5071 19.4206C5.48336 19.3739 4.92739 19.2029 4.5574 19.0591C4.06729 18.8686 3.71751 18.6411 3.3501 18.2736C2.9827 17.9062 2.75512 17.5565 2.56465 17.0664C2.42085 16.6964 2.2498 16.1404 2.20312 15.1167C2.1526 14.0095 2.14189 13.6774 2.14189 10.8738C2.14189 8.07017 2.1526 7.73807 2.20312 6.63089C2.2498 5.60715 2.42085 5.05119 2.56465 4.6812C2.75512 4.19108 2.98265 3.84131 3.3501 3.4739C3.71751 3.10645 4.06729 2.87892 4.5574 2.68845C4.92739 2.54465 5.48336 2.3736 6.5071 2.32692C7.61428 2.2764 7.94639 2.26569 10.75 2.26569ZM10.75 0.37381C7.89837 0.37381 7.5408 0.385897 6.42086 0.436996C5.30326 0.48797 4.53998 0.665484 3.8721 0.925023C3.18163 1.19336 2.59607 1.55239 2.01231 2.13611C1.42858 2.71988 1.06955 3.30543 0.801257 3.9959C0.541675 4.66377 0.364161 5.42705 0.313187 6.54465C0.262087 7.66459 0.25 8.02215 0.25 10.8738C0.25 13.7254 0.262087 14.083 0.313187 15.2029C0.364161 16.3205 0.541675 17.0838 0.801257 17.7516C1.06955 18.4421 1.42858 19.0277 2.01231 19.6114C2.59607 20.1952 3.18163 20.5542 3.8721 20.8225C4.53998 21.0821 5.30326 21.2596 6.42086 21.3106C7.5408 21.3617 7.89837 21.3737 10.75 21.3737C13.6016 21.3737 13.9592 21.3617 15.0791 21.3106C16.1967 21.2596 16.96 21.0821 17.6279 20.8225C18.3184 20.5542 18.9039 20.1952 19.4877 19.6114C20.0714 19.0277 20.4304 18.4421 20.6988 17.7516C20.9583 17.0838 21.1358 16.3205 21.1868 15.2029C21.2379 14.083 21.25 13.7254 21.25 10.8738C21.25 8.02215 21.2379 7.66459 21.1868 6.54465C21.1358 5.42705 20.9583 4.66377 20.6988 3.9959C20.4304 3.30543 20.0714 2.71988 19.4877 2.13611C18.9039 1.55239 18.3184 1.19336 17.6279 0.925023C16.96 0.665484 16.1967 0.48797 15.0791 0.436996C13.9592 0.385897 13.6016 0.37381 10.75 0.37381Z" fill=currentColor></path>
                                                        <path d="M10.7549 5.48676C7.77705 5.48676 5.36304 7.90076 5.36304 10.8786C5.36304 13.8565 7.77705 16.2705 10.7549 16.2705C13.7328 16.2705 16.1468 13.8565 16.1468 10.8786C16.1468 7.90076 13.7328 5.48676 10.7549 5.48676ZM10.7549 14.3786C8.82192 14.3786 7.25493 12.8116 7.25493 10.8786C7.25493 8.94563 8.82192 7.37864 10.7549 7.37864C12.6879 7.37864 14.2549 8.94563 14.2549 10.8786C14.2549 12.8116 12.6879 14.3786 10.7549 14.3786Z" fill=currentColor></path>
                                                        <path d="M17.6194 5.27046C17.6194 5.9663 17.0552 6.53044 16.3593 6.53044C15.6635 6.53044 15.0994 5.9663 15.0994 5.27046C15.0994 4.57457 15.6635 4.01044 16.3593 4.01044C17.0552 4.01044 17.6194 4.57457 17.6194 5.27046Z" fill=currentColor></path>
                                                    </svg>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class=flex-1>
                                    <div class="flex flex-col md:flex-row text-white">

                                        <div class="flex-1 md:w-1/2 mr-4 mb-12">
                                            <h3 class="text-body leading-[1.1] mb-4">Kundeservice</h3>
                                            <p class=mt-1>Mandag til fredag 8.30-16.00</p>
                                            <p class=mt-1>
                                                <a href=tel:70292929 class=hover:underline>
                                                    70 29 29 29
                                                </a>
                                            </p>
                                            <p class=mt-1>
                                                <a href=https://andelenergi.dk/kundeservice/kontakt-os/ class="group flex items-center">
                                                    Kontakt os
                                                    <svg xmlns=http://www.w3.org/2000/svg width=10 height=7 viewBox="0 0 10 7" fill=none class="text-white self-center ml-1 mt-0.5 group-hover:translate-x-1 transition-transform duration-200 ease-in-out">
                                                        <path d="M4.9 0L7.728 2.758H0.728V4.06H7.756L4.9 6.818H6.636L9.59 3.878V2.968L6.636 0H4.9Z" fill=currentColor></path>
                                                    </svg>
                                                </a>
                                            </p>

                                            <div class=mt-6>
                                                <p class="mt-1 first:mt-0">
                                                    <a href=https://andelenergi.dk/kundeservice/kontakt-os/om-energitte/ class="group flex items-center">
                                                        Chat med Energitte
                                                        <svg xmlns=http://www.w3.org/2000/svg width=10 height=7 viewBox="0 0 10 7" fill=none class="text-white self-center ml-1 mt-0.5 group-hover:translate-x-1 transition-transform duration-200 ease-in-out">
                                                            <path d="M4.9 0L7.728 2.758H0.728V4.06H7.756L4.9 6.818H6.636L9.59 3.878V2.968L6.636 0H4.9Z" fill=currentColor></path>
                                                        </svg>
                                                    </a>
                                                </p>
                                                <p class="mt-1 first:mt-0">
                                                    <a href=https://andelenergi.dk/kundeservice/ class="group flex items-center">
                                                        Find hjælp
                                                        <svg xmlns=http://www.w3.org/2000/svg width=10 height=7 viewBox="0 0 10 7" fill=none class="text-white self-center ml-1 mt-0.5 group-hover:translate-x-1 transition-transform duration-200 ease-in-out">
                                                            <path d="M4.9 0L7.728 2.758H0.728V4.06H7.756L4.9 6.818H6.636L9.59 3.878V2.968L6.636 0H4.9Z" fill=currentColor></path>
                                                        </svg>
                                                    </a>
                                                </p>
                                            </div>
                                        </div>

                                        <div class="flex-1 md:w-1/2 mr-4 mb-12">
                                            <h3 class="text-body leading-[1.1] mb-4">Download vores app</h3>
                                            <p class=mt-4>
                                                <a href=https://apps.apple.com/dk/app/andel-energi/id1447353892 target=_blank class=block aria-label="Hent app i App Store">
                                                    <svg xmlns=http://www.w3.org/2000/svg fill=none viewBox="0 0 119 40" class="duration-200 w-[120px]">
                                                        <path fill=currentColor d="M8.44487 39.125c-.30468 0-.602-.0039-.90429-.0107a12.695992 12.695992 0 0 1-1.86914-.1631c-.57641-.0993-1.1348-.2839-1.65674-.5479-.51716-.2618-.98885-.605-1.397-1.0166-.41406-.4067-.75879-.8785-1.02051-1.3965a5.721684 5.721684 0 0 1-.543-1.6572 12.413354 12.413354 0 0 1-.166503-1.875c-.00634-.2109-.01464-.9131-.01464-.9131V8.44434s.00884-.69141.01469-.89454a12.369951 12.369951 0 0 1 .165533-1.87207 5.75534 5.75534 0 0 1 .54346-1.6621 5.373204 5.373204 0 0 1 1.01514-1.39795 5.565215 5.565215 0 0 1 1.40234-1.02247 5.822793 5.822793 0 0 1 1.65332-.54394A12.585765 12.585765 0 0 1 7.54304.88721L8.44536.875H111.214l.913.0127c.623.007399 1.244.06175 1.858.16259.581.09869 1.145.28333 1.671.54785 1.038.53485 1.883 1.38102 2.415 2.41993.261.51951.441 1.07544.536 1.64892.103.624.161 1.25475.173 1.88721.003.2832.003.5874.003.89014.008.375.008.73193.008 1.09179V30.4648c0 .3633 0 .7178-.008 1.0752 0 .3252 0 .6231-.004.9297-.011.6212-.068 1.2407-.171 1.8535-.093.5811-.275 1.1443-.54 1.67-.263.5124-.606.9801-1.015 1.3857-.409.4138-.881.759-1.4 1.0225-.525.266-1.087.4513-1.668.5498-.618.101-1.243.1555-1.869.1631-.293.0068-.599.0107-.897.0107l-1.084.002-101.69013-.002Z"></path>
                                                        <path fill=#1E1E1E d="M24.997 19.8894c.0112-.8679.2418-1.7189.6702-2.4739.4285-.7549 1.0409-1.3891 1.7804-1.8438-.4697-.6709-1.0895-1.223-1.8099-1.6125-.7205-.3895-1.5219-.6056-2.3405-.6312-1.7462-.1833-3.4391 1.0449-4.329 1.0449-.907 0-2.2771-1.0267-3.7524-.9964-.9543.0309-1.8844.3084-2.6995.8055-.8152.4971-1.4876 1.1969-1.9519 2.0312-2.01113 3.482-.511 8.5994 1.4155 11.414.9639 1.3783 2.0904 2.9178 3.5644 2.8632 1.4424-.0599 1.9811-.9198 3.7222-.9198 1.7249 0 2.2303.9198 3.7342.8851 1.5478-.0252 2.523-1.3844 3.453-2.7757.6926-.982 1.2255-2.0674 1.579-3.2159-.8992-.3803-1.6665-1.0169-2.2064-1.8304-.5398-.8135-.8282-1.7679-.8293-2.7443ZM22.1563 11.4768c.844-1.0131 1.2597-2.3152 1.159-3.62988-1.2893.13542-2.4802.75162-3.3355 1.72582-.4182.47596-.7385 1.02956-.9426 1.62936-.204.5998-.2879 1.2339-.2467 1.8661.6448.0067 1.2828-.1331 1.8658-.4088.5831-.2756 1.0959-.68 1.5-1.1826ZM42.3018 27.1397h-4.7334l-1.1368 3.3564h-2.0048l4.4834-12.418h2.083l4.4834 12.418h-2.0391l-1.1357-3.3564Zm-4.2432-1.5489h3.752l-1.8496-5.4472h-.0518l-1.8506 5.4472ZM55.1592 25.9697c0 2.8135-1.5059 4.6211-3.7783 4.6211a3.06983 3.06983 0 0 1-1.652-.3826c-.5038-.2802-.9185-.6965-1.1966-1.2014h-.043v4.4844h-1.8584V21.4423h1.7988v1.5059h.0342c.2909-.5025.7127-.9166 1.2203-1.1985.5076-.2818 1.0822-.4208 1.6625-.4021 2.2979 0 3.8125 1.8164 3.8125 4.6221Zm-1.9102 0c0-1.833-.9472-3.0381-2.3925-3.0381-1.42 0-2.375 1.2305-2.375 3.0381 0 1.8242.955 3.0459 2.375 3.0459 1.4453 0 2.3925-1.1963 2.3925-3.0459ZM65.1245 25.9697c0 2.8135-1.5063 4.6211-3.7788 4.6211-.5756.0301-1.1481-.1025-1.6519-.3826-.5038-.2802-.9185-.6965-1.1967-1.2014h-.043v4.4844h-1.8584V21.4423h1.7988v1.5059h.0342c.291-.5025.7127-.9166 1.2203-1.1985.5077-.2818 1.0822-.4208 1.6625-.4021 2.2979 0 3.813 1.8164 3.813 4.6221Zm-1.9106 0c0-1.833-.9473-3.0381-2.3926-3.0381-1.4199 0-2.375 1.2305-2.375 3.0381 0 1.8242.9551 3.0459 2.375 3.0459 1.4453 0 2.3926-1.1963 2.3926-3.0459ZM71.709 27.0362c.1377 1.2314 1.334 2.04 2.9688 2.04 1.5664 0 2.6933-.8086 2.6933-1.919 0-.9638-.6796-1.541-2.289-1.9365l-1.6094-.3877c-2.2803-.5508-3.3389-1.6172-3.3389-3.3476 0-2.1426 1.8672-3.6143 4.5176-3.6143 2.625 0 4.4239 1.4717 4.4844 3.6143h-1.876c-.1123-1.2393-1.1367-1.9873-2.6338-1.9873-1.4971 0-2.5215.7568-2.5215 1.8584 0 .8779.6543 1.3945 2.2549 1.79l1.3682.3359c2.5478.6025 3.6054 1.626 3.6054 3.4424 0 2.3232-1.8496 3.7783-4.793 3.7783-2.7539 0-4.6132-1.4209-4.7334-3.667l1.9024.0001ZM83.3457 19.2998v2.1426h1.7217v1.4717h-1.7217v4.9912c0 .7754.3447 1.1367 1.1016 1.1367.2043-.0036.4084-.0179.6113-.043v1.4629c-.3403.0636-.6861.0924-1.0322.0859-1.833 0-2.5479-.6885-2.5479-2.4443v-5.1894h-1.3164v-1.4717h1.3164v-2.1426h1.8672ZM86.0645 25.9697c0-2.8486 1.6777-4.6386 4.2939-4.6386 2.625 0 4.2949 1.79 4.2949 4.6386 0 2.8565-1.6611 4.6387-4.2949 4.6387-2.6328 0-4.2939-1.7822-4.2939-4.6387Zm6.6953 0c0-1.9541-.8955-3.1074-2.4014-3.1074-1.5059 0-2.4014 1.1621-2.4014 3.1074 0 1.9619.8955 3.1065 2.4014 3.1065 1.5059 0 2.4014-1.1446 2.4014-3.1065ZM96.1846 21.4425h1.7724v1.541H98c.12-.4813.4019-.9066.7985-1.2045a2.15902 2.15902 0 0 1 1.3795-.4312c.214-.0008.428.0225.636.0693v1.7383c-.27-.0826-.552-.1206-.8345-.1123-.27-.011-.5391.0366-.789.1395-.2498.1029-.4744.2586-.6584.4565-.184.1979-.323.4333-.4074.69a1.87233 1.87233 0 0 0-.0817.797v5.3701h-1.8584v-9.0537ZM109.384 27.8369c-.25 1.6436-1.851 2.7715-3.899 2.7715-2.633 0-4.268-1.7647-4.268-4.5957 0-2.8398 1.643-4.6816 4.19-4.6816 2.505 0 4.08 1.7207 4.08 4.4658v.6367h-6.394v.1123c-.03.3332.012.6689.122.9847.11.3158.286.6046.517.8472.23.2425.509.4333.819.5596.31.1263.643.1852.977.1729.439.0412.88-.0605 1.257-.29.377-.2294.669-.5743.834-.9834h1.765Zm-6.282-2.7021h4.526c.017-.2996-.029-.5994-.133-.8807-.105-.2812-.267-.5377-.475-.7535-.209-.2157-.46-.3861-.737-.5003-.278-.1142-.576-.1698-.876-.1634-.302-.0018-.602.0564-.882.1711s-.535.2838-.749.4974c-.215.2137-.385.4676-.5.7473-.116.2796-.175.5794-.174.8821ZM39.6621 14.6977V12.08h-3.0644v2.6177h-.9268V8.73096h.9268v2.50584h3.0644V8.73096h.9219v5.96684l-.9219-.0001ZM45.9108 13.482c-.1207.4115-.3823.7675-.739 1.0057-.3567.2381-.7858.3433-1.2122.297a2.04297 2.04297 0 0 1-.8639-.1665c-.2725-.1175-.5162-.2929-.7141-.5141-.1979-.2211-.3453-.4827-.432-.7665a2.044713 2.044713 0 0 1-.07-.8771c-.0395-.2949-.0152-.5948.0713-.8795.0864-.2846.2331-.5474.4299-.7705.1969-.2231.4394-.4012.7111-.5224.2717-.1212.5663-.1827.8638-.1801 1.253 0 2.0088.856 2.0088 2.27v.3101h-3.1797v.0498c-.0139.1652.0069.3316.061.4883.0541.1568.1404.3005.2533.4219.1129.1215.25.218.4023.2834.1524.0654.3168.0982.4826.0964.2126.0255.428-.0128.6187-.11.1908-.0972.3483-.2489.4526-.4359h.8555Zm-3.126-1.4512h2.2744c.0112-.1511-.0093-.3029-.0603-.4456-.051-.1427-.1312-.2732-.2356-.3831a1.08783 1.08783 0 0 0-.3705-.2548c-.1399-.0582-.2905-.0864-.442-.083-.1537-.0019-.3062.027-.4486.0849-.1424.058-.2717.1438-.3804.2525-.1086.1087-.1944.2381-.2523.3805-.0579.1424-.0867.2949-.0847.4486ZM47.1582 10.1949h.8555v.7153h.0664c.1126-.2569.3026-.4723.5435-.6161.2409-.1438.5206-.2089.8002-.1862.2191-.0164.4391.0166.6437.0967.2046.0801.3886.2052.5383.3661.1496.1608.2612.3533.3264.5631.0652.2098.0824.4316.0502.6489v2.915h-.8886v-2.6918c0-.7236-.3145-1.0835-.9717-1.0835-.1488-.0069-.2973.0184-.4353.0742-.1381.0559-.2624.1409-.3646.2493-.1021.1084-.1796.2375-.2271.3787-.0475.1411-.064.2908-.0482.4389v2.6343h-.8887v-4.5029ZM53.5605 9.07373v1.14157h.9756v.7486h-.9756v2.3154c0 .4717.1944.6782.6368.6782.1132-.0003.2264-.0072.3388-.0205v.7402c-.1596.0286-.3212.0438-.4834.0454-.9882 0-1.3818-.3476-1.3818-1.2158v-2.543h-.7148v-.7485h.7148V9.07373h.8896ZM58.0352 8.86336c-.0069-.1151.021-.22961.08-.32869.059-.09908.1463-.17817.2508-.22702.1044-.04885.2211-.06522.335-.04698.1138.01824.2196.07024.3035.14928.084.07903.1423.18146.1673.294.0251.11255.0158.23003-.0266.33723a.57627.57627 0 0 1-.2115.26402c-.0954.06484-.208.09956-.3233.09966a.547637.547637 0 0 1-.2167-.03288c-.0692-.02545-.1326-.06465-.1864-.11523-.0537-.05058-.0966-.1115-.1262-.17911a.547153.547153 0 0 1-.0459-.21428Zm.1328 1.33154h.8848v4.5029h-.8848v-4.5029Z"></path>
                                                    </svg>
                                                </a>
                                            </p>
                                            <p class=mt-4>
                                                <a href="https://play.google.com/store/apps/details?id=com.andelenergi.andelenergi" target=_blank class=block aria-label="Hent app i Google Play">
                                                    <svg xmlns=http://www.w3.org/2000/svg fill=none viewBox="0 0 135 40" class="duration-200 w-[120px]">
                                                        <path fill=currentColor d="M0 5c0-2.76142 2.23858-5 5-5h125c2.761 0 5 2.23858 5 5v30c0 2.7614-2.239 5-5 5H5c-2.76143 0-5-2.2386-5-5V5Z"></path>
                                                        <path fill=#1E1E1E d="M68.136 21.7511c-2.352 0-4.269 1.789-4.269 4.253 0 2.449 1.917 4.253 4.269 4.253 2.353 0 4.27-1.804 4.27-4.253-.001-2.464-1.918-4.253-4.27-4.253Zm0 6.832c-1.289 0-2.4-1.063-2.4-2.578 0-1.531 1.112-2.578 2.4-2.578 1.289 0 2.4 1.047 2.4 2.578 0 1.514-1.111 2.578-2.4 2.578Zm-9.314-6.832c-2.352 0-4.269 1.789-4.269 4.253 0 2.449 1.917 4.253 4.269 4.253 2.353 0 4.27-1.804 4.27-4.253 0-2.464-1.917-4.253-4.27-4.253Zm0 6.832c-1.289 0-2.4-1.063-2.4-2.578 0-1.531 1.112-2.578 2.4-2.578 1.289 0 2.4 1.047 2.4 2.578.001 1.514-1.111 2.578-2.4 2.578Zm-11.078-5.526v1.804h4.318c-.129 1.015-.467 1.756-.983 2.271-.628.628-1.611 1.321-3.335 1.321-2.658 0-4.736-2.143-4.736-4.801 0-2.658 2.078-4.801 4.736-4.801 1.434 0 2.481.564 3.254 1.289l1.273-1.273c-1.08-1.031-2.513-1.82-4.527-1.82-3.641 0-6.702 2.964-6.702 6.605 0 3.641 3.061 6.605 6.702 6.605 1.965 0 3.448-.645 4.607-1.853 1.192-1.192 1.563-2.868 1.563-4.221 0-.418-.032-.805-.097-1.127h-6.073v.001Zm45.308 1.401c-.354-.95-1.434-2.707-3.641-2.707-2.191 0-4.012 1.724-4.012 4.253 0 2.384 1.805 4.253 4.221 4.253 1.949 0 3.077-1.192 3.545-1.885l-1.45-.967c-.483.709-1.144 1.176-2.095 1.176-.95 0-1.627-.435-2.062-1.289l5.687-2.352-.193-.482Zm-5.8 1.418c-.048-1.644 1.273-2.481 2.224-2.481.741 0 1.369.371 1.579.902l-3.803 1.579Zm-4.623 4.124h1.868v-12.501h-1.868v12.501Zm-3.062-7.298h-.064c-.419-.5-1.225-.951-2.239-.951-2.127 0-4.076 1.869-4.076 4.27 0 2.384 1.949 4.237 4.076 4.237 1.015 0 1.82-.451 2.239-.966h.064v.612c0 1.627-.87 2.497-2.271 2.497-1.144 0-1.853-.821-2.143-1.514l-1.627.677c.467 1.127 1.707 2.513 3.77 2.513 2.191 0 4.044-1.289 4.044-4.431v-7.636h-1.772v.692h-.001Zm-2.142 5.881c-1.289 0-2.368-1.08-2.368-2.562 0-1.499 1.079-2.594 2.368-2.594 1.272 0 2.271 1.095 2.271 2.594 0 1.482-.999 2.562-2.271 2.562Zm24.381-11.084h-4.471v12.501H99.2v-4.736h2.605c2.068 0 4.102-1.497 4.102-3.882s-2.033-3.883-4.101-3.883Zm.048 6.025H99.2v-4.285h2.654c1.395 0 2.187 1.155 2.187 2.143 0 .968-.792 2.142-2.187 2.142Zm11.532-1.795c-1.351 0-2.75.595-3.329 1.914l1.656.691c.354-.691 1.014-.917 1.705-.917.965 0 1.946.579 1.962 1.608v.129c-.338-.193-1.062-.482-1.946-.482-1.785 0-3.603.981-3.603 2.814 0 1.673 1.464 2.75 3.104 2.75 1.254 0 1.946-.563 2.38-1.223h.064v.965h1.802v-4.793c.001-2.218-1.657-3.456-3.795-3.456Zm-.226 6.851c-.61 0-1.463-.306-1.463-1.062 0-.965 1.062-1.335 1.979-1.335.819 0 1.206.177 1.704.418-.145 1.159-1.142 1.979-2.22 1.979Zm10.583-6.578-2.139 5.42h-.064l-2.22-5.42h-2.01l3.329 7.575-1.898 4.214h1.946l5.131-11.789h-2.075Zm-16.806 7.998h1.865v-12.501h-1.865v12.501Z"></path>
                                                        <path fill=#1E1E1E stroke=#1E1E1E stroke-miterlimit=10 stroke-width=.2 d="M42.0996 13.3101V7.31006h.94l2.91 4.67004V7.31006h.77v6.00004h-.8l-3-4.89004v4.89004h-.82ZM50.1799 13.4401c-.2978.0132-.5949-.038-.8711-.1502-.2761-.1122-.5248-.2827-.7289-.4998-.4221-.4672-.6447-1.0809-.62-1.71V7.31006h.77v3.80004c-.0276.4334.108.8614.38 1.2.2863.2827.6725.4413 1.075.4413.4024 0 .7886-.1586 1.075-.4413.259-.3295.3903-.7414.37-1.16V7.31006h.78v3.77004c.03.6263-.1852 1.2397-.6 1.71-.208.2205-.4616.393-.7431.5053-.2816.1122-.5843.1616-.8869.1447ZM56.4302 13.3101h-.77V7.31009h2c.4896-.0084.9632.17457 1.32.51.1767.16207.3178.35909.4143.57858.0965.21949.1463.45665.1463.69642 0 .23978-.0498.47693-.1463.69642-.0965.21949-.2376.41649-.4143.57859-.3568.3354-.8304.5184-1.32.51h-1.23v2.43Zm0-3.17h1.29c.1454.0067.2906-.0185.4253-.0738.1348-.0553.2558-.13929.3547-.24621.1864-.19532.2904-.45497.2904-.725s-.104-.52967-.2904-.725c-.0989-.10691-.2199-.19094-.3547-.24622a.999861.999861 0 0 0-.4253-.07378h-1.29v2.09001ZM59.46 13.3099l2.14-5.65999c-.0918-.07989-.1663-.17754-.2193-.28705-.0529-.10952-.0831-.22862-.0887-.35013a.900363.900363 0 0 1 .0561-.3568c.0426-.11392.1079-.21803.1919-.30602.0817-.0805.1786-.14402.285-.18693a.869741.869741 0 0 1 .335-.06307c.2291.00509.4474.09839.6095.26045.1621.16207.2554.38041.2605.60955.0028.12936-.0236.25769-.0773.37543-.0537.11774-.1332.22184-.2327.30457l2.15 5.65999h-.86l-.58-1.63h-2.56l-.56 1.63h-.85Zm1.7-2.35h2l-1-2.69999-1 2.69999Zm1-3.64999a.290102.290102 0 0 0 .1263-.02385c.0398-.01731.0753-.04333.1037-.07615a.330828.330828 0 0 0 .0746-.10974c.0172-.04125.0258-.08557.0254-.13026-.0004-.0431-.0094-.08568-.0266-.12521-.0172-.03952-.0421-.07517-.0734-.10479-.0284-.03282-.0639-.05884-.1037-.07615a.289813.289813 0 0 0-.1263-.02385.330153.330153 0 0 0-.1303.02536.328973.328973 0 0 0-.1097.07464c-.0591.06268-.0945.14403-.1.23a.359452.359452 0 0 0 .09.24c.0591.05839.1371.09384.22.1h.03Z"></path>
                                                        <path fill=#1E1E1E fill-rule=evenodd d="M10.156 7.96642c-.1181.2675-.18334.59526-.18334.97652V31.0589c0 .3821.06534.7099.18354.9773l12.034-12.0356L10.156 7.96642Zm.6952 24.78898c.4461.1909 1.028.1304 1.6625-.2295l14.1571-8.0447-3.7735-3.7735-12.0461 12.0477Zm16.722-8.786 4.4415-2.5235c1.3969-.795 1.3969-2.094 0-2.888l-4.4435-2.5248-3.9669 3.9674 3.9689 3.9689Zm-.9038-8.4488L12.5137 7.47694c-.6346-.36057-1.2165-.42074-1.6625-.2296l12.046 12.04606 3.7722-3.7728Z" clip-rule=evenodd></path>
                                                    </svg>
                                                </a>
                                            </p>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div class="flex-none flex space-x-4 mb-12">
                                <a href=https://andelenergi.dk/om-os/sustainable-brand-index-vinder />
                                <svg xmlns=http://www.w3.org/2000/svg width=138 height=195 viewBox="0 0 138 195" fill=none class="w-[138px] h-auto">
                                    <g clip-path=url(#clip0_5402_2541)>
                                        <path d="M138 -0.842285H-0.654053V140.796H138V-0.842285Z" fill=#EFEFEF></path>
                                        <path d="M138 140.138H-0.654053V195.476H138V140.138Z" fill=#014739></path>
                                        <path d="M92.3208 91.8315C91.6472 92.7631 90.8053 93.61 89.8792 94.3722C89.2899 94.7956 88.7848 94.965 89.3741 94.2028C90.1318 93.1865 91.0579 92.1703 92.0682 91.4081C92.8259 90.8153 92.7417 91.2387 92.3208 91.8315ZM92.6575 71.8451C90.9737 71.8451 89.7109 73.793 89.5425 75.9949C89.3741 78.0274 90.3002 79.8905 91.8156 79.8058C93.331 79.6364 94.5097 77.858 94.6781 75.6561C94.9307 73.9623 94.2571 71.9298 92.6575 71.8451ZM59.5706 93.1865C58.8129 91.7468 56.8765 90.4765 55.0243 90.4765C53.1721 90.4765 52.4144 91.6621 53.2563 93.1018C54.014 94.5415 56.1188 95.8118 57.971 95.8118C59.739 95.8118 60.3283 94.6262 59.5706 93.1865ZM85.5855 92.9325C86.3432 91.4928 85.5855 90.3071 83.8175 90.3071C82.0495 90.3071 80.1131 91.5775 79.2712 93.0172C78.5135 94.4568 79.1028 95.6425 80.8708 95.6425C82.723 95.6425 84.8278 94.3722 85.5855 92.9325ZM91.4789 89.9684C91.984 88.6981 91.2263 88.0206 89.8792 88.5287C88.5322 89.0368 87.1851 90.5612 86.68 91.8315C86.1748 93.1018 86.7642 93.7793 88.1954 93.2712C89.5425 92.7631 91.0579 91.2387 91.4789 89.9684ZM50.5622 93.61C51.9934 94.1181 52.5828 93.4406 52.0776 92.0856C51.5725 90.7306 50.2254 89.2062 48.7942 88.6981C47.3629 88.1899 46.6052 88.7827 47.1104 90.1378C47.6155 91.4928 49.131 93.1018 50.5622 93.61ZM45.9317 91.0693C46.8578 91.6621 46.942 90.9 46.3527 89.6296C45.7633 88.444 44.8372 87.089 43.9111 86.4962C42.985 85.9034 42.7325 86.4962 43.3218 87.7665C43.9111 89.0368 45.0056 90.4765 45.9317 91.0693ZM43.1534 85.3952C44.1637 86.4115 44.6688 85.5646 44.4163 84.1249C44.2479 82.6852 43.5744 80.9914 42.5641 80.0599C41.5538 79.0436 40.8803 79.6364 41.1328 81.0761C41.3012 82.5158 42.1431 84.379 43.1534 85.3952ZM97.288 80.9068C97.4564 79.4671 96.8671 78.9589 95.8568 79.8905C94.8465 80.8221 94.2571 82.4311 94.0046 83.8708C93.8362 85.3105 94.3413 86.0727 95.2674 85.0565C96.2777 84.1249 97.1196 82.3465 97.288 80.9068ZM98.3825 78.7049C97.8773 79.6364 97.4564 80.9914 97.2038 82.1771C96.9512 83.3627 97.1196 83.9555 97.6248 83.1086C98.1299 82.1771 98.5509 80.6527 98.8034 79.4671C98.9718 78.2814 98.8034 77.858 98.3825 78.7049ZM40.9645 82.3465C40.7119 81.1608 40.2909 79.7211 39.7858 78.8742C39.3648 78.0274 39.1123 78.4508 39.3648 79.6364C39.6174 80.8221 40.0384 82.4311 40.5435 83.278C41.0487 84.1249 41.217 83.5321 40.9645 82.3465ZM46.0159 71.7605C44.4163 71.7605 43.7428 73.9623 43.9111 75.6561C44.0795 77.9427 45.3424 79.8058 46.8578 79.9752C48.3732 80.1446 49.3835 78.1967 49.2151 76.0795C48.9626 73.793 47.6997 71.7605 46.0159 71.7605ZM64.3695 81.4149C66.9794 81.4149 69 79.213 68.9158 76.6724C68.8316 74.047 66.6426 71.9298 64.0327 72.0145C61.4228 72.0145 59.4022 74.2164 59.4864 76.757C59.5706 79.3824 61.7596 81.4149 64.3695 81.4149ZM75.1459 72.0145C72.536 72.0145 70.347 74.047 70.2628 76.6724C70.1786 79.2977 72.1992 81.4149 74.8091 81.4149C77.419 81.4149 79.608 79.3824 79.6922 76.757C79.7764 74.1317 77.7558 72.0145 75.1459 72.0145ZM54.3508 80.9068C56.5397 81.0761 58.2235 79.1283 58.1394 76.6724C58.0552 74.1317 55.9504 72.0145 53.9298 72.0145C51.5725 72.0145 50.2254 74.2164 50.3096 76.1642C50.3938 78.5355 52.246 80.7374 54.3508 80.9068ZM85.0804 71.9298C82.9756 71.9298 80.955 74.1317 80.8708 76.5877C80.7866 79.1283 82.4705 80.9915 84.6594 80.8221C86.8484 80.6527 88.7006 78.5355 88.7848 75.9949C88.7848 74.1317 87.4377 71.9298 85.0804 71.9298ZM82.1337 43.3053C83.0598 44.0675 84.2385 44.6603 85.3329 45.2531C85.7539 45.4225 86.9326 45.9306 86.1748 45.3378C85.3329 44.6603 84.3227 44.0675 83.3124 43.5593C83.0598 43.39 81.6285 42.8818 82.1337 43.3053ZM89.4583 47.8784C89.6267 48.0478 89.8792 48.2172 90.0476 48.3019C88.8689 47.2856 87.6903 46.2694 86.4274 45.4225C86.5116 45.5072 86.5958 45.5919 86.68 45.6765C87.6061 46.4387 88.5322 47.1162 89.4583 47.8784ZM76.4087 41.5268C77.1664 42.3737 78.7661 42.7125 79.7764 43.0512C80.1131 43.1359 82.0495 43.4747 81.4602 42.9665C80.6183 42.2043 79.3554 41.8656 78.3451 41.6115C78.0925 41.5268 76.072 41.1881 76.4087 41.5268ZM89.3741 48.3866C90.216 49.4028 91.1421 50.4191 92.1524 51.2659C92.9101 51.8588 92.7417 51.3506 92.3208 50.7578C91.563 49.8263 90.7211 48.8947 89.795 48.2172C89.2057 47.7091 88.7848 47.6244 89.3741 48.3866ZM78.0925 41.5268C78.5977 41.6962 79.187 41.8656 79.6922 41.9503C78.1767 41.4421 76.7455 41.0187 75.1459 40.6799C76.1562 41.0187 77.1664 41.2728 78.0925 41.5268ZM63.3592 40.5106C61.8437 40.7646 60.3283 41.1881 58.8129 41.6962C59.4022 41.6962 59.9074 41.4421 60.4967 41.2728C61.4228 41.1034 62.4331 40.934 63.3592 40.5106ZM65.1272 45.6765C63.5276 45.7612 61.2544 46.6081 61.0018 48.4712C60.6651 50.4191 63.1908 51.1813 64.7062 51.0966C66.39 51.0119 68.9158 49.9956 68.9999 47.9631C68.9158 46.1 66.5584 45.5919 65.1272 45.6765ZM64.622 52.0281C62.5173 52.1128 60.2441 53.7219 60.0757 55.9238C59.9074 58.2951 62.0963 59.9041 64.2853 59.8194C66.5584 59.7348 68.9158 58.041 68.9158 55.585C68.9158 53.3831 66.7268 51.9435 64.622 52.0281ZM74.5565 40.5106C74.4723 40.5106 74.4723 40.5106 74.5565 40.5106C72.9569 40.2565 71.3573 40.0871 69.8419 40.0024H69.7577C70.0944 40.4259 71.8624 40.3412 72.4518 40.3412C73.1253 40.5106 75.1459 40.8493 74.5565 40.5106ZM53.0037 49.9956C52.4144 51.6894 54.1824 52.3669 55.5294 52.1128C57.2974 51.7741 59.4022 50.5038 59.8232 48.6406C60.1599 46.9469 58.2235 46.6081 56.9607 46.8622C55.3611 47.2009 53.5931 48.3866 53.0037 49.9956ZM64.1169 70.5748C66.7268 70.5748 68.9158 68.3729 68.9158 65.7476C68.9158 63.207 66.7268 61.0898 64.2011 61.1744C61.6754 61.2591 59.5706 63.3763 59.4864 65.917C59.4022 68.4576 61.507 70.5748 64.1169 70.5748ZM58.7287 43.2206C57.4658 43.5593 55.782 44.2368 55.1085 45.3378C54.3508 46.6081 56.5397 46.4387 57.2133 46.2694C58.4761 45.9306 60.5809 45.2531 61.086 43.8981C61.507 42.6278 59.2338 43.0512 58.7287 43.2206ZM39.449 64.2232C40.2909 63.5457 40.6277 61.8519 40.9645 60.751C41.0487 60.4123 41.3854 58.3797 40.8803 58.9726C40.1226 59.8194 39.7858 61.0898 39.5332 62.1907C39.3648 62.4448 39.0281 64.4773 39.449 64.2232ZM94.7623 53.8913C94.8465 53.976 94.9307 54.0607 95.0149 54.1453C94.173 52.875 93.2469 51.6047 92.2366 50.5038C92.405 50.7578 92.5733 50.9272 92.6575 51.0966C93.4152 52.0281 94.0888 52.9597 94.7623 53.8913ZM58.8971 42.8818C59.9074 42.6278 61.5912 42.289 62.2647 41.4421C62.5173 41.1034 60.4967 41.4421 60.2441 41.4421C59.2338 41.6962 57.8868 42.035 57.0449 42.7971C56.5397 43.3053 58.6445 42.9665 58.8971 42.8818ZM39.2806 64.9854C38.5229 65.4935 38.5229 67.272 38.4387 68.1189C38.4387 68.5423 38.1862 70.8289 38.7755 70.8289C39.5332 70.8289 39.7016 68.2036 39.7016 67.6107C39.7858 67.272 39.7858 64.6467 39.2806 64.9854ZM99.5612 65.4088C99.3086 63.8845 98.8876 62.4448 98.3825 61.0051C98.4667 61.5132 98.6351 62.0213 98.8034 62.5295C99.056 63.461 99.2244 64.4773 99.5612 65.4088ZM92.4891 51.8588C91.563 51.0966 91.6472 52.1975 91.984 52.875C92.5733 54.1453 93.4994 55.585 94.6781 56.4319C95.6884 57.1094 95.1832 55.585 94.9307 55.0769C94.3413 53.8066 93.5836 52.621 92.4891 51.8588ZM94.7623 66.9332C94.6781 65.3242 93.8362 63.1223 92.0682 62.7835C90.1318 62.4448 89.4583 64.9007 89.5425 66.4251C89.6267 68.0342 90.6369 70.6595 92.5733 70.6595C94.3413 70.7442 94.8465 68.3729 94.7623 66.9332ZM83.4807 53.2138C81.5444 52.875 80.0289 54.23 80.1973 56.1779C80.4499 58.2951 82.3863 60.3276 84.5752 60.5816C86.5116 60.8357 87.8587 59.1419 87.5219 57.2788C87.1851 55.331 85.4171 53.5525 83.4807 53.2138ZM88.448 57.5329C88.7848 59.2266 90.0476 61.4285 91.8998 61.7673C93.5836 62.106 93.8362 60.1582 93.4994 58.9726C93.1627 57.3635 91.984 55.585 90.3844 54.9922C88.7848 54.3994 88.1954 56.1779 88.448 57.5329ZM95.3516 67.0179C95.4358 68.0342 95.7726 70.7442 97.2038 70.7442C98.3825 70.7442 98.2983 68.3729 98.2141 67.6107C98.1299 66.5098 97.7932 64.3926 96.6145 63.9692C95.2674 63.5457 95.2674 66.3404 95.3516 67.0179ZM99.3928 70.8289C99.8979 70.8289 99.7295 68.5423 99.7295 68.2036C99.6453 67.3567 99.6453 65.6629 98.8876 65.1548C98.4667 64.816 98.4667 67.3567 98.5509 67.6954C98.5509 68.2036 98.7193 70.8289 99.3928 70.8289ZM94.9307 57.1094C93.752 56.3472 94.0046 58.5491 94.0888 59.1419C94.4255 60.4123 95.0991 62.4448 96.4461 63.0376C97.5406 63.461 97.1196 61.1744 97.0354 60.751C96.6987 59.4807 96.1093 57.8716 94.9307 57.1094ZM100.066 70.9136C100.066 69.3045 99.8979 67.6954 99.6453 66.0864C99.5612 65.8323 99.7295 67.5261 99.7295 68.2882C99.8137 68.8811 99.9821 70.4901 100.066 70.9136ZM98.8876 77.4346C99.5612 76.8417 99.6453 75.148 99.7295 74.3858C99.7295 74.047 99.9821 71.6758 99.3928 71.7605C98.7193 71.7605 98.5509 74.3858 98.5509 74.8939C98.4667 75.2327 98.4667 77.7733 98.8876 77.4346ZM80.955 65.917C81.0392 68.1189 82.723 70.5748 85.1646 70.5748C87.4377 70.5748 88.7848 68.3729 88.6164 66.3404C88.5322 64.2232 86.9326 62.0213 84.7436 61.7673C82.3863 61.5979 80.8708 63.7998 80.955 65.917ZM97.3722 60.9204C97.6248 61.9366 97.9615 63.5457 98.8034 64.3079C99.056 64.562 98.8034 62.6141 98.7193 62.3601C98.4667 61.3438 98.1299 60.0735 97.4564 59.2266C96.8671 58.6338 97.2038 60.6663 97.3722 60.9204ZM97.2038 71.7605C95.8568 71.7605 95.4358 74.4705 95.3516 75.4867C95.2674 76.1642 95.2674 79.0436 96.6145 78.5355C97.7932 78.1121 98.1299 75.9949 98.2141 74.8939C98.2983 74.2164 98.3825 71.7605 97.2038 71.7605ZM73.7988 45.7612C72.3676 45.6765 70.0944 46.1847 70.0944 47.9631C70.1786 49.9956 72.7043 51.0119 74.3882 51.0966C75.9036 51.1813 78.3451 50.5038 77.9242 48.5559C77.6716 46.7775 75.3984 45.8459 73.7988 45.7612ZM73.1253 42.1196C72.3676 42.035 69.926 41.9503 70.0102 43.2206C70.0944 44.6603 72.7043 45.0837 73.7988 45.1684C74.5565 45.2531 77.3348 45.2531 76.8297 43.8134C76.3245 42.5431 74.2198 42.2043 73.1253 42.1196ZM72.4518 40.5106C72.115 40.5106 69.7577 40.2565 69.8419 40.8493C69.926 41.6115 72.4518 41.7809 73.0411 41.7809C73.3779 41.7809 75.9036 41.8656 75.5668 41.3574C74.9775 40.6799 73.2937 40.5953 72.4518 40.5106ZM95.2674 55.331C95.7726 56.4319 96.3619 57.6175 97.1196 58.5491C97.5406 59.0572 96.9512 57.6175 96.8671 57.3635C96.7829 57.1094 96.6145 56.8554 96.4461 56.6013C96.3619 56.4319 96.2777 56.2625 96.1935 56.0932C95.8568 55.5003 95.52 54.9922 95.1832 54.4841C94.5097 53.7219 95.0991 54.9922 95.2674 55.331ZM80.0289 43.39C79.5238 43.2206 77.2506 42.7971 77.7558 43.9828C78.2609 45.3378 80.3657 46.1 81.6285 46.4387C82.3021 46.6081 84.4068 46.7775 83.6491 45.5919C82.8914 44.4062 81.2918 43.7287 80.0289 43.39ZM85.6697 45.5919C85.1646 45.3378 83.7333 44.9143 84.4068 45.9306C85.1646 47.1162 86.5958 48.1325 87.8587 48.7253C88.6164 49.0641 89.5425 49.0641 88.7848 48.1325C88.027 47.0315 86.8484 46.1847 85.6697 45.5919ZM79.1028 48.7253C79.5238 50.5884 81.6285 51.9435 83.3124 52.2822C84.6594 52.5363 86.3432 51.8588 85.7539 50.2497C85.1646 48.6406 83.3966 47.455 81.8811 47.0315C80.6183 46.6928 78.7661 47.0315 79.1028 48.7253ZM88.1954 49.2334C87.1009 48.7253 86.1748 49.2334 86.5958 50.5038C87.1851 52.0281 88.6164 53.5525 90.216 54.1453C91.4789 54.6535 91.8998 53.6372 91.3947 52.5363C90.8053 51.1813 89.5425 49.8263 88.1954 49.2334ZM74.4723 52.1128C72.3676 51.9435 70.1786 53.3831 70.2628 55.6697C70.2628 58.1257 72.7043 59.9041 74.8933 59.9888C77.0823 60.0735 79.187 58.4644 79.0186 56.1779C78.7661 53.8066 76.5771 52.2822 74.4723 52.1128ZM70.347 65.7476C70.347 68.3729 72.536 70.5748 75.1459 70.5748C77.6716 70.5748 79.6922 68.4576 79.608 65.917C79.5238 63.461 77.419 61.2591 74.9775 61.1744C72.4518 61.0898 70.347 63.207 70.347 65.7476ZM68.8316 40.0024C67.2319 40.0024 65.7165 40.1718 64.1169 40.4259H64.0327C63.3592 40.7646 65.5481 40.4259 66.2217 40.3412C66.6426 40.3412 68.6632 40.4259 68.9158 40.0024H68.8316ZM65.7165 42.035C64.622 42.1196 62.5173 42.4584 62.0963 43.7287C61.6754 45.0837 64.4537 45.1684 65.2114 45.0837C66.2217 44.999 68.9158 44.6603 68.9158 43.2206C68.9158 41.9503 66.5584 41.9503 65.7165 42.035ZM39.3648 62.3601C39.5332 61.852 39.7016 61.2591 39.7858 60.751C39.2806 62.2754 38.8597 63.7998 38.5229 65.3242C38.8597 64.3926 39.1123 63.3763 39.3648 62.3601ZM37.9336 71.6758C37.9336 73.3695 38.102 74.9786 38.3545 76.5877C38.4387 76.0795 38.3545 75.148 38.2704 74.3858C38.2704 73.8777 38.102 71.8451 37.9336 71.6758ZM66.2217 40.4259C65.3797 40.5106 63.6117 40.5106 63.1066 41.2728C62.7698 41.7809 65.3797 41.7809 65.7165 41.6962C66.2217 41.6962 68.8316 41.5268 68.9158 40.7646C68.9158 40.2565 66.6426 40.4259 66.2217 40.4259ZM41.1328 58.2951C41.9747 57.3635 42.5641 56.1779 43.0692 55.0769C43.2376 54.6535 43.7428 53.3832 43.1534 54.1453C42.3957 54.9922 41.8906 56.0932 41.3854 57.1094C41.217 57.3635 40.6277 58.8032 41.1328 58.2951ZM38.2704 68.2036C38.3545 67.4414 38.6913 65.3242 38.3545 66.0017C38.3545 66.0017 38.3545 66.0017 38.3545 66.0864C38.102 67.6954 37.9336 69.3045 37.9336 70.9136V70.9983C38.3545 70.6595 38.2704 68.7117 38.2704 68.2036ZM39.2806 77.6039C39.7858 77.9427 39.7858 75.3173 39.7016 74.9786C39.6174 74.3858 39.5332 71.7605 38.7755 71.7605C38.1862 71.7605 38.3545 74.047 38.4387 74.4705C38.5229 75.2327 38.6913 77.1805 39.2806 77.6039ZM53.1721 44.999C54.2666 44.4909 55.4453 43.8981 56.3713 43.1359C56.8765 42.7125 55.3611 43.3053 55.1085 43.39C54.0982 43.8981 53.0879 44.4062 52.1618 45.1684C51.4883 45.6765 52.8353 45.1684 53.1721 44.999ZM45.5949 50.8425C45.7633 50.6731 45.9317 50.4191 46.1001 50.165C45.0056 51.3506 44.0795 52.621 43.1534 53.8913C43.2376 53.8066 43.3218 53.7219 43.406 53.5525C44.1637 52.7056 44.9214 51.7741 45.5949 50.8425ZM51.7409 45.3378C51.8251 45.2531 51.9934 45.1684 52.0776 45.0837C50.7306 45.9306 49.4677 46.9469 48.289 47.9631C48.5416 47.8784 48.7942 47.6244 48.9626 47.455C49.8887 46.8622 50.8148 46.1 51.7409 45.3378ZM46.1843 51.0119C47.2788 50.2497 48.289 49.2334 49.0468 48.1325C49.6361 47.3703 49.1309 47.455 48.5416 47.9631C47.6155 48.7253 46.6894 49.5722 45.9317 50.5038C45.5108 51.0966 45.4266 51.6047 46.1843 51.0119ZM40.0384 75.0633C40.1226 76.1642 40.4593 78.2814 41.7222 78.7049C43.1534 79.1283 43.1534 76.3336 43.1534 75.5714C43.0692 74.4705 42.6483 71.8451 41.217 71.7605C39.9542 71.7605 39.9542 74.2164 40.0384 75.0633ZM52.9195 45.2531C51.7409 45.8459 50.478 46.6928 49.7203 47.7091C48.9626 48.7253 50.0571 48.6406 50.8148 48.3019C52.0776 47.7091 53.5931 46.7775 54.3508 45.5072C54.9401 44.5756 53.4247 45.0837 52.9195 45.2531ZM47.1104 52.2822C46.6052 53.4678 47.1946 54.3994 48.4574 53.976C50.057 53.3831 51.5725 51.9435 52.1618 50.3344C52.667 48.9794 51.5725 48.5559 50.478 48.9794C49.0468 49.5722 47.7839 50.8425 47.1104 52.2822ZM58.1394 65.917C58.2235 63.7151 56.6239 61.5132 54.2666 61.6826C51.9934 61.852 50.3938 64.0538 50.3096 66.2557C50.2254 68.3729 51.6567 70.5748 53.9298 70.5748C56.2872 70.5748 58.1394 68.2036 58.1394 65.917ZM45.0056 58.8032C44.6688 60.0735 45.0898 62.0213 46.7736 61.6826C48.6258 61.3438 49.9729 59.1419 50.3096 57.3635C50.5622 55.9238 49.8887 54.23 48.2049 54.8228C46.6052 55.331 45.4266 57.1094 45.0056 58.8032ZM55.4453 53.0444C53.4247 53.3831 51.6567 55.1616 51.3199 57.1094C50.9831 59.0572 52.4144 60.6663 54.435 60.4969C56.6239 60.2429 58.6445 58.2951 58.8129 56.0932C58.9813 54.0607 57.2974 52.7056 55.4453 53.0444ZM100.066 71.6758C99.8979 72.0145 99.8137 73.793 99.7295 74.3011C99.6453 75.0633 99.5612 76.8417 99.6453 76.503C99.8979 74.8939 100.066 73.2848 100.066 71.6758ZM41.217 60.4969C41.0486 61.0898 40.7119 63.2916 41.8906 62.8682C43.2376 62.3601 43.9953 60.2429 44.3321 58.9726C44.5005 58.2951 44.6688 56.0932 43.406 56.8554C42.3115 57.6175 41.638 59.2266 41.217 60.4969ZM46.6052 62.6988C44.753 63.0376 43.9111 65.2395 43.7428 66.9332C43.6586 68.3729 44.2479 70.7442 46.1001 70.7442C48.1207 70.7442 49.2151 68.1189 49.2993 66.4251C49.3835 64.816 48.6258 62.3601 46.6052 62.6988ZM45.8475 51.52C44.753 52.2822 43.9111 53.5525 43.3218 54.7382C43.0692 55.2463 42.6483 56.7707 43.6586 56.0932C44.9214 55.331 45.8475 53.8913 46.4368 52.5363C46.8578 51.7741 46.8578 50.8425 45.8475 51.52ZM41.217 70.7442C42.6483 70.7442 43.0692 68.0342 43.1534 66.9332C43.2376 66.171 43.1534 63.3763 41.7222 63.7998C40.4593 64.2232 40.1226 66.3404 40.0384 67.4414C39.9542 68.3729 39.9542 70.8289 41.217 70.7442ZM79.7764 99.5381C78.7661 99.7922 77.0823 100.216 76.4087 101.063C76.1562 101.401 78.0925 101.063 78.3451 100.978C79.4396 100.639 80.6183 100.3 81.4602 99.6228C82.0495 99.03 80.1131 99.4534 79.7764 99.5381ZM86.7642 96.9128C86.68 96.9975 86.5958 97.0822 86.5116 97.0822C87.7745 96.2353 88.9531 95.3037 90.0476 94.2875C89.8792 94.4569 89.6267 94.5415 89.4583 94.7109C88.5322 95.4731 87.6061 96.1506 86.7642 96.9128ZM92.6575 91.4928C92.4891 91.6621 92.405 91.9162 92.2366 92.0856C92.4891 91.8315 92.7417 91.4928 92.9943 91.154H92.9101C92.8259 91.2387 92.7417 91.3234 92.6575 91.4928ZM85.3329 97.3362C84.2385 97.9291 83.0598 98.4372 82.1337 99.2841C81.6285 99.7075 83.0598 99.1147 83.3124 99.03C83.4807 98.9453 83.5649 98.8606 83.7333 98.8606C84.1543 98.6066 84.5752 98.3525 84.9962 98.0984C85.4171 97.8444 85.8381 97.5903 86.1748 97.2516C86.9326 96.6587 85.7539 97.1669 85.3329 97.3362ZM68.9158 101.74C68.9158 100.978 66.3058 100.893 65.7165 100.808C65.3797 100.808 62.7698 100.808 63.1066 101.232C63.6117 101.994 65.3797 101.994 66.2217 102.079C66.6426 102.163 68.9158 102.333 68.9158 101.74ZM58.8971 100.808C60.3283 101.317 61.8437 101.74 63.3592 101.994C62.4331 101.655 61.4228 101.486 60.4967 101.232C59.9074 101.063 59.4022 100.893 58.8971 100.808ZM66.3059 102.248C65.5481 102.163 63.4434 101.825 64.1169 102.163C65.7165 102.418 67.3161 102.587 68.9158 102.587C68.7474 102.163 66.7268 102.248 66.3059 102.248ZM75.2301 101.909C76.7455 101.571 78.1767 101.147 79.608 100.639C79.1028 100.724 78.5977 100.893 78.0925 101.063C77.1664 101.317 76.2403 101.571 75.2301 101.909ZM62.3489 101.147C61.6754 100.3 59.9915 99.9616 58.9813 99.7075C58.6445 99.6228 56.6239 99.2841 57.2133 99.7922C58.0552 100.554 59.318 100.893 60.4125 101.147C60.5809 101.147 62.6015 101.486 62.3489 101.147ZM48.8784 95.0497C48.71 94.8803 48.4574 94.7109 48.2049 94.6262C49.3835 95.6425 50.6464 96.6587 51.9092 97.5056C51.8251 97.4209 51.7409 97.3362 51.6567 97.2516C50.8148 96.4894 49.8887 95.7272 48.8784 95.0497ZM49.131 94.4568C48.289 93.3559 47.2788 92.4243 46.2685 91.5774C45.5108 90.9846 45.5949 91.4928 46.0159 92.0856C46.7736 93.0171 47.6155 93.9487 48.6258 94.6262C49.131 95.1343 49.7203 95.219 49.131 94.4568ZM56.4555 99.5381C55.5294 98.7759 54.3508 98.1831 53.2563 97.675C52.9195 97.5056 51.5725 96.9975 52.3302 97.5903C53.1721 98.2678 54.2666 98.8606 55.2769 99.3688C55.4452 99.3688 56.9607 99.9616 56.4555 99.5381ZM85.6697 96.9975C86.8484 96.4047 88.027 95.5578 88.7848 94.5415C89.5425 93.61 88.5322 93.61 87.8587 93.9487C86.5958 94.5415 85.1646 95.5578 84.4068 96.7434C83.7333 97.7597 85.1646 97.2516 85.6697 96.9975ZM65.7165 100.554C66.5584 100.639 68.9158 100.639 68.9158 99.3688C68.9158 97.9291 66.2217 97.5903 65.2114 97.5056C64.4537 97.4209 61.6754 97.5056 62.0963 98.8606C62.5173 100.131 64.622 100.47 65.7165 100.554ZM65.1272 96.9128C66.5584 96.9975 68.9158 96.4894 68.9158 94.6262C68.9158 92.5937 66.3059 91.5775 64.622 91.4928C63.1066 91.4081 60.5809 92.1703 60.9176 94.1181C61.2544 95.8965 63.5276 96.8281 65.1272 96.9128ZM58.7287 99.3688C59.2338 99.5381 61.5912 99.8769 61.086 98.6912C60.5809 97.3362 58.4761 96.574 57.2133 96.32C56.5397 96.1506 54.3508 95.9812 55.1085 97.2516C55.782 98.4372 57.4658 99.03 58.7287 99.3688ZM52.9195 97.2516C53.4247 97.5056 54.9401 97.9291 54.3508 96.9128C53.5931 95.6425 52.0776 94.7109 50.8148 94.1181C50.0571 93.7793 48.9626 93.6947 49.7203 94.7109C50.478 95.8965 51.6567 96.7434 52.9195 97.2516ZM72.4518 102.079C73.2937 101.994 74.9775 101.909 75.5668 101.232C75.9036 100.724 73.3779 100.808 73.0411 100.808C72.4518 100.893 69.926 100.978 69.8419 101.74C69.7577 102.333 72.115 102.079 72.4518 102.079ZM80.0289 99.1994C81.2918 98.8606 82.8914 98.1831 83.6491 96.9975C84.4068 95.8119 82.3021 95.9812 81.6285 96.1506C80.3657 96.4894 78.2609 97.2515 77.7558 98.6066C77.2506 99.7922 79.5238 99.3687 80.0289 99.1994ZM78.0083 94.0334C78.3451 92.0856 75.9036 91.4081 74.4723 91.4928C72.7885 91.5775 70.2628 92.6784 70.1786 94.6262C70.0944 96.4894 72.4518 96.9975 73.883 96.8281C75.3984 96.7434 77.6716 95.8119 78.0083 94.0334ZM76.7455 98.7759C77.2506 97.4209 74.4723 97.4209 73.7146 97.4209C72.7043 97.5056 70.0102 97.9291 69.926 99.3688C69.8419 100.639 72.2834 100.554 73.0411 100.47C74.2198 100.385 76.3245 100.046 76.7455 98.7759ZM72.3676 102.163C71.7782 102.248 70.0944 102.079 69.6735 102.502C71.2731 102.502 72.8727 102.333 74.4723 101.994C75.1459 101.74 73.1253 102.079 72.3676 102.163ZM98.8876 79.7211C98.8876 79.8058 98.8034 79.8905 98.8034 80.0599C98.6351 80.568 98.5509 81.0761 98.3825 81.5843C98.5509 80.9915 98.8034 80.3986 98.9718 79.7211C99.2244 78.8742 99.3928 78.0274 99.5612 77.1805C99.3086 78.0274 99.056 78.8742 98.8876 79.7211ZM92.9101 91.154H92.9943C93.6678 90.3071 94.3413 89.3756 94.9307 88.444C94.8465 88.5287 94.7623 88.6134 94.7623 88.6981C94.173 89.4602 93.5836 90.3071 92.9101 91.154ZM97.1196 84.0402C96.3619 84.9718 95.7726 86.1574 95.2674 87.2584C95.0991 87.5971 94.5939 88.9521 95.0991 88.1899C95.3516 87.8512 95.6042 87.5124 95.7726 87.1737C96.1093 86.6655 96.3619 86.0727 96.6145 85.5646C96.6145 85.4799 96.6987 85.3952 96.6987 85.3105C96.9512 84.9718 97.4564 83.5321 97.1196 84.0402ZM64.622 90.5612C66.7268 90.6459 68.9158 89.2909 68.9158 87.0043C68.9158 84.5483 66.5584 82.8546 64.2853 82.7699C62.0963 82.6852 59.9074 84.2943 60.0757 86.6656C60.2441 88.8674 62.4331 90.3918 64.622 90.5612ZM92.4891 90.7306C93.4994 89.8837 94.3413 88.6981 94.9307 87.5124C95.1832 87.0043 95.6042 85.4799 94.6781 86.1574C93.4994 86.9196 92.5733 88.3593 91.984 89.7143C91.6472 90.3918 91.563 91.4928 92.4891 90.7306ZM50.3096 85.2258C49.9729 83.4474 48.6258 81.3302 46.7736 80.9068C45.0898 80.568 44.6688 82.4311 45.0056 83.7862C45.4266 85.3952 46.6052 87.1737 48.2049 87.7665C49.8887 88.3593 50.5622 86.6655 50.3096 85.2258ZM55.4453 89.5449C57.3816 89.8837 59.0655 88.444 58.8129 86.4962C58.5603 84.2943 56.5397 82.3465 54.435 82.0924C52.4986 81.923 50.9831 83.5321 51.3199 85.4799C51.6567 87.4277 53.4247 89.2062 55.4453 89.5449ZM93.4994 83.6168C93.752 82.4311 93.4994 80.4833 91.8998 80.8221C90.0476 81.2455 88.7848 83.3627 88.448 85.0565C88.1954 86.4115 88.7848 88.1052 90.3844 87.5124C92.0682 87.0043 93.1627 85.2258 93.4994 83.6168ZM74.8933 82.6852C72.6201 82.7699 70.2628 84.5483 70.2628 87.0043C70.2628 89.2909 72.4518 90.6459 74.4723 90.5612C76.5771 90.3918 78.7661 88.8674 79.0186 86.5809C79.2712 84.1249 77.0823 82.6005 74.8933 82.6852ZM43.0692 87.5124C42.5641 86.4115 41.9747 85.2258 41.1328 84.2943C40.7119 83.7862 41.217 85.2258 41.3854 85.4799C41.8906 86.4962 42.3957 87.5124 43.1534 88.444C43.7428 89.2062 43.2376 87.9359 43.0692 87.5124ZM43.1534 88.6981C43.7428 89.5449 44.3321 90.3918 45.0056 91.154L46.0159 92.3396C45.4266 91.5775 43.9953 89.7143 43.406 88.9521C43.3218 88.8674 43.2376 88.7827 43.1534 88.6981ZM39.1965 79.7211C39.0281 78.8742 38.7755 78.0274 38.4387 77.2652C38.6071 78.1121 38.7755 78.9589 39.0281 79.7211C39.1965 80.3986 39.449 81.1608 39.7016 81.8383C39.6174 81.2455 39.449 80.7374 39.2806 80.2293C39.2806 80.0599 39.2806 79.8905 39.1965 79.7211ZM83.4807 89.3756C85.4171 89.0368 87.1851 87.2584 87.5219 85.3105C87.8587 83.4474 86.5116 81.7536 84.5752 82.0077C82.3863 82.2618 80.4499 84.2943 80.1973 86.4115C80.0289 88.3593 81.6285 89.7143 83.4807 89.3756Z" fill=#1B864A></path>
                                        <path d="M44.529 112.572C44.445 112.403 44.2771 112.318 44.1091 112.233C43.9411 112.148 43.6892 112.148 43.5212 112.148C43.4372 112.148 43.2693 112.148 43.1853 112.233C43.1013 112.233 42.9333 112.318 42.8493 112.403C42.7654 112.487 42.6814 112.572 42.5974 112.657C42.5134 112.741 42.5134 112.911 42.5134 112.995C42.5134 113.165 42.5974 113.334 42.7654 113.503C42.9333 113.588 43.1013 113.673 43.2693 113.757C43.4372 113.842 43.6892 113.927 43.9411 114.011C44.1931 114.096 44.445 114.181 44.613 114.35C44.781 114.52 45.0329 114.689 45.1169 114.858C45.2009 115.028 45.3688 115.366 45.3688 115.705C45.3688 116.044 45.2849 116.298 45.2009 116.552C45.1169 116.806 44.9489 116.975 44.697 117.145C44.529 117.314 44.2771 117.399 44.0251 117.483C43.7732 117.568 43.4372 117.568 43.1853 117.568C42.8493 117.568 42.4294 117.483 42.0935 117.399C41.7576 117.314 41.4216 117.06 41.1697 116.721L42.0095 115.959C42.1775 116.128 42.3454 116.298 42.5134 116.467C42.7654 116.552 42.9333 116.637 43.1853 116.637C43.2693 116.637 43.4372 116.637 43.5212 116.552C43.6052 116.552 43.7732 116.467 43.8571 116.383C43.9411 116.298 44.0251 116.213 44.1091 116.128C44.1931 116.044 44.1931 115.874 44.1931 115.79C44.1931 115.536 44.1091 115.366 43.9411 115.282C43.7732 115.197 43.6052 115.028 43.4372 114.943C43.2693 114.858 43.0173 114.774 42.7654 114.689C42.5134 114.604 42.2615 114.52 42.0935 114.35C41.9255 114.181 41.6736 114.011 41.5896 113.842C41.4216 113.588 41.3376 113.334 41.3376 112.995C41.3376 112.657 41.4216 112.403 41.5056 112.148C41.6736 111.894 41.8415 111.725 42.0095 111.556C42.1775 111.386 42.4294 111.302 42.6814 111.217C42.9333 111.132 43.1853 111.132 43.5212 111.132C43.8571 111.132 44.1091 111.217 44.445 111.302C44.781 111.386 45.0329 111.556 45.2849 111.81L44.529 112.572Z" fill=#128040></path>
                                        <path d="M51.4157 115.112C51.4157 115.451 51.3317 115.79 51.2477 116.129C51.1638 116.383 50.9118 116.637 50.7438 116.891C50.4919 117.06 50.2399 117.229 49.988 117.399C49.6521 117.483 49.4001 117.568 49.0642 117.568C48.7282 117.568 48.3923 117.483 48.1404 117.399C47.8044 117.314 47.5525 117.145 47.3845 116.891C47.1326 116.721 46.9646 116.467 46.8806 116.129C46.7966 115.875 46.7126 115.536 46.7126 115.112V111.302H47.8044V115.112C47.8044 115.282 47.8044 115.451 47.8884 115.62C47.9724 115.79 47.9724 115.959 48.1404 116.044C48.3083 116.129 48.3923 116.298 48.5603 116.383C48.7282 116.467 48.9802 116.552 49.2321 116.552C49.4841 116.552 49.736 116.467 49.904 116.383C50.072 116.298 50.2399 116.213 50.3239 116.044C50.4079 115.875 50.4919 115.79 50.5759 115.62C50.6599 115.451 50.6599 115.282 50.6599 115.112V111.302H51.4157V115.112Z" fill=#128040></path>
                                        <path d="M55.7827 112.572C55.6987 112.403 55.5307 112.318 55.3628 112.233C55.1948 112.148 54.9428 112.148 54.7749 112.148C54.6909 112.148 54.5229 112.148 54.4389 112.233C54.355 112.233 54.187 112.318 54.103 112.403C54.019 112.487 53.935 112.572 53.8511 112.657C53.7671 112.741 53.7671 112.911 53.7671 112.995C53.7671 113.165 53.8511 113.334 54.019 113.503C54.187 113.588 54.355 113.673 54.5229 113.757C54.6909 113.842 54.9428 113.927 55.1948 114.011C55.4467 114.096 55.6987 114.181 55.8667 114.35C56.0346 114.52 56.2866 114.689 56.3706 114.858C56.4545 115.028 56.6225 115.366 56.6225 115.705C56.6225 116.044 56.5385 116.298 56.4545 116.552C56.3706 116.806 56.2026 116.975 55.9506 117.145C55.7827 117.314 55.5307 117.399 55.2788 117.483C55.0268 117.568 54.6909 117.568 54.4389 117.568C54.103 117.568 53.6831 117.483 53.3472 117.399C53.0112 117.314 52.6753 117.06 52.4233 116.721L53.2632 115.959C53.4311 116.128 53.5991 116.298 53.7671 116.467C54.019 116.552 54.187 116.637 54.4389 116.637C54.5229 116.637 54.6909 116.637 54.7749 116.552C54.8589 116.552 55.0268 116.467 55.1108 116.383C55.1948 116.298 55.2788 116.213 55.3628 116.128C55.4467 116.044 55.4467 115.874 55.4467 115.79C55.4467 115.536 55.3628 115.366 55.1948 115.282C55.0268 115.197 54.8589 115.028 54.6909 114.943C54.5229 114.858 54.271 114.774 54.019 114.689C53.7671 114.604 53.5151 114.52 53.3472 114.35C53.1792 114.181 52.9272 114.011 52.8433 113.842C52.6753 113.588 52.5913 113.334 52.5913 112.995C52.5913 112.657 52.6753 112.403 52.7593 112.148C52.9272 111.894 53.0952 111.725 53.2632 111.556C53.4311 111.386 53.6831 111.302 53.935 111.217C54.187 111.132 54.4389 111.132 54.7749 111.132C55.1108 111.132 55.3628 111.217 55.6987 111.302C56.0346 111.386 56.2866 111.556 56.5385 111.81L55.7827 112.572Z" fill=#128040></path>
                                        <path d="M59.0581 112.233H57.2104V111.217H61.9975V112.233H60.1499V117.314H59.0581V112.233Z" fill=#128040></path>
                                        <path d="M64.2651 111.302H65.1889L67.7924 117.399H66.5327L65.9448 116.044H63.3413L62.8374 117.399H61.6616L64.2651 111.302ZM65.6088 115.028L64.685 112.572L63.7612 115.028H65.6088Z" fill=#128040></path>
                                        <path d="M68.5483 111.302H69.6401V117.399H68.5483V111.302Z" fill=#128040></path>
                                        <path d="M71.0676 111.302H72.4114L75.3508 115.79V111.302H76.4426V117.399H75.0988L72.1594 112.741V117.399H71.0676V111.302Z" fill=#128040></path>
                                        <path d="M80.0539 111.302H80.9777L83.5812 117.399H82.3215L81.7336 116.044H79.1301L78.6262 117.399H77.4504L80.0539 111.302ZM81.3976 115.028L80.4738 112.572L79.55 115.028H81.3976Z" fill=#128040></path>
                                        <path d="M84.5051 111.302H86.8567C87.1086 111.302 87.2766 111.302 87.5285 111.386C87.7805 111.471 87.9484 111.556 88.1164 111.64C88.2844 111.725 88.4523 111.895 88.5363 112.149C88.6203 112.403 88.7043 112.572 88.7043 112.826C88.7043 113.165 88.6203 113.419 88.4523 113.673C88.2844 113.927 88.0324 114.096 87.6965 114.181C87.8645 114.181 88.0324 114.266 88.2004 114.35C88.3684 114.435 88.5363 114.52 88.6203 114.689C88.7043 114.858 88.7883 114.943 88.8723 115.112C88.9562 115.282 88.9562 115.451 88.9562 115.62C88.9562 115.959 88.8723 116.213 88.7883 116.467C88.6203 116.721 88.4523 116.891 88.2844 116.975C88.0324 117.145 87.8645 117.229 87.5285 117.229C87.2766 117.314 86.9406 117.314 86.6887 117.314H84.5051V111.302ZM85.5969 113.757H86.6047C86.9406 113.757 87.1926 113.673 87.4445 113.588C87.6125 113.419 87.6965 113.249 87.6965 112.995C87.6965 112.741 87.6125 112.572 87.4445 112.403C87.2766 112.233 86.9406 112.233 86.5207 112.233H85.5969V113.757ZM85.5969 116.383H86.6047C86.7727 116.383 86.8567 116.383 87.0246 116.383C87.1926 116.383 87.3606 116.298 87.4445 116.298C87.6125 116.213 87.6965 116.129 87.7805 116.044C87.8645 115.959 87.9484 115.79 87.9484 115.536C87.9484 115.197 87.8645 115.028 87.6125 114.858C87.4445 114.774 87.1086 114.689 86.6047 114.689H85.5969V116.383Z" fill=#128040></path>
                                        <path d="M90.1318 111.302H91.2236V116.383H93.7431V117.399H90.1318V111.302Z" fill=#128040></path>
                                        <path d="M94.667 111.302H98.6982V112.318H95.7588V113.842H98.5302V114.858H95.7588V116.467H98.8662V117.483H94.751V111.302H94.667Z" fill=#128040></path>
                                        <path d="M41.5896 119.431H43.9411C44.1931 119.431 44.361 119.431 44.613 119.515C44.8649 119.6 45.0329 119.685 45.2009 119.769C45.3688 119.854 45.5368 120.023 45.6208 120.277C45.7048 120.532 45.7888 120.701 45.7888 120.955C45.7888 121.294 45.7048 121.548 45.5368 121.802C45.3688 122.056 45.1169 122.225 44.781 122.31C44.9489 122.31 45.1169 122.394 45.2849 122.479C45.4528 122.564 45.6208 122.649 45.7048 122.818C45.7888 122.987 45.8727 123.072 45.9567 123.241C46.0407 123.411 46.0407 123.58 46.0407 123.749C46.0407 124.088 45.9567 124.342 45.8727 124.596C45.7048 124.85 45.5368 125.02 45.3688 125.104C45.2009 125.189 44.9489 125.358 44.613 125.358C44.2771 125.358 44.0251 125.443 43.7732 125.443H41.5896V119.431ZM42.6814 121.971H43.6892C44.0251 121.971 44.2771 121.886 44.529 121.802C44.697 121.632 44.781 121.463 44.781 121.209C44.781 120.955 44.697 120.786 44.529 120.616C44.361 120.447 44.0251 120.447 43.6052 120.447H42.6814V121.971ZM42.6814 124.596H43.6892C43.8571 124.596 43.9411 124.596 44.1091 124.596C44.2771 124.596 44.445 124.512 44.529 124.512C44.697 124.427 44.781 124.342 44.8649 124.257C44.9489 124.173 45.0329 124.003 45.0329 123.749C45.0329 123.411 44.9489 123.241 44.697 123.072C44.529 122.987 44.1931 122.903 43.6892 122.903H42.6814V124.596Z" fill=#128040></path>
                                        <path d="M47.0486 119.431H49.1482C49.4001 119.431 49.736 119.431 49.988 119.515C50.2399 119.6 50.4919 119.685 50.7438 119.769C50.9958 119.854 51.1638 120.108 51.2477 120.277C51.3317 120.532 51.4157 120.786 51.4157 121.124C51.4157 121.548 51.3317 121.971 51.0798 122.225C50.8278 122.564 50.4919 122.733 50.072 122.733L51.6677 125.443H50.4079L48.9802 122.818H48.2243V125.443H47.1326V119.431H47.0486ZM48.9802 122.056C49.1482 122.056 49.3161 122.056 49.4001 122.056C49.5681 122.056 49.736 121.971 49.82 121.971C49.988 121.886 50.072 121.802 50.156 121.717C50.2399 121.632 50.2399 121.463 50.2399 121.209C50.2399 121.04 50.2399 120.87 50.156 120.786C50.072 120.701 49.988 120.616 49.904 120.532C49.82 120.447 49.6521 120.447 49.4841 120.447C49.3161 120.447 49.2321 120.447 49.0642 120.447H48.1404V122.14H48.9802V122.056Z" fill=#128040></path>
                                        <path d="M54.271 119.431H55.1948L57.7983 125.528H56.5385L55.9506 124.173H53.3471L52.7593 125.528H51.5835L54.271 119.431ZM55.6987 123.241L54.7749 120.786L53.851 123.241H55.6987Z" fill=#128040></path>
                                        <path d="M58.4702 119.431H59.8979L62.8373 124.003V119.431H63.9291V125.528H62.5854L59.562 120.87V125.528H58.4702V119.431Z" fill=#128040></path>
                                        <path d="M65.189 119.431H67.5405C67.9604 119.431 68.2963 119.515 68.7163 119.6C69.0522 119.685 69.3881 119.939 69.7241 120.193C69.976 120.447 70.228 120.786 70.3959 121.124C70.5639 121.548 70.6479 121.971 70.6479 122.479C70.6479 122.987 70.5639 123.495 70.3119 123.834C70.06 124.173 69.892 124.512 69.5561 124.766C69.2202 125.02 68.8842 125.189 68.5483 125.358C68.1284 125.443 67.7924 125.528 67.4565 125.528H65.189V119.431ZM67.0366 124.596C67.3725 124.596 67.7085 124.596 67.9604 124.512C68.2124 124.427 68.5483 124.342 68.7163 124.173C68.9682 124.003 69.1362 123.834 69.2202 123.495C69.3041 123.157 69.3881 122.903 69.3881 122.564C69.3881 122.225 69.3041 121.886 69.2202 121.632C69.1362 121.378 68.9682 121.124 68.7163 120.955C68.4643 120.786 68.2963 120.701 67.9604 120.616C67.7085 120.532 67.3725 120.532 67.0366 120.532H66.0288V124.681H67.0366V124.596Z" fill=#128040></path>
                                        <path d="M73.6711 119.431H74.7629V125.528H73.6711V119.431Z" fill=#128040></path>
                                        <path d="M75.9387 119.431H77.3664L80.3059 124.003V119.431H81.3976V125.528H80.0539L77.0305 120.87V125.528H75.9387V119.431Z" fill=#128040></path>
                                        <path d="M82.6575 119.431H85.009C85.4289 119.431 85.7649 119.515 86.1848 119.6C86.5207 119.685 86.8566 119.939 87.1926 120.193C87.4445 120.447 87.6965 120.786 87.8644 121.124C88.0324 121.548 88.1164 121.971 88.1164 122.479C88.1164 122.987 88.0324 123.495 87.7805 123.834C87.6125 124.257 87.3605 124.512 87.0246 124.766C86.6887 125.02 86.3527 125.189 86.0168 125.358C85.6809 125.528 85.261 125.528 84.925 125.528H82.6575V119.431ZM84.5891 124.596C84.925 124.596 85.261 124.596 85.5129 124.512C85.8488 124.427 86.1008 124.342 86.2688 124.173C86.5207 124.003 86.6887 123.834 86.7726 123.495C86.9406 123.241 86.9406 122.903 86.9406 122.564C86.9406 122.225 86.8566 121.886 86.7726 121.632C86.6887 121.378 86.5207 121.124 86.2688 120.955C86.1008 120.786 85.8488 120.701 85.5129 120.616C85.261 120.532 84.925 120.532 84.5891 120.532H83.5813V124.681H84.5891V124.596Z" fill=#128040></path>
                                        <path d="M88.7881 119.431H92.8193V120.447H89.8799V121.971H92.6513V122.987H89.8799V124.681H92.9872V125.697H88.7881V119.431Z" fill=#128040></path>
                                        <path d="M95.3388 122.394L93.3232 119.515H94.667L96.0947 121.802L97.5224 119.515H98.8661L96.8505 122.394L99.0341 125.612H97.6904L96.0947 123.072L94.499 125.612H93.2393L95.3388 122.394Z" fill=#128040></path>
                                        <path d="M22.2734 82.4255L21.6855 78.6995C21.6016 78.3608 21.6016 78.0221 21.6016 77.5987C21.6016 77.26 21.6855 76.9212 21.8535 76.5825C22.0215 76.2438 22.1894 75.9898 22.4414 75.8204C22.6933 75.651 23.0293 75.4817 23.4492 75.397C23.9531 75.3123 24.457 75.397 24.8769 75.651C25.2968 75.9051 25.5488 76.2438 25.8007 76.7519C25.8007 76.4132 25.8007 76.1591 25.8847 75.9051C25.9687 75.651 26.1367 75.397 26.3046 75.1429C26.4726 74.9736 26.6406 74.7195 26.8925 74.6349C27.1445 74.4655 27.3964 74.3808 27.7323 74.3808C28.2362 74.2961 28.6562 74.2961 29.0761 74.4655C29.496 74.6349 29.7479 74.8042 29.9999 75.1429C30.2518 75.4817 30.5038 75.8204 30.6718 76.2438C30.8397 76.6672 30.9237 77.0906 31.0077 77.514L31.5956 80.9012L22.2734 82.4255ZM25.8007 80.0544L25.5488 78.5302C25.4648 77.9374 25.2968 77.5987 25.0449 77.3446C24.7929 77.0906 24.457 77.0059 24.1211 77.0906C23.7011 77.1753 23.4492 77.3446 23.2812 77.6834C23.1133 78.0221 23.1133 78.5302 23.1972 79.1229L23.4492 80.4778L25.8007 80.0544ZM29.9159 79.377L29.664 77.8527C29.664 77.5987 29.58 77.4293 29.496 77.1753C29.412 76.9212 29.328 76.7519 29.1601 76.4978C28.9921 76.3285 28.8241 76.1591 28.6562 76.0744C28.4882 75.9897 28.2362 75.9051 27.9003 75.9897C27.3964 76.0744 27.0605 76.3285 26.9765 76.6672C26.8085 77.0059 26.8085 77.514 26.9765 78.1914L27.2284 79.8004L29.9159 79.377Z" fill=#228948></path>
                                        <path d="M20.9297 72.1792L21.0977 68.8767C21.0977 68.4533 21.1816 67.9452 21.2656 67.5218C21.3496 67.0984 21.5176 66.7597 21.7695 66.421C22.0215 66.0822 22.2734 65.8282 22.6094 65.6588C22.9453 65.4895 23.4492 65.4048 23.9531 65.4048C24.6249 65.4048 25.2128 65.6588 25.6327 66.0822C26.0527 66.5056 26.3046 67.0137 26.3886 67.7758L30.6717 65.4048V67.4371L26.5566 69.4695L26.4726 70.7397L30.5038 70.909L30.4198 72.6026L20.9297 72.1792ZM25.1289 69.3001C25.1289 69.0461 25.1289 68.792 25.1289 68.538C25.1289 68.2839 25.0449 68.0299 24.9609 67.8605C24.8769 67.6912 24.7929 67.5218 24.6249 67.3524C24.457 67.1831 24.205 67.1831 23.8691 67.0984C23.6172 67.0984 23.3652 67.0984 23.1972 67.2678C23.0293 67.3524 22.8613 67.5218 22.7773 67.6912C22.6933 67.8605 22.6094 68.1146 22.6094 68.2839C22.6094 68.538 22.5254 68.7073 22.5254 68.9614L22.4414 70.4009L25.0449 70.4856L25.1289 69.3001Z" fill=#228948></path>
                                        <path d="M22.5254 59.0535L22.9453 57.6139L33.1913 56.1743L32.6874 58.0373L30.3358 58.2913L29.2441 62.356L31.0917 63.7956L30.5878 65.6586L22.5254 59.0535ZM28.8241 58.5454L24.709 58.9688L28.0683 61.4245L28.8241 58.5454Z" fill=#228948></path>
                                        <path d="M25.2129 50.9243L26.3047 48.9766L34.703 48.4685L28.5722 44.912L29.4121 43.3877L37.6424 48.1298L36.5506 49.9928L27.9004 50.4162L34.1991 54.0575L33.3593 55.497L25.2129 50.9243Z" fill=#228948></path>
                                        <path d="M38.0622 37.1213C37.5583 37.1213 37.1384 37.206 36.8024 37.2907C36.4665 37.4601 36.2146 37.6294 35.9626 37.8835C35.6267 38.2222 35.3747 38.6456 35.2068 39.069C35.0388 39.4924 34.9548 39.9158 35.0388 40.3392C35.1228 40.7626 35.2068 41.186 35.3747 41.6094C35.5427 42.0328 35.7946 42.3715 36.1306 42.7103C36.4665 43.049 36.8864 43.303 37.3063 43.5571C37.7263 43.7264 38.1462 43.8111 38.5661 43.8958C38.986 43.8958 39.4059 43.8111 39.8258 43.6418C40.2458 43.4724 40.5817 43.2184 40.9176 42.8796C41.1696 42.6256 41.3375 42.2869 41.5055 41.8635C41.5895 41.4401 41.6735 41.0167 41.5895 40.5086L43.2692 40.1699C43.4371 40.932 43.3531 41.6094 43.1012 42.2022C42.8492 42.8796 42.5133 43.3877 42.0094 43.8958C41.5055 44.4039 40.9176 44.8273 40.3297 45.0813C39.7419 45.3354 39.154 45.5047 38.4821 45.5047C37.8942 45.5047 37.2224 45.4201 36.6345 45.166C36.0466 44.912 35.4587 44.5732 34.8708 43.9805C34.2829 43.4724 33.947 42.8796 33.6111 42.2869C33.3591 41.6941 33.1912 41.0167 33.1912 40.4239C33.1912 39.8311 33.2751 39.1537 33.5271 38.5609C33.779 37.9682 34.199 37.3754 34.7029 36.8673C35.1228 36.3592 35.6267 36.0205 36.2146 35.7665C36.8024 35.5124 37.3903 35.4277 38.1462 35.4277L38.0622 37.1213Z" fill=#228948></path>
                                        <path d="M39.7419 32.7176L41.1697 31.7862L43.1853 35.004L46.9645 32.5483L44.9489 29.3304L46.3766 28.3989L51.4996 36.4436L50.0719 37.3751L47.8043 33.8185L44.0251 36.2742L46.2926 39.8308L44.8649 40.7623L39.7419 32.7176Z" fill=#228948></path>
                                        <path d="M49.7358 26.8748L55.6987 24.7578L56.2025 26.1974L51.8354 27.8063L52.5913 30.008L56.7065 28.4838L57.2104 29.9233L53.0952 31.4476L53.935 33.9033L58.4701 32.2097L58.974 33.6493L52.8432 35.851L49.7358 26.8748Z" fill=#228948></path>
                                        <path d="M57.8823 23.9956L59.8139 23.7415L63.3412 30.6007L65.0209 23.0641L66.8685 22.8101L64.349 32.8024L62.9213 32.9717L57.8823 23.9956Z" fill=#228948></path>
                                        <path d="M68.968 22.9795H70.6477L70.3957 32.5484H68.7161L68.968 22.9795Z" fill=#228948></path>
                                        <path d="M74.091 23.0645L76.2746 23.4879L79.382 31.3632L80.8097 24.4193L82.4894 24.7581L80.6417 34.1576L78.5422 33.7342L75.3508 25.6049L73.9231 32.8027L72.2434 32.464L74.091 23.0645Z" fill=#228948></path>
                                        <path d="M86.2687 26.1128L89.6281 27.8064C90.216 28.0604 90.7199 28.4839 91.1398 28.9073C91.5597 29.3307 91.8956 29.8387 92.1476 30.4315C92.3995 31.0243 92.4835 31.617 92.4835 32.2945C92.4835 32.9719 92.2316 33.6494 91.8956 34.4115C91.5597 35.1736 91.0558 35.6817 90.5519 36.1051C90.048 36.5285 89.4601 36.7826 88.7882 36.9519C88.2004 37.1213 87.5285 37.1213 86.9406 37.0366C86.3527 36.9519 85.7648 36.7826 85.2609 36.5285L82.0696 34.9196L86.2687 26.1128ZM85.4289 34.6655C85.9328 34.9196 86.3527 35.0889 86.8566 35.1736C87.3605 35.2583 87.7804 35.2583 88.2004 35.1736C88.6203 35.0889 89.0402 34.9196 89.3761 34.6655C89.7121 34.4115 90.048 33.9881 90.2999 33.48C90.5519 32.9719 90.7199 32.4638 90.7199 32.0404C90.7199 31.617 90.6359 31.1936 90.4679 30.7702C90.2999 30.4315 90.048 30.0928 89.7121 29.7541C89.3761 29.4153 88.9562 29.1613 88.5363 28.9919L87.1086 28.3145L84.2531 34.1575L85.4289 34.6655Z" fill=#228948></path>
                                        <path d="M96.5986 31.8711L101.47 35.8511L100.462 37.0366L96.9345 34.0728L95.4228 35.9358L98.7821 38.7302L97.7743 39.9158L94.415 37.1213L92.8193 39.1536L96.5986 42.2868L95.5908 43.4723L90.5518 39.323L96.5986 31.8711Z" fill=#228948></path>
                                        <path d="M103.905 38.3916L106.005 41.0167C106.257 41.3554 106.509 41.7788 106.761 42.1175C106.929 42.541 107.097 42.8797 107.097 43.3031C107.181 43.7265 107.097 44.0652 106.929 44.4886C106.761 44.8273 106.509 45.2507 106.089 45.5895C105.585 46.0129 104.997 46.2669 104.409 46.2669C103.821 46.2669 103.233 46.0129 102.729 45.5048L101.05 50.1622L99.79 48.5533L101.554 44.2346L100.798 43.3031L97.6904 45.8435L96.5986 44.4886L103.905 38.3916ZM102.645 43.3031C102.813 43.4724 102.981 43.6418 103.149 43.8112C103.317 43.9805 103.485 44.1499 103.653 44.2346C103.821 44.3192 104.073 44.4039 104.241 44.4039C104.493 44.4039 104.661 44.3192 104.913 44.0652C105.165 43.8958 105.249 43.7265 105.333 43.4724C105.417 43.3031 105.417 43.049 105.333 42.8797C105.249 42.7103 105.165 42.4563 105.081 42.2869C104.997 42.1175 104.829 41.9482 104.661 41.7788L103.737 40.5933L101.722 42.2022L102.645 43.3031Z" fill=#228948></path>
                                        <path d="M104.661 53.2103L109.364 55.3274C109.532 55.412 109.616 55.412 109.784 55.4967C109.952 55.5814 110.12 55.5814 110.288 55.6661C110.456 55.7508 110.624 55.7508 110.792 55.7508C110.96 55.7508 111.128 55.7508 111.296 55.6661C111.464 55.5814 111.632 55.4967 111.716 55.3274C111.8 55.158 111.884 55.0733 111.968 54.904C112.052 54.7346 112.052 54.5652 112.052 54.3959C112.052 54.2265 111.968 54.0572 111.968 53.8878C111.8 53.5491 111.548 53.2103 111.296 53.1257C110.96 52.9563 110.624 52.9563 110.288 53.041L109.784 51.4321C110.204 51.2627 110.624 51.2627 110.96 51.2627C111.296 51.2627 111.716 51.4321 111.968 51.6014C112.304 51.7708 112.556 52.0248 112.807 52.2789C113.059 52.6176 113.227 52.9563 113.395 53.295C113.563 53.7184 113.647 54.0572 113.647 54.4806C113.647 54.904 113.647 55.2427 113.563 55.5814C113.479 55.9201 113.311 56.2589 113.059 56.5129C112.807 56.7669 112.472 57.021 112.052 57.1903C111.464 57.4444 110.96 57.4444 110.456 57.3597C109.952 57.275 109.448 57.1057 108.944 56.8516L105.333 55.158L107.013 59.3074L105.669 59.8154L103.317 53.8878L104.661 53.2103Z" fill=#228948></path>
                                        <path d="M110.372 59.8158C111.128 59.6465 111.715 59.6465 112.303 59.6465C112.891 59.6465 113.311 59.7312 113.731 59.9005C114.151 60.0699 114.487 60.1546 114.739 60.4086C114.991 60.6626 115.243 60.832 115.327 61.0861C115.495 61.3401 115.579 61.5095 115.663 61.7635C115.747 62.0175 115.831 62.1869 115.831 62.3563C115.831 62.5256 115.915 62.7797 115.915 62.949C115.915 63.2031 115.915 63.4571 115.831 63.7112C115.747 63.9652 115.663 64.3039 115.495 64.558C115.327 64.812 115.075 65.1507 114.739 65.4048C114.403 65.6588 113.983 65.9129 113.479 66.1669C112.975 66.4209 112.387 66.5903 111.632 66.675C110.876 66.8443 110.288 66.8443 109.7 66.8443C109.112 66.8443 108.692 66.7597 108.272 66.5903C107.852 66.4209 107.516 66.3363 107.264 66.0822C107.012 65.8282 106.76 65.6588 106.677 65.4048C106.509 65.1507 106.425 64.9814 106.341 64.7273C106.257 64.4733 106.173 64.3039 106.173 64.1346C106.173 63.9652 106.089 63.7112 106.089 63.5418C106.089 63.2878 106.089 63.0337 106.173 62.7797C106.257 62.5256 106.341 62.1869 106.509 61.9329C106.677 61.6788 106.928 61.3401 107.264 61.0861C107.6 60.832 108.02 60.578 108.524 60.3239C109.028 60.0699 109.7 59.9005 110.372 59.8158ZM110.708 61.3401C110.456 61.4248 110.12 61.5095 109.7 61.5941C109.364 61.6788 108.944 61.8482 108.692 62.0175C108.356 62.1869 108.104 62.4409 107.936 62.695C107.768 62.949 107.684 63.2878 107.768 63.7112C107.852 64.1346 108.02 64.3886 108.272 64.6426C108.524 64.812 108.86 64.9814 109.28 65.066C109.616 65.1507 110.036 65.1507 110.456 65.066C110.876 64.9814 111.212 64.9814 111.464 64.8967C111.715 64.812 112.051 64.7273 112.471 64.6426C112.807 64.558 113.227 64.3886 113.479 64.2192C113.815 64.0499 114.067 63.7958 114.235 63.5418C114.403 63.2878 114.487 62.949 114.403 62.5256C114.319 62.1022 114.151 61.8482 113.899 61.5941C113.647 61.4248 113.311 61.2554 112.891 61.1707C112.555 61.0861 112.135 61.0861 111.716 61.1707C111.296 61.2554 110.96 61.3401 110.708 61.3401Z" fill=#228948></path>
                                        <path d="M108.776 68.3687L112.303 72.1793C112.387 72.264 112.555 72.4333 112.639 72.518C112.723 72.6027 112.891 72.772 113.059 72.8567C113.227 72.9414 113.311 73.0261 113.479 73.1108C113.647 73.1954 113.815 73.1955 113.899 73.1955C114.067 73.1955 114.235 73.1954 114.403 73.1108C114.571 73.0261 114.655 72.9414 114.823 72.7721C114.907 72.6874 114.991 72.518 115.075 72.3486C115.159 72.1793 115.159 72.0099 115.159 71.8406C115.159 71.4172 115.075 71.0784 114.823 70.8244C114.571 70.5704 114.319 70.401 113.899 70.3163L114.067 68.6227C114.487 68.6227 114.907 68.7921 115.243 68.9614C115.579 69.1308 115.831 69.3848 116.083 69.6389C116.335 69.8929 116.503 70.2316 116.587 70.655C116.671 70.9938 116.755 71.4172 116.755 71.8406C116.755 72.264 116.671 72.6874 116.587 73.0261C116.503 73.3648 116.335 73.7035 116.083 74.0423C115.831 74.2963 115.579 74.5503 115.243 74.7197C114.907 74.8891 114.487 74.9737 114.067 74.9737C113.479 74.9737 112.975 74.8044 112.555 74.5503C112.135 74.2963 111.716 73.8729 111.296 73.4495L108.608 70.4857L108.524 74.8891H107.096L107.18 68.4533L108.776 68.3687Z" fill=#228948></path>
                                        <path d="M111.967 79.2922L111.883 79.7156C111.799 79.9696 111.799 80.139 111.799 80.393C111.799 80.647 111.799 80.8164 111.883 80.9858C111.967 81.1551 112.051 81.3245 112.135 81.4939C112.303 81.6632 112.471 81.7479 112.807 81.8326C113.143 81.9173 113.479 81.8326 113.731 81.6632C113.983 81.4939 114.151 81.1551 114.235 80.7317C114.319 80.393 114.235 80.139 114.151 79.8002C113.983 79.5462 113.815 79.2922 113.479 79.1228L114.319 77.5139C114.655 77.6832 114.907 77.9373 115.159 78.1913C115.411 78.4453 115.495 78.6994 115.663 79.0381C115.831 79.3768 115.831 79.6309 115.831 79.9696C115.831 80.3083 115.831 80.647 115.747 80.9858C115.663 81.4092 115.495 81.7479 115.327 82.0866C115.159 82.4253 114.907 82.6794 114.655 82.9334C114.403 83.1875 114.067 83.3568 113.731 83.4415C113.395 83.5262 112.975 83.5262 112.555 83.4415C112.051 83.3568 111.632 83.1028 111.296 82.7641C110.96 82.4253 110.792 81.9173 110.792 81.4092C110.54 82.0019 110.204 82.4253 109.784 82.5947C109.28 82.8487 108.776 82.8487 108.188 82.7641C107.768 82.6794 107.348 82.51 107.096 82.256C106.76 82.0019 106.593 81.7479 106.341 81.4092C106.173 81.0704 106.089 80.7317 106.005 80.3083C106.005 79.8849 106.005 79.4615 106.089 79.0381C106.173 78.6147 106.257 78.276 106.425 77.9373C106.593 77.5985 106.76 77.3445 107.012 77.0905C107.264 76.8364 107.516 76.6671 107.852 76.4977C108.188 76.3283 108.524 76.2437 108.944 76.2437L109.028 78.0219C108.608 78.0219 108.272 78.1066 108.02 78.3607C107.768 78.53 107.6 78.8688 107.516 79.2922C107.432 79.5462 107.432 79.7156 107.516 79.8849C107.6 80.0543 107.6 80.3083 107.684 80.4777C107.768 80.647 107.936 80.8164 108.104 80.9011C108.272 80.9858 108.44 81.0704 108.692 81.1551C109.028 81.2398 109.28 81.2398 109.448 81.1551C109.7 81.0704 109.868 80.9011 109.952 80.7317C110.036 80.5624 110.204 80.3083 110.288 80.139C110.372 79.8849 110.456 79.6309 110.456 79.4615L110.54 79.0381L111.967 79.2922Z" fill=#228948></path>
                                        <path d="M20.6777 154.743H21.8535C22.4414 154.743 23.1972 154.827 23.9531 155.42C24.457 155.844 24.8769 156.606 24.8769 157.622C24.8769 158.807 24.289 159.4 23.8691 159.824C23.3652 160.247 22.8613 160.501 21.8535 160.501H20.7617V154.743H20.6777ZM21.2656 159.824H21.7695C22.1894 159.824 22.8613 159.739 23.3652 159.315C23.7851 158.977 24.121 158.384 24.121 157.622C24.121 156.267 23.1972 155.42 21.7695 155.42H21.2656V159.824Z" fill=white></path>
                                        <path d="M28.4882 156.86H29.0761V160.332H28.4882V159.824C28.3203 160.078 27.9004 160.416 27.3125 160.416C26.4726 160.416 25.6328 159.824 25.6328 158.553C25.6328 157.368 26.4726 156.69 27.3125 156.69C27.9843 156.69 28.3203 157.029 28.4882 157.283V156.86ZM26.2207 158.638C26.2207 159.4 26.6406 159.993 27.3965 159.993C28.1523 159.993 28.5722 159.4 28.5722 158.723C28.5722 157.791 27.9843 157.453 27.3965 157.453C26.7246 157.368 26.2207 157.791 26.2207 158.638Z" fill=white></path>
                                        <path d="M30.252 156.86H30.8398V157.283C30.9238 157.114 31.2598 156.775 31.8476 156.775C32.2676 156.775 32.6035 156.945 32.8554 157.283C33.0234 157.538 33.0234 157.792 33.0234 158.215V160.417H32.4355V158.3C32.4355 158.13 32.4355 157.876 32.2676 157.622C32.1836 157.453 31.9316 157.368 31.6797 157.368C31.5117 157.368 31.2598 157.453 31.0918 157.622C30.8398 157.876 30.8398 158.3 30.8398 158.554V160.417H30.252V156.86Z" fill=white></path>
                                        <path d="M35.6267 157.707C35.5427 157.538 35.3747 157.368 35.1228 157.368C34.8708 157.368 34.7029 157.538 34.7029 157.792C34.7029 158.046 34.8708 158.13 35.2908 158.3C35.7946 158.469 36.0466 158.638 36.1306 158.808C36.2985 158.977 36.2985 159.146 36.2985 159.401C36.2985 160.163 35.7946 160.586 35.1228 160.586C34.9548 160.586 34.199 160.586 33.947 159.655L34.4509 159.401C34.5349 159.57 34.7029 159.993 35.1228 159.993C35.5427 159.993 35.7107 159.739 35.7107 159.401C35.7107 159.062 35.4587 158.977 35.1228 158.808C34.7029 158.638 34.4509 158.469 34.283 158.3C34.115 158.13 34.115 157.961 34.115 157.792C34.115 157.199 34.5349 156.775 35.1228 156.775C35.2908 156.775 35.7947 156.775 36.0466 157.453L35.6267 157.707Z" fill=white></path>
                                        <path d="M37.7263 154.235V158.215L38.9861 156.945H39.7419L38.2302 158.469L39.9939 160.501H39.238L37.8103 158.892L37.6423 159.062V160.501H37.1384V154.32H37.7263V154.235Z" fill=white></path>
                                        <path d="M43.6892 159.485C43.6052 159.655 43.4372 159.909 43.2692 160.078C42.9333 160.332 42.5974 160.501 42.0935 160.501C41.2537 160.501 40.4138 159.993 40.4138 158.638C40.4138 157.622 41.0857 156.775 42.0935 156.775C42.7653 156.775 43.1853 157.114 43.4372 157.453C43.6892 157.792 43.7731 158.3 43.7731 158.808H41.0857C41.0857 159.57 41.5896 159.993 42.1775 159.993C42.4294 159.993 42.6814 159.909 42.8493 159.739C43.0173 159.57 43.1013 159.4 43.1853 159.231L43.6892 159.485ZM43.1013 158.3C43.0173 157.707 42.5974 157.368 42.0935 157.368C41.5896 157.368 41.1697 157.792 41.0857 158.3H43.1013Z" fill=white></path>
                                        <path d="M47.2165 157.453V160.416H46.6287V157.453H46.2927V156.86H46.6287V155.336C46.6287 154.997 46.6287 154.574 46.9646 154.319C47.1326 154.15 47.3845 154.065 47.6365 154.065C47.8884 154.065 47.9724 154.15 48.0564 154.15V154.743C47.9724 154.658 47.8044 154.658 47.6365 154.658C47.4685 154.658 47.3845 154.658 47.2165 154.828C47.1326 154.997 47.1326 155.166 47.1326 155.336V156.775H47.9724V157.368H47.2165V157.453Z" fill=white></path>
                                        <path d="M48.3921 158.638C48.3921 157.538 49.1479 156.775 50.2397 156.775C51.3315 156.775 52.0874 157.538 52.0874 158.638C52.0874 159.739 51.3315 160.501 50.2397 160.501C49.1479 160.501 48.3921 159.739 48.3921 158.638ZM48.98 158.638C48.98 159.485 49.5679 159.909 50.2397 159.909C50.8276 159.909 51.4995 159.485 51.4995 158.638C51.4995 157.792 50.9116 157.368 50.2397 157.368C49.5679 157.368 48.98 157.792 48.98 158.638Z" fill=white></path>
                                        <path d="M53.0112 156.86H53.5991V157.199C53.6831 157.114 53.935 156.775 54.355 156.775C54.5229 156.775 54.7749 156.86 54.8589 156.945L54.6069 157.538C54.4389 157.453 54.355 157.453 54.271 157.453C54.019 157.453 53.8511 157.538 53.7671 157.707C53.6831 157.876 53.5991 158.046 53.5991 158.638V160.501H53.0112V156.86Z" fill=white></path>
                                        <path d="M56.1186 160.417H55.5308V154.235H56.1186V157.368C56.5386 156.86 57.0425 156.775 57.2944 156.775C58.3862 156.775 58.9741 157.707 58.9741 158.638C58.9741 159.57 58.3862 160.501 57.2944 160.501C56.7065 160.501 56.3706 160.247 56.1186 159.908V160.417ZM58.3862 158.638C58.3862 157.791 57.7983 157.283 57.2104 157.283C56.6225 157.283 56.0347 157.707 56.0347 158.554C56.0347 159.231 56.4546 159.824 57.2104 159.824C57.9663 159.993 58.3862 159.4 58.3862 158.638Z" fill=white></path>
                                        <path d="M59.8979 156.86H60.4858V157.199C60.5698 157.114 60.8218 156.775 61.2417 156.775C61.4096 156.775 61.6616 156.86 61.7456 156.945L61.4936 157.538C61.3257 157.453 61.2417 157.453 61.1577 157.453C60.9057 157.453 60.7378 157.538 60.6538 157.707C60.5698 157.876 60.4858 158.046 60.4858 158.638V160.501H59.8979V156.86Z" fill=white></path>
                                        <path d="M63.0054 158.977C63.0054 159.231 63.0054 159.485 63.1733 159.739C63.2573 159.823 63.4253 159.993 63.7612 159.993C64.0971 159.993 64.2651 159.823 64.3491 159.739C64.5171 159.485 64.5171 159.231 64.5171 158.977V156.944H65.1049V159.061C65.1049 159.485 65.021 159.823 64.769 160.078C64.4331 160.416 64.0132 160.501 63.6772 160.501C63.3413 160.501 62.9214 160.416 62.5854 160.078C62.3335 159.739 62.2495 159.485 62.2495 159.061V156.944H62.8374V158.977H63.0054Z" fill=white></path>
                                        <path d="M68.9682 156.86H69.5561V160.247C69.5561 160.586 69.5561 161.179 69.2202 161.602C68.9682 161.941 68.4643 162.279 67.7925 162.279C67.2046 162.279 66.7847 162.025 66.5327 161.771C66.2808 161.517 66.1128 161.179 66.1128 160.67H66.7007C66.7007 161.009 66.7847 161.263 66.9526 161.433C67.2046 161.687 67.5405 161.771 67.7925 161.771C68.2124 161.771 68.5483 161.602 68.7163 161.263C68.8842 161.009 68.8842 160.67 68.8842 160.332V159.824C68.7163 160.078 68.2964 160.416 67.7085 160.416C67.2046 160.416 66.7847 160.247 66.5327 159.908C66.2808 159.654 66.0288 159.231 66.0288 158.553C66.0288 157.876 66.2808 157.453 66.5327 157.199C66.7847 156.944 67.2886 156.69 67.7085 156.69C68.2124 156.69 68.6323 156.944 68.8842 157.283V156.86H68.9682ZM67.0366 157.707C66.7847 158.045 66.7007 158.384 66.7007 158.638C66.7007 158.977 66.7847 159.316 67.1206 159.654C67.2886 159.824 67.5405 159.908 67.8764 159.908C68.2124 159.908 68.4643 159.824 68.6323 159.654C68.8842 159.4 69.0522 159.061 69.0522 158.638C69.0522 158.215 68.8842 157.876 68.7163 157.622C68.5483 157.453 68.2124 157.283 67.9604 157.283C67.4565 157.368 67.2046 157.537 67.0366 157.707Z" fill=white></path>
                                        <path d="M73.8391 159.485C73.7551 159.655 73.5871 159.909 73.4191 160.078C73.0832 160.332 72.7473 160.501 72.2434 160.501C71.4036 160.501 70.5637 159.993 70.5637 158.638C70.5637 157.622 71.2356 156.775 72.2434 156.775C72.9153 156.775 73.3352 157.114 73.5871 157.453C73.8391 157.792 73.923 158.3 73.923 158.808H71.2356C71.2356 159.57 71.7395 159.993 72.3274 159.993C72.5793 159.993 72.8313 159.909 72.9992 159.739C73.1672 159.57 73.2512 159.4 73.3352 159.231L73.8391 159.485ZM73.2512 158.3C73.1672 157.707 72.7473 157.368 72.2434 157.368C71.7395 157.368 71.3196 157.792 71.2356 158.3H73.2512Z" fill=white></path>
                                        <path d="M74.7629 156.86H75.3508V157.199C75.4348 157.114 75.6868 156.775 76.1067 156.775C76.2746 156.775 76.5266 156.86 76.6106 156.945L76.3586 157.538C76.1906 157.453 76.1067 157.453 76.0227 157.453C75.7707 157.453 75.6028 157.538 75.5188 157.707C75.4348 157.876 75.3508 158.046 75.3508 158.638V160.501H74.7629V156.86Z" fill=white></path>
                                        <path d="M80.1379 159.485C80.0539 159.655 79.8859 159.909 79.718 160.078C79.382 160.332 79.0461 160.501 78.5422 160.501C77.7024 160.501 76.8625 159.993 76.8625 158.638C76.8625 157.622 77.5344 156.775 78.5422 156.775C79.2141 156.775 79.634 157.114 79.8859 157.453C80.1379 157.792 80.2219 158.3 80.2219 158.808H77.4504C77.4504 159.57 77.9543 159.993 78.5422 159.993C78.7942 159.993 79.0461 159.909 79.2141 159.739C79.382 159.57 79.466 159.4 79.55 159.231L80.1379 159.485ZM79.55 158.3C79.466 157.707 79.0461 157.368 78.5422 157.368C78.0383 157.368 77.6184 157.792 77.5344 158.3H79.55Z" fill=white></path>
                                        <path d="M82.8254 158.638C82.8254 157.538 83.5813 156.775 84.6731 156.775C85.7649 156.775 86.5207 157.538 86.5207 158.638C86.5207 159.739 85.7649 160.501 84.6731 160.501C83.6653 160.501 82.8254 159.739 82.8254 158.638ZM83.4973 158.638C83.4973 159.485 84.0852 159.909 84.7571 159.909C85.4289 159.909 86.0168 159.485 86.0168 158.638C86.0168 157.792 85.4289 157.368 84.7571 157.368C84.0852 157.368 83.4973 157.792 83.4973 158.638Z" fill=white></path>
                                        <path d="M88.0322 162.364H87.4443V156.945H88.0322V157.453C88.4521 156.945 88.956 156.86 89.208 156.86C90.2998 156.86 90.8876 157.791 90.8876 158.723C90.8876 159.654 90.2998 160.586 89.208 160.586C88.6201 160.586 88.2842 160.332 88.0322 159.993V162.364ZM90.2998 158.638C90.2998 157.791 89.7119 157.283 89.124 157.283C88.5361 157.283 87.9482 157.707 87.9482 158.553C87.9482 159.231 88.3682 159.824 89.124 159.824C89.8799 159.993 90.2998 159.4 90.2998 158.638Z" fill=white></path>
                                        <path d="M92.4834 157.453V160.416H91.8955V157.453H91.5596V156.86H91.8955V155.336C91.8955 154.997 91.8955 154.574 92.2314 154.319C92.3994 154.15 92.6514 154.065 92.9033 154.065C93.1553 154.065 93.2392 154.15 93.3232 154.15V154.743C93.2392 154.658 93.0713 154.658 92.9033 154.658C92.7353 154.658 92.6514 154.658 92.4834 154.828C92.3994 154.997 92.3994 155.166 92.3994 155.336V156.775H93.2392V157.368H92.4834V157.453Z" fill=white></path>
                                        <path d="M96.5986 156.86H97.1865V160.332H96.5986V159.824C96.4306 160.078 96.0107 160.416 95.4228 160.416C94.583 160.416 93.7432 159.824 93.7432 158.553C93.7432 157.368 94.583 156.69 95.4228 156.69C96.0947 156.69 96.4306 157.029 96.5986 157.283V156.86ZM94.331 158.638C94.331 159.4 94.751 159.993 95.5068 159.993C96.2627 159.993 96.6826 159.4 96.6826 158.723C96.6826 157.791 96.0947 157.453 95.5068 157.453C94.8349 157.368 94.331 157.791 94.331 158.638Z" fill=white></path>
                                        <path d="M98.9502 157.453V160.417H98.3623V157.453H98.0264V156.86H98.3623V155.59H98.9502V156.86H99.5381V157.453H98.9502Z" fill=white></path>
                                        <path d="M100.882 157.453V160.417H100.294V157.453H99.958V156.86H100.294V155.59H100.882V156.86H101.47V157.453H100.882Z" fill=white></path>
                                        <path d="M105.165 159.485C105.081 159.655 104.913 159.909 104.745 160.078C104.409 160.332 104.073 160.501 103.569 160.501C102.729 160.501 101.89 159.993 101.89 158.638C101.89 157.622 102.562 156.775 103.569 156.775C104.241 156.775 104.661 157.114 104.913 157.453C105.165 157.792 105.249 158.3 105.249 158.808H102.562C102.562 159.57 103.065 159.993 103.653 159.993C103.905 159.993 104.157 159.909 104.325 159.739C104.493 159.57 104.577 159.4 104.661 159.231L105.165 159.485ZM104.577 158.3C104.493 157.707 104.073 157.368 103.569 157.368C103.065 157.368 102.645 157.792 102.562 158.3H104.577Z" fill=white></path>
                                        <path d="M106.089 156.86H106.677V157.199C106.76 157.114 107.012 156.775 107.432 156.775C107.6 156.775 107.852 156.86 107.936 156.945L107.684 157.538C107.516 157.453 107.432 157.453 107.348 157.453C107.096 157.453 106.928 157.538 106.844 157.707C106.76 157.876 106.677 158.046 106.677 158.638V160.501H106.089V156.86Z" fill=white></path>
                                        <path d="M110.288 158.638C110.288 157.538 111.044 156.775 112.135 156.775C113.227 156.775 113.983 157.538 113.983 158.638C113.983 159.739 113.227 160.501 112.135 160.501C111.128 160.501 110.288 159.739 110.288 158.638ZM110.96 158.638C110.96 159.485 111.548 159.909 112.219 159.909C112.891 159.909 113.479 159.485 113.479 158.638C113.479 157.792 112.891 157.368 112.219 157.368C111.548 157.368 110.96 157.792 110.96 158.638Z" fill=white></path>
                                        <path d="M116.419 157.707C116.335 157.538 116.167 157.368 115.915 157.368C115.663 157.368 115.495 157.538 115.495 157.792C115.495 158.046 115.663 158.13 116.083 158.3C116.587 158.469 116.839 158.638 116.923 158.808C117.091 158.977 117.091 159.146 117.091 159.401C117.091 160.163 116.587 160.586 115.915 160.586C115.747 160.586 114.991 160.586 114.739 159.655L115.243 159.401C115.327 159.57 115.495 159.993 115.915 159.993C116.335 159.993 116.503 159.739 116.503 159.401C116.503 159.062 116.251 158.977 115.915 158.808C115.495 158.638 115.243 158.469 115.075 158.3C114.907 158.13 114.907 157.961 114.907 157.792C114.907 157.199 115.327 156.775 115.915 156.775C116.083 156.775 116.587 156.775 116.839 157.453L116.419 157.707Z" fill=white></path>
                                        <path d="M17.0664 167.869C16.9824 167.699 16.8144 167.53 16.5625 167.53C16.3105 167.53 16.1426 167.699 16.1426 167.953C16.1426 168.207 16.3105 168.292 16.7305 168.461C17.2344 168.631 17.4863 168.8 17.5703 168.969C17.7383 169.139 17.7382 169.308 17.7382 169.562C17.7382 170.324 17.2344 170.748 16.5625 170.748C16.3945 170.748 15.6387 170.748 15.3867 169.816L15.8906 169.562C15.9746 169.731 16.1426 170.155 16.5625 170.155C16.9824 170.155 17.1504 169.901 17.1504 169.562C17.1504 169.223 16.8984 169.139 16.5625 168.969C16.1426 168.8 15.8906 168.631 15.7227 168.461C15.5547 168.292 15.5547 168.123 15.5547 167.953C15.5547 167.36 15.9746 166.937 16.5625 166.937C16.7305 166.937 17.2344 166.937 17.4863 167.614L17.0664 167.869Z" fill=white></path>
                                        <path d="M18.3262 168.8C18.3262 167.699 19.082 166.937 20.1738 166.937C21.2656 166.937 22.0214 167.699 22.0214 168.8C22.0214 169.901 21.2656 170.663 20.1738 170.663C19.082 170.663 18.3262 169.901 18.3262 168.8ZM18.998 168.8C18.998 169.647 19.5859 170.07 20.2578 170.07C20.8457 170.07 21.5175 169.647 21.5175 168.8C21.5175 167.953 20.9297 167.53 20.2578 167.53C19.5859 167.53 18.998 167.953 18.998 168.8Z" fill=white></path>
                                        <path d="M22.9453 167.022H23.5332V167.36C23.7012 167.106 24.0371 166.937 24.373 166.937C24.9609 166.937 25.2129 167.36 25.2968 167.53C25.6328 167.022 26.1367 166.937 26.3046 166.937C27.3124 166.937 27.3964 167.784 27.3964 168.292V170.494H26.8085V168.377C26.8085 167.953 26.7246 167.445 26.2207 167.445C25.5488 167.445 25.4648 168.123 25.4648 168.546V170.494H24.8769V168.377C24.8769 168.123 24.8769 167.445 24.289 167.445C23.6172 167.445 23.5332 168.123 23.5332 168.546V170.494H22.9453V167.022Z" fill=white></path>
                                        <path d="M33.3591 164.396H33.947V170.578H33.3591V170.07C33.1911 170.324 32.7712 170.663 32.1833 170.663C31.3435 170.663 30.5037 170.07 30.5037 168.8C30.5037 167.614 31.3435 166.937 32.1833 166.937C32.8552 166.937 33.1911 167.276 33.3591 167.53V164.396ZM31.0915 168.8C31.0915 169.562 31.5115 170.155 32.2673 170.155C33.0232 170.155 33.4431 169.562 33.4431 168.885C33.4431 167.953 32.8552 167.614 32.2673 167.614C31.5954 167.53 31.0915 167.953 31.0915 168.8Z" fill=white></path>
                                        <path d="M38.1462 169.647C38.0622 169.816 37.8942 170.07 37.7263 170.24C37.3903 170.494 37.0544 170.663 36.5505 170.663C35.7107 170.663 34.8708 170.155 34.8708 168.8C34.8708 167.784 35.5427 166.937 36.5505 166.937C37.2224 166.937 37.6423 167.276 37.8942 167.614C38.1462 167.953 38.2302 168.461 38.2302 168.969H35.4587C35.4587 169.731 35.9626 170.155 36.5505 170.155C36.8025 170.155 37.0544 170.07 37.2224 169.901C37.3903 169.731 37.4743 169.562 37.5583 169.393L38.1462 169.647ZM37.5583 168.461C37.4743 167.868 37.0544 167.53 36.5505 167.53C36.0466 167.53 35.6267 167.953 35.5427 168.461H37.5583Z" fill=white></path>
                                        <path d="M39.7419 167.614V170.578H39.154V167.614H38.8181V167.022H39.154V165.751H39.7419V167.022H40.3298V167.614H39.7419Z" fill=white></path>
                                        <path d="M42.8494 167.022H43.4372V167.36C43.6052 167.106 43.9411 166.937 44.2771 166.937C44.865 166.937 45.1169 167.36 45.2009 167.53C45.5368 167.022 46.0407 166.937 46.2087 166.937C47.2165 166.937 47.3005 167.784 47.3005 168.292V170.494H46.7126V168.377C46.7126 167.953 46.6286 167.445 46.1247 167.445C45.4528 167.445 45.3689 168.123 45.3689 168.546V170.494H44.781V168.377C44.781 168.123 44.781 167.445 44.1931 167.445C43.5212 167.445 43.4372 168.123 43.4372 168.546V170.494H42.8494V167.022Z" fill=white></path>
                                        <path d="M51.7514 169.647C51.6674 169.816 51.4995 170.07 51.3315 170.24C50.9956 170.494 50.6596 170.663 50.1557 170.663C49.3159 170.663 48.4761 170.155 48.4761 168.8C48.4761 167.784 49.1479 166.937 50.1557 166.937C50.8276 166.937 51.2475 167.276 51.4995 167.614C51.7514 167.953 51.8354 168.461 51.8354 168.969H49.1479C49.1479 169.731 49.6518 170.155 50.2397 170.155C50.4917 170.155 50.7436 170.07 50.9116 169.901C51.0796 169.731 51.1635 169.562 51.2475 169.393L51.7514 169.647ZM51.1635 168.461C51.0796 167.868 50.6596 167.53 50.1557 167.53C49.6518 167.53 49.2319 167.953 49.1479 168.461H51.1635Z" fill=white></path>
                                        <path d="M54.103 167.869C54.019 167.699 53.8511 167.53 53.5991 167.53C53.3472 167.53 53.1792 167.699 53.1792 167.953C53.1792 168.207 53.3472 168.292 53.7671 168.461C54.271 168.631 54.5229 168.8 54.6069 168.969C54.7749 169.139 54.7749 169.308 54.7749 169.562C54.7749 170.324 54.271 170.748 53.5991 170.748C53.4311 170.748 52.6753 170.748 52.4233 169.816L52.9272 169.562C53.0112 169.731 53.1792 170.155 53.5991 170.155C54.019 170.155 54.187 169.901 54.187 169.562C54.187 169.223 53.935 169.139 53.5991 168.969C53.1792 168.8 52.9272 168.631 52.7593 168.461C52.5913 168.292 52.5913 168.123 52.5913 167.953C52.5913 167.36 53.0112 166.937 53.5991 166.937C53.7671 166.937 54.271 166.937 54.5229 167.614L54.103 167.869Z" fill=white></path>
                                        <path d="M56.2866 167.614V170.578H55.6147V167.614H55.2788V167.022H55.6147V165.751H56.2026V167.022H56.7905V167.614H56.2866Z" fill=white></path>
                                        <path d="M59.9819 170.578H59.394V164.396H59.9819V167.53C60.4018 167.022 60.9057 166.937 61.1577 166.937C62.2495 166.937 62.8374 167.868 62.8374 168.8C62.8374 169.731 62.2495 170.663 61.1577 170.663C60.5698 170.663 60.2339 170.409 59.9819 170.07V170.578ZM62.2495 168.8C62.2495 167.953 61.6616 167.445 61.0737 167.445C60.4858 167.445 59.8979 167.868 59.8979 168.715C59.8979 169.393 60.3179 169.985 61.0737 169.985C61.8296 170.155 62.2495 169.562 62.2495 168.8Z" fill=white></path>
                                        <path d="M69.3039 169.647C69.0519 170.07 68.632 170.663 67.7082 170.663C67.4562 170.663 66.7844 170.663 66.3645 169.986C66.0285 170.578 65.4406 170.663 65.0207 170.663C64.1809 170.663 63.509 170.324 63.509 169.562C63.509 168.8 64.1809 168.377 64.9367 168.377C65.3567 168.377 65.6926 168.461 65.9445 168.631C65.9445 168.461 65.9445 168.123 65.7766 167.869C65.6086 167.53 65.2727 167.445 64.9367 167.445C64.5168 167.445 64.0969 167.614 63.845 167.699V167.106C64.2649 166.937 64.6008 166.937 64.9367 166.937C65.3567 166.937 65.9445 167.022 66.2805 167.614C66.5324 167.191 67.0363 166.937 67.6242 166.937C68.632 166.937 69.3039 167.699 69.3039 168.8V168.885H66.6164C66.6164 169.562 67.1203 170.07 67.7082 170.07C68.2121 170.07 68.548 169.731 68.8 169.308L69.3039 169.647ZM64.1809 169.562C64.1809 169.816 64.3489 170.155 65.0207 170.155C65.6926 170.155 65.9445 169.816 65.9445 169.562C65.9445 169.308 65.6926 168.969 65.0207 168.969C64.5168 168.885 64.1809 169.223 64.1809 169.562ZM68.8 168.461C68.716 167.868 68.2961 167.53 67.7922 167.53C67.2883 167.53 66.8684 167.868 66.7844 168.461H68.8Z" fill=white></path>
                                        <path d="M70.3118 167.022H70.8996V167.36C70.9836 167.276 71.2356 166.937 71.6555 166.937C71.8235 166.937 72.0754 167.022 72.1594 167.106L71.9075 167.699C71.7395 167.614 71.6555 167.614 71.5715 167.614C71.3196 167.614 71.1516 167.699 71.0676 167.869C70.9836 168.038 70.8996 168.207 70.8996 168.8V170.663H70.3118V167.022Z" fill=white></path>
                                        <path d="M75.6867 169.647C75.6027 169.816 75.4348 170.07 75.2668 170.24C74.9309 170.494 74.5949 170.663 74.091 170.663C73.2512 170.663 72.4114 170.155 72.4114 168.8C72.4114 167.784 73.0832 166.937 74.091 166.937C74.7629 166.937 75.1828 167.276 75.4348 167.614C75.6867 167.953 75.7707 168.461 75.7707 168.969H73.0832C73.0832 169.731 73.5871 170.155 74.175 170.155C74.427 170.155 74.6789 170.07 74.8469 169.901C75.0149 169.731 75.0988 169.562 75.1828 169.393L75.6867 169.647ZM75.0988 168.461C75.0149 167.868 74.5949 167.53 74.091 167.53C73.5871 167.53 73.1672 167.953 73.0832 168.461H75.0988Z" fill=white></path>
                                        <path d="M79.2981 164.396H79.8859V170.578H79.2981V170.07C79.1301 170.324 78.7102 170.663 78.1223 170.663C77.2825 170.663 76.4426 170.07 76.4426 168.8C76.4426 167.614 77.2825 166.937 78.1223 166.937C78.7942 166.937 79.1301 167.276 79.2981 167.53V164.396ZM77.0305 168.8C77.0305 169.562 77.4504 170.155 78.2063 170.155C78.9621 170.155 79.382 169.562 79.382 168.885C79.382 167.953 78.7942 167.614 78.2063 167.614C77.6184 167.53 77.0305 167.953 77.0305 168.8Z" fill=white></path>
                                        <path d="M82.1533 170.239L80.5576 167.021H81.2295L82.4892 169.562L83.581 167.021H84.2529L81.7334 172.441H81.0615L82.1533 170.239Z" fill=white></path>
                                        <path d="M87.6123 167.021H88.2002V170.409C88.2002 170.747 88.2002 171.34 87.8642 171.764C87.6123 172.102 87.1084 172.441 86.4365 172.441C85.8486 172.441 85.4287 172.187 85.1768 171.933C84.9248 171.679 84.7568 171.34 84.7568 170.832H85.3447C85.3447 171.171 85.4287 171.425 85.5967 171.594C85.8486 171.848 86.1846 171.933 86.4365 171.933C86.8564 171.933 87.1924 171.764 87.3603 171.425C87.5283 171.171 87.5283 170.832 87.5283 170.493V169.985C87.3603 170.239 86.9404 170.578 86.3525 170.578C85.8486 170.578 85.4287 170.409 85.1768 170.07C84.9248 169.816 84.6729 169.392 84.6729 168.715C84.6729 168.038 84.9248 167.614 85.1768 167.36C85.4287 167.106 85.9326 166.852 86.3525 166.852C86.8564 166.852 87.2763 167.106 87.5283 167.445V167.021H87.6123ZM85.6807 167.868C85.4287 168.207 85.3447 168.546 85.3447 168.8C85.3447 169.138 85.4287 169.477 85.7646 169.816C85.9326 169.985 86.1846 170.07 86.5205 170.07C86.8564 170.07 87.1084 169.985 87.2763 169.816C87.5283 169.562 87.6963 169.223 87.6963 168.8C87.6963 168.376 87.5283 168.038 87.3603 167.784C87.1924 167.614 86.8564 167.445 86.6045 167.445C86.1006 167.53 85.8486 167.699 85.6807 167.868Z" fill=white></path>
                                        <path d="M89.9639 167.614V170.578H89.376V167.614H89.04V167.022H89.376V165.751H89.9639V167.022H90.5517V167.614H89.9639Z" fill=white></path>
                                        <path d="M91.4756 165.328C91.7275 165.328 91.8955 165.497 91.8955 165.752C91.8955 166.006 91.7275 166.175 91.4756 166.175C91.2236 166.175 91.0557 166.006 91.0557 165.752C91.0557 165.497 91.2236 165.328 91.4756 165.328ZM91.7275 167.022V170.494H91.1397V167.022H91.7275Z" fill=white></path>
                                        <path d="M95.5908 167.021H96.1787V170.409C96.1787 170.747 96.1787 171.34 95.8427 171.764C95.5908 172.102 95.0869 172.441 94.415 172.441C93.8271 172.441 93.4072 172.187 93.1553 171.933C92.9033 171.679 92.7353 171.34 92.7353 170.832H93.3232C93.3232 171.171 93.4072 171.425 93.5752 171.594C93.8271 171.848 94.1631 171.933 94.415 171.933C94.8349 171.933 95.1709 171.764 95.3388 171.425C95.5068 171.171 95.5068 170.832 95.5068 170.493V169.985C95.3388 170.239 94.9189 170.578 94.331 170.578C93.8271 170.578 93.4072 170.409 93.1553 170.07C92.9033 169.816 92.6514 169.392 92.6514 168.715C92.6514 168.038 92.9033 167.614 93.1553 167.36C93.4072 167.106 93.9111 166.852 94.331 166.852C94.8349 166.852 95.2548 167.106 95.5068 167.445V167.021H95.5908ZM93.6592 167.868C93.4072 168.207 93.3232 168.546 93.3232 168.8C93.3232 169.138 93.4072 169.477 93.7432 169.816C93.9111 169.985 94.1631 170.07 94.499 170.07C94.8349 170.07 95.0869 169.985 95.2548 169.816C95.5068 169.562 95.6748 169.223 95.6748 168.8C95.6748 168.376 95.5068 168.038 95.3388 167.784C95.1709 167.614 94.8349 167.445 94.583 167.445C94.0791 167.53 93.8271 167.699 93.6592 167.868Z" fill=white></path>
                                        <path d="M100.378 169.647C100.294 169.816 100.126 170.07 99.958 170.24C99.622 170.494 99.2861 170.663 98.7822 170.663C97.9424 170.663 97.1025 170.155 97.1025 168.8C97.1025 167.784 97.7744 166.937 98.7822 166.937C99.4541 166.937 99.874 167.276 100.126 167.614C100.378 167.953 100.462 168.461 100.462 168.969H97.7744C97.7744 169.731 98.2783 170.155 98.8662 170.155C99.1181 170.155 99.3701 170.07 99.5381 169.901C99.706 169.731 99.79 169.562 99.874 169.393L100.378 169.647ZM99.79 168.461C99.706 167.868 99.2861 167.53 98.7822 167.53C98.2783 167.53 97.8584 167.953 97.7744 168.461H99.79Z" fill=white></path>
                                        <path d="M103.905 170.578H103.317V164.396H103.905V167.53C104.325 167.022 104.829 166.937 105.081 166.937C106.173 166.937 106.76 167.868 106.76 168.8C106.76 169.731 106.173 170.663 105.081 170.663C104.493 170.663 104.157 170.409 103.905 170.07V170.578ZM106.173 168.8C106.173 167.953 105.585 167.445 104.997 167.445C104.409 167.445 103.821 167.868 103.821 168.715C103.821 169.393 104.241 169.985 104.997 169.985C105.753 170.155 106.173 169.562 106.173 168.8Z" fill=white></path>
                                        <path d="M107.684 167.022H108.272V167.36C108.356 167.276 108.608 166.937 109.028 166.937C109.196 166.937 109.448 167.022 109.532 167.106L109.28 167.699C109.112 167.614 109.028 167.614 108.944 167.614C108.692 167.614 108.524 167.699 108.44 167.869C108.356 168.038 108.272 168.207 108.272 168.8V170.663H107.684V167.022Z" fill=white></path>
                                        <path d="M112.723 167.021H113.311V170.493H112.723V169.985C112.555 170.239 112.135 170.578 111.548 170.578C110.708 170.578 109.868 169.985 109.868 168.715C109.868 167.53 110.708 166.852 111.548 166.852C112.219 166.852 112.555 167.191 112.723 167.445V167.021ZM110.456 168.8C110.456 169.562 110.876 170.155 111.632 170.155C112.387 170.155 112.807 169.562 112.807 168.884C112.807 167.953 112.219 167.614 111.632 167.614C110.96 167.53 110.456 167.953 110.456 168.8Z" fill=white></path>
                                        <path d="M114.487 167.022H115.075V167.445C115.159 167.276 115.495 166.937 116.083 166.937C116.503 166.937 116.839 167.106 117.091 167.445C117.259 167.699 117.258 167.953 117.258 168.377V170.578H116.671V168.461C116.671 168.292 116.671 168.038 116.503 167.784C116.419 167.614 116.167 167.53 115.915 167.53C115.747 167.53 115.495 167.614 115.327 167.784C115.075 168.038 115.075 168.461 115.075 168.715V170.578H114.487V167.022Z" fill=white></path>
                                        <path d="M121.038 164.396H121.625V170.578H121.038V170.07C120.87 170.324 120.45 170.663 119.862 170.663C119.022 170.663 118.182 170.07 118.182 168.8C118.182 167.614 119.022 166.937 119.862 166.937C120.534 166.937 120.87 167.276 121.038 167.53V164.396ZM118.77 168.8C118.77 169.562 119.19 170.155 119.946 170.155C120.702 170.155 121.122 169.562 121.122 168.885C121.122 167.953 120.534 167.614 119.946 167.614C119.358 167.53 118.77 167.953 118.77 168.8Z" fill=white></path>
                                        <path d="M52.3393 175.49C52.5913 175.49 52.7593 175.659 52.7593 175.913C52.7593 176.167 52.5913 176.337 52.3393 176.337C52.0874 176.337 51.9194 176.167 51.9194 175.913C51.9194 175.659 52.0874 175.49 52.3393 175.49ZM52.6753 177.183V180.655H52.0874V177.183H52.6753Z" fill=white></path>
                                        <path d="M56.3706 180.74H55.7827V174.558H56.3706V177.691C56.7905 177.183 57.2944 177.099 57.5464 177.099C58.6382 177.099 59.226 178.03 59.226 178.961C59.226 179.893 58.6382 180.824 57.5464 180.824C56.9585 180.824 56.6226 180.57 56.3706 180.232V180.74ZM58.6381 178.961C58.6381 178.115 58.0503 177.607 57.4624 177.607C56.8745 177.607 56.2866 178.03 56.2866 178.877C56.2866 179.554 56.7065 180.147 57.4624 180.147C58.2182 180.316 58.6381 179.724 58.6381 178.961Z" fill=white></path>
                                        <path d="M60.1499 177.183H60.7378V177.522C60.8218 177.437 61.0737 177.099 61.4936 177.099C61.6616 177.099 61.9135 177.183 61.9975 177.268L61.7456 177.861C61.5776 177.776 61.4936 177.776 61.4097 177.776C61.1577 177.776 60.9897 177.861 60.9058 178.03C60.8218 178.199 60.7378 178.369 60.7378 178.962V180.825H60.1499V177.183Z" fill=white></path>
                                        <path d="M65.1887 177.183H65.7766V180.655H65.1887V180.147C65.0207 180.401 64.6008 180.74 64.0129 180.74C63.1731 180.74 62.3333 180.147 62.3333 178.877C62.3333 177.691 63.1731 177.014 64.0129 177.014C64.6848 177.014 65.0207 177.352 65.1887 177.606V177.183ZM62.9211 178.961C62.9211 179.723 63.3411 180.316 64.0969 180.316C64.8528 180.316 65.2727 179.723 65.2727 179.046C65.2727 178.115 64.6848 177.776 64.0969 177.776C63.425 177.691 62.9211 178.115 62.9211 178.961Z" fill=white></path>
                                        <path d="M66.8684 177.183H67.4563V177.607C67.5403 177.437 67.8762 177.099 68.4641 177.099C68.884 177.099 69.2199 177.268 69.4719 177.607C69.6399 177.861 69.6399 178.115 69.6399 178.538V180.74H69.052V178.623C69.052 178.454 69.052 178.199 68.884 177.945C68.8 177.776 68.5481 177.691 68.2961 177.691C68.1282 177.691 67.8762 177.776 67.7082 177.945C67.4563 178.199 67.4563 178.623 67.4563 178.877V180.74H66.8684V177.183Z" fill=white></path>
                                        <path d="M73.5871 178.199C73.2512 177.776 72.8313 177.691 72.4953 177.691C71.8235 177.691 71.2356 178.115 71.2356 178.962C71.2356 179.808 71.8235 180.232 72.4953 180.232C72.8313 180.232 73.3352 180.062 73.5871 179.724V180.486C73.1672 180.74 72.8313 180.825 72.4953 180.825C71.4036 180.825 70.6477 180.062 70.6477 178.962C70.6477 177.861 71.4036 177.099 72.4953 177.099C73.0832 177.099 73.4192 177.353 73.5871 177.437V178.199Z" fill=white></path>
                                        <path d="M74.511 174.558H75.0989V177.607C75.1828 177.437 75.5188 177.099 76.1067 177.099C76.5266 177.099 76.8625 177.268 77.1145 177.607C77.2824 177.861 77.2824 178.115 77.2824 178.538V180.74H76.6945V178.623C76.6945 178.453 76.6945 178.199 76.5266 177.945C76.4426 177.776 76.1906 177.691 75.9387 177.691C75.7707 177.691 75.5188 177.776 75.3508 177.945C75.0989 178.199 75.0989 178.623 75.0989 178.877V180.74H74.511V174.558Z" fill=white></path>
                                        <path d="M81.4816 179.808C81.3977 179.978 81.2297 180.232 81.0617 180.401C80.7258 180.655 80.3899 180.825 79.886 180.825C79.0461 180.825 78.2063 180.316 78.2063 178.962C78.2063 177.945 78.8782 177.099 79.886 177.099C80.5578 177.099 80.9777 177.437 81.2297 177.776C81.4816 178.115 81.5656 178.623 81.5656 179.131H78.8782C78.8782 179.893 79.3821 180.316 79.9699 180.316C80.2219 180.316 80.4738 180.232 80.6418 180.062C80.8098 179.893 80.8938 179.724 80.9777 179.554L81.4816 179.808ZM80.8938 178.623C80.8098 178.03 80.3899 177.691 79.886 177.691C79.3821 177.691 78.9621 178.115 78.8782 178.623H80.8938Z" fill=white></path>
                                        <path d="M82.4053 177.183H82.9932V177.607C83.0771 177.437 83.4131 177.099 84.001 177.099C84.4209 177.099 84.7568 177.268 85.0088 177.607C85.1767 177.861 85.1767 178.115 85.1767 178.538V180.74H84.5888V178.623C84.5888 178.454 84.5888 178.199 84.4209 177.945C84.3369 177.776 84.0849 177.691 83.833 177.691C83.665 177.691 83.4131 177.776 83.2451 177.945C82.9932 178.199 82.9932 178.623 82.9932 178.877V180.74H82.4053V177.183Z" fill=white></path>
                                    </g>
                                    <defs>
                                        <clippath id=clip0_5402_2541>
                                            <rect width=138 height=195 fill=white></rect>
                                        </clippath>
                                    </defs>
                                </svg>
                                </a>
                                <a href=https://andelenergi.dk/om-os/sustainable-brand-index-vinder />
                                <svg xmlns=http://www.w3.org/2000/svg width=138 height=195 viewBox="0 0 138 195" fill=none class="w-[138px] h-auto">
                                    <g clip-path=url(#clip0_5402_2669)>
                                        <path d="M138.549 -0.300781H-0.548828V140.863H138.549V-0.300781Z" fill=#EFEFEF></path>
                                        <path d="M138.549 140.61H-0.548828V195.554H138.549V140.61Z" fill=#034638></path>
                                        <path d="M93.7003 90.4842C92.9416 91.4985 92.0986 92.4283 91.087 93.1891C90.4969 93.6963 89.9068 93.7808 90.4969 93.0201C91.3399 91.9212 92.3515 90.8223 93.4474 89.977C94.2061 89.3853 94.1218 89.8925 93.7003 90.4842ZM94.0375 69.0982C92.1829 69.0982 90.9184 71.2114 90.6655 73.5783C90.4969 75.776 91.5085 77.8047 93.1102 77.6357C94.7119 77.4666 95.9765 75.5224 96.2294 73.1556C96.398 71.296 95.7236 69.0982 94.0375 69.0982ZM58.3779 91.9212C57.5349 90.3151 55.4274 88.9626 53.4884 88.9626C51.5495 88.9626 50.7065 90.2306 51.5495 91.8366C52.3925 93.4427 54.6687 94.7952 56.6076 94.7952C58.5465 94.7952 59.2209 93.5272 58.3779 91.9212ZM86.3661 91.6676C87.2091 90.0615 86.3661 88.7936 84.4271 88.7936C82.4882 88.7936 80.3807 90.146 79.5376 91.7521C78.6946 93.3582 79.369 94.6261 81.308 94.6261C83.2469 94.6261 85.5231 93.2736 86.3661 91.6676ZM92.773 88.4555C93.2788 87.0185 92.5201 86.4268 91.0027 86.9339C89.4852 87.5256 88.0521 89.1317 87.5463 90.4842C87.0405 91.9212 87.7149 92.5974 89.148 92.0902C90.6655 91.4985 92.2672 89.8925 92.773 88.4555ZM48.5989 92.4283C50.1164 93.0201 50.7908 92.2593 50.285 90.8223C49.7792 89.3853 48.2617 87.7792 46.7443 87.1875C45.2269 86.5958 44.3839 87.3566 44.974 88.709C45.4798 90.146 47.0815 91.8366 48.5989 92.4283ZM43.7094 89.7234C44.7211 90.3996 44.8054 89.5543 44.2152 88.2019C43.6251 86.8494 42.6135 85.4969 41.6019 84.8207C40.5903 84.1445 40.3374 84.8207 40.9275 86.1732C41.5176 87.4411 42.6978 89.0472 43.7094 89.7234ZM40.6746 83.6373C41.7705 84.7362 42.2763 83.8063 42.1077 82.2848C41.8548 80.7633 41.1804 78.9882 40.0845 77.8893C38.9885 76.7904 38.3141 77.4666 38.4827 78.9882C38.6513 80.5097 39.5787 82.5384 40.6746 83.6373ZM99.0113 78.8191C99.2642 77.2976 98.5055 76.7059 97.4939 77.7202C96.4823 78.7346 95.7236 80.5097 95.555 81.9467C95.3864 83.3837 95.8922 84.3135 96.9038 83.2146C97.9154 82.2848 98.7584 80.3406 99.0113 78.8191ZM100.107 76.3677C99.6014 77.2976 99.0956 78.8191 98.8427 80.087C98.5898 81.355 98.7584 82.0312 99.2642 81.1014C99.77 80.1716 100.276 78.3965 100.529 77.1285C100.866 75.9451 100.613 75.5224 100.107 76.3677ZM38.3141 80.3406C38.0612 79.0727 37.5554 77.5512 37.0496 76.6213C36.5438 75.776 36.3752 76.1987 36.6281 77.3821C36.881 78.65 37.3025 80.3406 37.8926 81.355C38.3984 82.2848 38.567 81.6086 38.3141 80.3406ZM43.7094 68.9291C41.9391 68.9291 41.2647 71.2114 41.4333 73.0711C41.6862 75.5224 43.035 77.5512 44.6368 77.6357C46.3228 77.8047 47.3344 75.776 47.1658 73.4092C46.9972 71.1269 45.5641 68.9291 43.7094 68.9291ZM63.5203 79.3263C66.3023 79.3263 68.4941 76.9595 68.4098 74.17C68.3255 71.3805 65.9651 69.0982 63.1831 69.1827C60.4012 69.1827 58.2093 71.5496 58.2936 74.339C58.3779 77.1285 60.7384 79.3263 63.5203 79.3263ZM75.154 69.1827C72.372 69.1827 70.0116 71.3805 69.9273 74.17C69.843 76.9595 72.0348 79.2417 74.8168 79.3263C77.5987 79.3263 79.9592 77.1285 80.0435 74.339C80.1278 71.5496 77.9359 69.1827 75.154 69.1827ZM52.7297 78.7346C55.0902 78.9036 56.8605 76.8749 56.7762 74.17C56.6919 71.465 54.4157 69.0982 52.2239 69.1827C49.6949 69.1827 48.1774 71.5496 48.2617 73.5783C48.4303 76.2832 50.4536 78.5655 52.7297 78.7346ZM85.776 69.1827C83.5841 69.1827 81.308 71.5496 81.2237 74.17C81.1394 76.7904 82.994 78.9036 85.2702 78.7346C87.6306 78.5655 89.6538 76.2832 89.6538 73.5783C89.8224 71.5496 88.3893 69.1827 85.776 69.1827ZM82.6568 38.414C83.6684 39.2593 84.933 39.9355 86.1132 40.5272C86.5347 40.6963 87.8835 41.288 87.0405 40.6118C86.1132 39.851 85.0173 39.2593 83.9213 38.7521C83.6684 38.4985 82.151 37.9068 82.6568 38.414ZM90.5812 43.2322C90.8341 43.4012 91.0027 43.5703 91.2556 43.7394C89.991 42.6405 88.7265 41.5416 87.2934 40.6118C87.3777 40.6963 87.462 40.7808 87.6306 40.8654C88.5579 41.7107 89.5695 42.4714 90.5812 43.2322ZM76.5028 36.5544C77.2615 37.4842 79.0318 37.8223 80.1278 38.1604C80.465 38.2449 82.5725 38.6676 81.9824 38.1604C81.0551 37.3997 79.7062 36.977 78.6103 36.6389C78.2731 36.5544 76.1656 36.1317 76.5028 36.5544ZM90.4126 43.9084C91.2556 45.0073 92.3515 46.1062 93.4474 46.9515C94.2904 47.6277 94.1218 47.036 93.616 46.4443C92.8573 45.43 91.93 44.5001 90.9184 43.6548C90.3283 43.1477 89.8224 43.0631 90.4126 43.9084ZM78.3574 36.4698C78.9475 36.6389 79.5376 36.8925 80.1278 36.8925C78.526 36.3008 76.9243 35.8781 75.2383 35.54C76.2499 35.9627 77.3458 36.2162 78.3574 36.4698ZM62.4244 35.4555C60.7384 35.7091 59.1366 36.2162 57.5349 36.7234C58.125 36.7234 58.7151 36.4698 59.3052 36.3008C60.3169 36.0472 61.4971 35.8781 62.4244 35.4555ZM64.3633 40.9499C62.6773 41.0344 60.2326 41.9642 59.8954 43.9084C59.5581 46.0217 62.2558 46.7824 63.8575 46.6979C65.6279 46.6134 68.4098 45.5145 68.4098 43.4012C68.4098 41.4571 65.8808 40.8654 64.3633 40.9499ZM63.7732 47.7968C61.4971 47.8813 59.0523 49.5719 58.8837 52.0233C58.6308 54.5591 61.0756 56.2497 63.436 56.1652C65.8808 56.0807 68.4098 54.221 68.4098 51.6006C68.4098 49.1492 66.0494 47.6277 63.7732 47.7968ZM74.4795 35.3709C72.7092 35.0328 71.0232 34.8638 69.3371 34.8638H69.2528C69.6744 35.2864 71.529 35.2019 72.1191 35.2864C72.9621 35.3709 75.154 35.7936 74.4795 35.3709ZM51.2966 45.599C50.7065 47.4587 52.5611 48.1349 54.0785 47.8813C55.9332 47.5432 58.2936 46.1062 58.6308 44.0775C58.968 42.2178 56.8605 41.8797 55.5117 42.2178C53.8256 42.556 51.8867 43.8239 51.2966 45.599ZM63.1831 67.6612C65.9651 67.6612 68.4098 65.2944 68.4098 62.4204C68.4098 59.7154 66.0494 57.4331 63.3517 57.5177C60.6541 57.6022 58.3779 59.8845 58.2936 62.5894C58.2093 65.3789 60.4855 67.6612 63.1831 67.6612ZM57.4506 38.2449C56.1018 38.5831 54.3314 39.2593 53.5727 40.5272C52.814 41.8797 55.1745 41.6261 55.8489 41.5416C57.1977 41.2035 59.4739 40.4427 60.064 39.0057C60.4855 37.6532 58.0407 38.0759 57.4506 38.2449ZM36.7124 60.8143C37.6397 60.0536 38.0612 58.1939 38.3141 57.095C38.3984 56.7569 38.8199 54.5591 38.2298 55.2354C37.3868 56.1652 37.0496 57.5177 36.7124 58.7011C36.6281 58.9547 36.2909 61.1524 36.7124 60.8143ZM96.3137 49.741C96.398 49.8255 96.4823 49.91 96.5666 49.9945C95.6393 48.6421 94.6276 47.2896 93.5317 46.0217C93.7003 46.2752 93.8689 46.4443 94.0375 46.6979C94.7962 47.7968 95.555 48.8111 96.3137 49.741ZM57.7035 37.9068C58.7994 37.6532 60.6541 37.3151 61.3285 36.3853C61.5814 35.9627 59.4739 36.3853 59.1366 36.3853C58.0407 36.6389 56.6076 37.0615 55.7646 37.8223C55.0902 38.414 57.3663 37.9914 57.7035 37.9068ZM36.5438 61.6596C35.7008 62.2513 35.7008 64.111 35.6165 65.0408C35.6165 65.4634 35.3636 67.9993 36.038 67.9148C36.881 67.8303 37.0496 65.0408 37.0496 64.4491C37.0496 64.111 37.0496 61.3215 36.5438 61.6596ZM101.372 62.0823C101.035 60.4762 100.613 58.8701 100.107 57.3486C100.192 57.9403 100.36 58.4475 100.529 59.0392C100.866 60.0536 101.119 61.0679 101.372 62.0823ZM93.8689 47.5432C92.8573 46.6979 92.9416 47.8813 93.2788 48.6421C93.9532 49.9945 94.8805 51.6006 96.1451 52.4459C97.241 53.1221 96.6509 51.5161 96.398 51.0089C95.8079 49.741 94.9649 48.3885 93.8689 47.5432ZM96.2294 63.7729C96.0608 62.0823 95.2178 59.7154 93.2788 59.2928C91.1713 58.8701 90.4969 61.5751 90.5812 63.1811C90.6655 64.9563 91.6771 67.7457 93.8689 67.7457C95.8079 67.8303 96.398 65.2944 96.2294 63.7729ZM84.1742 48.9802C82.151 48.6421 80.465 50.0791 80.6336 52.1923C80.8865 54.4746 82.994 56.6724 85.3545 56.926C87.462 57.1796 88.8951 55.4044 88.5579 53.3757C88.1364 51.2625 86.2818 49.4028 84.1742 48.9802ZM89.4852 53.6293C89.8225 55.489 91.2556 57.7713 93.1945 58.1939C94.9648 58.532 95.3021 56.5033 94.9649 55.2354C94.5433 53.5448 93.3631 51.6006 91.6771 51.0089C89.8224 50.3327 89.2323 52.1923 89.4852 53.6293ZM96.9038 63.8574C96.9881 64.9563 97.4096 67.8303 98.8427 67.8303C100.192 67.8303 100.023 65.2099 100.023 64.4491C99.9387 63.2657 99.6014 60.9834 98.2526 60.5607C96.8195 60.1381 96.8195 63.0966 96.9038 63.8574ZM101.203 67.9993C101.793 67.9993 101.54 65.548 101.54 65.1253C101.456 64.1955 101.456 62.4204 100.697 61.8287C100.276 61.4906 100.276 64.1955 100.276 64.6181C100.36 65.2099 100.444 67.9148 101.203 67.9993ZM96.4823 53.2067C95.2178 52.3614 95.4707 54.7282 95.6393 55.4044C95.9765 56.7569 96.7352 58.9547 98.1683 59.5464C99.3485 60.0536 98.927 57.6022 98.7584 57.0105C98.3369 55.7425 97.6625 54.052 96.4823 53.2067ZM101.962 68.0839C101.962 66.3087 101.793 64.6181 101.54 62.9276C101.372 62.674 101.625 64.4491 101.625 65.2944C101.709 65.8016 101.962 67.5767 101.962 68.0839ZM100.697 75.0153C101.456 74.4236 101.456 72.6484 101.54 71.7186C101.54 71.296 101.793 68.8446 101.203 68.8446C100.444 68.9291 100.276 71.6341 100.276 72.2258C100.276 72.6484 100.276 75.3534 100.697 75.0153ZM81.3923 62.674C81.4766 65.0408 83.3312 67.6612 85.8603 67.6612C88.305 67.6612 89.7381 65.2944 89.5695 63.0966C89.4009 60.8143 87.7992 58.4475 85.4388 58.1939C82.9097 58.0248 81.308 60.3917 81.3923 62.674ZM99.0113 57.3486C99.2642 58.4475 99.6014 60.2226 100.529 60.9834C100.866 61.237 100.529 59.1237 100.444 58.8701C100.107 57.7713 99.77 56.4188 99.0113 55.489C98.5898 54.8973 98.927 57.0105 99.0113 57.3486ZM98.8427 69.0137C97.3253 69.0137 96.9881 71.9722 96.9038 72.9866C96.8195 73.7473 96.8195 76.7904 98.2526 76.2832C99.6014 75.776 99.8543 73.5783 100.023 72.3949C100.107 71.5496 100.192 68.9292 98.8427 69.0137ZM73.7208 41.0344C72.2034 40.8654 69.6744 41.4571 69.7587 43.4012C69.843 45.599 72.5406 46.6979 74.3952 46.7824C75.997 46.867 78.6103 46.1062 78.2731 43.993C77.8516 42.1333 75.4069 41.119 73.7208 41.0344ZM72.9621 37.0615C72.1191 36.977 69.5057 36.8925 69.59 38.2449C69.6743 39.7665 72.5406 40.1891 73.6365 40.3582C74.3952 40.4427 77.4301 40.4427 76.9243 38.9212C76.4185 37.5687 74.1423 37.2306 72.9621 37.0615ZM72.2034 35.3709C71.7819 35.3709 69.3371 35.1174 69.3371 35.7091C69.4214 36.5544 72.1191 36.7234 72.7935 36.7234C73.1307 36.7234 75.9127 36.8079 75.4912 36.3008C74.9854 35.54 73.1307 35.54 72.2034 35.3709ZM96.8195 51.347C97.4096 52.5304 97.9997 53.7984 98.8427 54.8127C99.2642 55.3199 98.6741 53.7984 98.5055 53.5448C98.3369 53.2912 98.2526 52.9531 98.084 52.6995C97.9997 52.5304 97.9154 52.3614 97.7468 52.1078C97.4096 51.5161 97.0724 50.9244 96.6509 50.3327C96.0608 49.4874 96.5666 50.9244 96.8195 51.347ZM80.3807 38.4985C79.7906 38.3295 77.4301 37.9068 77.9359 39.1748C78.526 40.6118 80.7179 41.4571 82.0667 41.7952C82.7411 41.9642 85.0173 42.2178 84.2585 40.8654C83.4998 39.5974 81.7295 38.8367 80.3807 38.4985ZM86.4504 40.7808C85.8603 40.5272 84.3428 40.0201 85.0173 41.1189C85.8603 42.3869 87.3777 43.4858 88.7265 44.0775C89.4852 44.5001 90.5812 44.5001 89.7381 43.4012C88.9794 42.3869 87.7149 41.4571 86.4504 40.7808ZM79.369 44.2465C79.7906 46.1907 82.0667 47.7122 83.9213 48.0504C85.3545 48.304 87.1248 47.6277 86.5347 45.8526C85.9446 44.0775 84.0056 42.8941 82.3196 42.3869C81.0551 42.0488 79.0318 42.4714 79.369 44.2465ZM89.148 44.7537C87.9678 44.162 86.9562 44.7537 87.462 46.1062C88.0521 47.7968 89.6538 49.4028 91.3399 49.9945C92.773 50.5017 93.1945 49.4028 92.6887 48.2194C92.0143 46.7824 90.6655 45.43 89.148 44.7537ZM74.3952 47.8813C72.1191 47.7123 69.843 49.2338 69.843 51.6851C69.843 54.3056 72.4563 56.1652 74.9011 56.2497C77.2615 56.3343 79.5376 54.6437 79.2847 52.1078C79.1161 49.6564 76.7557 47.9658 74.3952 47.8813ZM69.9273 62.5049C69.9273 65.2944 72.2877 67.6612 75.0697 67.7457C77.7673 67.7457 79.9592 65.4634 79.8749 62.7585C79.7906 60.0536 77.5144 57.7713 74.9011 57.6867C72.2034 57.5177 69.9273 59.8 69.9273 62.5049ZM68.3255 34.8638C66.6395 34.8638 64.9535 35.0328 63.2674 35.2864H63.1831C62.5087 35.7091 64.7849 35.2864 65.5436 35.2019C66.0494 35.2019 68.2412 35.2864 68.4098 34.8638C68.4941 34.8638 68.3255 34.8638 68.3255 34.8638ZM64.9535 37.0615C63.7732 37.1461 61.4971 37.4842 61.0756 38.8367C60.5698 40.3582 63.6046 40.3582 64.4476 40.3582C65.5436 40.2737 68.4941 39.851 68.4941 38.3295C68.4098 36.8925 65.8808 36.977 64.9535 37.0615ZM36.5438 58.8701C36.7124 58.2784 36.9653 57.6867 36.9653 57.095C36.3752 58.7011 35.9537 60.3071 35.6165 61.9977C36.038 61.0679 36.2909 59.969 36.5438 58.8701ZM35.1107 68.8446C35.1107 70.6197 35.2793 72.3949 35.5322 74.0854C35.6165 73.4937 35.5322 72.4794 35.4479 71.7186C35.4479 71.2114 35.195 69.0137 35.1107 68.8446ZM65.5436 35.3709C64.7006 35.4555 62.7616 35.4555 62.2558 36.2162C61.9186 36.7234 64.7006 36.7234 65.0378 36.7234C65.6279 36.7234 68.4098 36.5544 68.4098 35.7091C68.4941 35.1174 65.9651 35.2864 65.5436 35.3709ZM38.4827 54.4746C39.3258 53.4603 40.0002 52.1923 40.5903 51.0089C40.7589 50.5863 41.349 49.2338 40.6746 49.9945C39.9159 50.9244 39.3257 52.0233 38.7356 53.1221C38.567 53.4603 37.9769 55.0663 38.4827 54.4746ZM35.4479 65.1253C35.5322 64.3646 35.8694 62.0823 35.5322 62.7585C35.5322 62.7585 35.5322 62.7585 35.5322 62.843C35.2793 64.5336 35.1107 66.3087 35.0264 67.9993V68.0839C35.5322 67.7457 35.4479 65.717 35.4479 65.1253ZM36.5438 75.1843C37.1339 75.5224 37.0496 72.733 37.0496 72.3949C36.9653 71.8032 36.881 69.0137 36.038 68.9291C35.3636 68.9291 35.6165 71.3805 35.6165 71.8032C35.7008 72.733 35.9537 74.7617 36.5438 75.1843ZM51.4652 40.1891C52.6454 39.5974 53.9099 39.0057 54.9216 38.1604C55.4274 37.7378 53.8256 38.3295 53.5727 38.414C52.4768 38.9212 51.3809 39.5129 50.4536 40.2737C49.6949 40.9499 51.128 40.3582 51.4652 40.1891ZM43.3722 46.4443C43.5408 46.1907 43.7937 46.0217 43.878 45.7681C42.6978 47.036 41.6862 48.3885 40.6746 49.8255C40.7589 49.741 40.8432 49.6564 40.9275 49.4874C41.7705 48.473 42.5292 47.4587 43.3722 46.4443ZM49.8635 40.6118C49.9478 40.5272 50.1164 40.4427 50.2007 40.3582C48.7675 41.288 47.4187 42.3024 46.1542 43.4858C46.4071 43.4012 46.66 43.1477 46.9129 42.9786C47.9245 42.2178 48.9361 41.3725 49.8635 40.6118ZM43.9623 46.6134C45.1426 45.7681 46.2385 44.6692 47.0815 43.4858C47.7559 42.6405 47.1658 42.8095 46.4914 43.2322C45.4798 43.993 44.4682 44.9228 43.7094 46.0217C43.2036 46.7824 43.2036 47.2896 43.9623 46.6134ZM37.3868 72.4794C37.4711 73.6628 37.8926 75.9451 39.2415 76.4523C40.7589 76.9594 40.7589 73.9164 40.7589 73.0711C40.6746 71.9722 40.2531 69.0137 38.6513 69.0137C37.2182 68.9292 37.3025 71.5496 37.3868 72.4794ZM51.2123 40.5272C49.9478 41.1189 48.5989 42.0488 47.7559 43.1477C46.9129 44.2465 48.0931 44.162 48.9361 43.8239C50.3693 43.2322 51.8867 42.2178 52.7297 40.8654C53.4041 39.7665 51.7181 40.2737 51.2123 40.5272ZM44.974 47.9658C44.3839 49.2338 44.974 50.2481 46.4071 49.741C48.0931 49.1493 49.7792 47.5432 50.3693 45.8526C50.8751 44.4156 49.7792 43.9084 48.5146 44.4156C47.0815 45.0918 45.6484 46.4443 44.974 47.9658ZM56.8605 62.674C56.9448 60.3071 55.1745 57.9403 52.6454 58.1939C50.2007 58.4475 48.5146 60.8143 48.346 63.0966C48.1774 65.3789 49.7792 67.7457 52.2239 67.7457C54.9216 67.6612 56.7762 65.1253 56.8605 62.674ZM42.6978 54.9818C42.3606 56.3343 42.7821 58.363 44.6368 58.0248C46.66 57.6022 48.0931 55.3199 48.4303 53.4603C48.6832 51.9387 47.9245 50.1636 46.1542 50.7553C44.3839 51.347 43.1193 53.2067 42.6978 54.9818ZM53.9099 48.8111C51.8024 49.1493 49.8635 51.0934 49.5263 53.2067C49.189 55.3199 50.7065 57.0105 52.814 56.8414C55.1745 56.5878 57.3663 54.4746 57.5349 52.1078C57.7878 49.9945 56.0175 48.473 53.9099 48.8111ZM102.046 68.8446C101.878 69.1827 101.793 71.1269 101.709 71.7186C101.625 72.4794 101.54 74.4236 101.625 74.0854C101.793 72.3103 102.046 70.5352 102.046 68.8446ZM38.6513 56.926C38.4827 57.5177 38.0612 59.969 39.4101 59.4618C40.9275 58.8701 41.6862 56.6724 42.0234 55.2354C42.192 54.4746 42.3606 52.1923 41.0118 52.9531C39.7473 53.7138 38.9885 55.489 38.6513 56.926ZM44.4682 59.2083C42.5292 59.5464 41.5176 61.9132 41.4333 63.6883C41.349 65.2944 41.9391 67.7457 43.9623 67.7457C46.1542 67.7457 47.2501 64.9563 47.3344 63.0966C47.4187 61.4906 46.5757 58.7856 44.4682 59.2083ZM43.6251 47.2051C42.4449 48.0504 41.5176 49.4028 40.9275 50.6708C40.6746 51.2625 40.1688 52.8685 41.349 52.1923C42.6978 51.347 43.7094 49.8255 44.3839 48.3885C44.7211 47.5432 44.7211 46.4443 43.6251 47.2051ZM38.567 67.9148C40.0845 67.9148 40.5903 64.9563 40.6746 63.8574C40.7589 63.0121 40.6746 59.969 39.1571 60.4762C37.8083 60.8988 37.3868 63.1811 37.3025 64.4491C37.3025 65.2944 37.2182 67.9148 38.567 67.9148ZM80.1278 98.7681C79.0318 99.1062 77.2615 99.4443 76.5028 100.374C76.1656 100.712 78.2731 100.374 78.6103 100.29C79.7062 99.9515 81.0551 99.6133 81.9824 98.7681C82.6568 98.2609 80.465 98.6835 80.1278 98.7681ZM87.6306 95.9786C87.5463 96.0631 87.462 96.1476 87.3777 96.2322C88.7265 95.3023 89.9911 94.288 91.1713 93.1891C91.0027 93.3582 90.7498 93.5272 90.5812 93.6963C89.5695 94.3725 88.6422 95.1333 87.6306 95.9786ZM94.0375 90.0615C93.8689 90.2306 93.7003 90.4842 93.5317 90.6532C93.7846 90.3151 94.1218 89.977 94.3747 89.7234H94.2904C94.2061 89.8925 94.1218 89.977 94.0375 90.0615ZM86.1132 96.4012C84.933 96.9929 83.6684 97.5846 82.6568 98.5145C82.0667 99.0216 83.6684 98.3454 83.9213 98.2609C84.0899 98.1764 84.1742 98.0918 84.3428 98.0073C84.8486 97.7537 85.2702 97.5001 85.776 97.2465C86.1975 96.9929 86.7033 96.6548 87.0405 96.3167C87.8835 95.6405 86.5347 96.2322 86.1132 96.4012ZM68.4941 101.135C68.4941 100.374 65.7122 100.205 65.1221 100.205C64.7849 100.205 61.9186 100.121 62.3401 100.712C62.9302 101.473 64.7849 101.558 65.6279 101.642C65.9651 101.558 68.4941 101.811 68.4941 101.135ZM57.6192 100.205C59.2209 100.712 60.8227 101.135 62.4244 101.473C61.4128 101.135 60.4012 100.881 59.3052 100.628C58.7994 100.459 58.2093 100.29 57.6192 100.205ZM65.6279 101.642C64.8692 101.558 62.5087 101.219 63.2674 101.558C64.9535 101.811 66.7238 101.98 68.4941 101.98H68.5784C68.2412 101.558 66.1337 101.642 65.6279 101.642ZM75.2383 101.304C76.84 100.966 78.4417 100.543 79.9592 99.9515C79.369 100.036 78.8632 100.205 78.2731 100.374C77.3458 100.712 76.2499 100.966 75.2383 101.304ZM61.3285 100.459C60.6541 99.5288 58.7151 99.1907 57.7035 98.9371C57.3663 98.8526 55.1745 98.5145 55.7646 99.0217C56.6919 99.7824 58.0407 100.205 59.1366 100.459C59.3895 100.543 61.6657 100.881 61.3285 100.459ZM46.9129 93.9499C46.66 93.7808 46.4914 93.6118 46.2385 93.4427C47.503 94.5416 48.8518 95.5559 50.2007 96.4858C50.1164 96.4012 50.0321 96.3167 49.9478 96.2322C48.9361 95.4714 47.9245 94.7106 46.9129 93.9499ZM47.0815 93.3582C46.2385 92.1748 45.1426 91.1604 43.9623 90.2306C43.1193 89.6389 43.2036 90.146 43.7094 90.8223C44.4682 91.8366 45.4798 92.7665 46.4914 93.6118C47.1658 94.0344 47.7559 94.2035 47.0815 93.3582ZM55.0059 98.7681C53.9942 97.9228 52.7297 97.3311 51.5495 96.7393C51.128 96.5703 49.6949 95.9786 50.5379 96.6548C51.4652 97.4156 52.5611 98.0073 53.657 98.5145C53.9099 98.599 55.5117 99.1907 55.0059 98.7681ZM86.4504 96.0631C87.7149 95.3869 88.9794 94.5416 89.8224 93.3582C90.5812 92.3438 89.5695 92.3438 88.8108 92.6819C87.462 93.3582 85.9446 94.3725 85.1016 95.6405C84.4271 96.8239 85.9446 96.3167 86.4504 96.0631ZM64.9535 99.8669C65.7965 99.9515 68.4098 99.9515 68.4098 98.599C68.4098 97.0775 65.4593 96.6548 64.3633 96.5703C63.5203 96.4858 60.4855 96.5703 60.9913 98.0918C61.4971 99.4443 63.7732 99.7824 64.9535 99.8669ZM64.3633 95.9786C65.8808 96.0631 68.4098 95.4714 68.4098 93.5272C68.4098 91.3295 65.6279 90.3151 63.8575 90.2306C62.2558 90.1461 59.5581 90.9068 59.8954 93.0201C60.2326 94.8797 62.593 95.8095 64.3633 95.9786ZM57.4506 98.599C58.0407 98.7681 60.4855 99.1907 60.064 97.9228C59.5582 96.4858 57.282 95.6405 55.8489 95.3023C55.1745 95.1333 52.7297 94.9642 53.5727 96.3167C54.3314 97.5846 56.1018 98.2609 57.4506 98.599ZM51.128 96.3167C51.6338 96.5703 53.3198 97.0775 52.6454 95.9786C51.8024 94.6261 50.2007 93.6118 48.8518 93.0201C48.0931 92.6819 46.9129 92.5974 47.6716 93.6963C48.5989 94.8797 49.8635 95.725 51.128 96.3167ZM72.2034 101.473C73.1307 101.388 74.9011 101.304 75.5755 100.543C75.997 100.036 73.215 100.036 72.8778 100.121C72.2034 100.205 69.5057 100.374 69.4214 101.135C69.3371 101.727 71.8662 101.558 72.2034 101.473ZM80.3807 98.4299C81.7295 98.0918 83.4998 97.3311 84.2585 96.0631C85.1016 94.7106 82.8254 94.9642 82.0667 95.1333C80.6336 95.4714 78.526 96.3167 77.9359 97.7537C77.4301 99.0217 79.7906 98.599 80.3807 98.4299ZM78.1888 92.851C78.6103 90.7378 75.9127 89.977 74.3109 90.0615C72.4563 90.146 69.7587 91.2449 69.6744 93.4427C69.59 95.3869 72.1191 95.9786 73.6365 95.8095C75.4912 95.725 77.8516 94.7106 78.1888 92.851ZM76.9243 97.9228C77.4301 96.4858 74.4795 96.4012 73.6365 96.4858C72.5406 96.5703 69.6743 97.0775 69.59 98.599C69.5057 99.9515 72.1191 99.8669 72.9621 99.7824C74.1423 99.6979 76.4185 99.2752 76.9243 97.9228ZM72.2034 101.558C71.529 101.642 69.7587 101.473 69.3371 101.98C71.1075 101.896 72.7935 101.727 74.5638 101.473C75.154 101.135 72.9621 101.473 72.2034 101.558ZM100.697 77.4666C100.697 77.5512 100.613 77.7202 100.613 77.8047C100.444 78.3965 100.276 78.9036 100.192 79.4108C100.444 78.7346 100.613 78.0583 100.782 77.4666C101.035 76.5368 101.287 75.6915 101.456 74.7617C101.119 75.6915 100.95 76.6213 100.697 77.4666ZM94.2904 89.7234H94.3747C95.1334 88.7936 95.8079 87.8638 96.4823 86.8494C96.398 86.9339 96.3137 87.0185 96.3137 87.103C95.6393 87.9483 94.9649 88.8781 94.2904 89.7234ZM98.7584 82.1158C97.9154 83.1301 97.3253 84.398 96.7352 85.5815C96.5666 86.0041 95.9765 87.3566 96.5666 86.5958C96.8195 86.2577 97.0724 85.835 97.3253 85.4969C97.6625 84.9052 97.9997 84.398 98.2526 83.8063C98.3369 83.7218 98.3369 83.6373 98.4212 83.5527C98.5898 83.1301 99.1799 81.6086 98.7584 82.1158ZM63.7732 89.0472C66.0494 89.1317 68.4098 87.6102 68.4098 85.1588C68.4098 82.5384 65.7965 80.6787 63.436 80.5942C61.0756 80.5097 58.7151 82.2003 58.8837 84.7362C59.0523 87.272 61.4971 88.9626 63.7732 89.0472ZM93.8689 89.3008C94.9649 88.4555 95.8922 87.103 96.4823 85.9196C96.7352 85.4124 97.241 83.7218 96.2294 84.4826C94.9649 85.3279 93.9532 86.8494 93.3631 88.2864C92.9416 88.9626 92.773 90.1461 93.8689 89.3008ZM48.4303 83.3837C48.0931 81.524 46.5757 79.1572 44.6368 78.8191C42.7821 78.481 42.3606 80.5097 42.6978 81.8622C43.1193 83.6373 44.3839 85.5815 46.1542 86.1732C47.9245 86.7649 48.6832 84.9052 48.4303 83.3837ZM53.9099 88.0328C56.0175 88.3709 57.7878 86.9339 57.5349 84.7362C57.282 82.3693 55.1745 80.2561 52.814 80.0025C50.7065 79.7489 49.1047 81.524 49.5263 83.6373C49.7792 85.7505 51.7181 87.6947 53.9099 88.0328ZM94.9649 81.6931C95.3021 80.4252 94.9648 78.3119 93.1945 78.7346C91.2556 79.1572 89.8225 81.4395 89.4852 83.2992C89.2323 84.7362 89.8225 86.5958 91.5928 86.0041C93.3631 85.3279 94.5433 83.3837 94.9649 81.6931ZM74.9011 80.6787C72.4563 80.7633 69.9273 82.7075 69.843 85.2433C69.843 87.6947 72.2034 89.2162 74.3952 89.0472C76.6714 88.8781 79.0318 87.1875 79.2847 84.7362C79.5376 82.2848 77.1772 80.5097 74.9011 80.6787ZM40.506 85.835C39.9159 84.6516 39.3258 83.3837 38.3984 82.3693C37.8926 81.7776 38.567 83.3837 38.6513 83.7218C39.1571 84.8207 39.7473 85.9196 40.5903 86.8494C41.349 87.6947 40.7589 86.2577 40.506 85.835ZM40.6746 87.103C41.2647 88.0328 41.9391 88.8781 42.6135 89.7234L43.7094 90.9913C43.1193 90.1461 41.5176 88.1173 40.9275 87.3566C40.8432 87.272 40.7589 87.1875 40.6746 87.103ZM36.4595 77.4666C36.2066 76.5368 36.038 75.6915 35.7008 74.8462C35.8694 75.776 36.1223 76.6213 36.3752 77.4666C36.5438 78.2274 36.7967 78.9882 37.0496 79.7489C36.9653 79.1572 36.7967 78.5655 36.6281 77.9738C36.5438 77.8047 36.4595 77.6357 36.4595 77.4666ZM84.0899 87.8638C86.1975 87.4411 88.0521 85.5815 88.4736 83.4682C88.8108 81.4395 87.3777 79.6644 85.2702 79.918C82.9097 80.1716 80.8865 82.3693 80.5493 84.6516C80.3807 86.7649 82.0667 88.2019 84.0899 87.8638Z" fill=#228848></path>
                                        <path d="M40.0847 113.392C39.9161 113.223 39.7475 113.054 39.5789 112.969C39.4103 112.885 39.1574 112.8 38.9045 112.8C38.7359 112.8 38.6516 112.8 38.483 112.885C38.3144 112.969 38.2301 112.969 38.1458 113.054C38.0615 113.138 37.9772 113.223 37.8929 113.307C37.8086 113.392 37.8086 113.561 37.8086 113.73C37.8086 113.984 37.8929 114.153 38.0615 114.237C38.2301 114.322 38.3987 114.491 38.6516 114.575C38.9045 114.66 39.1574 114.744 39.4103 114.829C39.6632 114.913 40.0004 114.998 40.169 115.167C40.3376 115.336 40.5905 115.505 40.7592 115.759C40.9278 116.012 41.0121 116.35 41.0121 116.773C41.0121 117.111 40.9278 117.449 40.8435 117.703C40.6748 117.956 40.5062 118.21 40.2533 118.379C40.0004 118.548 39.7475 118.717 39.4103 118.802C39.0731 118.886 38.8202 118.971 38.3987 118.971C37.9772 118.971 37.5557 118.886 37.1342 118.802C36.7127 118.717 36.3755 118.379 36.1226 118.041L37.0499 117.111C37.2185 117.365 37.3871 117.534 37.64 117.618C37.8929 117.703 38.1458 117.787 38.3987 117.787C38.5673 117.787 38.6516 117.787 38.8202 117.703C38.9888 117.618 39.0731 117.618 39.2417 117.534C39.326 117.449 39.4103 117.365 39.4946 117.196C39.5789 117.111 39.5789 116.942 39.5789 116.773C39.5789 116.519 39.4946 116.35 39.326 116.181C39.1574 116.012 38.9888 115.928 38.7359 115.843C38.483 115.759 38.2301 115.674 37.9772 115.59C37.7243 115.505 37.3871 115.421 37.2185 115.252C36.9656 115.082 36.797 114.913 36.6284 114.66C36.4598 114.406 36.3755 114.068 36.3755 113.645C36.3755 113.307 36.4598 112.969 36.6284 112.716C36.797 112.462 36.9656 112.208 37.2185 112.039C37.4714 111.87 37.7243 111.701 38.0615 111.617C38.3987 111.532 38.6516 111.532 38.9888 111.532C39.326 111.532 39.6632 111.617 40.0847 111.701C40.4219 111.786 40.7591 112.039 41.0121 112.208L40.0847 113.392Z" fill=#228848></path>
                                        <path d="M48.0935 116.266C48.0935 116.688 48.0092 117.026 47.9249 117.365C47.8406 117.703 47.5877 117.956 47.3348 118.21C47.0819 118.463 46.829 118.632 46.4918 118.717C46.1546 118.802 45.8174 118.886 45.3959 118.886C44.9744 118.886 44.6372 118.802 44.3 118.717C43.9628 118.632 43.6256 118.379 43.457 118.21C43.2884 118.041 43.0354 117.703 42.8668 117.365C42.6982 117.026 42.6982 116.688 42.6982 116.266V111.87H43.9628V116.181C43.9628 116.35 43.9628 116.519 44.0471 116.688C44.1314 116.857 44.2157 117.026 44.3 117.195C44.3843 117.365 44.5529 117.449 44.8058 117.618C44.9744 117.703 45.2273 117.787 45.5645 117.787C45.9017 117.787 46.0703 117.703 46.3232 117.618C46.4918 117.534 46.6604 117.365 46.829 117.195C46.9133 117.026 46.9976 116.857 47.0819 116.688C47.1662 116.519 47.1662 116.35 47.1662 116.181V111.87H48.4308C48.0935 111.87 48.0935 116.266 48.0935 116.266Z" fill=#228848></path>
                                        <path d="M53.2356 113.392C53.067 113.223 52.8984 113.054 52.7298 112.969C52.5612 112.885 52.3083 112.8 52.0554 112.8C51.8868 112.8 51.8025 112.8 51.6339 112.885C51.4653 112.885 51.381 112.969 51.2967 113.054C51.2124 113.138 51.1281 113.223 51.0438 113.307C50.9595 113.392 50.9595 113.561 50.9595 113.73C50.9595 113.984 51.0438 114.153 51.2124 114.237C51.381 114.322 51.5496 114.491 51.8025 114.575C52.0554 114.66 52.3083 114.744 52.5612 114.829C52.8141 114.913 53.1513 114.998 53.3199 115.167C53.4885 115.336 53.7414 115.505 53.91 115.759C54.0786 116.012 54.1629 116.35 54.1629 116.773C54.1629 117.111 54.0786 117.449 53.9943 117.703C53.8257 117.956 53.6571 118.21 53.4042 118.379C53.1513 118.548 52.8984 118.717 52.5612 118.802C52.224 118.886 51.9711 118.971 51.5496 118.971C51.1281 118.971 50.7066 118.886 50.2851 118.802C49.8636 118.717 49.5263 118.379 49.2734 118.041L50.2008 117.111C50.3694 117.365 50.538 117.534 50.7909 117.618C51.0438 117.703 51.2967 117.787 51.5496 117.787C51.7182 117.787 51.8025 117.787 51.9711 117.703C52.1397 117.618 52.224 117.618 52.3926 117.534C52.4769 117.449 52.5612 117.365 52.6455 117.196C52.7298 117.111 52.7298 116.942 52.7298 116.773C52.7298 116.519 52.6455 116.35 52.4769 116.181C52.3083 116.012 52.1397 115.928 51.8868 115.843C51.6339 115.759 51.381 115.674 51.1281 115.59C50.8752 115.505 50.538 115.421 50.3694 115.252C50.2008 115.082 49.9478 114.913 49.7792 114.66C49.6106 114.406 49.5263 114.068 49.5263 113.645C49.5263 113.307 49.6106 112.969 49.7792 112.716C49.9478 112.462 50.1165 112.208 50.3694 112.039C50.6223 111.87 50.8752 111.701 51.2124 111.617C51.5496 111.532 51.8025 111.532 52.1397 111.532C52.4769 111.532 52.8141 111.617 53.2356 111.701C53.5728 111.786 53.91 112.039 54.1629 112.208L53.2356 113.392Z" fill=#228848></path>
                                        <path d="M56.9449 112.969H54.8374V111.87H60.317V112.969H58.2095V118.802H56.9449V112.969Z" fill=#228848></path>
                                        <path d="M62.6774 111.87H63.7734L66.7239 118.802H65.2908L64.6164 117.195H61.5815L60.9914 118.802H59.6426C59.7269 118.802 62.6774 111.87 62.6774 111.87ZM64.2792 116.181L63.1832 113.392L62.0873 116.181H64.2792Z" fill=#228848></path>
                                        <path d="M67.7358 111.87H69.0004V118.802H67.7358V111.87Z" fill=#228848></path>
                                        <path d="M70.686 111.87H72.2878L75.6598 117.026V111.87H76.9244V118.802H75.4069L71.9506 113.476V118.802H70.686V111.87Z" fill=#228848></path>
                                        <path d="M80.8024 111.87H81.8984L84.8489 118.802H83.4158L82.7414 117.195H79.7065L79.1164 118.802H77.7676L80.8024 111.87ZM82.3199 116.181L81.2239 113.392L80.128 116.181H82.3199Z" fill=#228848></path>
                                        <path d="M85.6074 111.87H88.3051C88.558 111.87 88.8109 111.87 89.0638 111.955C89.3167 112.039 89.5696 112.124 89.7382 112.293C89.9068 112.462 90.0754 112.631 90.244 112.8C90.4126 113.054 90.4126 113.307 90.4126 113.561C90.4126 113.983 90.3283 114.321 90.0754 114.491C89.8225 114.744 89.5696 114.913 89.2324 114.998C89.4853 114.998 89.6539 115.082 89.8225 115.167C89.9911 115.251 90.1597 115.336 90.3283 115.505C90.4969 115.674 90.5812 115.843 90.6655 116.012C90.7498 116.181 90.7498 116.435 90.7498 116.604C90.7498 116.942 90.6655 117.28 90.4969 117.534C90.3283 117.787 90.1597 117.956 89.9068 118.125C89.6539 118.294 89.401 118.379 89.0638 118.463C88.7266 118.548 88.3894 118.548 88.1365 118.548H85.6917V111.87H85.6074ZM86.8719 114.66H87.9679C88.3894 114.66 88.6423 114.575 88.8952 114.406C89.1481 114.237 89.2324 114.068 89.2324 113.73C89.2324 113.392 89.1481 113.223 88.8952 113.054C88.6423 112.884 88.3051 112.8 87.8836 112.8H86.8719V114.66ZM86.8719 117.703H87.9679C88.1365 117.703 88.3051 117.703 88.4737 117.703C88.6423 117.703 88.8109 117.618 88.9795 117.534C89.1481 117.449 89.2324 117.365 89.3167 117.195C89.401 117.026 89.4853 116.857 89.4853 116.688C89.4853 116.35 89.401 116.097 89.1481 115.928C88.8952 115.758 88.558 115.758 88.0522 115.758H86.8719V117.703Z" fill=#228848></path>
                                        <path d="M92.1831 111.87H93.4476V117.703H96.3982V118.802H92.1831V111.87Z" fill=#228848></path>
                                        <path d="M97.4941 111.87H102.046V112.969H98.6744V114.66H101.878V115.758H98.6744V117.618H102.215V118.717H97.4941V111.87Z" fill=#228848></path>
                                        <path d="M36.7129 121.676H39.4105C39.6635 121.676 39.9164 121.676 40.1693 121.76C40.4222 121.845 40.6751 121.929 40.8437 122.098C41.0123 122.267 41.1809 122.437 41.3495 122.606C41.5181 122.859 41.5181 123.113 41.5181 123.366C41.5181 123.789 41.4338 124.127 41.1809 124.296C40.928 124.55 40.6751 124.719 40.3379 124.803C40.5908 124.803 40.7594 124.888 40.928 124.972C41.0966 125.057 41.2652 125.141 41.4338 125.311C41.6024 125.48 41.6867 125.649 41.771 125.818C41.8553 125.987 41.8553 126.24 41.8553 126.409C41.8553 126.748 41.771 127.086 41.6024 127.339C41.4338 127.593 41.2652 127.762 41.0123 127.931C40.7594 128.1 40.5065 128.185 40.1693 128.269C39.8321 128.354 39.4948 128.354 39.2419 128.354H36.7129V121.676ZM37.9774 124.465H39.0733C39.4948 124.465 39.7478 124.381 40.0007 124.212C40.2536 124.043 40.3379 123.874 40.3379 123.535C40.3379 123.197 40.2536 123.028 40.0007 122.859C39.7478 122.69 39.4105 122.606 38.989 122.606H37.9774V124.465ZM37.9774 127.508H39.0733C39.2419 127.508 39.4105 127.508 39.5791 127.508C39.7478 127.508 39.9164 127.424 40.085 127.339C40.2536 127.255 40.3379 127.17 40.4222 127.001C40.5065 126.832 40.5908 126.663 40.5908 126.494C40.5908 126.156 40.5065 125.902 40.2536 125.733C40.0007 125.564 39.6634 125.564 39.1576 125.564H37.9774V127.508Z" fill=#228848></path>
                                        <path d="M42.8665 121.676H45.227C45.5642 121.676 45.9014 121.676 46.1543 121.76C46.4072 121.845 46.7444 121.929 46.9973 122.098C47.2502 122.267 47.4188 122.437 47.5874 122.69C47.756 122.944 47.8403 123.282 47.8403 123.62C47.8403 124.127 47.6717 124.55 47.4188 124.888C47.1659 125.226 46.7444 125.395 46.2386 125.48L48.0932 128.523H46.5758L44.9741 125.564H44.0468V128.523H42.7822V121.676H42.8665ZM45.0584 124.634C45.227 124.634 45.3956 124.634 45.5642 124.634C45.7328 124.634 45.9014 124.55 46.07 124.55C46.2386 124.55 46.3229 124.381 46.4072 124.296C46.4915 124.212 46.5758 123.958 46.5758 123.789C46.5758 123.62 46.4915 123.451 46.4072 123.282C46.3229 123.197 46.2386 123.028 46.07 123.028C45.9014 122.944 45.8171 122.944 45.6485 122.944C45.4799 122.944 45.3113 122.944 45.1427 122.944H44.0468V124.803H45.0584V124.634Z" fill=#228848></path>
                                        <path d="M51.2126 121.676H52.3085L55.2591 128.607H53.8259L53.1515 127.001H50.1167L49.5266 128.607H48.1777C48.262 128.607 51.2126 121.676 51.2126 121.676ZM52.8143 125.902L51.7184 123.113L50.6225 125.902H52.8143Z" fill=#228848></path>
                                        <path d="M56.0176 121.676H57.6193L60.9914 126.832V121.676H62.2559V128.607H60.7385L57.2821 123.282V128.607H56.0176V121.676Z" fill=#228848></path>
                                        <path d="M63.7733 121.676H66.4709C66.8924 121.676 67.3982 121.76 67.8197 121.845C68.2413 121.929 68.5785 122.183 68.9157 122.521C69.2529 122.775 69.5058 123.197 69.6744 123.62C69.843 124.043 69.9273 124.55 69.9273 125.141C69.9273 125.733 69.843 126.24 69.5901 126.663C69.3372 127.086 69.0843 127.424 68.7471 127.762C68.4099 128.015 67.9884 128.269 67.5668 128.438C67.1453 128.607 66.7238 128.607 66.3023 128.607H63.689V121.676H63.7733ZM65.9651 127.508C66.3866 127.508 66.7238 127.424 67.061 127.339C67.3982 127.255 67.7355 127.086 67.9884 126.917C68.2413 126.748 68.4099 126.494 68.5785 126.156C68.7471 125.818 68.8314 125.48 68.8314 125.057C68.8314 124.634 68.7471 124.296 68.6628 123.958C68.5785 123.62 68.3256 123.451 68.157 123.197C67.9884 122.944 67.6511 122.859 67.3139 122.775C66.9767 122.69 66.6395 122.606 66.3023 122.606H65.2064V127.339L65.9651 127.508Z" fill=#228848></path>
                                        <path d="M73.1309 121.676H74.3954V128.607H73.1309V121.676Z" fill=#228848></path>
                                        <path d="M76.0815 121.676H77.6833L81.0553 126.832V121.676H82.3199V128.607H80.8024L77.3461 123.282V128.607H76.0815V121.676Z" fill=#228848></path>
                                        <path d="M83.8372 121.676H86.5349C86.9564 121.676 87.4622 121.76 87.8837 121.845C88.3052 121.929 88.6424 122.183 88.9796 122.521C89.3168 122.775 89.5697 123.197 89.7383 123.62C89.907 124.043 89.9913 124.55 89.9913 125.141C89.9913 125.733 89.907 126.24 89.654 126.663C89.4011 127.086 89.1482 127.424 88.811 127.762C88.4738 128.015 88.0523 128.269 87.6308 128.438C87.2093 128.607 86.7878 128.607 86.3663 128.607H83.7529V121.676H83.8372ZM85.9448 127.508C86.3663 127.508 86.7035 127.424 87.0407 127.339C87.3779 127.255 87.7151 127.086 87.968 126.917C88.2209 126.748 88.3895 126.494 88.5581 126.156C88.7267 125.818 88.811 125.48 88.811 125.057C88.811 124.634 88.7267 124.296 88.6424 123.958C88.5581 123.62 88.3052 123.451 88.1366 123.197C87.968 122.944 87.6308 122.859 87.2936 122.775C86.9564 122.69 86.6192 122.606 86.282 122.606H85.1861V127.339L85.9448 127.508Z" fill=#228848></path>
                                        <path d="M91.0874 121.676H95.6397V122.775H92.2676V124.465H95.4711V125.564H92.2676V127.424H95.8083V128.523H91.0874V121.676Z" fill=#228848></path>
                                        <path d="M98.6744 124.972L96.3982 121.676H97.9157L99.5174 124.212L101.119 121.676H102.637L100.36 124.972L102.889 128.607H101.288L99.4331 125.649L97.5785 128.607H96.061L98.6744 124.972Z" fill=#228848></path>
                                        <path d="M17.4919 81.2705L16.8175 77.2131C16.7332 76.7904 16.7332 76.4523 16.7332 76.0296C16.7332 75.607 16.8175 75.2689 16.9861 74.9308C17.1547 74.5926 17.4076 74.3391 17.6605 74.0855C17.9977 73.8319 18.3349 73.6628 18.8407 73.5783C19.4308 73.4938 19.9366 73.5783 20.3581 73.8319C20.7796 74.0855 21.1168 74.5081 21.3697 75.0153C21.3697 74.6772 21.3697 74.3391 21.454 74.0855C21.5383 73.8319 21.707 73.4938 21.8756 73.3247C22.0442 73.1556 22.2971 72.9021 22.55 72.733C22.8029 72.5639 23.1401 72.4794 23.4773 72.3949C24.0674 72.3104 24.4889 72.3103 24.9104 72.4794C25.3319 72.6485 25.6691 72.9021 25.922 73.2402C26.1749 73.5783 26.4278 73.9164 26.5964 74.4236C26.7651 74.8462 26.9337 75.3534 27.018 75.8606L27.6924 79.5799C27.7767 79.5799 17.4919 81.355 17.4919 81.2705ZM21.3697 78.7346L21.1168 77.044C21.0325 76.4523 20.7796 76.0296 20.5267 75.6915C20.2738 75.4379 19.8523 75.3534 19.5151 75.4379C19.0936 75.5225 18.7564 75.6915 18.5878 76.1142C18.4192 76.4523 18.4192 77.044 18.5035 77.7202L18.7564 79.2418L21.3697 78.7346ZM25.922 77.9738L25.6691 76.2832C25.6691 76.0296 25.5848 75.7761 25.5005 75.5225C25.4162 75.2689 25.3319 75.0153 25.1633 74.8462C24.9947 74.6772 24.8261 74.5081 24.5732 74.3391C24.3203 74.17 24.0674 74.17 23.7302 74.2545C23.1401 74.3391 22.8029 74.5926 22.7186 75.0153C22.55 75.4379 22.55 75.9451 22.7186 76.7059L23.0558 78.481L25.922 77.9738Z" fill=#228848></path>
                                        <path d="M15.9744 70.028L16.143 66.3932C16.143 65.8861 16.2273 65.3789 16.3116 64.9562C16.3959 64.5336 16.6488 64.1109 16.8174 63.6883C16.986 63.2656 17.4075 63.0121 17.7447 62.843C18.0819 62.6739 18.5877 62.5894 19.2621 62.5894C20.0208 62.5894 20.6953 62.843 21.1168 63.2656C21.5383 63.6883 21.8755 64.28 21.9598 65.1253L26.765 62.5049L26.6807 64.7872L22.1284 67.0695L22.0441 68.4219L26.5121 68.591L26.4278 70.5352L15.9744 70.028ZM20.611 66.9004C20.611 66.6468 20.611 66.3932 20.611 66.1397C20.611 65.8861 20.5267 65.6325 20.4424 65.3789C20.3581 65.1253 20.1894 64.9562 20.0208 64.7872C19.8522 64.6181 19.5993 64.5336 19.1778 64.5336C18.8406 64.5336 18.5877 64.6181 18.4191 64.7026C18.2505 64.7872 18.0819 64.9562 17.9976 65.2098C17.9133 65.3789 17.829 65.6325 17.829 65.8861C17.829 66.1396 17.7447 66.3932 17.7447 66.6468L17.6604 68.2529L20.5267 68.4219L20.611 66.9004Z" fill=#228848></path>
                                        <path d="M17.7446 55.6579L18.1661 54.1363L29.4626 52.5303L28.9568 54.559L26.3434 54.8971L25.1632 59.2926L27.2707 60.8142L26.6806 62.8429L17.7446 55.6579ZM24.6574 55.0662L20.1051 55.4888L23.8144 58.1937L24.6574 55.0662Z" fill=#228848></path>
                                        <path d="M20.6953 46.7824L21.9598 44.6691L31.233 44.0774L24.4889 40.1891L25.4162 38.583L34.5208 43.8238L33.3406 45.8525L23.8145 46.3597L30.8115 50.3326L29.7999 51.9387L20.6953 46.7824Z" fill=#228848></path>
                                        <path d="M34.8581 31.567C34.2679 31.567 33.8464 31.6515 33.5092 31.8206C33.172 31.9897 32.8348 32.2432 32.5819 32.4968C32.1604 32.9195 31.9075 33.3421 31.7389 33.7648C31.5703 34.1874 31.486 34.6946 31.5703 35.1173C31.6546 35.5399 31.7389 36.0471 31.9075 36.4697C32.0761 36.8924 32.4133 37.315 32.7505 37.6531C33.172 38.0758 33.5935 38.3294 34.015 38.583C34.4365 38.8365 34.9424 38.9211 35.4482 38.9211C35.954 38.9211 36.3755 38.8365 36.797 38.6675C37.2185 38.4984 37.64 38.2448 38.0615 37.8222C38.3144 37.4841 38.5673 37.146 38.7359 36.7233C38.9045 36.3007 38.9045 35.7935 38.8202 35.2018L40.6749 34.8637C40.8435 35.6244 40.7592 36.3852 40.5063 37.146C40.2534 37.8222 39.8318 38.4984 39.326 39.0056C38.7359 39.5973 38.1458 40.02 37.4714 40.3581C36.797 40.6962 36.1226 40.8653 35.4482 40.8653C34.7738 40.8653 34.0993 40.7807 33.4249 40.5271C32.7505 40.2735 32.0761 39.8509 31.486 39.2592C30.8959 38.6675 30.3901 38.0758 30.1372 37.3995C29.8 36.7233 29.7156 36.0471 29.6313 35.3708C29.6313 34.6946 29.8 34.0184 30.0529 33.3421C30.3058 32.6659 30.7273 32.0742 31.3174 31.4825C31.8232 30.9753 32.329 30.5527 33.0034 30.2991C33.5935 30.0455 34.2679 29.8764 35.111 29.961L34.8581 31.567Z" fill=#228848></path>
                                        <path d="M36.7124 26.6643L38.3141 25.6499L40.5903 29.2001L44.7211 26.5797L42.4449 23.0295L44.0466 22.0151L49.6949 30.8907L48.0931 31.9051L45.5641 28.0167L41.4333 30.6371L43.9623 34.5255L42.3606 35.5399L36.7124 26.6643Z" fill=#228848></path>
                                        <path d="M47.7559 20.3248L54.3314 17.958L54.9215 19.5641L50.1163 21.2547L50.9593 23.706L55.5116 22.0154L56.1017 23.6215L51.5494 25.2275L52.5611 27.9325L57.6192 26.0728L58.2093 27.6789L51.3808 30.1303L47.7559 20.3248Z" fill=#228848></path>
                                        <path d="M56.8608 17.1971L58.9684 16.9436L62.8463 24.4667L64.7009 16.1828L66.7241 15.9292L63.9422 26.918L62.3404 27.0871L56.8608 17.1971Z" fill=#228848></path>
                                        <path d="M69.0844 16.0137H70.9391L70.6862 26.5799H68.8315L69.0844 16.0137Z" fill=#228848></path>
                                        <path d="M74.6486 16.1826L77.0933 16.6898L80.5497 25.3963L82.1514 17.7041L84.006 18.0423L81.8985 28.3549L79.5381 27.8477L76.0817 18.8876L74.48 26.8333L72.541 26.4952L74.6486 16.1826Z" fill=#228848></path>
                                        <path d="M88.1364 19.564L91.8457 21.4236C92.4358 21.7617 93.0259 22.0999 93.5317 22.607C94.0375 23.1142 94.3747 23.6214 94.6277 24.2131C94.8806 24.8048 94.9649 25.481 94.9649 26.2418C94.9649 27.0026 94.712 27.7633 94.2904 28.5241C93.8689 29.3694 93.3631 29.9611 92.773 30.3837C92.1829 30.8064 91.5085 31.1445 90.8341 31.229C90.1597 31.3981 89.4852 31.3981 88.8108 31.3136C88.1364 31.229 87.462 31.06 86.9562 30.7219L83.4155 28.9467L88.1364 19.564ZM87.1248 28.8622C87.6306 29.1158 88.1364 29.2849 88.7265 29.4539C89.3166 29.623 89.7382 29.623 90.244 29.4539C90.7498 29.3694 91.1713 29.2003 91.5085 28.8622C91.93 28.5241 92.2672 28.1014 92.5201 27.5097C92.773 26.918 92.9416 26.4109 92.9416 25.9037C92.9416 25.3965 92.8573 24.9739 92.6887 24.5512C92.5201 24.1286 92.1829 23.7904 91.8457 23.4523C91.5085 23.1142 91.0027 22.8606 90.4969 22.607L88.9794 21.8463L85.8603 28.2705L87.1248 28.8622Z" fill=#228848></path>
                                        <path d="M99.5173 25.8193L104.913 30.2149L103.817 31.4828L99.8545 28.2707L98.2527 30.2994L101.962 33.3425L100.866 34.6104L97.1568 31.5673L95.3865 33.7651L99.5173 37.1463L98.4213 38.4142L92.8574 33.8496L99.5173 25.8193Z" fill=#228848></path>
                                        <path d="M107.61 32.9194L109.886 35.7934C110.223 36.2161 110.476 36.6387 110.729 37.0614C110.982 37.484 111.066 37.9067 111.151 38.3293C111.235 38.752 111.151 39.1746 110.982 39.5973C110.814 40.0199 110.476 40.4426 110.055 40.7807C109.465 41.2879 108.875 41.4569 108.2 41.4569C107.526 41.4569 106.936 41.2033 106.346 40.6116L104.491 45.6834L103.058 43.9083L104.997 39.2591L104.154 38.1603L100.697 40.9497L99.5171 39.5127L107.61 32.9194ZM106.177 38.3293C106.346 38.4984 106.514 38.752 106.683 38.921C106.851 39.0901 107.104 39.2591 107.273 39.3437C107.441 39.4282 107.694 39.5127 107.947 39.5127C108.2 39.5127 108.453 39.3437 108.706 39.1746C108.959 39.0056 109.127 38.752 109.127 38.5829C109.212 38.3293 109.212 38.1603 109.127 37.9067C109.043 37.6531 108.959 37.484 108.875 37.2304C108.79 36.9768 108.622 36.8078 108.453 36.6387L107.441 35.3708L105.25 37.1459L106.177 38.3293Z" fill=#228848></path>
                                        <path d="M108.369 49.2339L113.512 51.6007C113.68 51.6852 113.849 51.7698 114.017 51.7698C114.186 51.8543 114.355 51.9388 114.523 51.9388C114.692 52.0234 114.86 52.0234 115.029 52.0234C115.198 52.0234 115.366 52.0234 115.535 51.9388C115.703 51.8543 115.872 51.7698 116.041 51.6007C116.125 51.4317 116.294 51.3471 116.294 51.0935C116.294 50.84 116.378 50.7554 116.378 50.5018C116.378 50.3328 116.294 50.0792 116.294 49.9101C116.125 49.4875 115.872 49.2339 115.535 49.0648C115.198 48.8958 114.776 48.8958 114.355 48.9803L113.764 47.2052C114.27 47.0361 114.692 47.0361 115.113 47.0361C115.535 47.1207 115.872 47.2052 116.294 47.3742C116.631 47.5433 116.968 47.7969 117.221 48.135C117.474 48.4731 117.727 48.8112 117.895 49.3184C118.064 49.7411 118.148 50.1637 118.232 50.5864C118.232 51.009 118.232 51.4317 118.148 51.7698C118.064 52.1079 117.811 52.446 117.558 52.7841C117.305 53.1223 116.884 53.3758 116.462 53.5449C115.872 53.7985 115.282 53.883 114.692 53.714C114.102 53.6294 113.596 53.4604 113.006 53.1223L109.044 51.1781L110.814 55.7427L109.296 56.3344L106.683 49.8256L108.369 49.2339Z" fill=#228848></path>
                                        <path d="M114.776 56.5035C115.619 56.3345 116.294 56.3345 116.884 56.3345C117.474 56.3345 117.98 56.419 118.401 56.5881C118.823 56.7571 119.16 56.9262 119.497 57.1798C119.75 57.4334 120.003 57.6869 120.171 57.856C120.34 58.1096 120.509 58.3632 120.593 58.6168C120.677 58.8704 120.761 59.1239 120.761 59.293C120.761 59.4621 120.846 59.7156 120.846 59.9692C120.846 60.2228 120.846 60.5609 120.761 60.8145C120.677 61.1526 120.593 61.4062 120.34 61.7444C120.171 62.0825 119.834 62.3361 119.497 62.6742C119.16 63.0123 118.654 63.2659 118.148 63.4349C117.558 63.6885 116.884 63.8576 116.125 64.0267C115.366 64.1957 114.607 64.1957 114.017 64.1957C113.427 64.1957 112.921 64.1112 112.5 63.9421C112.078 63.7731 111.741 63.604 111.404 63.3504C111.151 63.0968 110.898 62.8432 110.73 62.6742C110.561 62.4206 110.392 62.167 110.308 61.9134C110.224 61.6598 110.139 61.4062 110.139 61.2372C110.139 61.0681 110.055 60.8145 110.055 60.5609C110.055 60.3074 110.055 59.9692 110.139 59.7157C110.224 59.4621 110.308 59.1239 110.561 58.7858C110.73 58.4477 111.067 58.1941 111.404 57.856C111.741 57.5179 112.247 57.2643 112.753 57.0952C113.259 56.9262 113.933 56.6726 114.776 56.5035ZM115.029 58.2786C114.692 58.3632 114.355 58.4477 113.933 58.5322C113.512 58.6168 113.174 58.7858 112.753 59.0394C112.416 59.2085 112.078 59.5466 111.91 59.8002C111.741 60.1383 111.657 60.4764 111.741 60.8991C111.826 61.3217 111.994 61.6598 112.331 61.9134C112.669 62.167 113.006 62.2515 113.427 62.3361C113.849 62.4206 114.27 62.4206 114.692 62.4206C115.113 62.4206 115.535 62.3361 115.788 62.2515C116.125 62.167 116.462 62.0825 116.884 61.9979C117.305 61.9134 117.642 61.7444 118.064 61.4908C118.401 61.3217 118.738 60.9836 118.907 60.73C119.075 60.3919 119.16 60.0538 119.075 59.6311C118.991 59.2085 118.823 58.8704 118.485 58.6168C118.148 58.4477 117.811 58.2786 117.389 58.1941C116.968 58.1096 116.546 58.1096 116.125 58.1096C115.703 58.1096 115.366 58.1941 115.029 58.2786Z" fill=#228848></path>
                                        <path d="M112.921 65.9707L116.799 70.1126C116.883 70.1972 117.052 70.3662 117.136 70.4508C117.305 70.6198 117.389 70.7044 117.558 70.7889C117.726 70.8734 117.895 70.9579 118.064 71.0425C118.232 71.127 118.401 71.127 118.569 71.127C118.822 71.127 118.991 71.127 119.16 71.0425C119.328 70.9579 119.497 70.8734 119.581 70.7044C119.665 70.5353 119.75 70.4508 119.834 70.1972C119.918 69.9436 119.918 69.8591 119.918 69.6055C119.918 69.1828 119.834 68.7602 119.581 68.5066C119.328 68.253 118.991 67.9994 118.569 67.9994L118.738 66.1398C119.244 66.2243 119.665 66.3088 120.003 66.4779C120.34 66.6469 120.677 66.9005 120.93 67.2386C121.183 67.5768 121.351 67.9149 121.436 68.3375C121.52 68.7602 121.604 69.1828 121.604 69.69C121.604 70.1972 121.52 70.6198 121.436 71.0425C121.351 71.4651 121.098 71.8032 120.846 72.1414C120.593 72.4795 120.255 72.6485 119.918 72.8176C119.581 72.9867 119.075 73.0712 118.569 73.0712C117.895 73.0712 117.305 72.9021 116.883 72.564C116.462 72.2259 115.956 71.8878 115.535 71.3806L112.584 68.0839L112.5 72.9867H110.898L110.982 65.9707H112.921Z" fill=#228848></path>
                                        <path d="M111.994 78.7344L112.921 74.3389L114.692 74.677L120.256 80.2559L119.834 82.2001L113.259 80.7631L112.921 82.2846L111.32 81.9465L111.657 80.425L109.549 80.0023L109.887 78.2272L111.994 78.7344ZM117.727 79.9178L114.102 76.4521L113.511 79.0725L117.727 79.9178Z" fill=#228848></path>
                                        <path d="M18.8403 153.881H20.8636C21.2008 153.881 21.6223 153.966 21.9595 154.05C22.2967 154.135 22.6339 154.389 22.9711 154.642C23.3083 154.896 23.4769 155.234 23.7298 155.572C23.8984 155.91 23.9827 156.417 23.9827 156.84C23.9827 157.347 23.8984 157.77 23.7298 158.108C23.5612 158.446 23.3083 158.784 22.9711 159.038C22.6339 159.291 22.2967 159.46 21.9595 159.629C21.6223 159.798 21.2008 159.798 20.8636 159.798H18.8403V153.881ZM19.4304 159.291H20.6107C21.0322 159.291 21.4537 159.207 21.7909 159.122C22.1281 158.953 22.381 158.784 22.6339 158.615C22.8868 158.361 23.0554 158.108 23.1397 157.854C23.224 157.601 23.3083 157.263 23.3083 156.924C23.3083 156.586 23.224 156.333 23.1397 155.995C23.0554 155.741 22.8868 155.487 22.6339 155.234C22.381 154.98 22.1281 154.811 21.7909 154.727C21.4537 154.558 21.0322 154.558 20.6107 154.558H19.4304V159.291Z" fill=white></path>
                                        <path d="M27.5235 157.347C27.5235 156.671 27.1863 156.332 26.5119 156.332C26.0904 156.332 25.6689 156.501 25.3317 156.755L24.9945 156.332C25.3317 155.91 25.9218 155.741 26.6805 155.741C26.8491 155.741 27.0177 155.741 27.2706 155.825C27.4392 155.91 27.6078 155.994 27.6921 156.079C27.7764 156.163 27.945 156.332 28.0293 156.501C28.1136 156.671 28.1136 156.924 28.1136 157.093V158.868C28.1136 159.037 28.1136 159.206 28.1136 159.375C28.1136 159.545 28.1136 159.714 28.1979 159.798H27.6921C27.6921 159.714 27.6921 159.629 27.6921 159.46C27.6921 159.375 27.6921 159.206 27.6921 159.122C27.5235 159.375 27.3549 159.545 27.102 159.714C26.8491 159.798 26.5962 159.883 26.259 159.883C26.0904 159.883 25.9218 159.883 25.7532 159.798C25.5846 159.714 25.416 159.714 25.3317 159.545C25.2474 159.46 25.0788 159.291 24.9945 159.206C24.9102 159.037 24.9102 158.868 24.9102 158.699C24.9102 158.361 24.9945 158.108 25.1631 157.938C25.3317 157.769 25.5003 157.6 25.7532 157.516C26.0061 157.431 26.259 157.347 26.5119 157.347C26.7648 157.347 27.0177 157.347 27.2706 157.347H27.5235ZM27.2706 157.854C27.102 157.854 26.9334 157.854 26.7648 157.854C26.5962 157.854 26.3433 157.938 26.1747 157.938C26.0061 157.938 25.8375 158.108 25.6689 158.192C25.5003 158.277 25.5003 158.446 25.5003 158.615C25.5003 158.784 25.5003 158.868 25.5846 158.953C25.6689 159.037 25.6689 159.122 25.8375 159.206C25.9218 159.291 26.0061 159.291 26.1747 159.291C26.259 159.291 26.4276 159.291 26.5119 159.291C26.6805 159.291 26.8491 159.291 27.0177 159.206C27.1863 159.122 27.2706 159.037 27.3549 158.953C27.4392 158.868 27.5235 158.699 27.6078 158.53C27.6921 158.361 27.6921 158.192 27.6921 158.023V157.769H27.2706V157.854Z" fill=white></path>
                                        <path d="M29.8837 155.91C29.8837 155.994 29.8837 156.163 29.8837 156.248C29.8837 156.332 29.8837 156.417 29.8837 156.586C29.968 156.501 30.0523 156.417 30.1366 156.248C30.2209 156.163 30.3052 156.079 30.4738 155.994C30.5581 155.91 30.7267 155.91 30.811 155.825C30.9796 155.825 31.0639 155.741 31.2325 155.741C31.7384 155.741 32.0756 155.91 32.3285 156.163C32.5814 156.417 32.6657 156.84 32.6657 157.347V159.883H32.0756V157.685C32.0756 157.262 31.9913 156.924 31.8227 156.671C31.6541 156.417 31.4011 156.332 30.9796 156.332C30.9796 156.332 30.8953 156.332 30.7267 156.332C30.5581 156.332 30.4738 156.417 30.3052 156.501C30.1366 156.586 30.0523 156.755 29.8837 156.924C29.7994 157.093 29.7151 157.431 29.7151 157.769V159.798H29.125V156.671C29.125 156.586 29.125 156.417 29.125 156.248C29.125 156.079 29.125 155.91 29.125 155.825H29.8837V155.91Z" fill=white></path>
                                        <path d="M36.122 156.84C36.0377 156.671 35.9534 156.586 35.7848 156.417C35.6162 156.333 35.4476 156.248 35.279 156.248C35.1947 156.248 35.1104 156.248 35.0261 156.248C34.9418 156.248 34.8575 156.333 34.7732 156.333C34.6889 156.333 34.6046 156.417 34.6046 156.502C34.5203 156.586 34.5203 156.671 34.5203 156.755C34.5203 156.925 34.6046 157.094 34.6889 157.178C34.8575 157.263 35.0261 157.347 35.279 157.432L35.8691 157.601C36.122 157.685 36.3749 157.77 36.5435 157.939C36.7121 158.108 36.7964 158.362 36.7964 158.615C36.7964 158.869 36.7121 159.038 36.6278 159.207C36.5435 159.376 36.4592 159.46 36.2906 159.629C36.122 159.714 35.9534 159.799 35.7848 159.883C35.6162 159.968 35.4476 159.968 35.1947 159.968C34.8575 159.968 34.6046 159.883 34.3517 159.799C34.0988 159.714 33.8458 159.46 33.6772 159.207L34.1831 158.869C34.2674 159.038 34.436 159.207 34.6046 159.291C34.7732 159.376 34.9418 159.46 35.1947 159.46C35.279 159.46 35.4476 159.46 35.5319 159.46C35.6162 159.46 35.7848 159.376 35.8691 159.376C35.9534 159.291 36.0377 159.291 36.0377 159.207C36.122 159.122 36.122 159.038 36.122 158.953C36.122 158.784 36.0377 158.615 35.8691 158.531C35.7005 158.446 35.5319 158.362 35.3633 158.362L34.8575 158.192C34.7732 158.192 34.6889 158.108 34.6046 158.108C34.5203 158.108 34.3517 158.023 34.2674 157.939C34.1831 157.854 34.0988 157.77 34.0145 157.601C33.9302 157.432 33.9302 157.347 33.9302 157.094C33.9302 156.925 33.9302 156.671 34.0145 156.586C34.0988 156.417 34.1831 156.333 34.3517 156.248C34.5203 156.164 34.6046 156.079 34.8575 155.995C35.1104 155.91 35.1947 155.91 35.3633 155.91C35.6162 155.91 35.8691 155.995 36.122 156.079C36.3749 156.164 36.5435 156.333 36.6278 156.671L36.122 156.84Z" fill=white></path>
                                        <path d="M38.2299 157.685L40.0846 155.91H40.9276L38.9886 157.685L41.1805 159.798H40.3375L38.3142 157.685V159.798H37.7241V153.374H38.2299V157.685Z" fill=white></path>
                                        <path d="M42.1075 158.023C42.1075 158.192 42.1918 158.446 42.2761 158.615C42.3604 158.784 42.4447 158.953 42.6133 159.037C42.7819 159.122 42.8662 159.291 43.0348 159.376C43.2034 159.46 43.372 159.46 43.5406 159.46C43.8779 159.46 44.1308 159.376 44.2994 159.291C44.5523 159.122 44.7209 158.953 44.8052 158.784L45.2267 159.122C44.9738 159.46 44.7209 159.629 44.468 159.798C44.2151 159.967 43.8779 159.967 43.5406 159.967C43.2877 159.967 42.9505 159.883 42.6976 159.798C42.4447 159.714 42.1918 159.545 42.0232 159.376C41.8546 159.206 41.686 158.953 41.6017 158.699C41.5174 158.446 41.4331 158.192 41.4331 157.854C41.4331 157.516 41.5174 157.262 41.6017 157.009C41.686 156.755 41.8546 156.502 42.0232 156.332C42.1918 156.163 42.4447 155.994 42.6976 155.91C42.9505 155.825 43.2034 155.741 43.4563 155.741C43.7936 155.741 44.0465 155.825 44.2994 155.91C44.5523 155.994 44.7209 156.163 44.8895 156.332C45.0581 156.502 45.1424 156.755 45.2267 156.924C45.311 157.178 45.311 157.431 45.311 157.685V157.939H42.1075V158.023ZM44.8052 157.516C44.8052 157.178 44.7209 156.84 44.468 156.586C44.2151 156.332 43.9622 156.248 43.5406 156.248C43.372 156.248 43.2034 156.248 43.0348 156.332C42.8662 156.417 42.6976 156.501 42.6133 156.586C42.529 156.671 42.3604 156.84 42.2761 157.009C42.1918 157.178 42.1918 157.347 42.1918 157.516H44.8052Z" fill=white></path>
                                        <path d="M50.5377 156.417H49.6104V159.883H49.0203V156.417H48.1772V155.91H49.0203V154.811C49.0203 154.304 49.1046 153.881 49.3575 153.712C49.6104 153.459 49.9476 153.374 50.2848 153.374C50.3691 153.374 50.4534 153.374 50.5377 153.374C50.622 153.374 50.7063 153.374 50.7906 153.374L50.7063 153.881C50.622 153.881 50.5377 153.881 50.5377 153.881C50.4534 153.881 50.3691 153.881 50.2848 153.881C50.1162 153.881 50.0319 153.881 49.9476 153.966C49.8633 154.05 49.779 154.05 49.6947 154.219C49.6104 154.304 49.6104 154.388 49.6104 154.557C49.6104 154.726 49.6104 154.811 49.6104 154.98V155.994H50.5377V156.417Z" fill=white></path>
                                        <path d="M55.1746 157.854C55.1746 158.192 55.0903 158.446 55.006 158.699C54.9217 158.953 54.7531 159.206 54.5844 159.376C54.4158 159.545 54.1629 159.714 53.91 159.798C53.6571 159.883 53.4042 159.967 53.067 159.967C52.7298 159.967 52.4769 159.883 52.224 159.798C51.9711 159.714 51.7182 159.545 51.5496 159.376C51.381 159.206 51.2124 158.953 51.1281 158.699C51.0438 158.446 50.9595 158.192 50.9595 157.854C50.9595 157.516 51.0438 157.262 51.1281 157.009C51.2124 156.755 51.381 156.502 51.5496 156.332C51.7182 156.163 51.9711 155.994 52.224 155.91C52.4769 155.825 52.7298 155.741 53.067 155.741C53.4042 155.741 53.6571 155.825 53.91 155.91C54.1629 155.994 54.4158 156.163 54.5844 156.332C54.7531 156.502 54.9217 156.755 55.006 157.009C55.1746 157.262 55.1746 157.516 55.1746 157.854ZM54.5844 157.854C54.5844 157.6 54.5844 157.431 54.5001 157.262C54.4158 157.093 54.3315 156.924 54.1629 156.755C53.9943 156.586 53.91 156.501 53.6571 156.417C53.4885 156.332 53.2356 156.332 53.067 156.332C52.8984 156.332 52.6455 156.332 52.4769 156.417C52.3083 156.501 52.1397 156.586 51.9711 156.755C51.8868 156.924 51.7182 157.093 51.7182 157.262C51.6339 157.431 51.6339 157.685 51.6339 157.854C51.6339 158.023 51.6339 158.277 51.7182 158.446C51.8025 158.615 51.8868 158.784 51.9711 158.953C52.1397 159.122 52.224 159.206 52.4769 159.291C52.6455 159.376 52.8984 159.376 53.067 159.376C53.2356 159.376 53.4885 159.376 53.6571 159.291C53.8257 159.206 53.9943 159.122 54.1629 158.953C54.3315 158.784 54.4158 158.615 54.5001 158.446C54.5844 158.277 54.5844 158.108 54.5844 157.854Z" fill=white></path>
                                        <path d="M56.2703 157.093C56.2703 156.924 56.2703 156.755 56.2703 156.586C56.2703 156.417 56.2703 156.163 56.2703 155.91H56.7761V156.67C56.7761 156.586 56.8604 156.501 56.9447 156.332C57.029 156.248 57.1134 156.163 57.1977 156.079C57.282 155.994 57.4506 155.91 57.5349 155.91C57.7035 155.825 57.7878 155.825 58.0407 155.825C58.2093 155.825 58.3779 155.825 58.4622 155.91L58.3779 156.501C58.2936 156.501 58.2093 156.501 58.0407 156.501C57.7878 156.501 57.6192 156.501 57.5349 156.586C57.4506 156.67 57.282 156.755 57.1134 156.924C57.0291 157.093 56.9447 157.178 56.8604 157.347C56.7761 157.516 56.7761 157.6 56.7761 157.769V159.967H56.186V157.093H56.2703Z" fill=white></path>
                                        <path d="M59.0522 153.458H59.6424V156.586C59.7267 156.417 59.811 156.333 59.9796 156.248C60.0639 156.163 60.2325 156.079 60.4011 155.994C60.5697 155.91 60.654 155.91 60.8226 155.825C60.9912 155.741 61.0755 155.825 61.2441 155.825C61.5813 155.825 61.8342 155.91 62.0871 155.994C62.34 156.079 62.5929 156.248 62.7615 156.417C62.9301 156.586 63.0987 156.84 63.183 157.093C63.2673 157.347 63.3516 157.6 63.3516 157.939C63.3516 158.277 63.2673 158.53 63.183 158.784C63.0987 159.037 62.9301 159.291 62.7615 159.46C62.5929 159.629 62.34 159.798 62.0871 159.883C61.8342 159.967 61.5813 160.052 61.2441 160.052C61.0755 160.052 60.9912 160.052 60.8226 160.052C60.654 160.052 60.5697 159.967 60.4011 159.883C60.2325 159.798 60.1482 159.714 59.9796 159.629C59.8953 159.545 59.7267 159.46 59.6424 159.291V159.967H59.0522V153.458ZM62.5929 157.854C62.5929 157.6 62.5929 157.431 62.5086 157.262C62.4243 157.093 62.34 156.924 62.1714 156.755C62.0028 156.586 61.9185 156.502 61.6656 156.417C61.497 156.333 61.2441 156.333 61.0755 156.333C60.8226 156.333 60.654 156.333 60.4011 156.417C60.2325 156.502 60.0639 156.586 59.8953 156.755C59.7267 156.924 59.6424 157.093 59.5581 157.262C59.4738 157.431 59.4738 157.685 59.4738 157.854C59.4738 158.023 59.4738 158.277 59.5581 158.446C59.6424 158.615 59.7267 158.784 59.8953 158.953C60.0639 159.122 60.2325 159.207 60.4011 159.291C60.5697 159.376 60.8226 159.376 61.0755 159.376C61.3284 159.376 61.497 159.376 61.6656 159.291C61.8342 159.207 62.0028 159.122 62.1714 158.953C62.34 158.784 62.4243 158.615 62.5086 158.446C62.5929 158.277 62.5929 158.108 62.5929 157.854Z" fill=white></path>
                                        <path d="M64.1947 157.093C64.1947 156.924 64.1947 156.755 64.1947 156.586C64.1947 156.417 64.1947 156.163 64.1947 155.91H64.7005V156.67C64.7005 156.586 64.7848 156.501 64.8691 156.332C64.9534 156.248 65.0377 156.163 65.122 156.079C65.2063 155.994 65.3749 155.91 65.4592 155.91C65.6278 155.825 65.7121 155.825 65.965 155.825C66.1336 155.825 66.3022 155.825 66.3865 155.91L66.3022 156.501C66.2179 156.501 66.1336 156.501 65.965 156.501C65.7121 156.501 65.5435 156.501 65.4592 156.586C65.3749 156.67 65.2063 156.755 65.0377 156.924C64.9534 157.093 64.8691 157.178 64.7848 157.347C64.7005 157.516 64.7005 157.6 64.7005 157.769V159.967H64.1104V157.093H64.1947Z" fill=white></path>
                                        <path d="M69.843 159.798C69.843 159.714 69.843 159.545 69.843 159.46C69.843 159.375 69.843 159.291 69.843 159.122C69.7587 159.206 69.6744 159.291 69.5901 159.375C69.5058 159.46 69.4215 159.545 69.2529 159.629C69.1686 159.714 69 159.714 68.9157 159.798C68.7471 159.798 68.6628 159.883 68.4942 159.883C67.9884 159.883 67.6511 159.714 67.3982 159.46C67.1453 159.206 67.061 158.784 67.061 158.277V155.741H67.6512V157.938C67.6512 158.192 67.6511 158.361 67.7355 158.53C67.7355 158.699 67.8197 158.868 67.9041 158.953C67.9884 159.037 68.0727 159.122 68.2413 159.206C68.4099 159.291 68.5785 159.291 68.7471 159.291C68.7471 159.291 68.8314 159.291 69 159.291C69.1686 159.291 69.2529 159.206 69.4215 159.122C69.5901 159.037 69.6744 158.868 69.843 158.699C69.9273 158.53 70.0116 158.192 70.0116 157.854V155.825H70.6017V158.868C70.6017 158.953 70.6017 159.122 70.6017 159.291C70.6017 159.46 70.6017 159.629 70.6017 159.714H69.843V159.798Z" fill=white></path>
                                        <path d="M71.9505 160.643C72.1191 160.897 72.2877 161.066 72.6249 161.151C72.8778 161.32 73.215 161.32 73.4679 161.32C73.7208 161.32 73.9737 161.32 74.1423 161.235C74.3109 161.151 74.4795 161.066 74.6481 160.897C74.7324 160.728 74.8167 160.559 74.901 160.39C74.9853 160.221 74.9853 159.967 74.9853 159.798V159.122C74.8167 159.376 74.5638 159.545 74.3109 159.714C74.058 159.798 73.8051 159.883 73.4679 159.883C73.1307 159.883 72.8778 159.798 72.6249 159.714C72.372 159.629 72.1191 159.46 71.9505 159.291C71.7819 159.122 71.6133 158.868 71.529 158.615C71.4447 158.361 71.3604 158.108 71.3604 157.769C71.3604 157.431 71.4447 157.178 71.529 156.924C71.6133 156.671 71.7819 156.502 71.9505 156.248C72.1191 156.079 72.372 155.91 72.6249 155.825C72.8778 155.741 73.1307 155.656 73.4679 155.656C73.5522 155.656 73.7208 155.656 73.8051 155.656C73.8894 155.656 74.058 155.741 74.2266 155.741C74.3952 155.825 74.4795 155.91 74.6481 155.994C74.8167 156.079 74.901 156.248 74.9853 156.332V155.656H75.5754V159.545C75.5754 159.798 75.5754 159.967 75.4911 160.221C75.4068 160.474 75.3225 160.728 75.1539 160.897C74.9853 161.066 74.8167 161.235 74.4795 161.404C74.2266 161.573 73.8051 161.573 73.3836 161.573C72.9621 161.573 72.6249 161.489 72.372 161.404C72.0348 161.235 71.7819 161.066 71.529 160.813L71.9505 160.643ZM72.0348 157.769C72.0348 157.939 72.0348 158.192 72.1191 158.361C72.2034 158.53 72.2877 158.699 72.4563 158.868C72.6249 159.037 72.7092 159.122 72.8778 159.206C73.0464 159.291 73.215 159.291 73.4679 159.291C73.6365 159.291 73.8894 159.291 74.058 159.206C74.2266 159.122 74.3952 159.037 74.5638 158.868C74.7324 158.699 74.8167 158.615 74.901 158.361C74.9853 158.108 74.9853 157.939 74.9853 157.769C74.9853 157.6 74.9853 157.347 74.901 157.178C74.8167 157.009 74.7324 156.84 74.6481 156.671C74.4795 156.502 74.3952 156.417 74.1423 156.332C73.8894 156.248 73.7208 156.248 73.5522 156.248C73.3836 156.248 73.1307 156.248 72.9621 156.332C72.7935 156.417 72.6249 156.502 72.5406 156.671C72.372 156.84 72.2877 157.009 72.2034 157.178C72.1191 157.347 72.0348 157.6 72.0348 157.769Z" fill=white></path>
                                        <path d="M77.177 158.023C77.177 158.192 77.2613 158.446 77.3456 158.615C77.4299 158.784 77.5142 158.953 77.6828 159.037C77.8514 159.122 77.9357 159.291 78.1043 159.376C78.2729 159.46 78.4415 159.46 78.6945 159.46C79.0317 159.46 79.2846 159.376 79.4532 159.291C79.7061 159.122 79.8747 158.953 79.959 158.784L80.3805 159.122C80.1276 159.46 79.8747 159.629 79.6218 159.798C79.3689 159.967 79.0317 159.967 78.6945 159.967C78.4415 159.967 78.1043 159.883 77.8514 159.798C77.5985 159.714 77.3456 159.545 77.177 159.376C77.0084 159.206 76.8398 158.953 76.7555 158.699C76.6712 158.446 76.5869 158.192 76.5869 157.854C76.5869 157.516 76.6712 157.262 76.7555 157.009C76.8398 156.755 77.0084 156.502 77.177 156.332C77.3456 156.163 77.5985 155.994 77.8514 155.91C78.1043 155.825 78.3572 155.741 78.6102 155.741C78.9474 155.741 79.2003 155.825 79.4532 155.91C79.7061 155.994 79.8747 156.163 80.0433 156.332C80.2119 156.502 80.2962 156.755 80.3805 156.924C80.4648 157.178 80.4648 157.431 80.4648 157.685V157.939H77.177V158.023ZM79.8747 157.516C79.8747 157.178 79.7904 156.84 79.5375 156.586C79.2846 156.332 79.0317 156.248 78.6102 156.248C78.4415 156.248 78.2729 156.248 78.1043 156.332C77.9357 156.417 77.7671 156.501 77.6828 156.586C77.5142 156.671 77.4299 156.84 77.3456 157.009C77.2613 157.178 77.2613 157.347 77.2613 157.516H79.8747Z" fill=white></path>
                                        <path d="M81.5609 157.093C81.5609 156.924 81.5609 156.755 81.5609 156.586C81.5609 156.417 81.5609 156.163 81.5609 155.91H82.0667V156.67C82.0667 156.586 82.151 156.501 82.2353 156.332C82.3196 156.248 82.4039 156.163 82.4882 156.079C82.5725 155.994 82.7411 155.91 82.8254 155.91C82.994 155.825 83.0783 155.825 83.3312 155.825C83.4998 155.825 83.5841 155.825 83.7527 155.91L83.6684 156.501C83.5841 156.501 83.4998 156.501 83.3312 156.501C83.0783 156.501 82.9097 156.501 82.8254 156.586C82.6568 156.67 82.5725 156.755 82.4039 156.924C82.2353 157.093 82.2353 157.178 82.151 157.347C82.0667 157.516 82.0667 157.6 82.0667 157.769V159.967H81.4766V157.093H81.5609Z" fill=white></path>
                                        <path d="M84.5115 158.023C84.5115 158.192 84.5958 158.446 84.6801 158.615C84.7644 158.784 84.8487 158.953 85.0173 159.037C85.1859 159.122 85.2702 159.291 85.4388 159.376C85.6074 159.46 85.776 159.46 86.0289 159.46C86.3661 159.46 86.619 159.376 86.7876 159.291C87.0405 159.122 87.2092 158.953 87.2935 158.784L87.715 159.122C87.4621 159.46 87.2092 159.629 86.9563 159.798C86.7033 159.967 86.3661 159.967 86.0289 159.967C85.776 159.967 85.4388 159.883 85.1859 159.798C84.933 159.714 84.6801 159.545 84.5115 159.376C84.3429 159.206 84.1743 158.953 84.09 158.699C84.0057 158.446 83.9214 158.192 83.9214 157.854C83.9214 157.516 84.0057 157.262 84.09 157.009C84.1743 156.755 84.3429 156.502 84.5115 156.332C84.6801 156.163 84.933 155.994 85.1859 155.91C85.4388 155.825 85.6917 155.741 85.9446 155.741C86.2818 155.741 86.5347 155.825 86.7876 155.91C87.0405 155.994 87.2092 156.163 87.3778 156.332C87.5464 156.502 87.6307 156.755 87.715 156.924C87.7993 157.093 87.8836 157.431 87.8836 157.685V157.939H84.5115V158.023ZM87.2092 157.516C87.2092 157.178 87.1248 156.84 86.8719 156.586C86.619 156.332 86.3661 156.248 85.9446 156.248C85.776 156.248 85.6074 156.248 85.4388 156.332C85.2702 156.417 85.1016 156.501 85.0173 156.586C84.8487 156.671 84.7644 156.84 84.6801 157.009C84.5958 157.178 84.5958 157.347 84.5958 157.516H87.2092Z" fill=white></path>
                                        <path d="M95.1335 157.854C95.1335 158.192 95.0492 158.446 94.9649 158.699C94.8806 158.953 94.712 159.206 94.5434 159.376C94.3748 159.545 94.1219 159.714 93.869 159.798C93.6161 159.883 93.3632 159.967 93.026 159.967C92.6888 159.967 92.4359 159.883 92.183 159.798C91.9301 159.714 91.6772 159.545 91.5086 159.376C91.34 159.206 91.1714 158.953 91.0871 158.699C91.0028 158.446 90.9185 158.192 90.9185 157.854C90.9185 157.516 91.0028 157.262 91.0871 157.009C91.1714 156.755 91.34 156.502 91.5086 156.332C91.6772 156.163 91.9301 155.994 92.183 155.91C92.4359 155.825 92.6888 155.741 93.026 155.741C93.3632 155.741 93.6161 155.825 93.869 155.91C94.1219 155.994 94.3748 156.163 94.5434 156.332C94.712 156.502 94.8806 156.755 94.9649 157.009C95.1335 157.262 95.1335 157.516 95.1335 157.854ZM94.5434 157.854C94.5434 157.6 94.5434 157.431 94.4591 157.262C94.3748 157.093 94.2905 156.924 94.1219 156.755C93.9533 156.586 93.869 156.501 93.6161 156.417C93.3632 156.332 93.1946 156.332 93.026 156.332C92.8574 156.332 92.6045 156.332 92.4359 156.417C92.2673 156.501 92.0987 156.586 92.0144 156.755C91.9301 156.924 91.7615 157.093 91.7615 157.262C91.7615 157.431 91.6772 157.685 91.6772 157.854C91.6772 158.023 91.6772 158.277 91.7615 158.446C91.8458 158.615 91.9301 158.784 92.0144 158.953C92.183 159.122 92.2673 159.206 92.4359 159.291C92.6045 159.376 92.8574 159.376 93.026 159.376C93.1946 159.376 93.4475 159.376 93.6161 159.291C93.7847 159.206 93.9533 159.122 94.1219 158.953C94.2905 158.784 94.3748 158.615 94.4591 158.446C94.5434 158.277 94.5434 158.108 94.5434 157.854Z" fill=white></path>
                                        <path d="M96.145 155.91H96.7351V156.586C96.8194 156.417 96.9037 156.332 97.0723 156.248C97.1566 156.163 97.3252 156.079 97.4939 155.994C97.6625 155.91 97.7468 155.91 97.9154 155.825C98.084 155.741 98.1683 155.825 98.3369 155.825C98.6741 155.825 98.927 155.91 99.1799 155.994C99.4328 156.079 99.6857 156.248 99.8543 156.417C100.023 156.586 100.192 156.84 100.276 157.093C100.36 157.347 100.444 157.6 100.444 157.938C100.444 158.277 100.36 158.53 100.276 158.784C100.192 159.037 100.023 159.291 99.8543 159.46C99.6857 159.629 99.4328 159.798 99.1799 159.883C98.927 159.967 98.6741 160.052 98.3369 160.052C98.1683 160.052 98.084 160.052 97.9154 160.052C97.7468 160.052 97.6625 159.967 97.4939 159.883C97.3252 159.798 97.2409 159.714 97.0723 159.629C96.988 159.544 96.8194 159.46 96.7351 159.291V162.418H96.145V155.91ZM99.77 157.854C99.77 157.6 99.77 157.431 99.6857 157.262C99.6014 157.093 99.5171 156.924 99.3485 156.755C99.1799 156.586 99.0956 156.501 98.8427 156.417C98.5898 156.332 98.4212 156.332 98.2526 156.332C98.084 156.332 97.8311 156.332 97.5782 156.417C97.3252 156.501 97.2409 156.586 97.0723 156.755C96.9037 156.924 96.8194 157.093 96.7351 157.262C96.6508 157.431 96.6508 157.685 96.6508 157.854C96.6508 158.023 96.6508 158.277 96.7351 158.446C96.8194 158.615 96.9037 158.784 97.0723 158.953C97.2409 159.122 97.4095 159.206 97.5782 159.291C97.7468 159.375 97.9997 159.375 98.2526 159.375C98.5055 159.375 98.6741 159.375 98.8427 159.291C99.0113 159.206 99.1799 159.122 99.3485 158.953C99.5171 158.784 99.6014 158.615 99.6857 158.446C99.77 158.277 99.77 158.107 99.77 157.854Z" fill=white></path>
                                        <path d="M103.142 156.417H102.215V159.883H101.625V156.417H100.782V155.91H101.625V154.811C101.625 154.304 101.709 153.881 101.962 153.712C102.215 153.459 102.552 153.374 102.889 153.374C102.974 153.374 103.058 153.374 103.142 153.374C103.226 153.374 103.311 153.374 103.395 153.374L103.311 153.881C103.226 153.881 103.142 153.881 103.142 153.881C103.058 153.881 102.974 153.881 102.889 153.881C102.721 153.881 102.636 153.881 102.552 153.966C102.468 154.05 102.383 154.05 102.299 154.219C102.215 154.304 102.215 154.388 102.215 154.557C102.215 154.642 102.215 154.811 102.215 154.98V155.994H103.142V156.417Z" fill=white></path>
                                        <path d="M106.346 157.347C106.346 156.671 106.009 156.332 105.334 156.332C104.913 156.332 104.491 156.501 104.154 156.755L103.817 156.332C104.154 155.91 104.744 155.741 105.503 155.741C105.671 155.741 105.84 155.741 106.093 155.825C106.261 155.91 106.43 155.994 106.514 156.079C106.599 156.163 106.767 156.332 106.852 156.501C106.936 156.671 106.936 156.924 106.936 157.093V158.868C106.936 159.037 106.936 159.206 106.936 159.375C106.936 159.545 106.936 159.714 107.02 159.798H106.514C106.514 159.714 106.514 159.629 106.514 159.46C106.514 159.375 106.514 159.206 106.514 159.122C106.346 159.375 106.177 159.545 105.924 159.714C105.671 159.883 105.418 159.883 105.081 159.883C104.913 159.883 104.744 159.883 104.575 159.798C104.407 159.714 104.238 159.714 104.154 159.545C104.07 159.46 103.901 159.291 103.817 159.206C103.732 159.122 103.732 158.868 103.732 158.699C103.732 158.361 103.817 158.108 103.985 157.938C104.154 157.769 104.323 157.6 104.575 157.516C104.828 157.431 105.081 157.347 105.334 157.347C105.587 157.347 105.84 157.347 106.093 157.347H106.346ZM106.093 157.854C105.924 157.854 105.756 157.854 105.587 157.854C105.418 157.854 105.166 157.938 104.997 157.938C104.828 157.938 104.66 158.108 104.491 158.192C104.323 158.277 104.323 158.446 104.323 158.615C104.323 158.784 104.323 158.868 104.407 158.953C104.491 159.037 104.491 159.122 104.66 159.206C104.744 159.291 104.828 159.291 104.997 159.291C105.081 159.291 105.25 159.291 105.334 159.291C105.503 159.291 105.671 159.291 105.84 159.206C106.009 159.122 106.093 159.037 106.177 158.953C106.261 158.868 106.346 158.699 106.43 158.53C106.514 158.361 106.514 158.192 106.514 158.023V157.769H106.093V157.854Z" fill=white></path>
                                        <path d="M110.224 156.417H109.128V158.784C109.128 158.953 109.128 159.037 109.128 159.122C109.128 159.207 109.212 159.291 109.212 159.376C109.296 159.46 109.296 159.46 109.381 159.46C109.465 159.46 109.549 159.46 109.633 159.46C109.718 159.46 109.802 159.46 109.886 159.46C109.971 159.46 110.055 159.376 110.139 159.376V159.883C109.971 159.967 109.718 160.052 109.381 160.052C109.296 160.052 109.128 160.052 109.043 160.052C108.959 160.052 108.79 159.967 108.706 159.883C108.622 159.798 108.538 159.714 108.453 159.545C108.369 159.376 108.369 159.207 108.369 159.037V156.502H107.526V155.994H108.369V154.896H108.959V155.994H110.055V156.417H110.224Z" fill=white></path>
                                        <path d="M113.006 156.417H111.825V158.784C111.825 158.953 111.825 159.037 111.825 159.122C111.825 159.207 111.91 159.291 111.91 159.376C111.994 159.46 111.994 159.46 112.078 159.46C112.163 159.46 112.247 159.46 112.331 159.46C112.415 159.46 112.5 159.46 112.584 159.46C112.668 159.46 112.753 159.376 112.837 159.376V159.883C112.668 159.967 112.415 160.052 112.078 160.052C111.994 160.052 111.825 160.052 111.741 160.052C111.657 160.052 111.488 159.967 111.404 159.883C111.32 159.798 111.235 159.714 111.151 159.545C111.067 159.376 111.067 159.207 111.067 159.037V156.502H110.224V155.994H111.067V154.896H111.657V155.994H112.837V156.417H113.006Z" fill=white></path>
                                        <path d="M114.186 158.023C114.186 158.192 114.27 158.446 114.354 158.615C114.439 158.784 114.523 158.953 114.691 159.037C114.86 159.122 114.944 159.291 115.113 159.376C115.282 159.46 115.45 159.46 115.619 159.46C115.956 159.46 116.209 159.376 116.377 159.291C116.63 159.122 116.799 158.953 116.883 158.784L117.305 159.122C117.052 159.46 116.799 159.629 116.546 159.798C116.293 159.967 115.956 159.967 115.619 159.967C115.366 159.967 115.029 159.883 114.776 159.798C114.523 159.714 114.27 159.545 114.101 159.376C113.933 159.206 113.764 158.953 113.68 158.699C113.596 158.446 113.511 158.192 113.511 157.854C113.511 157.516 113.596 157.262 113.68 157.009C113.764 156.755 113.933 156.502 114.101 156.332C114.27 156.163 114.523 155.994 114.776 155.91C115.029 155.825 115.282 155.741 115.534 155.741C115.872 155.741 116.125 155.825 116.293 155.91C116.546 155.994 116.715 156.163 116.883 156.332C117.052 156.502 117.136 156.755 117.22 156.924C117.305 157.093 117.389 157.431 117.389 157.685V157.939H114.186V158.023ZM116.883 157.516C116.883 157.178 116.799 156.84 116.546 156.586C116.293 156.332 116.04 156.248 115.619 156.248C115.45 156.248 115.282 156.248 115.113 156.332C114.944 156.417 114.776 156.501 114.691 156.586C114.607 156.671 114.439 156.84 114.354 157.009C114.27 157.178 114.27 157.347 114.27 157.516H116.883Z" fill=white></path>
                                        <path d="M118.569 157.093C118.569 156.924 118.569 156.755 118.569 156.586C118.569 156.417 118.569 156.163 118.569 155.91H119.075V156.67C119.075 156.586 119.159 156.501 119.244 156.332C119.328 156.248 119.412 156.163 119.496 156.079C119.581 155.994 119.749 155.91 119.834 155.91C119.918 155.91 120.087 155.825 120.34 155.825C120.508 155.825 120.677 155.825 120.761 155.91L120.677 156.501C120.592 156.501 120.508 156.501 120.34 156.501C120.087 156.501 119.918 156.501 119.834 156.586C119.749 156.67 119.581 156.755 119.412 156.924C119.328 157.093 119.244 157.178 119.159 157.347C119.075 157.516 119.075 157.6 119.075 157.769V159.967H118.485V157.093H118.569Z" fill=white></path>
                                        <path d="M6.6168 169.942H5.94238L8.55573 163.94H9.14585L11.7592 169.942H11.0848L10.4104 168.336H7.37551L6.6168 169.942ZM7.45981 167.829H10.0732L8.80864 164.701L7.45981 167.829Z" fill=white></path>
                                        <path d="M12.7709 166.053C12.7709 166.138 12.7709 166.307 12.7709 166.391C12.7709 166.476 12.7709 166.561 12.7709 166.73C12.8552 166.645 12.9395 166.561 13.0238 166.391C13.1081 166.307 13.1924 166.222 13.361 166.138C13.4453 166.053 13.6139 166.053 13.6982 165.969C13.8668 165.969 13.9511 165.884 14.1197 165.884C14.6256 165.884 14.9628 166.053 15.2157 166.307C15.4686 166.561 15.5529 166.983 15.5529 167.49V170.026H14.9628V167.828C14.9628 167.406 14.8785 167.068 14.7099 166.814C14.5413 166.561 14.2884 166.476 13.8668 166.476C13.8668 166.476 13.7825 166.476 13.6139 166.476C13.4453 166.476 13.361 166.561 13.1924 166.645C13.0238 166.73 12.9395 166.899 12.7709 167.068C12.6866 167.237 12.6023 167.575 12.6023 167.913V169.942H12.0122V166.814C12.0122 166.73 12.0122 166.561 12.0122 166.391C12.0122 166.222 12.0122 166.053 12.0122 165.969H12.7709V166.053Z" fill=white></path>
                                        <path d="M20.8638 169.942H20.2737V169.35C20.1894 169.519 20.1051 169.604 19.9365 169.688C19.8522 169.773 19.6836 169.857 19.515 169.942C19.3464 170.026 19.2621 170.026 19.0935 170.111C18.9249 170.111 18.8406 170.111 18.672 170.111C18.3348 170.111 18.0819 170.026 17.829 169.942C17.5761 169.857 17.3232 169.688 17.1546 169.519C16.986 169.35 16.8174 169.097 16.7331 168.843C16.6488 168.589 16.5645 168.336 16.5645 167.998C16.5645 167.66 16.6488 167.406 16.7331 167.152C16.8174 166.899 16.986 166.645 17.1546 166.476C17.3232 166.307 17.5761 166.138 17.829 166.053C18.0819 165.969 18.3348 165.884 18.672 165.884C18.8406 165.884 18.9249 165.884 19.0935 165.884C19.2621 165.884 19.3464 165.969 19.515 166.053C19.6836 166.138 19.7679 166.223 19.9365 166.307C20.0208 166.392 20.1894 166.476 20.2737 166.645V163.518H20.8638V169.942ZM17.3232 167.998C17.3232 168.251 17.3232 168.42 17.4075 168.589C17.4918 168.758 17.5761 168.927 17.7447 169.097C17.9133 169.266 17.9976 169.35 18.2505 169.435C18.4191 169.519 18.672 169.519 18.8406 169.519C19.0935 169.519 19.2621 169.519 19.4307 169.435C19.5993 169.35 19.7679 169.266 19.9365 169.097C20.1051 168.927 20.1894 168.758 20.2737 168.589C20.358 168.42 20.358 168.167 20.358 167.998C20.358 167.829 20.358 167.575 20.2737 167.406C20.1894 167.237 20.1051 167.068 19.9365 166.899C19.7679 166.73 19.5993 166.645 19.4307 166.561C19.2621 166.476 19.0092 166.476 18.8406 166.476C18.5877 166.476 18.4191 166.476 18.2505 166.561C18.0819 166.645 17.9133 166.73 17.7447 166.899C17.5761 167.068 17.4918 167.237 17.4075 167.406C17.3232 167.575 17.3232 167.744 17.3232 167.998Z" fill=white></path>
                                        <path d="M22.4654 168.167C22.4654 168.336 22.5497 168.589 22.634 168.758C22.7183 168.927 22.8026 169.096 22.9712 169.181C23.1398 169.265 23.2241 169.435 23.3927 169.519C23.5614 169.604 23.73 169.604 23.8986 169.604C24.2358 169.604 24.4887 169.519 24.6573 169.435C24.9102 169.265 25.0788 169.096 25.1631 168.927L25.5846 169.265C25.3317 169.604 25.0788 169.773 24.8259 169.942C24.573 170.111 24.2358 170.111 23.8986 170.111C23.6457 170.111 23.3084 170.026 23.0555 169.942C22.8026 169.857 22.5497 169.688 22.3811 169.519C22.2125 169.35 22.0439 169.096 21.9596 168.843C21.8753 168.589 21.791 168.336 21.791 167.998C21.791 167.659 21.8753 167.406 21.9596 167.152C22.0439 166.899 22.2125 166.645 22.3811 166.476C22.5497 166.307 22.8026 166.138 23.0555 166.053C23.3084 165.969 23.5614 165.884 23.8143 165.884C24.1515 165.884 24.4044 165.969 24.6573 166.053C24.9102 166.138 25.0788 166.307 25.2474 166.476C25.416 166.645 25.5003 166.899 25.5846 167.068C25.6689 167.321 25.6689 167.575 25.6689 167.828V168.082H22.4654V168.167ZM25.1631 167.659C25.1631 167.321 25.0788 166.983 24.8259 166.73C24.573 166.476 24.3201 166.391 23.8986 166.391C23.73 166.391 23.5614 166.391 23.3927 166.476C23.2241 166.561 23.0555 166.645 22.9712 166.73C22.8869 166.814 22.7183 166.983 22.634 167.152C22.5497 167.321 22.5497 167.49 22.5497 167.659H25.1631Z" fill=white></path>
                                        <path d="M27.4392 169.942H26.8491V163.518H27.4392V169.942Z" fill=white></path>
                                        <path d="M33.2563 166.983C33.172 166.814 33.0877 166.729 32.9191 166.56C32.7505 166.476 32.5819 166.391 32.4133 166.391C32.329 166.391 32.2447 166.391 32.1603 166.391C32.076 166.391 31.9917 166.476 31.9074 166.476C31.8231 166.476 31.7388 166.56 31.7388 166.645C31.6545 166.729 31.6545 166.814 31.6545 166.899C31.6545 167.068 31.7388 167.237 31.8231 167.321C31.9917 167.406 32.1603 167.49 32.4133 167.575L33.0034 167.744C33.2563 167.828 33.5092 167.913 33.6778 168.082C33.8464 168.251 33.9307 168.505 33.9307 168.758C33.9307 169.012 33.8464 169.181 33.7621 169.35C33.6778 169.519 33.5935 169.603 33.4249 169.773C33.2563 169.857 33.0877 169.942 32.9191 170.026C32.7505 170.111 32.5819 170.111 32.329 170.111C31.9917 170.111 31.7388 170.026 31.4859 169.942C31.233 169.857 30.9801 169.603 30.8115 169.35L31.3173 169.012C31.4016 169.181 31.5702 169.35 31.7388 169.434C31.9074 169.519 32.076 169.603 32.329 169.603C32.4133 169.603 32.5819 169.603 32.6662 169.603C32.7505 169.603 32.9191 169.519 33.0034 169.519C33.0877 169.434 33.172 169.434 33.172 169.35C33.2563 169.265 33.2563 169.181 33.2563 169.096C33.2563 168.927 33.172 168.758 33.0034 168.674C32.8348 168.589 32.6662 168.505 32.4976 168.505L31.9917 168.336C31.9074 168.336 31.8231 168.251 31.7388 168.251C31.6545 168.251 31.4859 168.166 31.4016 168.082C31.3173 167.997 31.233 167.913 31.1487 167.744C31.0644 167.575 31.0644 167.49 31.0644 167.237C31.0644 167.068 31.0644 166.814 31.1487 166.729C31.233 166.56 31.3173 166.476 31.4859 166.391C31.6545 166.307 31.7388 166.222 31.9917 166.138C32.2446 166.053 32.329 166.053 32.4976 166.053C32.7505 166.053 33.0034 166.138 33.2563 166.222C33.5092 166.307 33.6778 166.476 33.7621 166.814L33.2563 166.983Z" fill=white></path>
                                        <path d="M38.7356 167.998C38.7356 168.336 38.6513 168.589 38.567 168.843C38.4827 169.096 38.3141 169.35 38.1455 169.519C37.9769 169.688 37.724 169.857 37.4711 169.942C37.2182 170.026 36.9653 170.111 36.628 170.111C36.2908 170.111 36.0379 170.026 35.785 169.942C35.5321 169.857 35.2792 169.688 35.1106 169.519C34.942 169.35 34.7734 169.096 34.6891 168.843C34.6048 168.589 34.5205 168.336 34.5205 167.998C34.5205 167.659 34.6048 167.406 34.6891 167.152C34.7734 166.899 34.942 166.645 35.1106 166.476C35.2792 166.307 35.5321 166.138 35.785 166.053C36.0379 165.969 36.2908 165.884 36.628 165.884C36.9653 165.884 37.2182 165.969 37.4711 166.053C37.724 166.138 37.9769 166.307 38.1455 166.476C38.3141 166.645 38.4827 166.899 38.567 167.152C38.6513 167.406 38.7356 167.659 38.7356 167.998ZM38.1455 167.998C38.1455 167.744 38.1455 167.575 38.0612 167.406C37.9769 167.237 37.8926 167.068 37.724 166.899C37.5554 166.73 37.4711 166.645 37.2182 166.561C37.0496 166.476 36.7967 166.476 36.628 166.476C36.4594 166.476 36.2065 166.476 36.0379 166.561C35.8693 166.645 35.7007 166.73 35.5321 166.899C35.4478 167.068 35.2792 167.237 35.2792 167.406C35.1949 167.575 35.1949 167.828 35.1949 167.998C35.1949 168.167 35.1949 168.42 35.2792 168.589C35.3635 168.758 35.4478 168.927 35.5321 169.096C35.7007 169.265 35.785 169.35 36.0379 169.435C36.2065 169.519 36.4594 169.519 36.628 169.519C36.7967 169.519 37.0496 169.519 37.2182 169.435C37.3868 169.35 37.5554 169.265 37.724 169.096C37.8926 168.927 37.9769 168.758 38.0612 168.589C38.0612 168.42 38.1455 168.251 38.1455 167.998Z" fill=white></path>
                                        <path d="M39.7476 166.899C39.7476 166.73 39.7476 166.645 39.7476 166.476C39.7476 166.307 39.7476 166.222 39.7476 166.053H40.3377V166.645C40.5063 166.391 40.6749 166.222 40.9278 166.138C41.1807 166.053 41.4336 165.969 41.6022 165.969C41.6865 165.969 41.8551 165.969 41.9394 165.969C42.0237 165.969 42.1923 166.053 42.2766 166.053C42.3609 166.138 42.5295 166.222 42.6138 166.307C42.6981 166.391 42.7824 166.561 42.8667 166.73C42.951 166.476 43.1196 166.307 43.3725 166.138C43.6254 165.969 43.8783 165.884 44.1312 165.884C44.6371 165.884 44.9743 166.053 45.2272 166.307C45.4801 166.561 45.5644 166.983 45.5644 167.49V170.026H44.9743V167.659C44.9743 167.237 44.89 166.983 44.8057 166.73C44.6371 166.476 44.3842 166.391 44.0469 166.391C43.8783 166.391 43.6254 166.391 43.5411 166.476C43.3725 166.561 43.2882 166.645 43.2039 166.814C43.1196 166.983 43.0353 167.068 43.0353 167.237C43.0353 167.406 42.951 167.575 42.951 167.744V169.857H42.4452V167.659C42.4452 167.237 42.3609 166.983 42.2766 166.73C42.108 166.476 41.8551 166.391 41.5179 166.391C41.5179 166.391 41.4336 166.391 41.265 166.391C41.1807 166.391 41.0121 166.476 40.9278 166.561C40.7592 166.645 40.6749 166.814 40.5906 166.983C40.5063 167.152 40.422 167.49 40.422 167.828V169.857H39.8319V166.899H39.7476Z" fill=white></path>
                                        <path d="M53.2354 169.942H52.6453V169.35C52.561 169.519 52.4767 169.604 52.3081 169.688C52.2238 169.773 52.0552 169.857 51.8866 169.942C51.718 170.026 51.6337 170.026 51.4651 170.111C51.2965 170.111 51.2122 170.111 51.0436 170.111C50.7064 170.111 50.4535 170.026 50.2006 169.942C49.9477 169.857 49.6948 169.688 49.5262 169.519C49.3575 169.35 49.1889 169.097 49.1046 168.843C49.0203 168.589 48.936 168.336 48.936 167.998C48.936 167.66 49.0203 167.406 49.1046 167.152C49.1889 166.899 49.3575 166.645 49.5262 166.476C49.6948 166.307 49.9477 166.138 50.2006 166.053C50.4535 165.969 50.7064 165.884 51.0436 165.884C51.2122 165.884 51.2965 165.884 51.4651 165.884C51.6337 165.884 51.718 165.969 51.8866 166.053C52.0552 166.138 52.1395 166.223 52.3081 166.307C52.3924 166.392 52.561 166.476 52.6453 166.645V163.518H53.2354V169.942ZM49.6105 167.998C49.6105 168.251 49.6104 168.42 49.6948 168.589C49.7791 168.758 49.8634 168.927 50.032 169.097C50.2006 169.266 50.2849 169.35 50.5378 169.435C50.7064 169.519 50.9593 169.519 51.1279 169.519C51.3808 169.519 51.5494 169.519 51.718 169.435C51.8866 169.35 52.0552 169.266 52.2238 169.097C52.3924 168.927 52.4767 168.758 52.561 168.589C52.6453 168.42 52.6453 168.167 52.6453 167.998C52.6453 167.829 52.6453 167.575 52.561 167.406C52.4767 167.237 52.3924 167.068 52.2238 166.899C52.0552 166.73 51.8866 166.645 51.718 166.561C51.5494 166.476 51.2965 166.476 51.1279 166.476C50.875 166.476 50.7064 166.476 50.5378 166.561C50.3692 166.645 50.2006 166.73 50.032 166.899C49.8634 167.068 49.7791 167.237 49.6948 167.406C49.6104 167.575 49.6105 167.744 49.6105 167.998Z" fill=white></path>
                                        <path d="M54.8375 168.167C54.8375 168.336 54.9218 168.589 55.0061 168.758C55.0904 168.927 55.1747 169.096 55.3433 169.181C55.5119 169.265 55.5962 169.435 55.7648 169.519C55.9334 169.604 56.102 169.604 56.2706 169.604C56.6078 169.604 56.8607 169.519 57.0293 169.435C57.2822 169.265 57.4508 169.096 57.5352 168.927L57.9567 169.265C57.7038 169.604 57.4508 169.773 57.1979 169.942C56.945 170.111 56.6078 170.111 56.2706 170.111C56.0177 170.111 55.6805 170.026 55.4276 169.942C55.1747 169.857 54.9218 169.688 54.7532 169.519C54.5846 169.35 54.416 169.096 54.3317 168.843C54.2474 168.589 54.1631 168.336 54.1631 167.998C54.1631 167.659 54.2474 167.406 54.3317 167.152C54.416 166.899 54.5846 166.645 54.7532 166.476C54.9218 166.307 55.1747 166.138 55.4276 166.053C55.6805 165.969 55.9334 165.884 56.1863 165.884C56.5235 165.884 56.7764 165.969 57.0293 166.053C57.2822 166.138 57.4508 166.307 57.6195 166.476C57.7881 166.645 57.8724 166.899 57.9567 167.068C58.041 167.321 58.041 167.575 58.041 167.828V168.082H54.8375V168.167ZM57.4508 167.659C57.4508 167.321 57.3665 166.983 57.1136 166.73C56.8607 166.476 56.6078 166.391 56.1863 166.391C56.0177 166.391 55.8491 166.391 55.6805 166.476C55.5119 166.561 55.3433 166.645 55.259 166.73C55.1747 166.814 55.0061 166.983 54.9218 167.152C54.8375 167.321 54.8375 167.49 54.8375 167.659H57.4508Z" fill=white></path>
                                        <path d="M61.1599 166.561H59.9797V168.927C59.9797 169.096 59.9797 169.181 59.9797 169.266C59.9797 169.35 60.064 169.435 60.064 169.519C60.1483 169.604 60.1483 169.604 60.2326 169.604C60.3169 169.604 60.4012 169.604 60.4855 169.604C60.5698 169.604 60.6541 169.604 60.7384 169.604C60.8227 169.604 60.907 169.519 60.9913 169.519V170.026C60.8227 170.111 60.5698 170.195 60.2326 170.195C60.1483 170.195 59.9797 170.195 59.8954 170.195C59.8111 170.195 59.6425 170.111 59.5582 170.026C59.4739 169.942 59.3895 169.857 59.3052 169.688C59.2209 169.519 59.2209 169.35 59.2209 169.181V166.645H58.3779V166.138H59.2209V165.039H59.8111V166.138H60.9913V166.561H61.1599Z" fill=white></path>
                                        <path d="M64.2793 166.899C64.2793 166.73 64.2793 166.645 64.2793 166.476C64.2793 166.307 64.2793 166.222 64.2793 166.053H64.8694V166.645C65.038 166.391 65.2066 166.222 65.4595 166.138C65.7124 166.053 65.9653 165.969 66.1339 165.969C66.2182 165.969 66.3868 165.969 66.4711 165.969C66.5554 165.969 66.724 166.053 66.8083 166.053C66.8926 166.138 67.0613 166.222 67.1456 166.307C67.2299 166.391 67.3142 166.561 67.3985 166.73C67.4828 166.476 67.6514 166.307 67.9043 166.138C68.1572 165.969 68.4101 165.884 68.663 165.884C69.1688 165.884 69.506 166.053 69.7589 166.307C70.0118 166.561 70.0961 166.983 70.0961 167.49V170.026H69.506V167.659C69.506 167.237 69.4217 166.983 69.3374 166.73C69.1688 166.476 68.9159 166.391 68.5787 166.391C68.4101 166.391 68.1572 166.391 68.0729 166.476C67.9043 166.561 67.82 166.645 67.7357 166.814C67.6514 166.983 67.5671 167.068 67.5671 167.237C67.5671 167.406 67.4828 167.575 67.4828 167.744V169.857H66.8926V167.659C66.8926 167.237 66.8083 166.983 66.724 166.73C66.5554 166.476 66.3025 166.391 65.9653 166.391C65.9653 166.391 65.881 166.391 65.7124 166.391C65.6281 166.391 65.4595 166.476 65.3752 166.561C65.2066 166.645 65.1223 166.814 65.038 166.983C64.9537 167.152 64.8694 167.49 64.8694 167.828V169.857H64.2793V166.899Z" fill=white></path>
                                        <path d="M71.782 168.167C71.782 168.336 71.8663 168.589 71.9506 168.758C72.0349 168.927 72.1192 169.096 72.2878 169.181C72.4564 169.265 72.5407 169.435 72.7093 169.519C72.8779 169.604 73.0465 169.604 73.2994 169.604C73.6366 169.604 73.8895 169.519 74.0582 169.435C74.3111 169.265 74.4797 169.096 74.564 168.927L74.9855 169.265C74.7326 169.604 74.4797 169.773 74.2268 169.942C73.9738 170.111 73.6366 170.111 73.2994 170.111C73.0465 170.111 72.7093 170.026 72.4564 169.942C72.2035 169.857 71.9506 169.688 71.782 169.519C71.6134 169.35 71.4448 169.096 71.3605 168.843C71.2762 168.589 71.1919 168.336 71.1919 167.998C71.1919 167.659 71.2762 167.406 71.3605 167.152C71.4448 166.899 71.6134 166.645 71.782 166.476C71.9506 166.307 72.2035 166.138 72.4564 166.053C72.7093 165.969 72.9622 165.884 73.2151 165.884C73.5523 165.884 73.8052 165.969 74.0582 166.053C74.3111 166.138 74.4797 166.307 74.6483 166.476C74.8169 166.645 74.9012 166.899 74.9855 167.068C75.0698 167.321 75.0698 167.575 75.0698 167.828V168.082H71.782V168.167ZM74.4797 167.659C74.4797 167.321 74.3954 166.983 74.1425 166.73C73.8895 166.476 73.6366 166.391 73.2151 166.391C73.0465 166.391 72.8779 166.391 72.7093 166.476C72.5407 166.561 72.3721 166.645 72.2878 166.73C72.1192 166.814 72.0349 166.983 71.9506 167.152C71.8663 167.321 71.8663 167.49 71.8663 167.659H74.4797Z" fill=white></path>
                                        <path d="M78.1889 166.983C78.1046 166.814 78.0203 166.729 77.8517 166.56C77.6831 166.476 77.5145 166.391 77.3459 166.391C77.2616 166.391 77.1773 166.391 77.093 166.391C77.0087 166.391 76.9244 166.476 76.8401 166.476C76.7558 166.56 76.6715 166.56 76.6715 166.645C76.5872 166.729 76.5872 166.814 76.5872 166.899C76.5872 167.068 76.6715 167.237 76.7558 167.321C76.9244 167.406 77.093 167.49 77.3459 167.575L77.936 167.744C78.1889 167.828 78.4418 167.913 78.6104 168.082C78.779 168.251 78.8633 168.505 78.8633 168.758C78.8633 169.012 78.779 169.181 78.6947 169.35C78.6104 169.519 78.5261 169.603 78.3575 169.773C78.1889 169.857 78.0203 169.942 77.8517 170.026C77.6831 170.111 77.5145 170.111 77.2616 170.111C76.9244 170.111 76.6715 170.026 76.4186 169.942C76.1657 169.857 75.9127 169.603 75.7441 169.35L76.25 169.012C76.3343 169.181 76.5029 169.35 76.6715 169.434C76.8401 169.519 77.0087 169.603 77.2616 169.603C77.3459 169.603 77.5145 169.603 77.5988 169.603C77.6831 169.603 77.8517 169.519 77.936 169.519C78.0203 169.434 78.1046 169.434 78.1046 169.35C78.1889 169.265 78.1889 169.181 78.1889 169.096C78.1889 168.927 78.1046 168.758 77.936 168.674C77.7674 168.589 77.5988 168.505 77.4302 168.505L76.9244 168.336C76.8401 168.336 76.7558 168.251 76.6715 168.251C76.5872 168.251 76.4186 168.166 76.3343 168.082C76.2499 167.997 76.1657 167.913 76.0813 167.744C75.997 167.575 75.997 167.49 75.997 167.237C75.997 167.068 75.997 166.814 76.0813 166.729C76.1657 166.56 76.25 166.476 76.4186 166.391C76.5872 166.307 76.6715 166.222 76.9244 166.138C77.093 166.053 77.2616 166.053 77.4302 166.053C77.6831 166.053 77.936 166.138 78.1889 166.222C78.4418 166.307 78.6104 166.476 78.6947 166.814L78.1889 166.983Z" fill=white></path>
                                        <path d="M81.7294 166.561H80.6335V168.927C80.6335 169.096 80.6335 169.181 80.6335 169.266C80.6335 169.35 80.7178 169.435 80.7178 169.519C80.8021 169.604 80.8021 169.604 80.8864 169.604C80.9707 169.604 81.055 169.604 81.1393 169.604C81.2236 169.604 81.3079 169.604 81.3922 169.604C81.4765 169.604 81.5608 169.519 81.6451 169.519V170.026C81.4765 170.111 81.2236 170.195 80.8864 170.195C80.8021 170.195 80.6335 170.195 80.5492 170.195C80.4649 170.195 80.2963 170.111 80.212 170.026C80.1277 169.942 80.0434 169.857 79.9591 169.688C79.8748 169.519 79.8748 169.35 79.8748 169.181V166.645H79.0317V166.138H79.8748V165.039H80.4649V166.138H81.5608V166.561H81.7294Z" fill=white></path>
                                        <path d="M84.8486 163.602H85.4387V166.73C85.523 166.561 85.6073 166.476 85.776 166.392C85.8603 166.307 86.0289 166.222 86.1975 166.138C86.3661 166.053 86.4504 166.053 86.619 165.969C86.7876 165.884 86.8719 165.969 87.0405 165.969C87.3777 165.969 87.6306 166.053 87.8835 166.138C88.1364 166.222 88.3893 166.392 88.5579 166.561C88.7265 166.73 88.8951 166.983 88.9794 167.237C89.0637 167.49 89.148 167.744 89.148 168.082C89.148 168.42 89.0637 168.674 88.9794 168.927C88.8951 169.181 88.7265 169.435 88.5579 169.604C88.3893 169.773 88.1364 169.942 87.8835 170.026C87.6306 170.111 87.3777 170.195 87.0405 170.195C86.8719 170.195 86.7876 170.195 86.619 170.195C86.4504 170.195 86.3661 170.111 86.1975 170.026C86.0289 169.942 85.9446 169.857 85.776 169.773C85.6916 169.688 85.523 169.604 85.4387 169.435V170.111H84.8486V163.602ZM88.4736 167.998C88.4736 167.744 88.4736 167.575 88.3893 167.406C88.305 167.237 88.2207 167.068 88.0521 166.899C87.8835 166.73 87.7992 166.645 87.5463 166.561C87.3777 166.476 87.1248 166.476 86.9562 166.476C86.7876 166.476 86.5347 166.476 86.2818 166.561C86.0289 166.645 85.9446 166.73 85.776 166.899C85.6073 167.068 85.523 167.237 85.4387 167.406C85.3544 167.575 85.3544 167.829 85.3544 167.998C85.3544 168.167 85.3544 168.42 85.4387 168.589C85.523 168.758 85.6073 168.927 85.776 169.096C85.9446 169.266 86.1132 169.35 86.2818 169.435C86.4504 169.519 86.7033 169.519 86.9562 169.519C87.2091 169.519 87.3777 169.519 87.5463 169.435C87.7149 169.35 87.8835 169.266 88.0521 169.096C88.2207 168.927 88.305 168.758 88.3893 168.589C88.3893 168.42 88.4736 168.251 88.4736 167.998Z" fill=white></path>
                                        <path d="M93.1948 168.167C93.1948 168.42 93.1948 168.589 93.2791 168.758C93.3634 168.927 93.4477 169.097 93.532 169.181C93.6163 169.266 93.7849 169.435 93.8692 169.435C94.0378 169.519 94.2064 169.519 94.375 169.519C94.5437 169.519 94.7123 169.519 94.7966 169.435C94.9652 169.435 95.0495 169.35 95.1338 169.266C95.2181 169.181 95.3024 169.097 95.3867 169.097C95.471 169.012 95.5553 168.927 95.5553 168.843L95.9768 169.181C95.7239 169.435 95.471 169.688 95.2181 169.773C94.9652 169.942 94.628 169.942 94.2907 169.942C93.9535 169.942 93.7006 169.857 93.4477 169.688C93.1948 169.519 92.9419 169.266 92.8576 169.012C92.689 169.35 92.4361 169.604 92.1832 169.688C91.9303 169.773 91.5931 169.857 91.1716 169.857C91.003 169.857 90.8344 169.857 90.6658 169.773C90.4972 169.688 90.3286 169.688 90.2443 169.519C90.0757 169.435 89.9914 169.266 89.9071 169.181C89.8228 169.097 89.8228 168.843 89.8228 168.674C89.8228 168.42 89.9071 168.167 89.9914 167.998C90.0757 167.829 90.2443 167.744 90.4129 167.66C90.5815 167.575 90.8344 167.49 91.003 167.49C91.2559 167.49 91.4245 167.49 91.6774 167.49H92.6047V167.237C92.6047 167.068 92.5204 166.899 92.5204 166.73C92.4361 166.561 92.3518 166.476 92.2675 166.392C92.1832 166.307 92.0146 166.223 91.9303 166.223C91.846 166.223 91.7617 166.223 91.6774 166.223C91.1716 166.223 90.8344 166.392 90.4972 166.73L90.16 166.307C90.3286 166.138 90.5815 165.969 90.8344 165.884C91.0873 165.8 91.4245 165.715 91.6774 165.715C92.0146 165.715 92.2675 165.8 92.5204 165.969C92.7733 166.138 92.9419 166.307 93.0262 166.476C93.1948 166.223 93.3634 166.053 93.6163 165.884C93.8692 165.715 94.1221 165.715 94.4593 165.715C94.7123 165.715 95.0495 165.8 95.2181 165.884C95.471 165.969 95.6396 166.138 95.8082 166.307C95.9768 166.476 96.0611 166.73 96.1454 166.899C96.2297 167.152 96.2297 167.406 96.2297 167.66V167.913H93.1948V168.167ZM91.5088 168.167C91.4245 168.167 91.2559 168.167 91.1716 168.167C91.0873 168.167 90.9187 168.251 90.8344 168.251C90.7501 168.336 90.6658 168.336 90.5815 168.42C90.4972 168.505 90.4972 168.589 90.4972 168.758C90.4972 168.927 90.4972 169.012 90.5815 169.097C90.6658 169.181 90.6658 169.266 90.8344 169.35C90.9187 169.435 91.003 169.435 91.1716 169.435C91.2559 169.435 91.4245 169.435 91.5088 169.435C91.6774 169.435 91.9303 169.435 92.0989 169.35C92.2675 169.266 92.4361 169.181 92.5204 169.097C92.6047 169.012 92.689 168.843 92.7733 168.674C92.8576 168.505 92.8576 168.336 92.8576 168.167V168.082H91.5088V168.167ZM95.6396 167.66C95.6396 167.49 95.6396 167.321 95.5553 167.152C95.471 166.983 95.3867 166.899 95.3024 166.73C95.2181 166.645 95.0495 166.561 94.8809 166.476C94.7123 166.392 94.5437 166.392 94.375 166.392C94.2064 166.392 94.0378 166.392 93.8692 166.476C93.7006 166.561 93.6163 166.645 93.532 166.73C93.4477 166.814 93.3634 166.983 93.2791 167.152C93.1948 167.321 93.1948 167.49 93.1948 167.66H95.6396Z" fill=white></path>
                                        <path d="M97.2412 167.237C97.2412 167.068 97.2412 166.899 97.2412 166.73C97.2412 166.56 97.2412 166.307 97.2412 166.053H97.8313V166.814C97.8313 166.73 97.9156 166.645 97.9999 166.476C98.0842 166.391 98.1685 166.307 98.2528 166.222C98.3371 166.138 98.5057 166.053 98.59 166.053C98.6743 166.053 98.8429 165.969 99.0958 165.969C99.2644 165.969 99.433 165.969 99.5173 166.053L99.433 166.645C99.3487 166.645 99.2644 166.645 99.0958 166.645C98.8429 166.645 98.6743 166.645 98.5057 166.73C98.3371 166.814 98.2528 166.899 98.0842 167.068C97.9999 167.237 97.9156 167.321 97.8313 167.49C97.747 167.659 97.747 167.744 97.747 167.913V170.111H97.2412V167.237Z" fill=white></path>
                                        <path d="M100.192 168.167C100.192 168.336 100.276 168.589 100.36 168.758C100.445 168.927 100.529 169.096 100.697 169.181C100.866 169.265 100.95 169.435 101.119 169.519C101.288 169.604 101.456 169.604 101.709 169.604C102.046 169.604 102.299 169.519 102.468 169.435C102.721 169.265 102.889 169.096 102.974 168.927L103.395 169.265C103.142 169.604 102.889 169.773 102.636 169.942C102.384 170.111 102.046 170.111 101.709 170.111C101.456 170.111 101.119 170.026 100.866 169.942C100.613 169.857 100.36 169.688 100.192 169.519C100.023 169.35 99.8545 169.096 99.7702 168.843C99.6859 168.589 99.6016 168.336 99.6016 167.998C99.6016 167.659 99.6859 167.406 99.7702 167.152C99.8545 166.899 100.023 166.645 100.192 166.476C100.36 166.307 100.613 166.138 100.866 166.053C101.119 165.969 101.372 165.884 101.625 165.884C101.962 165.884 102.215 165.969 102.468 166.053C102.721 166.138 102.889 166.307 103.058 166.476C103.227 166.645 103.311 166.899 103.395 167.068C103.479 167.321 103.479 167.575 103.479 167.828V168.082H100.192V168.167ZM102.889 167.659C102.889 167.321 102.805 166.983 102.552 166.73C102.299 166.476 102.046 166.391 101.625 166.391C101.456 166.391 101.288 166.391 101.119 166.476C100.95 166.561 100.782 166.645 100.697 166.73C100.529 166.814 100.445 166.983 100.36 167.152C100.276 167.321 100.276 167.49 100.276 167.659H102.889Z" fill=white></path>
                                        <path d="M108.453 169.942H107.863V169.35C107.779 169.519 107.694 169.604 107.526 169.688C107.442 169.773 107.273 169.857 107.104 169.942C106.936 170.026 106.851 170.026 106.683 170.111C106.514 170.111 106.43 170.111 106.261 170.111C105.924 170.111 105.671 170.026 105.418 169.942C105.165 169.857 104.913 169.688 104.744 169.519C104.575 169.35 104.407 169.097 104.322 168.843C104.238 168.589 104.154 168.336 104.154 167.998C104.154 167.66 104.238 167.406 104.322 167.152C104.407 166.899 104.575 166.645 104.744 166.476C104.913 166.307 105.165 166.138 105.418 166.053C105.671 165.969 105.924 165.884 106.261 165.884C106.43 165.884 106.514 165.884 106.683 165.884C106.851 165.884 106.936 165.969 107.104 166.053C107.273 166.138 107.357 166.223 107.526 166.307C107.61 166.392 107.779 166.476 107.863 166.645V163.518H108.453V169.942ZM104.828 167.998C104.828 168.251 104.828 168.42 104.913 168.589C104.997 168.758 105.081 168.927 105.25 169.097C105.418 169.266 105.503 169.35 105.756 169.435C105.924 169.519 106.177 169.519 106.346 169.519C106.599 169.519 106.767 169.519 106.936 169.435C107.104 169.35 107.273 169.266 107.442 169.097C107.61 168.927 107.694 168.758 107.779 168.589C107.863 168.42 107.863 168.167 107.863 167.998C107.863 167.829 107.863 167.575 107.779 167.406C107.694 167.237 107.61 167.068 107.442 166.899C107.273 166.73 107.104 166.645 106.936 166.561C106.767 166.476 106.514 166.476 106.346 166.476C106.093 166.476 105.924 166.476 105.756 166.561C105.587 166.645 105.418 166.73 105.25 166.899C105.081 167.068 104.997 167.237 104.913 167.406C104.913 167.575 104.828 167.744 104.828 167.998Z" fill=white></path>
                                        <path d="M111.151 169.265L112.331 165.969H113.006L111.067 170.956C110.982 171.294 110.814 171.463 110.645 171.717C110.477 171.886 110.224 171.97 109.886 171.97C109.802 171.97 109.718 171.97 109.634 171.97C109.549 171.97 109.465 171.97 109.381 171.886L109.465 171.379C109.549 171.463 109.718 171.463 109.886 171.463C110.055 171.463 110.224 171.379 110.392 171.294C110.477 171.21 110.561 170.956 110.645 170.787L110.898 170.026L109.296 166.053H109.971L111.151 169.265Z" fill=white></path>
                                        <path d="M114.017 170.787C114.186 171.041 114.355 171.21 114.692 171.294C114.945 171.463 115.282 171.463 115.535 171.463C115.788 171.463 116.041 171.463 116.209 171.379C116.378 171.294 116.546 171.21 116.715 171.041C116.799 170.872 116.884 170.703 116.968 170.533C117.052 170.364 117.052 170.111 117.052 169.942V169.266C116.884 169.519 116.631 169.688 116.378 169.857C116.125 169.942 115.872 170.026 115.535 170.026C115.198 170.026 114.945 169.942 114.692 169.857C114.439 169.773 114.186 169.604 114.017 169.435C113.849 169.266 113.68 169.012 113.596 168.758C113.512 168.505 113.427 168.251 113.427 167.913C113.427 167.575 113.512 167.321 113.596 167.068C113.68 166.814 113.849 166.645 114.017 166.392C114.186 166.222 114.439 166.053 114.692 165.969C114.945 165.884 115.198 165.8 115.535 165.8C115.619 165.8 115.788 165.8 115.872 165.8C115.956 165.8 116.125 165.884 116.294 165.884C116.462 165.969 116.546 166.053 116.715 166.138C116.884 166.222 116.968 166.392 117.052 166.476V165.8H117.642V169.688C117.642 169.942 117.642 170.111 117.558 170.364C117.474 170.618 117.389 170.872 117.221 171.041C117.052 171.21 116.884 171.379 116.546 171.548C116.294 171.717 115.872 171.717 115.45 171.717C115.029 171.717 114.692 171.632 114.439 171.548C114.102 171.379 113.849 171.21 113.596 170.956L114.017 170.787ZM114.102 167.913C114.102 168.082 114.102 168.336 114.186 168.505C114.27 168.674 114.355 168.843 114.523 169.012C114.692 169.181 114.776 169.266 114.945 169.35C115.113 169.435 115.282 169.435 115.535 169.435C115.703 169.435 115.956 169.435 116.125 169.35C116.294 169.266 116.462 169.181 116.631 169.012C116.799 168.843 116.884 168.758 116.968 168.505C117.052 168.251 117.052 168.082 117.052 167.913C117.052 167.744 117.052 167.49 116.968 167.321C116.884 167.152 116.799 166.983 116.715 166.814C116.546 166.645 116.462 166.561 116.209 166.476C115.956 166.392 115.788 166.392 115.619 166.392C115.45 166.392 115.198 166.392 115.029 166.476C114.86 166.561 114.692 166.645 114.607 166.814C114.439 166.983 114.355 167.152 114.27 167.321C114.186 167.49 114.102 167.744 114.102 167.913Z" fill=white></path>
                                        <path d="M120.93 166.561H119.75V168.927C119.75 169.096 119.75 169.181 119.75 169.266C119.75 169.35 119.834 169.435 119.834 169.519C119.918 169.604 119.918 169.604 120.003 169.604C120.087 169.604 120.171 169.604 120.255 169.604C120.34 169.604 120.424 169.604 120.508 169.604C120.593 169.604 120.677 169.519 120.761 169.519V170.026C120.593 170.111 120.34 170.195 120.003 170.195C119.918 170.195 119.75 170.195 119.665 170.195C119.581 170.195 119.412 170.111 119.328 170.026C119.244 169.942 119.16 169.857 119.075 169.688C118.991 169.519 118.991 169.35 118.991 169.181V166.645H118.148V166.138H118.991V165.039H119.581V166.138H120.761V166.561H120.93Z" fill=white></path>
                                        <path d="M122.448 164.532C122.448 164.617 122.448 164.786 122.279 164.786C122.195 164.87 122.11 164.87 122.026 164.87C121.942 164.87 121.857 164.87 121.773 164.786C121.689 164.701 121.604 164.617 121.604 164.532C121.604 164.447 121.605 164.278 121.773 164.278C121.857 164.194 121.942 164.194 122.026 164.194C122.11 164.194 122.195 164.194 122.279 164.278C122.448 164.278 122.448 164.363 122.448 164.532ZM122.363 169.942H121.773V165.969H122.363V169.942Z" fill=white></path>
                                        <path d="M123.965 170.787C124.133 171.041 124.302 171.21 124.639 171.294C124.892 171.463 125.229 171.463 125.482 171.463C125.735 171.463 125.988 171.463 126.241 171.379C126.41 171.294 126.578 171.21 126.747 171.041C126.831 170.872 126.915 170.703 127 170.533C127.084 170.364 127.084 170.111 127.084 169.942V169.266C126.915 169.519 126.662 169.688 126.41 169.857C126.157 169.942 125.904 170.026 125.567 170.026C125.229 170.026 124.976 169.942 124.724 169.857C124.471 169.773 124.218 169.604 124.049 169.435C123.88 169.266 123.712 169.012 123.628 168.758C123.543 168.505 123.459 168.251 123.459 167.913C123.459 167.575 123.543 167.321 123.628 167.068C123.712 166.814 123.88 166.645 124.049 166.392C124.218 166.222 124.471 166.053 124.724 165.969C124.976 165.884 125.229 165.8 125.567 165.8C125.651 165.8 125.819 165.8 125.904 165.8C126.072 165.8 126.157 165.884 126.325 165.884C126.494 165.969 126.578 166.053 126.747 166.138C126.915 166.222 127 166.392 127.084 166.476V165.8H127.674V169.688C127.674 169.942 127.674 170.111 127.59 170.364C127.505 170.618 127.421 170.872 127.253 171.041C127.084 171.21 126.915 171.379 126.578 171.548C126.325 171.717 125.904 171.717 125.482 171.717C125.061 171.717 124.724 171.632 124.471 171.548C124.133 171.379 123.88 171.21 123.628 170.956L123.965 170.787ZM124.133 167.913C124.133 168.082 124.133 168.336 124.218 168.505C124.302 168.674 124.386 168.843 124.555 169.012C124.724 169.181 124.808 169.266 124.976 169.35C125.145 169.435 125.314 169.435 125.567 169.435C125.735 169.435 125.988 169.435 126.157 169.35C126.325 169.266 126.494 169.181 126.662 169.012C126.831 168.843 126.915 168.758 127 168.505C127.084 168.251 127.084 168.082 127.084 167.913C127.084 167.744 127.084 167.49 127 167.321C126.915 167.152 126.831 166.983 126.747 166.814C126.662 166.645 126.494 166.561 126.241 166.476C126.072 166.392 125.819 166.392 125.651 166.392C125.482 166.392 125.229 166.392 125.061 166.476C124.892 166.561 124.724 166.645 124.639 166.814C124.555 166.983 124.386 167.152 124.302 167.321C124.218 167.49 124.133 167.744 124.133 167.913Z" fill=white></path>
                                        <path d="M129.276 168.167C129.276 168.336 129.36 168.589 129.444 168.758C129.529 168.927 129.613 169.096 129.781 169.181C129.95 169.265 130.034 169.435 130.203 169.519C130.372 169.604 130.54 169.604 130.793 169.604C131.13 169.604 131.383 169.519 131.552 169.435C131.805 169.265 131.973 169.096 132.058 168.927L132.479 169.265C132.226 169.604 131.973 169.773 131.72 169.942C131.467 170.111 131.13 170.111 130.793 170.111C130.54 170.111 130.203 170.026 129.95 169.942C129.697 169.857 129.444 169.688 129.276 169.519C129.107 169.35 128.938 169.096 128.854 168.843C128.77 168.589 128.686 168.336 128.686 167.998C128.686 167.659 128.77 167.406 128.854 167.152C128.938 166.899 129.107 166.645 129.276 166.476C129.444 166.307 129.697 166.138 129.95 166.053C130.203 165.969 130.456 165.884 130.709 165.884C131.046 165.884 131.299 165.969 131.552 166.053C131.805 166.138 131.973 166.307 132.142 166.476C132.311 166.645 132.395 166.899 132.479 167.068C132.563 167.321 132.563 167.575 132.563 167.828V168.082H129.276V168.167ZM131.889 167.659C131.889 167.321 131.805 166.983 131.552 166.73C131.299 166.476 131.046 166.391 130.624 166.391C130.456 166.391 130.287 166.391 130.119 166.476C129.95 166.561 129.781 166.645 129.697 166.73C129.529 166.814 129.444 166.983 129.36 167.152C129.276 167.321 129.276 167.49 129.276 167.659H131.889Z" fill=white></path>
                                        <path d="M34.0146 173.746H34.6048V176.873C34.6891 176.704 34.7734 176.62 34.942 176.535C35.0263 176.451 35.1949 176.366 35.3635 176.281C35.5321 176.197 35.6164 176.197 35.785 176.112C35.9536 176.028 36.0379 176.112 36.2065 176.112C36.5437 176.112 36.7966 176.197 37.0495 176.281C37.3024 176.366 37.5553 176.535 37.7239 176.704C37.8925 176.873 38.0611 177.127 38.1454 177.38C38.2297 177.634 38.314 177.888 38.314 178.226C38.314 178.564 38.2297 178.817 38.1454 179.071C38.0611 179.325 37.8925 179.578 37.7239 179.747C37.5553 179.916 37.3024 180.085 37.0495 180.17C36.7966 180.254 36.5437 180.339 36.2065 180.339C36.0379 180.339 35.9536 180.339 35.785 180.339C35.6164 180.339 35.5321 180.254 35.3635 180.17C35.1949 180.085 35.1106 180.001 34.942 179.916C34.8577 179.832 34.6891 179.747 34.6048 179.578V180.254H34.0146V173.746ZM37.6396 178.141C37.6396 177.888 37.6396 177.718 37.5553 177.549C37.471 177.38 37.3867 177.211 37.2181 177.042C37.0495 176.873 36.9652 176.789 36.7123 176.704C36.5437 176.62 36.2908 176.62 36.1222 176.62C35.8693 176.62 35.7007 176.62 35.4478 176.704C35.2792 176.789 35.1106 176.873 34.942 177.042C34.7734 177.211 34.6891 177.38 34.6048 177.549C34.5205 177.718 34.5205 177.972 34.5205 178.141C34.5205 178.31 34.5205 178.564 34.6048 178.733C34.6891 178.902 34.7734 179.071 34.942 179.24C35.1106 179.409 35.2792 179.494 35.4478 179.578C35.6164 179.663 35.8693 179.663 36.1222 179.663C36.3751 179.663 36.5437 179.663 36.7123 179.578C36.8809 179.494 37.0495 179.409 37.2181 179.24C37.3867 179.071 37.471 178.902 37.5553 178.733C37.5553 178.564 37.6396 178.395 37.6396 178.141Z" fill=white></path>
                                        <path d="M39.2415 177.38C39.2415 177.211 39.2415 177.042 39.2415 176.873C39.2415 176.704 39.2415 176.45 39.2415 176.197H39.7473V176.958C39.7473 176.873 39.8316 176.789 39.9159 176.619C40.0002 176.535 40.0845 176.45 40.1688 176.366C40.2531 176.281 40.4218 176.197 40.5061 176.197C40.6747 176.112 40.759 176.112 41.0119 176.112C41.1805 176.112 41.3491 176.112 41.4334 176.197L41.3491 176.789C41.2648 176.789 41.1805 176.789 41.0119 176.789C40.759 176.789 40.5904 176.789 40.5061 176.873C40.4218 176.958 40.2532 177.042 40.0845 177.211C40.0002 177.38 39.9159 177.465 39.8316 177.634C39.7473 177.803 39.7473 177.887 39.7473 178.056V180.254H39.1572V177.38H39.2415Z" fill=white></path>
                                        <path d="M44.4678 177.634C44.4678 176.958 44.1306 176.62 43.4562 176.62C43.0347 176.62 42.6132 176.789 42.276 177.042L41.9388 176.62C42.276 176.197 42.8661 176.028 43.6248 176.028C43.7934 176.028 43.962 176.028 44.2149 176.112C44.3835 176.197 44.5521 176.281 44.6364 176.366C44.7207 176.45 44.8894 176.62 44.9737 176.789C45.058 176.958 45.058 177.211 45.058 177.38V179.155C45.058 179.324 45.058 179.494 45.058 179.663C45.058 179.832 45.058 180.001 45.1423 180.085H44.6364C44.6364 180.001 44.6364 179.916 44.6364 179.747C44.6364 179.663 44.6364 179.494 44.6364 179.409C44.4678 179.663 44.2992 179.832 44.0463 180.001C43.7934 180.085 43.5405 180.17 43.2033 180.17C43.0347 180.17 42.8661 180.17 42.6975 180.085C42.5289 180.001 42.3603 180.001 42.276 179.832C42.1917 179.747 42.0231 179.578 41.9388 179.494C41.8545 179.324 41.8545 179.155 41.8545 178.986C41.8545 178.648 41.9388 178.395 42.1074 178.226C42.276 178.057 42.4446 177.887 42.6975 177.803C42.9504 177.718 43.2033 177.634 43.4562 177.634C43.7091 177.634 43.962 177.634 44.2149 177.634H44.4678ZM44.2149 178.141C44.0463 178.141 43.8777 178.141 43.7091 178.141C43.5405 178.141 43.2876 178.226 43.119 178.226C42.9504 178.226 42.7818 178.395 42.6132 178.479C42.4446 178.564 42.4446 178.733 42.4446 178.902C42.4446 179.071 42.4446 179.155 42.5289 179.24C42.6132 179.324 42.6132 179.409 42.7818 179.494C42.8661 179.578 42.9504 179.578 43.119 179.578C43.2033 179.578 43.3719 179.578 43.4562 179.578C43.6248 179.578 43.7934 179.578 43.962 179.494C44.1306 179.409 44.2149 179.324 44.2992 179.24C44.3835 179.155 44.4678 178.986 44.5521 178.817C44.6364 178.648 44.6364 178.479 44.6364 178.31V178.057H44.2149V178.141Z" fill=white></path>
                                        <path d="M46.9127 176.197C46.9127 176.281 46.9127 176.45 46.9127 176.535C46.9127 176.62 46.9127 176.704 46.9127 176.873C46.997 176.789 47.0813 176.704 47.1656 176.535C47.2499 176.45 47.3342 176.366 47.5028 176.281C47.5871 176.197 47.7557 176.197 47.84 176.112C48.0086 176.112 48.0929 176.028 48.2615 176.028C48.7673 176.028 49.1045 176.197 49.3574 176.45C49.6103 176.704 49.6946 177.127 49.6946 177.634V180.17H49.1888V177.972C49.1888 177.549 49.1045 177.211 48.9359 176.958C48.7673 176.704 48.5144 176.62 48.0929 176.62C48.0929 176.62 48.0086 176.62 47.84 176.62C47.6714 176.62 47.5871 176.704 47.4185 176.789C47.2499 176.873 47.1656 177.042 46.997 177.211C46.9127 177.38 46.8284 177.718 46.8284 178.057V180.085H46.2383V176.958C46.2383 176.873 46.2383 176.704 46.2383 176.535C46.2383 176.366 46.2383 176.197 46.2383 176.112H46.9127V176.197Z" fill=white></path>
                                        <path d="M55.0059 180.085H54.4158V179.494C54.3315 179.663 54.2472 179.747 54.0786 179.832C53.9943 179.916 53.8257 180.001 53.6571 180.085C53.4885 180.17 53.4042 180.17 53.2356 180.254C53.067 180.254 52.9827 180.254 52.8141 180.254C52.4769 180.254 52.224 180.17 51.9711 180.085C51.7182 180.001 51.4653 179.832 51.2967 179.663C51.128 179.494 50.9594 179.24 50.8751 178.986C50.7908 178.733 50.7065 178.479 50.7065 178.141C50.7065 177.803 50.7908 177.549 50.8751 177.296C50.9594 177.042 51.128 176.789 51.2967 176.62C51.4653 176.451 51.7182 176.282 51.9711 176.197C52.224 176.112 52.4769 176.028 52.8141 176.028C52.9827 176.028 53.067 176.028 53.2356 176.028C53.4042 176.028 53.4885 176.112 53.6571 176.197C53.8257 176.282 53.91 176.366 54.0786 176.451C54.1629 176.535 54.3315 176.62 54.4158 176.789V173.661H55.0059V180.085ZM51.381 178.141C51.381 178.395 51.381 178.564 51.4653 178.733C51.5496 178.902 51.6339 179.071 51.8025 179.24C51.9711 179.409 52.0554 179.494 52.3083 179.578C52.4769 179.663 52.7298 179.663 52.8984 179.663C53.1513 179.663 53.3199 179.663 53.4885 179.578C53.6571 179.494 53.8257 179.409 53.9943 179.24C54.1629 179.071 54.2472 178.902 54.3315 178.733C54.4158 178.564 54.4158 178.31 54.4158 178.141C54.4158 177.972 54.4158 177.719 54.3315 177.549C54.2472 177.38 54.1629 177.211 53.9943 177.042C53.8257 176.873 53.6571 176.789 53.4885 176.704C53.3199 176.62 53.067 176.62 52.8984 176.62C52.6455 176.62 52.4769 176.62 52.3083 176.704C52.1397 176.789 51.9711 176.873 51.8025 177.042C51.6339 177.211 51.5496 177.38 51.4653 177.549C51.381 177.719 51.381 177.888 51.381 178.141Z" fill=white></path>
                                        <path d="M59.3051 174.676C59.3051 174.76 59.2208 174.929 59.1365 174.929C59.0522 175.014 58.9679 175.014 58.8836 175.014C58.7993 175.014 58.715 175.014 58.6307 174.929C58.5464 174.845 58.5464 174.76 58.5464 174.676C58.5464 174.591 58.5464 174.422 58.6307 174.422C58.715 174.422 58.7993 174.337 58.8836 174.337C58.9679 174.337 59.0522 174.337 59.1365 174.422C59.3051 174.422 59.3051 174.506 59.3051 174.676ZM59.2208 180.085H58.6307V176.113H59.2208V180.085Z" fill=white></path>
                                        <path d="M64.9535 177.127C64.8692 176.958 64.7849 176.873 64.6163 176.704C64.4477 176.619 64.2791 176.535 64.1105 176.535C64.0262 176.535 63.9419 176.535 63.8576 176.535C63.7733 176.535 63.689 176.619 63.6047 176.619C63.5204 176.619 63.4361 176.704 63.4361 176.788C63.3518 176.873 63.3518 176.958 63.3518 177.042C63.3518 177.211 63.4361 177.38 63.5204 177.465C63.689 177.549 63.8576 177.634 64.1105 177.718L64.7006 177.887C64.9535 177.972 65.2064 178.056 65.375 178.225C65.5436 178.395 65.6279 178.648 65.6279 178.902C65.6279 179.155 65.5436 179.324 65.4593 179.493C65.375 179.662 65.2907 179.747 65.1221 179.916C64.9535 180.001 64.7849 180.085 64.6163 180.17C64.4477 180.254 64.2791 180.254 64.0262 180.254C63.689 180.254 63.4361 180.17 63.1832 180.085C62.9303 180.001 62.6774 179.747 62.5088 179.493L63.0146 179.155C63.0989 179.324 63.2675 179.493 63.4361 179.578C63.6047 179.662 63.7733 179.747 64.0262 179.747C64.1105 179.747 64.2791 179.747 64.3634 179.747C64.4477 179.747 64.6163 179.662 64.7006 179.662C64.7849 179.578 64.8692 179.578 64.8692 179.493C64.9535 179.409 64.9535 179.324 64.9535 179.24C64.9535 179.071 64.8692 178.902 64.7006 178.817C64.532 178.733 64.3634 178.648 64.1948 178.648L63.689 178.479C63.6047 178.479 63.5204 178.395 63.4361 178.395C63.3518 178.395 63.1832 178.31 63.0989 178.225C63.0146 178.141 62.9303 178.056 62.846 177.887C62.7617 177.718 62.7617 177.634 62.7617 177.38C62.7617 177.211 62.7617 176.958 62.846 176.873C62.9303 176.704 63.0146 176.619 63.1832 176.535C63.3518 176.45 63.4361 176.366 63.689 176.281C63.9419 176.197 64.0262 176.197 64.1948 176.197C64.4477 176.197 64.7006 176.281 64.9535 176.366C65.2064 176.45 65.375 176.619 65.4593 176.958L64.9535 177.127Z" fill=white></path>
                                        <path d="M67.3139 174.676C67.3139 174.76 67.2296 174.929 67.1453 174.929C67.061 175.014 66.9767 175.014 66.8924 175.014C66.8081 175.014 66.7238 175.014 66.6395 174.929C66.5552 174.845 66.5552 174.76 66.5552 174.676C66.5552 174.591 66.5552 174.422 66.6395 174.422C66.7238 174.422 66.8081 174.337 66.8924 174.337C66.9767 174.337 67.061 174.337 67.1453 174.422C67.2296 174.422 67.3139 174.506 67.3139 174.676ZM67.1453 180.085H66.5552V176.113H67.1453V180.085Z" fill=white></path>
                                        <path d="M68.9999 176.197C68.9999 176.281 68.9999 176.45 68.9999 176.535C68.9999 176.62 68.9999 176.704 68.9999 176.873C69.0842 176.789 69.1685 176.704 69.2528 176.535C69.3371 176.45 69.4214 176.366 69.59 176.281C69.6743 176.197 69.8429 176.197 69.9272 176.112C70.0959 176.112 70.1802 176.028 70.3488 176.028C70.8546 176.028 71.1918 176.197 71.4447 176.45C71.6976 176.704 71.7819 177.127 71.7819 177.634V180.17H71.1918V177.972C71.1918 177.549 71.1075 177.211 70.9389 176.958C70.7703 176.704 70.5174 176.62 70.0959 176.62C70.0959 176.62 70.0116 176.62 69.8429 176.62C69.6743 176.62 69.59 176.704 69.4214 176.789C69.2528 176.873 69.1685 177.042 68.9999 177.211C68.9156 177.38 68.8313 177.718 68.8313 178.057V180.085H68.2412V176.958C68.2412 176.873 68.2412 176.704 68.2412 176.535C68.2412 176.366 68.2412 176.197 68.2412 176.112H68.9999V176.197Z" fill=white></path>
                                        <path d="M75.5752 173.746H76.1653V176.873C76.2496 176.704 76.3339 176.62 76.5025 176.535C76.6711 176.451 76.7554 176.366 76.924 176.281C77.0926 176.197 77.1769 176.197 77.3455 176.112C77.5141 176.028 77.5984 176.112 77.767 176.112C78.1042 176.112 78.3571 176.197 78.6101 176.281C78.863 176.366 79.1159 176.535 79.2845 176.704C79.4531 176.873 79.6217 177.127 79.706 177.38C79.7903 177.634 79.8746 177.888 79.8746 178.226C79.8746 178.564 79.7903 178.817 79.706 179.071C79.6217 179.325 79.4531 179.578 79.2845 179.747C79.1159 179.916 78.863 180.085 78.6101 180.17C78.3571 180.254 78.1042 180.339 77.767 180.339C77.5984 180.339 77.5141 180.339 77.3455 180.339C77.1769 180.339 77.0926 180.254 76.924 180.17C76.7554 180.085 76.6711 180.001 76.5025 179.916C76.3339 179.832 76.2496 179.747 76.1653 179.578V180.254H75.5752V173.746ZM79.1159 178.141C79.1159 177.888 79.1159 177.718 79.0316 177.549C78.9473 177.38 78.863 177.211 78.6944 177.042C78.5258 176.873 78.4415 176.789 78.1885 176.704C77.9356 176.62 77.767 176.62 77.5984 176.62C77.3455 176.62 77.1769 176.62 76.924 176.704C76.7554 176.789 76.5868 176.873 76.4182 177.042C76.2496 177.211 76.1653 177.38 76.081 177.549C75.9967 177.718 75.9967 177.972 75.9967 178.141C75.9967 178.31 75.9967 178.564 76.081 178.733C76.1653 178.902 76.2496 179.071 76.4182 179.24C76.5868 179.409 76.7554 179.494 76.924 179.578C77.0926 179.663 77.3455 179.663 77.5984 179.663C77.8513 179.663 78.0199 179.663 78.1885 179.578C78.3571 179.494 78.5258 179.409 78.6944 179.24C78.863 179.071 78.9473 178.902 79.0316 178.733C79.1159 178.564 79.1159 178.395 79.1159 178.141Z" fill=white></path>
                                        <path d="M80.7176 177.38C80.7176 177.211 80.7176 177.042 80.7176 176.873C80.7176 176.704 80.7176 176.45 80.7176 176.197H81.2234V176.958C81.2234 176.873 81.3077 176.789 81.392 176.619C81.4763 176.535 81.5606 176.45 81.6449 176.366C81.7292 176.281 81.8978 176.197 81.9821 176.197C82.1507 176.112 82.235 176.112 82.4879 176.112C82.6565 176.112 82.7408 176.112 82.9094 176.197L82.8251 176.789C82.7408 176.789 82.6565 176.789 82.4879 176.789C82.235 176.789 82.0664 176.789 81.9821 176.873C81.8135 176.958 81.7292 177.042 81.5606 177.211C81.392 177.38 81.392 177.465 81.3077 177.634C81.2234 177.803 81.2234 177.887 81.2234 178.056V180.254H80.6333V177.38H80.7176Z" fill=white></path>
                                        <path d="M86.0289 177.634C86.0289 176.958 85.6917 176.62 85.0173 176.62C84.5958 176.62 84.1742 176.789 83.837 177.042L83.4998 176.62C83.837 176.197 84.4271 176.028 85.1859 176.028C85.3545 176.028 85.5231 176.028 85.776 176.112C85.9446 176.197 86.1132 176.281 86.1975 176.366C86.2818 176.45 86.4504 176.62 86.5347 176.789C86.619 176.958 86.619 177.211 86.619 177.38V179.155C86.619 179.324 86.619 179.494 86.619 179.663C86.619 179.832 86.619 180.001 86.7033 180.085H86.1975C86.1975 180.001 86.1975 179.916 86.1975 179.747C86.1975 179.663 86.1975 179.494 86.1975 179.409C86.0289 179.663 85.8603 179.832 85.6074 180.001C85.3545 180.085 85.1016 180.17 84.7644 180.17C84.5957 180.17 84.4271 180.17 84.2585 180.085C84.0899 180.001 83.9213 180.001 83.837 179.832C83.6684 179.747 83.5841 179.578 83.4998 179.494C83.4155 179.409 83.4155 179.155 83.4155 178.986C83.4155 178.648 83.4998 178.395 83.6684 178.226C83.837 178.057 84.0056 177.887 84.2585 177.803C84.5114 177.718 84.7644 177.634 85.0173 177.634C85.2702 177.634 85.5231 177.634 85.776 177.634H86.0289ZM85.6917 178.141C85.5231 178.141 85.3545 178.141 85.1859 178.141C85.0173 178.141 84.7644 178.226 84.5958 178.226C84.4271 178.31 84.2585 178.395 84.0899 178.479C83.9213 178.564 83.9213 178.733 83.9213 178.902C83.9213 179.071 83.9213 179.155 84.0056 179.24C84.0899 179.324 84.0899 179.409 84.2585 179.494C84.3428 179.578 84.4271 179.578 84.5958 179.578C84.6801 179.578 84.8487 179.578 84.933 179.578C85.1016 179.578 85.2702 179.578 85.4388 179.494C85.6074 179.409 85.6917 179.324 85.776 179.24C85.8603 179.155 85.9446 178.986 86.0289 178.817C86.1132 178.648 86.1132 178.479 86.1132 178.31V178.057H85.6917V178.141Z" fill=white></path>
                                        <path d="M88.3891 176.197C88.3891 176.281 88.3891 176.45 88.3891 176.535C88.3891 176.62 88.3891 176.704 88.3891 176.873C88.4734 176.789 88.5577 176.704 88.642 176.535C88.7263 176.45 88.8106 176.366 88.9792 176.281C89.0635 176.197 89.2321 176.197 89.3164 176.112C89.485 176.112 89.5693 176.028 89.7379 176.028C90.2437 176.028 90.5809 176.197 90.8338 176.45C91.0867 176.704 91.1711 177.127 91.1711 177.634V180.17H90.5809V177.972C90.5809 177.549 90.4966 177.211 90.328 176.958C90.1594 176.704 89.9065 176.62 89.485 176.62C89.485 176.62 89.4007 176.62 89.2321 176.62C89.0635 176.62 88.9792 176.704 88.8106 176.789C88.642 176.873 88.5577 177.042 88.3891 177.211C88.3048 177.38 88.2205 177.718 88.2205 178.057V180.085H87.6304V176.958C87.6304 176.873 87.6304 176.704 87.6304 176.535C87.6304 176.366 87.6304 176.197 87.6304 176.112H88.3891V176.197Z" fill=white></path>
                                        <path d="M95.3863 177.127C95.302 176.958 95.1333 176.873 94.9647 176.789C94.7961 176.704 94.6275 176.62 94.3746 176.62C94.1217 176.62 93.9531 176.62 93.7845 176.704C93.6159 176.789 93.4473 176.873 93.2787 177.042C93.1101 177.211 93.0258 177.38 93.0258 177.549C92.9415 177.718 92.9415 177.972 92.9415 178.141C92.9415 178.31 92.9415 178.564 93.0258 178.733C93.1101 178.902 93.1944 179.071 93.2787 179.24C93.363 179.409 93.5316 179.494 93.7845 179.578C93.9531 179.663 94.206 179.663 94.3746 179.663C94.6275 179.663 94.7961 179.578 94.9647 179.494C95.1333 179.409 95.302 179.24 95.3863 179.155L95.8078 179.494C95.6392 179.747 95.3863 179.916 95.1333 180.001C94.8804 180.085 94.6275 180.17 94.3746 180.17C94.0374 180.17 93.7845 180.085 93.5316 180.001C93.2787 179.916 93.0258 179.747 92.8572 179.578C92.6886 179.409 92.52 179.155 92.4357 178.902C92.3514 178.648 92.2671 178.395 92.2671 178.057C92.2671 177.718 92.3514 177.465 92.4357 177.211C92.52 176.958 92.6886 176.704 92.8572 176.535C93.0258 176.366 93.2787 176.197 93.5316 176.112C93.7845 176.028 94.0374 175.943 94.3746 175.943C94.6275 175.943 94.8804 176.028 95.1333 176.112C95.3863 176.197 95.6392 176.366 95.8078 176.62L95.3863 177.127Z" fill=white></path>
                                        <path d="M96.651 173.746H97.2411V176.789C97.3254 176.704 97.4097 176.62 97.494 176.451C97.5783 176.366 97.6626 176.281 97.8312 176.197C97.9155 176.112 98.0842 176.112 98.1685 176.028C98.3371 176.028 98.4214 175.943 98.59 175.943C99.0958 175.943 99.433 176.112 99.6859 176.366C99.9388 176.62 100.023 177.042 100.023 177.549V180.085H99.433V177.888C99.433 177.465 99.3487 177.127 99.1801 176.873C99.0115 176.62 98.7586 176.535 98.3371 176.535C98.3371 176.535 98.2528 176.535 98.0842 176.535C97.9156 176.535 97.8312 176.62 97.6626 176.704C97.494 176.789 97.4097 176.958 97.2411 177.127C97.1568 177.296 97.0725 177.634 97.0725 177.972V180.001H96.4824V173.746H96.651Z" fill=white></path>
                                        <path d="M101.709 178.31C101.709 178.479 101.793 178.733 101.877 178.902C101.962 179.071 102.046 179.24 102.215 179.324C102.383 179.409 102.467 179.578 102.636 179.663C102.805 179.747 102.973 179.747 103.226 179.747C103.563 179.747 103.816 179.663 103.985 179.578C104.238 179.409 104.406 179.24 104.491 179.071L104.912 179.409C104.659 179.747 104.406 179.916 104.154 180.085C103.901 180.254 103.563 180.254 103.226 180.254C102.973 180.254 102.636 180.17 102.383 180.085C102.13 180.001 101.877 179.832 101.709 179.663C101.54 179.494 101.372 179.24 101.287 178.986C101.203 178.733 101.119 178.479 101.119 178.141C101.119 177.803 101.203 177.549 101.287 177.296C101.372 177.042 101.54 176.789 101.709 176.62C101.877 176.45 102.13 176.281 102.383 176.197C102.636 176.112 102.889 176.028 103.142 176.028C103.479 176.028 103.732 176.112 103.985 176.197C104.238 176.281 104.406 176.45 104.575 176.62C104.744 176.789 104.828 177.042 104.912 177.211C104.997 177.465 104.997 177.718 104.997 177.972V178.226H101.709V178.31ZM104.406 177.803C104.406 177.465 104.322 177.127 104.069 176.873C103.816 176.62 103.563 176.535 103.142 176.535C102.973 176.535 102.805 176.535 102.636 176.62C102.467 176.704 102.299 176.789 102.215 176.873C102.046 176.958 101.962 177.127 101.877 177.296C101.793 177.465 101.793 177.634 101.793 177.803H104.406Z" fill=white></path>
                                    </g>
                                    <defs>
                                        <clippath id=clip0_5402_2669>
                                            <rect width=138 height=195 fill=white></rect>
                                        </clippath>
                                    </defs>
                                </svg>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="layout-footer-sub bg-gray-900">
                    <div class="inner inner--full">
                        <div class="flex justify-center py-6 flex-col sm:flex-row md:flex-wrap">
                            <div class="row flex flex-col flex-1 md:flex-row md:flex-none md:mb-4 lg:mb-0">
                                <p class="text-white mb-6 md:mb-0 hover:underline">
                                    <a href=https://andelenergi.dk />
                                    <span class="text-body-2xs mr-6">
                                        © Andel Energi 2024
                                    </span>
                                    </a>
                                </p>
                                <p class="text-white mb-6 md:mb-0 hover:underline">
                                    <a href=https://andelenergi.dk/om-os />
                                    <span class="text-body-2xs mr-6">
                                        Om os
                                    </span>
                                    </a>
                                </p>
                                <p class="text-white mb-6 md:mb-0 hover:underline">
                                    <a href=https://andelenergi.dk/om-os/job-og-karriere />
                                    <span class="text-body-2xs mr-6">
                                        Job og karriere
                                    </span>
                                    </a>
                                </p>
                                <p class="text-white mb-6 md:mb-0 hover:underline">
                                    <a href=https://andelenergi.dk/generelt/dine-vilkaar />
                                    <span class="text-body-2xs mr-6">
                                        Vilkår og betingelser
                                    </span>
                                    </a>
                                </p>
                                <p class="text-white mb-6 md:mb-0 hover:underline">
                                    <a href=https://ens.dk/ansvarsomraader/el/elkunder>
                                        <span class="text-body-2xs mr-6">
                                            Rettigheder for elkunder
                                        </span>
                                    </a>
                                </p>
                            </div>
                            <div class="row flex flex-col flex-1 md:flex-row md:flex-none">
                                <p class="text-white mb-6 md:mb-0 hover:underline">
                                    <a href=https://andelenergi.dk/cookie-politik />
                                    <span class="text-body-2xs mr-6">
                                        Cookiepolitik
                                    </span>
                                    </a>
                                </p>
                                <p class="text-white mb-6 md:mb-0 hover:underline">
                                    <a href=https://andelenergi.dk/generelt/privatlivspolitik />
                                    <span class="text-body-2xs mr-6">
                                        Privatlivspolitik
                                    </span>
                                    </a>
                                </p>
                                <p class="text-white mb-6 md:mb-0 hover:underline">
                                    <a href=https://andelenergi.dk/kundeservice/kontakt-os/klage />
                                    <span class="text-body-2xs mr-6">
                                        Klage
                                    </span>
                                    </a>
                                </p>
                                <p class="text-white mb-6 md:mb-0 hover:underline">
                                    <a href=https://andelenergi.dk/generelt/whistleblower />
                                    <span class="text-body-2xs mr-6">
                                        Whistleblower
                                    </span>
                                    </a>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <aside class="mobile-menu lg:hidden fixed top-0 left-0 bg-white flex flex-col h-screen w-full z-30" x-show=$store.MobileMenu.isOpen x-trap=$store.MobileMenu.isOpen x-transition:enter="transition duration-500" x-transition:enter-start=translate-x-full x-transition:enter-end=translate-x-0 x-transition:leave="transition duration-500" x-transition:leave-start=translate-x-0 x-transition:leave-end=translate-x-full style=display:none>


        </aside>
        <aside class="mobile-menu-logged-in lg:hidden fixed top-0 left-0 bg-white flex flex-col h-screen w-full z-30" x-trap=$store.MobileMenuLoggedIn.isOpen x-show=$store.MobileMenuLoggedIn.isOpen x-transition:enter="transition duration-500" x-transition:enter-start=translate-x-full x-transition:enter-end=translate-x-0 x-transition:leave="transition duration-500" x-transition:leave-start=translate-x-0 x-transition:leave-end=translate-x-full style=display:none>


        </aside>
        <aside class="site-overlay fixed w-full h-screen left-0 top-0 bg-[#000] bg-opacity-50 z-20" @click=$store.SiteOverlay.onClick() :class="$store.SiteOverlay.isBehindHeader ? 'z-10' : 'z-20' " x-show=$store.SiteOverlay.isOpen x-transition:enter="transition ease-out duration-300" x-transition:enter-start=opacity-0 x-transition:enter-end=opacity-100 x-transition:leave="transition ease-out duration-400" x-transition:leave-start=opacity-100 x-transition:leave-end=opacity-0 style=display:none>
        </aside>
        <aside class="login fixed top-0 left-0 w-full h-screen z-30 p-4 pointer-events-none" data-config="{&quot;RedirectOnSignInUrl&quot;:&quot;https:\/\/andelenergi.dk\/min-side&quot;,&quot;LoginHeading&quot;:&quot;Log ind&quot;,&quot;LoginText&quot;:&quot;&quot;,&quot;LoginBtnLabelForgotPassword&quot;:&quot;Glemt adgangskode?&quot;,&quot;LoginBtnLabelUserPass&quot;:&quot;Log ind&quot;,&quot;PreLoginBtnLabelOneTime&quot;:&quot;Opret login&quot;,&quot;PreLoginBtnLabelOneTimeInMail&quot;:&quot;Send mig engangslogin&quot;,&quot;ShowLoginBtnOneTimeInMail&quot;:true,&quot;MagicLinkText&quot;:&quot;<p>Skriv din mail, s\u00e5 f\u00e5r du en bekr\u00e6ftelseskode til at oprette din nye adgangskode.<\/p>\n&quot;,&quot;MagicLinkBtnLabelUser&quot;:&quot;Send bekr\u00e6ftelseskode&quot;,&quot;PreLoginBtnLabelUserPass&quot;:&quot;Tilbage&quot;,&quot;MagicCodeText&quot;:&quot;<p>Inds\u00e6t bekr\u00e6ftelseskoden fra mailen.<\/p>\n&quot;,&quot;MagicCodeReSendCodeText&quot;:&quot;F\u00e5 tilsendt en ny kode&quot;,&quot;MagicLinkBtnLabelCode&quot;:&quot;N\u00e6ste&quot;,&quot;SendMagicLinkSuccessText&quot;:&quot;Du f\u00e5r en bekr\u00e6ftelseskode p\u00e5 mail inden for f\u00e5 minutter. Tjek evt. 'u\u00f8nsket mail'.&quot;,&quot;ReSendMagicLinkSuccessText&quot;:&quot;Du f\u00e5r en ny bekr\u00e6ftelseskode p\u00e5 mail inden for f\u00e5 minutter. Tjek evt. 'u\u00f8nsket mail'.&quot;,&quot;MagicPasswordText&quot;:&quot;<p><strong>Opret adgangskode<\/strong><\/p>\n<p>Adgangskoden skal v\u00e6re mindst 8 valgfrie tegn.<\/p>\n&quot;,&quot;MagicLinkBtnLabelPassword&quot;:&quot;Gem og log ind&quot;,&quot;SendMagicLinkMailCreateLoginLink&quot;:&quot;Opret dit login med det samme&quot;,&quot;SendMagicLinkMailCreateLoginMessage&quot;:&quot;S\u00e5 kan du nemt logge ind med din mail og adgangskode n\u00e6ste gang.&quot;,&quot;SendMagicLinkMailBtnLabelContinue&quot;:&quot;Forts\u00e6t med engangslogin&quot;,&quot;SendMagicLinkText&quot;:&quot;<p>Skriv din mail, s\u00e5 f\u00e5r du en mail med et engangslogin.<\/p>\n&quot;,&quot;SendMagicLinkBtnLabel&quot;:&quot;Send mig engangslogin&quot;,&quot;SendMagicLinkMailSuccessText&quot;:&quot;Du f\u00e5r en mail med et engangslogin inden for f\u00e5 minutter. Tjek evt. 'u\u00f8nsket mail'.&quot;,&quot;UnknownError&quot;:&quot;Der skete en fejl. Pr\u00f8v igen senere.&quot;,&quot;WrongEmailOrPasswordError&quot;:&quot;Vi kan ikke genkende din mail eller adgangskode.\u00a0M\u00e5ske du bruger en anden mail hos os? Ellers s\u00e5 v\u00e6lg \u2018Opret login\u2019.&quot;,&quot;WrongEmailOrPasswordErrorMagicLink&quot;:&quot;Vi kan ikke genkende dit engangslogin.\u00a0Hvis du kopierer linket fra mailen, s\u00e5 tjek, at du f\u00e5r det hele med, eller klik direkte p\u00e5 linket. Virker det stadig ikke? S\u00e5 v\u00e6lg \u2018Opret login\u2019.&quot;,&quot;CustomerBlockedError&quot;:&quot;Du kan\u00a0desv\u00e6rre ikke\u00a0logge ind \u2013 ring\u00a0til os p\u00e5\u00a070\u00a029 29 29,\u00a0s\u00e5\u00a0hj\u00e6lper vi\u00a0dig.&quot;,&quot;CustomerInactiveError&quot;:&quot;Du er ikke l\u00e6ngere kunde hos Andel Energi. Har du\u00a0fortrudt, eller er det en fejl? S\u00e5\u00a0ring til os p\u00e5\u00a070 29 28 60.&quot;,&quot;PasswordAttemptsExceededError&quot;:&quot;Du har tastet forkert for mange gange. Vent et\u00a0kvarter, og pr\u00f8v\u00a0igen.&quot;,&quot;CodeMissingError&quot;:&quot;Husk at udfylde dette felt.&quot;,&quot;SessionExpiredError&quot;:&quot;Dit engangslogin er desv\u00e6rre\u00a0udl\u00f8bet. Pr\u00f8v igen, og husk, at \u00e5bne linket i samme browser-vindue, som du bestilte det. Virker det stadig ikke? S\u00e5 v\u00e6lg \u2018Opret login\u2019 i stedet.&quot;,&quot;UserDoesNotExistError&quot;:&quot;<p>Vi kan ikke genkende din mail. M\u00e5ske du bruger en anden mail hos os? Virker det stadig ikke, s\u00e5 skal vi bruge lidt flere oplysninger om dig. <a href=\&quot;https:\/\/andelenergi.dk\/min-side\/opret-login\/\&quot;>Indtast oplysninger<\/a><\/p>\n&quot;,&quot;SessionMissingError&quot;:&quot;Der skete en fejl. For at undg\u00e5 det skal du blive p\u00e5 den samme enhed og i det samme browser-vindue. Bestiller du f.eks. i Chrome, skal du ogs\u00e5 \u00e5bne linket i Chrome. Bestiller du p\u00e5 din mobil, skal du \u00e5bne det her. Pr\u00f8v igen, eller v\u00e6lg \u2018Opret login\u2019 i stedet.&quot;,&quot;CodeAttemptsExceededError&quot;:&quot;Du har tastet forkert for mange gange. Vent et\u00a0kvarter, og pr\u00f8v igen.\u00a0&quot;,&quot;WrongCodeError&quot;:&quot;Vi kan ikke genkende bekr\u00e6ftelseskoden. Tjek, at du har skrevet rigtigt, ret direkte i feltet, og klik 'Gem og log ind'. Virker det ikke? &quot;,&quot;CodeUserOrExpiredError&quot;:&quot;Din bekr\u00e6ftelseskode er desv\u00e6rre udl\u00f8bet.&quot;,&quot;ValidateEmailText&quot;:&quot;Skriv en gyldig mail.&quot;,&quot;ValidateCodeText&quot;:&quot;Vi kan ikke genkende bekr\u00e6ftelseskoden. Den skal best\u00e5 af 6 cifre.&quot;,&quot;ValidatePasswordText&quot;:&quot;Din adgangskode skal v\u00e6re mindst 8 tegn.&quot;,&quot;ValidatePasswordRepeatText&quot;:&quot;Dine adgangskode skal v\u00e6re ens i begge felter.&quot;}" x-trap=$store.Login.isOpen x-show=$store.Login.isOpen x-transition:enter="transition duration-500" x-transition:enter-start=opacity-0 x-transition:enter-end=opacity-100 x-transition:leave="transition duration-500" x-transition:leave-start=opacity-100 x-transition:leave-end=opacity-0 style=display:none>

        </aside>
    </div>
    <div id=pum-7435 class="pum pum-overlay pum-theme-6988 pum-theme-orsted-default-backdrop popmake-overlay click_open sf-hidden" data-popmake='{"id":7435,"slug":"standard-cpr-felt","theme_id":6988,"cookies":[],"triggers":[{"type":"click_open","settings":{"cookie_name":"","extra_selectors":""}}],"mobile_disabled":null,"tablet_disabled":null,"meta":{"display":{"stackable":false,"overlay_disabled":false,"scrollable_content":false,"disable_reposition":false,"size":"medium","responsive_min_width":"0%","responsive_min_width_unit":false,"responsive_max_width":"600px","responsive_max_width_unit":false,"custom_width":"640px","custom_width_unit":false,"custom_height":"380px","custom_height_unit":false,"custom_height_auto":false,"location":"center","position_from_trigger":false,"position_top":"100","position_left":"0","position_bottom":"0","position_right":"0","position_fixed":false,"animation_type":"fade","animation_speed":"350","animation_origin":"center top","overlay_zindex":false,"zindex":"1999999999"},"close":{"text":"","button_delay":"0","overlay_click":false,"esc_press":false,"f4_press":false},"click_open":[]}}' role=dialog aria-modal=false>

    </div>
    <div id=pum-8663 class="pum pum-overlay pum-theme-6988 pum-theme-orsted-default-backdrop popmake-overlay pum-click-to-close click_open sf-hidden" data-popmake='{"id":8663,"slug":"fortryd-i-14-dage","theme_id":6988,"cookies":[],"triggers":[{"type":"click_open","settings":{"cookie_name":"","extra_selectors":""}}],"mobile_disabled":null,"tablet_disabled":null,"meta":{"display":{"stackable":false,"overlay_disabled":false,"scrollable_content":false,"disable_reposition":false,"size":"medium","responsive_min_width":"0%","responsive_min_width_unit":false,"responsive_max_width":"600px","responsive_max_width_unit":false,"custom_width":"640px","custom_width_unit":false,"custom_height":"380px","custom_height_unit":false,"custom_height_auto":false,"location":"center","position_from_trigger":false,"position_top":"100","position_left":"0","position_bottom":"0","position_right":"0","position_fixed":false,"animation_type":"fade","animation_speed":"350","animation_origin":"center top","overlay_zindex":false,"zindex":"1999999999"},"close":{"text":"X","button_delay":"0","overlay_click":"1","esc_press":"1","f4_press":"1"},"click_open":[]}}' role=dialog aria-modal=false>

    </div>
    <div id=pum-165015 class="pum pum-overlay pum-theme-6988 pum-theme-orsted-default-backdrop popmake-overlay pum-click-to-close click_open sf-hidden" data-popmake='{"id":165015,"slug":"solcelleberegner-gem-beregning","theme_id":6988,"cookies":[],"triggers":[{"type":"click_open","settings":{"extra_selectors":""}}],"mobile_disabled":null,"tablet_disabled":null,"meta":{"display":{"stackable":false,"overlay_disabled":false,"scrollable_content":false,"disable_reposition":false,"size":"medium","responsive_min_width":"600px","responsive_min_width_unit":false,"responsive_max_width":"100%","responsive_max_width_unit":false,"custom_width":"640px","custom_width_unit":false,"custom_height":"380px","custom_height_unit":false,"custom_height_auto":false,"location":"center","position_from_trigger":false,"position_top":"100","position_left":"0","position_bottom":"0","position_right":"0","position_fixed":false,"animation_type":"fade","animation_speed":"350","animation_origin":"center top","overlay_zindex":false,"zindex":"1999999999"},"close":{"text":"","button_delay":"0","overlay_click":"1","esc_press":"1","f4_press":"1"},"click_open":[]}}' role=dialog aria-modal=false>
        <div id=popmake-165015 class="pum-container popmake theme-6988 pum-responsive pum-responsive-medium responsive size-medium sf-hidden">



            <div class="pum-content popmake-content sf-hidden" tabindex=0>
                <section class="block acf-block acf-block--form text-black mt-12 lg:mt-16 mb-12 lg:mb-16 sf-hidden" id=form-13>
                    <div class="inner inner--content sf-hidden">


                        <div class="inner--px-remove sf-hidden">
                            <div class="inner inner--prose sf-hidden">


                                <div class="wpforms-container varmepumpe-pop-formular sf-hidden" id=wpforms-165002>
                                    <form id=wpforms-form-165002 class="wpforms-validate wpforms-form sf-hidden" data-formid=165002 method=post enctype=multipart/form-data action=/opladning/evflw/ev-brik-step2-formular/ data-token=aef00875fc0a8746d20ee95afcb4dc51 novalidate><noscript class=wpforms-error-noscript>Please enable JavaScript in your browser to complete this form.</noscript></form>
                                </div>
                            </div>
                        </div>

                    </div>

                </section>
            </div>



        </div>
    </div>
    <div id=pum-148732 class="pum pum-overlay pum-theme-6988 pum-theme-orsted-default-backdrop popmake-overlay pum-click-to-close click_open sf-hidden" data-popmake='{"id":148732,"slug":"timeenergi-clever-prisen-i-detaljer-oest_vest","theme_id":6988,"cookies":[],"triggers":[{"type":"click_open","settings":{"extra_selectors":"","cookie_name":null}}],"mobile_disabled":null,"tablet_disabled":null,"meta":{"display":{"stackable":"1","overlay_disabled":false,"scrollable_content":false,"disable_reposition":false,"size":"large","responsive_min_width":"0%","responsive_min_width_unit":false,"responsive_max_width":"900px","responsive_max_width_unit":false,"custom_width":"640px","custom_width_unit":false,"custom_height":"380px","custom_height_unit":false,"custom_height_auto":false,"location":"center","position_from_trigger":false,"position_top":"100","position_left":"0","position_bottom":"0","position_right":"0","position_fixed":false,"animation_type":"fade","animation_speed":"350","animation_origin":"center top","overlay_zindex":false,"zindex":"1999999999"},"close":{"text":"X","button_delay":"0","overlay_click":"1","esc_press":"1","f4_press":"1"},"click_open":[]}}' role=dialog aria-modal=false>

    </div>
    <div id=pum-148783 class="pum pum-overlay pum-theme-6988 pum-theme-orsted-default-backdrop popmake-overlay pum-click-to-close click_open sf-hidden" data-popmake='{"id":148783,"slug":"timeenergi-prisen-i-detaljer-oest_vest","theme_id":6988,"cookies":[],"triggers":[{"type":"click_open","settings":{"extra_selectors":"","cookie_name":null}}],"mobile_disabled":null,"tablet_disabled":null,"meta":{"display":{"stackable":"1","overlay_disabled":false,"scrollable_content":false,"disable_reposition":false,"size":"large","responsive_min_width":"0%","responsive_min_width_unit":false,"responsive_max_width":"900px","responsive_max_width_unit":false,"custom_width":"640px","custom_width_unit":false,"custom_height":"380px","custom_height_unit":false,"custom_height_auto":false,"location":"center","position_from_trigger":false,"position_top":"100","position_left":"0","position_bottom":"0","position_right":"0","position_fixed":false,"animation_type":"fade","animation_speed":"350","animation_origin":"center top","overlay_zindex":false,"zindex":"1999999999"},"close":{"text":"X","button_delay":"0","overlay_click":"1","esc_press":"1","f4_press":"1"},"click_open":[]}}' role=dialog aria-modal=false>

    </div>
    <div id=pum-138510 class="pum pum-overlay pum-theme-7006 pum-theme-orsted-default-no-backdrop popmake-overlay pum-click-to-close click_open sf-hidden" data-popmake='{"id":138510,"slug":"fulde-navn-paa-tilflytter","theme_id":7006,"cookies":[],"triggers":[{"type":"click_open","settings":{"cookie_name":"","extra_selectors":""}}],"mobile_disabled":null,"tablet_disabled":null,"meta":{"display":{"stackable":false,"overlay_disabled":false,"scrollable_content":false,"disable_reposition":false,"size":"medium","responsive_min_width":"0%","responsive_min_width_unit":false,"responsive_max_width":"600px","responsive_max_width_unit":false,"custom_width":"640px","custom_width_unit":false,"custom_height":"380px","custom_height_unit":false,"custom_height_auto":false,"location":"center","position_from_trigger":false,"position_top":"100","position_left":"0","position_bottom":"0","position_right":"0","position_fixed":false,"animation_type":"fade","animation_speed":"350","animation_origin":"center top","overlay_zindex":false,"zindex":"1999999999"},"close":{"text":"X","button_delay":"0","overlay_click":"1","esc_press":"1","f4_press":"1"},"click_open":[]}}' role=dialog aria-modal=false>

    </div>
    <div id=pum-165009 class="pum pum-overlay pum-theme-6988 pum-theme-orsted-default-backdrop popmake-overlay pum-click-to-close click_open sf-hidden" data-popmake='{"id":165009,"slug":"solforudsaetninger","theme_id":6988,"cookies":[],"triggers":[{"type":"click_open","settings":{"extra_selectors":"","cookie_name":null}}],"mobile_disabled":null,"tablet_disabled":null,"meta":{"display":{"stackable":false,"overlay_disabled":false,"scrollable_content":false,"disable_reposition":false,"size":"medium","responsive_min_width":"60%","responsive_min_width_unit":false,"responsive_max_width":"600px","responsive_max_width_unit":false,"custom_width":"640px","custom_width_unit":false,"custom_height":"380px","custom_height_unit":false,"custom_height_auto":false,"location":"center","position_from_trigger":false,"position_top":"100","position_left":"0","position_bottom":"0","position_right":"0","position_fixed":false,"animation_type":"fade","animation_speed":"350","animation_origin":"center top","overlay_zindex":false,"zindex":"1999999999"},"close":{"text":"","button_delay":"0","overlay_click":"1","esc_press":"1","f4_press":"1"},"click_open":[]}}' role=dialog aria-modal=false>

    </div>
    <div id=pum-155758 class="pum pum-overlay pum-theme-6988 pum-theme-orsted-default-backdrop popmake-overlay pum-click-to-close click_open sf-hidden" data-popmake='{"id":155758,"slug":"ev-clever-timeenergi-og-brik-sammen","theme_id":6988,"cookies":[],"triggers":[{"type":"click_open","settings":{"extra_selectors":"","cookie_name":null}}],"mobile_disabled":null,"tablet_disabled":null,"meta":{"display":{"stackable":"1","overlay_disabled":false,"scrollable_content":false,"disable_reposition":false,"size":"medium","responsive_min_width":"0%","responsive_min_width_unit":false,"responsive_max_width":"600px","responsive_max_width_unit":false,"custom_width":"640px","custom_width_unit":false,"custom_height":"380px","custom_height_unit":false,"custom_height_auto":false,"location":"center","position_from_trigger":false,"position_top":"100","position_left":"0","position_bottom":"0","position_right":"0","position_fixed":false,"animation_type":"fade","animation_speed":"350","animation_origin":"center top","overlay_zindex":false,"zindex":"1999999999"},"close":{"text":"X","button_delay":"0","overlay_click":"1","esc_press":"1","f4_press":"1"},"click_open":[]}}' role=dialog aria-modal=false>

    </div>
    <div id=pum-147938 class="pum pum-overlay pum-theme-7006 pum-theme-orsted-default-no-backdrop popmake-overlay pum-click-to-close click_open sf-hidden" data-popmake='{"id":147938,"slug":"ev-clever-service-ingen-binding","theme_id":7006,"cookies":[],"triggers":[{"type":"click_open","settings":{"extra_selectors":"","cookie_name":null}}],"mobile_disabled":null,"tablet_disabled":null,"meta":{"display":{"stackable":"1","overlay_disabled":false,"scrollable_content":false,"disable_reposition":false,"size":"medium","responsive_min_width":"0%","responsive_min_width_unit":false,"responsive_max_width":"600px","responsive_max_width_unit":false,"custom_width":"640px","custom_width_unit":false,"custom_height":"380px","custom_height_unit":false,"custom_height_auto":false,"location":"center","position_from_trigger":false,"position_top":"100","position_left":"0","position_bottom":"0","position_right":"0","position_fixed":false,"animation_type":"fade","animation_speed":"350","animation_origin":"center top","overlay_zindex":false,"zindex":"1999999999"},"close":{"text":"X","button_delay":"0","overlay_click":"1","esc_press":"1","f4_press":"1"},"click_open":[]}}' role=dialog aria-modal=false>

    </div>



    <div id=automa-palette><template shadowrootmode=open>
            <style class=sf-hidden>
                .input-ui input[type="color"] {
                    padding-top: 0 !important;
                    padding-bottom: 0 !important
                }

                .tippy-box[data-animation=shift-toward-subtle][data-state=hidden] {
                    opacity: 0
                }

                .tippy-box[data-animation=shift-toward-subtle][data-state=hidden][data-placement^=top][data-state=hidden] {
                    transform: translateY(-5px)
                }

                .tippy-box[data-animation=shift-toward-subtle][data-state=hidden][data-placement^=bottom][data-state=hidden] {
                    transform: translateY(5px)
                }

                .tippy-box[data-animation=shift-toward-subtle][data-state=hidden][data-placement^=left][data-state=hidden] {
                    transform: translateX(-5px)
                }

                .tippy-box[data-animation=shift-toward-subtle][data-state=hidden][data-placement^=right][data-state=hidden] {
                    transform: translateX(5px)
                }

                .root {
                    font-size: 16px;
                    z-index: 99999;
                    line-height: 1.5 !important;
                    font-family: "Inter var", sans-serif;
                    font-feature-settings: "cv02", "cv03", "cv04", "cv11"
                }

                .root-card:hover .drag-button {
                    transform: scale(1)
                }

                .drag-button {
                    transform: scale(0);
                    transition: transform 200ms ease-in-out
                }

                .main-tab {
                    background-color: transparent !important;
                    padding: 0 !important
                }

                .main-tab .ui-tab.is-active.fill {
                    --tw-bg-opacity: 1 !important;
                    background-color: rgb(var(--color-accent)/var(--tw-bg-opacity)) !important;
                    --tw-text-opacity: 1 !important;
                    color: rgb(255 255 255/var(--tw-text-opacity)) !important
                }

                .ui-tab[data-v-681b5d14] {
                    z-index: 1;
                    border-bottom-width: 2px;
                    border-color: transparent;
                    padding-top: 12px;
                    padding-bottom: 12px;
                    padding-left: 8px;
                    padding-right: 8px
                }

                .ui-tab.small[data-v-681b5d14] {
                    padding: 8px
                }

                .ui-tab.fill[data-v-681b5d14] {
                    border-radius: 8px;
                    border-bottom-width: 0px;
                    padding-left: 16px;
                    padding-right: 16px;
                    padding-top: 8px;
                    padding-bottom: 8px
                }

                .ui-tab.fill.small[data-v-681b5d14] {
                    padding: 8px
                }

                .ui-tab.is-active[data-v-681b5d14] {
                    --tw-border-opacity: 1;
                    border-color: rgb(var(--color-accent)/var(--tw-border-opacity));
                    --tw-text-opacity: 1;
                    color: rgb(39 39 42/var(--tw-text-opacity))
                }

                [data-v-681b5d14]:is(.dark .ui-tab.is-active) {
                    --tw-border-opacity: 1;
                    border-color: rgb(244 244 245/var(--tw-border-opacity));
                    --tw-text-opacity: 1;
                    color: rgb(255 255 255/var(--tw-text-opacity))
                }

                .ui-tab.is-active.fill[data-v-681b5d14] {
                    background-color: rgb(0 0 0/var(--tw-bg-opacity));
                    --tw-bg-opacity: 0.05
                }

                [data-v-681b5d14]:is(.dark .ui-tab.is-active.fill) {
                    background-color: rgb(228 228 231/var(--tw-bg-opacity));
                    --tw-bg-opacity: 0.05
                }

                .ui-tab.is-active[data-v-681b5d14] {
                    --tw-border-opacity: 1;
                    border-color: rgb(var(--color-accent)/var(--tw-border-opacity));
                    --tw-text-opacity: 1;
                    color: rgb(39 39 42/var(--tw-text-opacity))
                }

                [data-v-681b5d14]:is(.dark .ui-tab.is-active) {
                    --tw-border-opacity: 1;
                    border-color: rgb(244 244 245/var(--tw-border-opacity));
                    --tw-text-opacity: 1;
                    color: rgb(255 255 255/var(--tw-text-opacity))
                }

                .ui-tabs__indicator {
                    min-height: 24px;
                    min-width: 50px;
                    transition-duration: 200ms;
                    transition-property: transform, width;
                    transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1)
                }

                .button-loading {
                    position: absolute;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%, -50%)
                }

                .ui-select__arrow {
                    top: 50%;
                    transform: translateY(-50%) rotate(90deg)
                }

                .ui-select option,
                .ui-select optgroup {
                    --tw-bg-opacity: 1;
                    background-color: rgb(244 244 245/var(--tw-bg-opacity))
                }

                :is(.dark .ui-select option),
                :is(.dark .ui-select optgroup) {
                    --tw-bg-opacity: 1;
                    background-color: rgb(63 63 70/var(--tw-bg-opacity))
                }

                .ui-switch[data-v-cc5de7b2] {
                    overflow: hidden;
                    transition: all 250ms ease
                }

                .ui-switch[data-v-cc5de7b2]:active {
                    transform: scale(0.93)
                }

                .ui-switch__ball[data-v-cc5de7b2] {
                    transition: all 250ms ease;
                    left: 6px
                }

                .ui-switch__background[data-v-cc5de7b2] {
                    transition: all 250ms ease;
                    margin-left: -100%
                }

                .ui-switch:hover .ui-switch__ball[data-v-cc5de7b2] {
                    transform: scale(1.1)
                }

                .ui-switch input:focus~.ui-switch__ball[data-v-cc5de7b2] {
                    transform: scale(1.1)
                }

                [data-v-cc5de7b2]:is(.dark .ui-switch input:checked~.ui-switch__ball) {
                    --tw-bg-opacity: 1;
                    background-color: rgb(24 24 27/var(--tw-bg-opacity))
                }

                .ui-switch input:checked~.ui-switch__ball[data-v-cc5de7b2] {
                    background-color: white;
                    left: calc(100% - 21px)
                }

                .ui-switch input:checked~.ui-switch__background[data-v-cc5de7b2] {
                    margin-left: 0
                }

                .checkbox-ui__input:checked~.checkbox-ui__mark .v-remixicon[data-v-32d46196],
                .checkbox-ui__input.indeterminate~.checkbox-ui__mark .v-remixicon[data-v-32d46196] {
                    transform: scale(1) !important
                }

                .checkbox-ui .v-remixicon[data-v-32d46196] {
                    transform: scale(0)
                }

                .checkbox-ui__input:checked~.checkbox-ui__mark[data-v-32d46196],
                .checkbox-ui__input.indeterminate~.checkbox-ui__mark[data-v-32d46196] {
                    --tw-border-opacity: 1;
                    border-color: rgb(var(--color-accent)/var(--tw-border-opacity));
                    background-color: rgb(var(--color-accent)/var(--tw-bg-opacity));
                    --tw-bg-opacity: 1
                }

                .checkbox-ui__mark[data-v-32d46196] {
                    width: 100%;
                    height: 100%;
                    transition-property: background-color, border-color;
                    transition-timing-function: ease;
                    transition-duration: 200ms;
                    display: flex;
                    align-items: center;
                    justify-content: center
                }

                .checkbox-ui__mark .v-remixicon[data-v-32d46196] {
                    transform: scale(0) !important;
                    transition: transform 200ms ease
                }

                .expand-enter-active,
                .expand-leave-active {
                    transition: height 0.2s ease-in-out;
                    overflow: hidden
                }

                .expand-enter,
                .expand-leave-to {
                    height: 0
                }

                *,
                ::before,
                ::after {
                    box-sizing: border-box;
                    border-width: 0;
                    border-style: solid;
                    border-color: #e4e4e7
                }

                ::before,
                ::after {
                    --tw-content: ""
                }

                html {
                    line-height: 1.5;
                    -webkit-text-size-adjust: 100%;
                    -moz-tab-size: 4;
                    -o-tab-size: 4;
                    tab-size: 4;
                    font-family: Poppins, sans-serif;
                    font-feature-settings: normal;
                    font-variation-settings: normal
                }

                body {
                    margin: 0;
                    line-height: inherit
                }

                hr {
                    height: 0;
                    color: inherit;
                    border-top-width: 1px
                }

                abbr:where([title]) {
                    -webkit-text-decoration: underline dotted;
                    text-decoration: underline dotted
                }

                h1,
                h2,
                h3,
                h4,
                h5,
                h6 {
                    font-size: inherit;
                    font-weight: inherit
                }

                a {
                    color: inherit;
                    text-decoration: inherit
                }

                b,
                strong {
                    font-weight: bolder
                }

                code,
                kbd,
                samp,
                pre {
                    font-family: Source Code Pro, monospace;
                    font-size: 1em
                }

                small {
                    font-size: 80%
                }

                sub,
                sup {
                    font-size: 75%;
                    line-height: 0;
                    position: relative;
                    vertical-align: baseline
                }

                sub {
                    bottom: -0.25em
                }

                sup {
                    top: -0.5em
                }

                table {
                    text-indent: 0;
                    border-color: inherit;
                    border-collapse: collapse
                }

                button,
                input,
                optgroup,
                select,
                textarea {
                    font-family: inherit;
                    font-feature-settings: inherit;
                    font-variation-settings: inherit;
                    font-size: 100%;
                    font-weight: inherit;
                    line-height: inherit;
                    color: inherit;
                    margin: 0;
                    padding: 0
                }

                button,
                select {
                    text-transform: none
                }

                button,
                [type="button"],
                [type="reset"],
                [type="submit"] {
                    -webkit-appearance: button;
                    background-color: transparent;
                    background-image: none
                }

                :-moz-focusring {
                    outline: auto
                }

                :-moz-ui-invalid {
                    box-shadow: none
                }

                progress {
                    vertical-align: baseline
                }

                ::-webkit-inner-spin-button,
                ::-webkit-outer-spin-button {
                    height: auto
                }

                [type="search"] {
                    -webkit-appearance: textfield;
                    outline-offset: -2px
                }

                ::-webkit-search-decoration {
                    -webkit-appearance: none
                }

                ::-webkit-file-upload-button {
                    -webkit-appearance: button;
                    font: inherit
                }

                summary {
                    display: list-item
                }

                blockquote,
                dl,
                dd,
                h1,
                h2,
                h3,
                h4,
                h5,
                h6,
                hr,
                figure,
                p,
                pre {
                    margin: 0
                }

                fieldset {
                    margin: 0;
                    padding: 0
                }

                legend {
                    padding: 0
                }

                ol,
                ul,
                menu {
                    list-style: none;
                    margin: 0;
                    padding: 0
                }

                dialog {
                    padding: 0
                }

                textarea {
                    resize: vertical
                }

                input::-moz-placeholder,
                textarea::-moz-placeholder {
                    opacity: 1;
                    color: #a1a1aa
                }

                input::placeholder,
                textarea::placeholder {
                    opacity: 1;
                    color: #a1a1aa
                }

                button,
                [role="button"] {
                    cursor: pointer
                }

                :disabled {
                    cursor: default
                }

                img,
                svg,
                video,
                canvas,
                audio,
                iframe,
                embed,
                object {
                    display: block;
                    vertical-align: middle
                }

                img,
                video {
                    max-width: 100%;
                    height: auto
                }

                [hidden] {
                    display: none
                }

                *,
                ::before,
                ::after {
                    --tw-border-spacing-x: 0;
                    --tw-border-spacing-y: 0;
                    --tw-translate-x: 0;
                    --tw-translate-y: 0;
                    --tw-rotate: 0;
                    --tw-skew-x: 0;
                    --tw-skew-y: 0;
                    --tw-scale-x: 1;
                    --tw-scale-y: 1;
                    --tw-pan-x: ;
                    --tw-pan-y: ;
                    --tw-pinch-zoom: ;
                    --tw-scroll-snap-strictness: proximity;
                    --tw-gradient-from-position: ;
                    --tw-gradient-via-position: ;
                    --tw-gradient-to-position: ;
                    --tw-ordinal: ;
                    --tw-slashed-zero: ;
                    --tw-numeric-figure: ;
                    --tw-numeric-spacing: ;
                    --tw-numeric-fraction: ;
                    --tw-ring-inset: ;
                    --tw-ring-offset-width: 0px;
                    --tw-ring-offset-color: #fff;
                    --tw-ring-color: rgb(59 130 246/0.5);
                    --tw-ring-offset-shadow: 0 0#0000;
                    --tw-ring-shadow: 0 0#0000;
                    --tw-shadow: 0 0#0000;
                    --tw-shadow-colored: 0 0#0000;
                    --tw-blur: ;
                    --tw-brightness: ;
                    --tw-contrast: ;
                    --tw-grayscale: ;
                    --tw-hue-rotate: ;
                    --tw-invert: ;
                    --tw-saturate: ;
                    --tw-sepia: ;
                    --tw-drop-shadow: ;
                    --tw-backdrop-blur: ;
                    --tw-backdrop-brightness: ;
                    --tw-backdrop-contrast: ;
                    --tw-backdrop-grayscale: ;
                    --tw-backdrop-hue-rotate: ;
                    --tw-backdrop-invert: ;
                    --tw-backdrop-opacity: ;
                    --tw-backdrop-saturate: ;
                    --tw-backdrop-sepia:
                }

                ::backdrop {
                    --tw-border-spacing-x: 0;
                    --tw-border-spacing-y: 0;
                    --tw-translate-x: 0;
                    --tw-translate-y: 0;
                    --tw-rotate: 0;
                    --tw-skew-x: 0;
                    --tw-skew-y: 0;
                    --tw-scale-x: 1;
                    --tw-scale-y: 1;
                    --tw-pan-x: ;
                    --tw-pan-y: ;
                    --tw-pinch-zoom: ;
                    --tw-scroll-snap-strictness: proximity;
                    --tw-gradient-from-position: ;
                    --tw-gradient-via-position: ;
                    --tw-gradient-to-position: ;
                    --tw-ordinal: ;
                    --tw-slashed-zero: ;
                    --tw-numeric-figure: ;
                    --tw-numeric-spacing: ;
                    --tw-numeric-fraction: ;
                    --tw-ring-inset: ;
                    --tw-ring-offset-width: 0px;
                    --tw-ring-offset-color: #fff;
                    --tw-ring-color: rgb(59 130 246/0.5);
                    --tw-ring-offset-shadow: 0 0#0000;
                    --tw-ring-shadow: 0 0#0000;
                    --tw-shadow: 0 0#0000;
                    --tw-shadow-colored: 0 0#0000;
                    --tw-blur: ;
                    --tw-brightness: ;
                    --tw-contrast: ;
                    --tw-grayscale: ;
                    --tw-hue-rotate: ;
                    --tw-invert: ;
                    --tw-saturate: ;
                    --tw-sepia: ;
                    --tw-drop-shadow: ;
                    --tw-backdrop-blur: ;
                    --tw-backdrop-brightness: ;
                    --tw-backdrop-contrast: ;
                    --tw-backdrop-grayscale: ;
                    --tw-backdrop-hue-rotate: ;
                    --tw-backdrop-invert: ;
                    --tw-backdrop-opacity: ;
                    --tw-backdrop-saturate: ;
                    --tw-backdrop-sepia:
                }

                .\!container {
                    width: 100% !important;
                    margin-right: auto !important;
                    margin-left: auto !important;
                    padding-right: 1rem !important;
                    padding-left: 1rem !important
                }

                .container {
                    width: 100%;
                    margin-right: auto;
                    margin-left: auto;
                    padding-right: 1rem;
                    padding-left: 1rem
                }

                @media (min-width:640px) {
                    .\!container {
                        max-width: 640px !important;
                        padding-right: 2rem !important;
                        padding-left: 2rem !important
                    }

                    .container {
                        max-width: 640px;
                        padding-right: 2rem;
                        padding-left: 2rem
                    }
                }

                @media (min-width:768px) {
                    .\!container {
                        max-width: 768px !important
                    }

                    .container {
                        max-width: 768px
                    }
                }

                @media (min-width:1024px) {
                    .\!container {
                        max-width: 1024px !important
                    }

                    .container {
                        max-width: 1024px
                    }
                }

                @media (min-width:1280px) {
                    .\!container {
                        max-width: 1280px !important
                    }

                    .container {
                        max-width: 1280px
                    }
                }

                @media (min-width:1536px) {
                    .\!container {
                        max-width: 1536px !important
                    }

                    .container {
                        max-width: 1536px
                    }
                }

                .prose {
                    color: var(--tw-prose-body);
                    max-width: 65ch
                }

                .prose :where(p):not(:where([class~="not-prose"] *)) {
                    margin-top: 1.25em;
                    margin-bottom: 1.25em
                }

                .prose :where([class~="lead"]):not(:where([class~="not-prose"] *)) {
                    color: var(--tw-prose-lead);
                    font-size: 1.25em;
                    line-height: 1.6;
                    margin-top: 1.2em;
                    margin-bottom: 1.2em
                }

                .prose :where(a):not(:where([class~="not-prose"] *)) {
                    color: var(--tw-prose-links);
                    text-decoration: underline;
                    font-weight: 500
                }

                .prose :where(strong):not(:where([class~="not-prose"] *)) {
                    color: var(--tw-prose-bold);
                    font-weight: 600
                }

                .prose :where(a strong):not(:where([class~="not-prose"] *)) {
                    color: inherit
                }

                .prose :where(blockquote strong):not(:where([class~="not-prose"] *)) {
                    color: inherit
                }

                .prose :where(thead th strong):not(:where([class~="not-prose"] *)) {
                    color: inherit
                }

                .prose :where(ol):not(:where([class~="not-prose"] *)) {
                    list-style-type: decimal;
                    margin-top: 1.25em;
                    margin-bottom: 1.25em;
                    padding-left: 1.625em
                }

                .prose :where(ol[type="A"]):not(:where([class~="not-prose"] *)) {
                    list-style-type: upper-alpha
                }

                .prose :where(ol[type="a"]):not(:where([class~="not-prose"] *)) {
                    list-style-type: lower-alpha
                }

                .prose :where(ol[type="A" s]):not(:where([class~="not-prose"] *)) {
                    list-style-type: upper-alpha
                }

                .prose :where(ol[type="a" s]):not(:where([class~="not-prose"] *)) {
                    list-style-type: lower-alpha
                }

                .prose :where(ol[type="I"]):not(:where([class~="not-prose"] *)) {
                    list-style-type: upper-roman
                }

                .prose :where(ol[type="i"]):not(:where([class~="not-prose"] *)) {
                    list-style-type: lower-roman
                }

                .prose :where(ol[type="I" s]):not(:where([class~="not-prose"] *)) {
                    list-style-type: upper-roman
                }

                .prose :where(ol[type="i" s]):not(:where([class~="not-prose"] *)) {
                    list-style-type: lower-roman
                }

                .prose :where(ol[type="1"]):not(:where([class~="not-prose"] *)) {
                    list-style-type: decimal
                }

                .prose :where(ul):not(:where([class~="not-prose"] *)) {
                    list-style-type: disc;
                    margin-top: 1.25em;
                    margin-bottom: 1.25em;
                    padding-left: 1.625em
                }

                .prose :where(ol>li):not(:where([class~="not-prose"] *))::marker {
                    font-weight: 400;
                    color: var(--tw-prose-counters)
                }

                .prose :where(ul>li):not(:where([class~="not-prose"] *))::marker {
                    color: var(--tw-prose-bullets)
                }

                .prose :where(hr):not(:where([class~="not-prose"] *)) {
                    border-color: var(--tw-prose-hr);
                    border-top-width: 1px;
                    margin-top: 3em;
                    margin-bottom: 3em
                }

                .prose :where(blockquote):not(:where([class~="not-prose"] *)) {
                    font-weight: 500;
                    font-style: italic;
                    color: var(--tw-prose-quotes);
                    border-left-width: 0.25rem;
                    border-left-color: var(--tw-prose-quote-borders);
                    quotes: "“" "”" "‘" "’";
                    margin-top: 1.6em;
                    margin-bottom: 1.6em;
                    padding-left: 1em
                }

                .prose :where(blockquote p:first-of-type):not(:where([class~="not-prose"] *))::before {
                    content: open-quote
                }

                .prose :where(blockquote p:last-of-type):not(:where([class~="not-prose"] *))::after {
                    content: close-quote
                }

                .prose :where(h1):not(:where([class~="not-prose"] *)) {
                    color: var(--tw-prose-headings);
                    font-weight: 800;
                    font-size: 2.25em;
                    margin-top: 0;
                    margin-bottom: 0.8888889em;
                    line-height: 1.1111111
                }

                .prose :where(h1 strong):not(:where([class~="not-prose"] *)) {
                    font-weight: 900;
                    color: inherit
                }

                .prose :where(h2):not(:where([class~="not-prose"] *)) {
                    color: var(--tw-prose-headings);
                    font-weight: 700;
                    font-size: 1.5em;
                    margin-top: 2em;
                    margin-bottom: 1em;
                    line-height: 1.3333333
                }

                .prose :where(h2 strong):not(:where([class~="not-prose"] *)) {
                    font-weight: 800;
                    color: inherit
                }

                .prose :where(h3):not(:where([class~="not-prose"] *)) {
                    color: var(--tw-prose-headings);
                    font-weight: 600;
                    font-size: 1.25em;
                    margin-top: 1.6em;
                    margin-bottom: 0.6em;
                    line-height: 1.6
                }

                .prose :where(h3 strong):not(:where([class~="not-prose"] *)) {
                    font-weight: 700;
                    color: inherit
                }

                .prose :where(h4):not(:where([class~="not-prose"] *)) {
                    color: var(--tw-prose-headings);
                    font-weight: 600;
                    margin-top: 1.5em;
                    margin-bottom: 0.5em;
                    line-height: 1.5
                }

                .prose :where(h4 strong):not(:where([class~="not-prose"] *)) {
                    font-weight: 700;
                    color: inherit
                }

                .prose :where(img):not(:where([class~="not-prose"] *)) {
                    margin-top: 2em;
                    margin-bottom: 2em
                }

                .prose :where(figure>*):not(:where([class~="not-prose"] *)) {
                    margin-top: 0;
                    margin-bottom: 0
                }

                .prose :where(figcaption):not(:where([class~="not-prose"] *)) {
                    color: var(--tw-prose-captions);
                    font-size: 0.875em;
                    line-height: 1.4285714;
                    margin-top: 0.8571429em
                }

                .prose :where(code):not(:where([class~="not-prose"] *)) {
                    color: var(--tw-prose-code);
                    font-weight: 600;
                    font-size: 0.875em
                }

                .prose :where(code):not(:where([class~="not-prose"] *))::before {
                    content: "`"
                }

                .prose :where(code):not(:where([class~="not-prose"] *))::after {
                    content: "`"
                }

                .prose :where(a code):not(:where([class~="not-prose"] *)) {
                    color: inherit
                }

                .prose :where(h1 code):not(:where([class~="not-prose"] *)) {
                    color: inherit
                }

                .prose :where(h2 code):not(:where([class~="not-prose"] *)) {
                    color: inherit;
                    font-size: 0.875em
                }

                .prose :where(h3 code):not(:where([class~="not-prose"] *)) {
                    color: inherit;
                    font-size: 0.9em
                }

                .prose :where(h4 code):not(:where([class~="not-prose"] *)) {
                    color: inherit
                }

                .prose :where(blockquote code):not(:where([class~="not-prose"] *)) {
                    color: inherit
                }

                .prose :where(thead th code):not(:where([class~="not-prose"] *)) {
                    color: inherit
                }

                .prose :where(pre):not(:where([class~="not-prose"] *)) {
                    color: var(--tw-prose-pre-code);
                    background-color: var(--tw-prose-pre-bg);
                    overflow-x: auto;
                    font-weight: 400;
                    font-size: 0.875em;
                    line-height: 1.7142857;
                    margin-top: 1.7142857em;
                    margin-bottom: 1.7142857em;
                    border-radius: 0.375rem;
                    padding-top: 0.8571429em;
                    padding-right: 1.1428571em;
                    padding-bottom: 0.8571429em;
                    padding-left: 1.1428571em
                }

                .prose :where(pre code):not(:where([class~="not-prose"] *)) {
                    background-color: transparent;
                    border-width: 0;
                    border-radius: 0;
                    padding: 0;
                    font-weight: inherit;
                    color: inherit;
                    font-size: inherit;
                    font-family: inherit;
                    line-height: inherit
                }

                .prose :where(pre code):not(:where([class~="not-prose"] *))::before {
                    content: none
                }

                .prose :where(pre code):not(:where([class~="not-prose"] *))::after {
                    content: none
                }

                .prose :where(table):not(:where([class~="not-prose"] *)) {
                    width: 100%;
                    table-layout: auto;
                    text-align: left;
                    margin-top: 2em;
                    margin-bottom: 2em;
                    font-size: 0.875em;
                    line-height: 1.7142857
                }

                .prose :where(thead):not(:where([class~="not-prose"] *)) {
                    border-bottom-width: 1px;
                    border-bottom-color: var(--tw-prose-th-borders)
                }

                .prose :where(thead th):not(:where([class~="not-prose"] *)) {
                    color: var(--tw-prose-headings);
                    font-weight: 600;
                    vertical-align: bottom;
                    padding-right: 0.5714286em;
                    padding-bottom: 0.5714286em;
                    padding-left: 0.5714286em
                }

                .prose :where(tbody tr):not(:where([class~="not-prose"] *)) {
                    border-bottom-width: 1px;
                    border-bottom-color: var(--tw-prose-td-borders)
                }

                .prose :where(tbody tr:last-child):not(:where([class~="not-prose"] *)) {
                    border-bottom-width: 0
                }

                .prose :where(tbody td):not(:where([class~="not-prose"] *)) {
                    vertical-align: baseline
                }

                .prose :where(tfoot):not(:where([class~="not-prose"] *)) {
                    border-top-width: 1px;
                    border-top-color: var(--tw-prose-th-borders)
                }

                .prose :where(tfoot td):not(:where([class~="not-prose"] *)) {
                    vertical-align: top
                }

                .prose {
                    --tw-prose-body: #374151;
                    --tw-prose-headings: #111827;
                    --tw-prose-lead: #4b5563;
                    --tw-prose-links: #111827;
                    --tw-prose-bold: #111827;
                    --tw-prose-counters: #6b7280;
                    --tw-prose-bullets: #d1d5db;
                    --tw-prose-hr: #e5e7eb;
                    --tw-prose-quotes: #111827;
                    --tw-prose-quote-borders: #e5e7eb;
                    --tw-prose-captions: #6b7280;
                    --tw-prose-code: #111827;
                    --tw-prose-pre-code: #e5e7eb;
                    --tw-prose-pre-bg: #1f2937;
                    --tw-prose-th-borders: #d1d5db;
                    --tw-prose-td-borders: #e5e7eb;
                    --tw-prose-invert-body: #d1d5db;
                    --tw-prose-invert-headings: #fff;
                    --tw-prose-invert-lead: #9ca3af;
                    --tw-prose-invert-links: #fff;
                    --tw-prose-invert-bold: #fff;
                    --tw-prose-invert-counters: #9ca3af;
                    --tw-prose-invert-bullets: #4b5563;
                    --tw-prose-invert-hr: #374151;
                    --tw-prose-invert-quotes: #f3f4f6;
                    --tw-prose-invert-quote-borders: #374151;
                    --tw-prose-invert-captions: #9ca3af;
                    --tw-prose-invert-code: #fff;
                    --tw-prose-invert-pre-code: #d1d5db;
                    --tw-prose-invert-pre-bg: rgb(0 0 0/50%);
                    --tw-prose-invert-th-borders: #4b5563;
                    --tw-prose-invert-td-borders: #374151;
                    font-size: 1rem;
                    line-height: 1.75
                }

                .prose :where(video):not(:where([class~="not-prose"] *)) {
                    margin-top: 2em;
                    margin-bottom: 2em
                }

                .prose :where(figure):not(:where([class~="not-prose"] *)) {
                    margin-top: 2em;
                    margin-bottom: 2em
                }

                .prose :where(li):not(:where([class~="not-prose"] *)) {
                    margin-top: 0.5em;
                    margin-bottom: 0.5em
                }

                .prose :where(ol>li):not(:where([class~="not-prose"] *)) {
                    padding-left: 0.375em
                }

                .prose :where(ul>li):not(:where([class~="not-prose"] *)) {
                    padding-left: 0.375em
                }

                .prose :where(.prose>ul>li p):not(:where([class~="not-prose"] *)) {
                    margin-top: 0.75em;
                    margin-bottom: 0.75em
                }

                .prose :where(.prose>ul>li>*:first-child):not(:where([class~="not-prose"] *)) {
                    margin-top: 1.25em
                }

                .prose :where(.prose>ul>li>*:last-child):not(:where([class~="not-prose"] *)) {
                    margin-bottom: 1.25em
                }

                .prose :where(.prose>ol>li>*:first-child):not(:where([class~="not-prose"] *)) {
                    margin-top: 1.25em
                }

                .prose :where(.prose>ol>li>*:last-child):not(:where([class~="not-prose"] *)) {
                    margin-bottom: 1.25em
                }

                .prose :where(ul ul, ul ol, ol ul, ol ol):not(:where([class~="not-prose"] *)) {
                    margin-top: 0.75em;
                    margin-bottom: 0.75em
                }

                .prose :where(hr+*):not(:where([class~="not-prose"] *)) {
                    margin-top: 0
                }

                .prose :where(h2+*):not(:where([class~="not-prose"] *)) {
                    margin-top: 0
                }

                .prose :where(h3+*):not(:where([class~="not-prose"] *)) {
                    margin-top: 0
                }

                .prose :where(h4+*):not(:where([class~="not-prose"] *)) {
                    margin-top: 0
                }

                .prose :where(thead th:first-child):not(:where([class~="not-prose"] *)) {
                    padding-left: 0
                }

                .prose :where(thead th:last-child):not(:where([class~="not-prose"] *)) {
                    padding-right: 0
                }

                .prose :where(tbody td, tfoot td):not(:where([class~="not-prose"] *)) {
                    padding-top: 0.5714286em;
                    padding-right: 0.5714286em;
                    padding-bottom: 0.5714286em;
                    padding-left: 0.5714286em
                }

                .prose :where(tbody td:first-child, tfoot td:first-child):not(:where([class~="not-prose"] *)) {
                    padding-left: 0
                }

                .prose :where(tbody td:last-child, tfoot td:last-child):not(:where([class~="not-prose"] *)) {
                    padding-right: 0
                }

                .prose :where(.prose>:first-child):not(:where([class~="not-prose"] *)) {
                    margin-top: 0
                }

                .prose :where(.prose>:last-child):not(:where([class~="not-prose"] *)) {
                    margin-bottom: 0
                }

                .prose-zinc {
                    --tw-prose-body: #3f3f46;
                    --tw-prose-headings: #18181b;
                    --tw-prose-lead: #52525b;
                    --tw-prose-links: #18181b;
                    --tw-prose-bold: #18181b;
                    --tw-prose-counters: #71717a;
                    --tw-prose-bullets: #d4d4d8;
                    --tw-prose-hr: #e4e4e7;
                    --tw-prose-quotes: #18181b;
                    --tw-prose-quote-borders: #e4e4e7;
                    --tw-prose-captions: #71717a;
                    --tw-prose-code: #18181b;
                    --tw-prose-pre-code: #e4e4e7;
                    --tw-prose-pre-bg: #27272a;
                    --tw-prose-th-borders: #d4d4d8;
                    --tw-prose-td-borders: #e4e4e7;
                    --tw-prose-invert-body: #d4d4d8;
                    --tw-prose-invert-headings: #fff;
                    --tw-prose-invert-lead: #a1a1aa;
                    --tw-prose-invert-links: #fff;
                    --tw-prose-invert-bold: #fff;
                    --tw-prose-invert-counters: #a1a1aa;
                    --tw-prose-invert-bullets: #52525b;
                    --tw-prose-invert-hr: #3f3f46;
                    --tw-prose-invert-quotes: #f4f4f5;
                    --tw-prose-invert-quote-borders: #3f3f46;
                    --tw-prose-invert-captions: #a1a1aa;
                    --tw-prose-invert-code: #fff;
                    --tw-prose-invert-pre-code: #d4d4d8;
                    --tw-prose-invert-pre-bg: rgb(0 0 0/50%);
                    --tw-prose-invert-th-borders: #52525b;
                    --tw-prose-invert-td-borders: #3f3f46
                }

                .pointer-events-none {
                    pointer-events: none
                }

                .pointer-events-auto {
                    pointer-events: auto
                }

                .visible {
                    visibility: visible
                }

                .invisible {
                    visibility: hidden
                }

                .static {
                    position: static
                }

                .fixed {
                    position: fixed
                }

                .absolute {
                    position: absolute
                }

                .relative {
                    position: relative
                }

                .sticky {
                    position: sticky
                }

                .-right-2 {
                    right: -8px
                }

                .-top-1 {
                    top: -4px
                }

                .-top-2 {
                    top: -8px
                }

                .bottom-0 {
                    bottom: 0px
                }

                .bottom-2 {
                    bottom: 8px
                }

                .bottom-5 {
                    bottom: 20px
                }

                .bottom-8 {
                    bottom: 32px
                }

                .left-0 {
                    left: 0px
                }

                .left-1\/2 {
                    left: 50%
                }

                .left-2 {
                    left: 8px
                }

                .right-0 {
                    right: 0px
                }

                .right-2 {
                    right: 8px
                }

                .right-4 {
                    right: 16px
                }

                .right-8 {
                    right: 32px
                }

                .top-0 {
                    top: 0px
                }

                .top-1\/2 {
                    top: 50%
                }

                .top-2 {
                    top: 8px
                }

                .top-4 {
                    top: 16px
                }

                .top-8 {
                    top: 32px
                }

                .z-0 {
                    z-index: 0
                }

                .z-10 {
                    z-index: 10
                }

                .z-20 {
                    z-index: 20
                }

                .z-40 {
                    z-index: 40
                }

                .z-50 {
                    z-index: 50
                }

                .z-\[1\] {
                    z-index: 1
                }

                .col-span-1 {
                    grid-column: span 1/span 1
                }

                .col-span-2 {
                    grid-column: span 2/span 2
                }

                .col-span-3 {
                    grid-column: span 3/span 3
                }

                .col-span-4 {
                    grid-column: span 4/span 4
                }

                .col-span-5 {
                    grid-column: span 5/span 5
                }

                .col-span-6 {
                    grid-column: span 6/span 6
                }

                .m-4 {
                    margin: 16px
                }

                .m-5 {
                    margin: 20px
                }

                .mx-1 {
                    margin-left: 4px;
                    margin-right: 4px
                }

                .mx-2 {
                    margin-left: 8px;
                    margin-right: 8px
                }

                .mx-4 {
                    margin-left: 16px;
                    margin-right: 16px
                }

                .mx-auto {
                    margin-left: auto;
                    margin-right: auto
                }

                .my-1 {
                    margin-top: 4px;
                    margin-bottom: 4px
                }

                .my-2 {
                    margin-top: 8px;
                    margin-bottom: 8px
                }

                .my-4 {
                    margin-top: 16px;
                    margin-bottom: 16px
                }

                .my-8 {
                    margin-top: 32px;
                    margin-bottom: 32px
                }

                .-ml-1 {
                    margin-left: -4px
                }

                .-ml-2 {
                    margin-left: -8px
                }

                .-ml-6 {
                    margin-left: -24px
                }

                .-mr-1 {
                    margin-right: -4px
                }

                .-mr-2 {
                    margin-right: -8px
                }

                .-mt-1 {
                    margin-top: -4px
                }

                .-mt-2 {
                    margin-top: -8px
                }

                .mb-1 {
                    margin-bottom: 4px
                }

                .mb-10 {
                    margin-bottom: 40px
                }

                .mb-12 {
                    margin-bottom: 48px
                }

                .mb-2 {
                    margin-bottom: 8px
                }

                .mb-4 {
                    margin-bottom: 16px
                }

                .mb-6 {
                    margin-bottom: 24px
                }

                .mb-8 {
                    margin-bottom: 32px
                }

                .ml-1 {
                    margin-left: 4px
                }

                .ml-12 {
                    margin-left: 48px
                }

                .ml-2 {
                    margin-left: 8px
                }

                .ml-3 {
                    margin-left: 12px
                }

                .ml-4 {
                    margin-left: 16px
                }

                .ml-6 {
                    margin-left: 24px
                }

                .mr-0 {
                    margin-right: 0px
                }

                .mr-0\.5 {
                    margin-right: 2px
                }

                .mr-1 {
                    margin-right: 4px
                }

                .mr-12 {
                    margin-right: 48px
                }

                .mr-2 {
                    margin-right: 8px
                }

                .mr-3 {
                    margin-right: 12px
                }

                .mr-4 {
                    margin-right: 16px
                }

                .mr-6 {
                    margin-right: 24px
                }

                .mr-8 {
                    margin-right: 32px
                }

                .mt-1 {
                    margin-top: 4px
                }

                .mt-12 {
                    margin-top: 48px
                }

                .mt-2 {
                    margin-top: 8px
                }

                .mt-3 {
                    margin-top: 12px
                }

                .mt-4 {
                    margin-top: 16px
                }

                .mt-5 {
                    margin-top: 20px
                }

                .mt-6 {
                    margin-top: 24px
                }

                .mt-8 {
                    margin-top: 32px
                }

                .\!block {
                    display: block !important
                }

                .block {
                    display: block
                }

                .inline-block {
                    display: inline-block
                }

                .inline {
                    display: inline
                }

                .\!flex {
                    display: flex !important
                }

                .flex {
                    display: flex
                }

                .inline-flex {
                    display: inline-flex
                }

                .\!table {
                    display: table !important
                }

                .table {
                    display: table
                }

                .grid {
                    display: grid
                }

                .hidden {
                    display: none
                }

                .\!h-8 {
                    height: 32px !important
                }

                .h-10 {
                    height: 40px
                }

                .h-12 {
                    height: 48px
                }

                .h-28 {
                    height: 112px
                }

                .h-3 {
                    height: 12px
                }

                .h-32 {
                    height: 128px
                }

                .h-4 {
                    height: 16px
                }

                .h-40 {
                    height: 160px
                }

                .h-48 {
                    height: 192px
                }

                .h-5 {
                    height: 20px
                }

                .h-56 {
                    height: 224px
                }

                .h-6 {
                    height: 24px
                }

                .h-7 {
                    height: 28px
                }

                .h-72 {
                    height: 288px
                }

                .h-8 {
                    height: 32px
                }

                .h-\[105px\] {
                    height: 105px
                }

                .h-full {
                    height: 100%
                }

                .h-screen {
                    height: 100vh
                }

                .max-h-56 {
                    max-height: 224px
                }

                .max-h-60 {
                    max-height: 240px
                }

                .max-h-80 {
                    max-height: 320px
                }

                .max-h-96 {
                    max-height: 384px
                }

                .w-10 {
                    width: 40px
                }

                .w-11\/12 {
                    width: 91.666667%
                }

                .w-12 {
                    width: 48px
                }

                .w-14 {
                    width: 56px
                }

                .w-16 {
                    width: 64px
                }

                .w-2 {
                    width: 8px
                }

                .w-2\/12 {
                    width: 16.666667%
                }

                .w-20 {
                    width: 80px
                }

                .w-24 {
                    width: 96px
                }

                .w-3 {
                    width: 12px
                }

                .w-3\/12 {
                    width: 25%
                }

                .w-32 {
                    width: 128px
                }

                .w-36 {
                    width: 144px
                }

                .w-4 {
                    width: 16px
                }

                .w-4\/12 {
                    width: 33.333333%
                }

                .w-40 {
                    width: 160px
                }

                .w-44 {
                    width: 176px
                }

                .w-48 {
                    width: 192px
                }

                .w-5 {
                    width: 20px
                }

                .w-5\/12 {
                    width: 41.666667%
                }

                .w-52 {
                    width: 208px
                }

                .w-56 {
                    width: 224px
                }

                .w-6\/12 {
                    width: 50%
                }

                .w-60 {
                    width: 240px
                }

                .w-64 {
                    width: 256px
                }

                .w-72 {
                    width: 288px
                }

                .w-8 {
                    width: 32px
                }

                .w-8\/12 {
                    width: 66.666667%
                }

                .w-80 {
                    width: 320px
                }

                .w-96 {
                    width: 384px
                }

                .w-full {
                    width: 100%
                }

                .w-px {
                    width: 1px
                }

                .min-w-\[90px\] {
                    min-width: 90px
                }

                .max-w-2xl {
                    max-width: 672px
                }

                .max-w-3xl {
                    max-width: 768px
                }

                .max-w-4xl {
                    max-width: 896px
                }

                .max-w-5xl {
                    max-width: 1024px
                }

                .max-w-7xl {
                    max-width: 1280px
                }

                .max-w-\[170px\] {
                    max-width: 170px
                }

                .max-w-lg {
                    max-width: 512px
                }

                .max-w-md {
                    max-width: 448px
                }

                .max-w-none {
                    max-width: none
                }

                .max-w-sm {
                    max-width: 384px
                }

                .max-w-xl {
                    max-width: 576px
                }

                .flex-1 {
                    flex: 1 1 0%
                }

                .flex-shrink-0 {
                    flex-shrink: 0
                }

                .shrink-0 {
                    flex-shrink: 0
                }

                .grow {
                    flex-grow: 1
                }

                .-translate-x-1\/2 {
                    --tw-translate-x: -50%;
                    transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
                }

                .-translate-y-1 {
                    --tw-translate-y: -4px;
                    transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
                }

                .-translate-y-1\/2 {
                    --tw-translate-y: -50%;
                    transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
                }

                .scale-0 {
                    --tw-scale-x: 0;
                    --tw-scale-y: 0;
                    transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
                }

                .transform {
                    transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
                }

                @keyframes ping {

                    75%,
                    100% {
                        transform: scale(2);
                        opacity: 0
                    }
                }

                .animate-ping {
                    animation: ping 1s cubic-bezier(0, 0, 0.2, 1) infinite
                }

                @keyframes pulse {
                    50% {
                        opacity: .5
                    }
                }

                .animate-pulse {
                    animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite
                }

                @keyframes spin {
                    to {
                        transform: rotate(360deg)
                    }
                }

                .animate-spin {
                    animation: spin 1s linear infinite
                }

                .cursor-default {
                    cursor: default
                }

                .cursor-grab {
                    cursor: grab
                }

                .cursor-grabbing {
                    cursor: grabbing
                }

                .cursor-move {
                    cursor: move
                }

                .cursor-pointer {
                    cursor: pointer
                }

                .select-none {
                    -webkit-user-select: none;
                    -moz-user-select: none;
                    user-select: none
                }

                .resize-none {
                    resize: none
                }

                .resize {
                    resize: both
                }

                .list-inside {
                    list-style-position: inside
                }

                .list-decimal {
                    list-style-type: decimal
                }

                .list-disc {
                    list-style-type: disc
                }

                .appearance-none {
                    -webkit-appearance: none;
                    -moz-appearance: none;
                    appearance: none
                }

                .grid-cols-1 {
                    grid-template-columns: repeat(1, minmax(0, 1fr))
                }

                .grid-cols-12 {
                    grid-template-columns: repeat(12, minmax(0, 1fr))
                }

                .grid-cols-2 {
                    grid-template-columns: repeat(2, minmax(0, 1fr))
                }

                .grid-cols-5 {
                    grid-template-columns: repeat(5, minmax(0, 1fr))
                }

                .grid-cols-6 {
                    grid-template-columns: repeat(6, minmax(0, 1fr))
                }

                .grid-cols-7 {
                    grid-template-columns: repeat(7, minmax(0, 1fr))
                }

                .flex-col {
                    flex-direction: column
                }

                .flex-col-reverse {
                    flex-direction: column-reverse
                }

                .flex-wrap {
                    flex-wrap: wrap
                }

                .items-start {
                    align-items: flex-start
                }

                .items-end {
                    align-items: flex-end
                }

                .items-center {
                    align-items: center
                }

                .\!items-stretch {
                    align-items: stretch !important
                }

                .justify-end {
                    justify-content: flex-end
                }

                .justify-center {
                    justify-content: center
                }

                .justify-between {
                    justify-content: space-between
                }

                .justify-items-center {
                    justify-items: center
                }

                .gap-1 {
                    gap: 4px
                }

                .gap-2 {
                    gap: 8px
                }

                .gap-3 {
                    gap: 12px
                }

                .gap-4 {
                    gap: 16px
                }

                .gap-x-2 {
                    -moz-column-gap: 8px;
                    column-gap: 8px
                }

                .gap-x-4 {
                    -moz-column-gap: 16px;
                    column-gap: 16px
                }

                .gap-y-2 {
                    row-gap: 8px
                }

                .space-x-1>:not([hidden])~:not([hidden]) {
                    --tw-space-x-reverse: 0;
                    margin-right: calc(4px*var(--tw-space-x-reverse));
                    margin-left: calc(4px*calc(1 - var(--tw-space-x-reverse)))
                }

                .space-x-2>:not([hidden])~:not([hidden]) {
                    --tw-space-x-reverse: 0;
                    margin-right: calc(8px*var(--tw-space-x-reverse));
                    margin-left: calc(8px*calc(1 - var(--tw-space-x-reverse)))
                }

                .space-x-3>:not([hidden])~:not([hidden]) {
                    --tw-space-x-reverse: 0;
                    margin-right: calc(12px*var(--tw-space-x-reverse));
                    margin-left: calc(12px*calc(1 - var(--tw-space-x-reverse)))
                }

                .space-x-4>:not([hidden])~:not([hidden]) {
                    --tw-space-x-reverse: 0;
                    margin-right: calc(16px*var(--tw-space-x-reverse));
                    margin-left: calc(16px*calc(1 - var(--tw-space-x-reverse)))
                }

                .space-x-6>:not([hidden])~:not([hidden]) {
                    --tw-space-x-reverse: 0;
                    margin-right: calc(24px*var(--tw-space-x-reverse));
                    margin-left: calc(24px*calc(1 - var(--tw-space-x-reverse)))
                }

                .space-y-1>:not([hidden])~:not([hidden]) {
                    --tw-space-y-reverse: 0;
                    margin-top: calc(4px*calc(1 - var(--tw-space-y-reverse)));
                    margin-bottom: calc(4px*var(--tw-space-y-reverse))
                }

                .space-y-2>:not([hidden])~:not([hidden]) {
                    --tw-space-y-reverse: 0;
                    margin-top: calc(8px*calc(1 - var(--tw-space-y-reverse)));
                    margin-bottom: calc(8px*var(--tw-space-y-reverse))
                }

                .space-y-4>:not([hidden])~:not([hidden]) {
                    --tw-space-y-reverse: 0;
                    margin-top: calc(16px*calc(1 - var(--tw-space-y-reverse)));
                    margin-bottom: calc(16px*var(--tw-space-y-reverse))
                }

                .divide-y>:not([hidden])~:not([hidden]) {
                    --tw-divide-y-reverse: 0;
                    border-top-width: calc(1px*calc(1 - var(--tw-divide-y-reverse)));
                    border-bottom-width: calc(1px*var(--tw-divide-y-reverse))
                }

                .overflow-auto {
                    overflow: auto
                }

                .overflow-hidden {
                    overflow: hidden
                }

                .overflow-x-auto {
                    overflow-x: auto
                }

                .overflow-y-auto {
                    overflow-y: auto
                }

                .overflow-y-hidden {
                    overflow-y: hidden
                }

                .whitespace-nowrap {
                    white-space: nowrap
                }

                .whitespace-pre-wrap {
                    white-space: pre-wrap
                }

                .rounded {
                    border-radius: 4px
                }

                .rounded-full {
                    border-radius: 9999px
                }

                .rounded-lg {
                    border-radius: 8px
                }

                .rounded-md {
                    border-radius: 6px
                }

                .rounded-sm {
                    border-radius: 2px
                }

                .rounded-b-2xl {
                    border-bottom-right-radius: 16px;
                    border-bottom-left-radius: 16px
                }

                .rounded-l-lg {
                    border-top-left-radius: 8px;
                    border-bottom-left-radius: 8px
                }

                .rounded-l-none {
                    border-top-left-radius: 0px;
                    border-bottom-left-radius: 0px
                }

                .rounded-r-lg {
                    border-top-right-radius: 8px;
                    border-bottom-right-radius: 8px
                }

                .rounded-r-none {
                    border-top-right-radius: 0px;
                    border-bottom-right-radius: 0px
                }

                .rounded-t-none {
                    border-top-left-radius: 0px;
                    border-top-right-radius: 0px
                }

                .rounded-bl-lg {
                    border-bottom-left-radius: 8px
                }

                .rounded-br-lg {
                    border-bottom-right-radius: 8px
                }

                .border {
                    border-width: 1px
                }

                .border-2 {
                    border-width: 2px
                }

                .border-x {
                    border-left-width: 1px;
                    border-right-width: 1px
                }

                .border-b {
                    border-bottom-width: 1px
                }

                .border-b-0 {
                    border-bottom-width: 0px
                }

                .border-b-2 {
                    border-bottom-width: 2px
                }

                .border-l {
                    border-left-width: 1px
                }

                .border-r {
                    border-right-width: 1px
                }

                .border-r-0 {
                    border-right-width: 0px
                }

                .border-t {
                    border-top-width: 1px
                }

                .border-dashed {
                    border-style: dashed
                }

                .border-none {
                    border-style: none
                }

                .border-accent {
                    --tw-border-opacity: 1;
                    border-color: rgb(var(--color-accent)/var(--tw-border-opacity))
                }

                .border-blue-200 {
                    --tw-border-opacity: 1;
                    border-color: rgb(191 219 254/var(--tw-border-opacity))
                }

                .border-blue-500 {
                    --tw-border-opacity: 1;
                    border-color: rgb(59 130 246/var(--tw-border-opacity))
                }

                .border-cyan-200 {
                    --tw-border-opacity: 1;
                    border-color: rgb(165 243 252/var(--tw-border-opacity))
                }

                .border-gray-100 {
                    --tw-border-opacity: 1;
                    border-color: rgb(244 244 245/var(--tw-border-opacity))
                }

                .border-gray-200 {
                    --tw-border-opacity: 1;
                    border-color: rgb(228 228 231/var(--tw-border-opacity))
                }

                .border-gray-300 {
                    --tw-border-opacity: 1;
                    border-color: rgb(212 212 216/var(--tw-border-opacity))
                }

                .border-green-200 {
                    --tw-border-opacity: 1;
                    border-color: rgb(187 247 208/var(--tw-border-opacity))
                }

                .border-lime-200 {
                    --tw-border-opacity: 1;
                    border-color: rgb(217 249 157/var(--tw-border-opacity))
                }

                .border-orange-200 {
                    --tw-border-opacity: 1;
                    border-color: rgb(254 215 170/var(--tw-border-opacity))
                }

                .border-red-200 {
                    --tw-border-opacity: 1;
                    border-color: rgb(254 202 202/var(--tw-border-opacity))
                }

                .border-transparent {
                    border-color: transparent
                }

                .border-yellow-200 {
                    --tw-border-opacity: 1;
                    border-color: rgb(254 240 138/var(--tw-border-opacity))
                }

                .bg-accent {
                    --tw-bg-opacity: 1;
                    background-color: rgb(var(--color-accent)/var(--tw-bg-opacity))
                }

                .bg-amber-200 {
                    --tw-bg-opacity: 1;
                    background-color: rgb(253 230 138/var(--tw-bg-opacity))
                }

                .bg-black {
                    --tw-bg-opacity: 1;
                    background-color: rgb(0 0 0/var(--tw-bg-opacity))
                }

                .bg-blue-200 {
                    --tw-bg-opacity: 1;
                    background-color: rgb(191 219 254/var(--tw-bg-opacity))
                }

                .bg-blue-300 {
                    --tw-bg-opacity: 1;
                    background-color: rgb(147 197 253/var(--tw-bg-opacity))
                }

                .bg-blue-500 {
                    --tw-bg-opacity: 1;
                    background-color: rgb(59 130 246/var(--tw-bg-opacity))
                }

                .bg-blue-600 {
                    --tw-bg-opacity: 1;
                    background-color: rgb(37 99 235/var(--tw-bg-opacity))
                }

                .bg-cyan-200 {
                    --tw-bg-opacity: 1;
                    background-color: rgb(165 243 252/var(--tw-bg-opacity))
                }

                .bg-gray-100 {
                    --tw-bg-opacity: 1;
                    background-color: rgb(244 244 245/var(--tw-bg-opacity))
                }

                .bg-gray-300 {
                    --tw-bg-opacity: 1;
                    background-color: rgb(212 212 216/var(--tw-bg-opacity))
                }

                .bg-gray-50 {
                    --tw-bg-opacity: 1;
                    background-color: rgb(250 250 250/var(--tw-bg-opacity))
                }

                .bg-gray-900 {
                    --tw-bg-opacity: 1;
                    background-color: rgb(24 24 27/var(--tw-bg-opacity))
                }

                .bg-green-200 {
                    --tw-bg-opacity: 1;
                    background-color: rgb(187 247 208/var(--tw-bg-opacity))
                }

                .bg-green-300 {
                    --tw-bg-opacity: 1;
                    background-color: rgb(134 239 172/var(--tw-bg-opacity))
                }

                .bg-indigo-200 {
                    --tw-bg-opacity: 1;
                    background-color: rgb(199 210 254/var(--tw-bg-opacity))
                }

                .bg-indigo-500 {
                    --tw-bg-opacity: 1;
                    background-color: rgb(99 102 241/var(--tw-bg-opacity))
                }

                .bg-lime-200 {
                    --tw-bg-opacity: 1;
                    background-color: rgb(217 249 157/var(--tw-bg-opacity))
                }

                .bg-orange-200 {
                    --tw-bg-opacity: 1;
                    background-color: rgb(254 215 170/var(--tw-bg-opacity))
                }

                .bg-primary {
                    --tw-bg-opacity: 1;
                    background-color: rgb(var(--color-primary)/var(--tw-bg-opacity))
                }

                .bg-red-200 {
                    --tw-bg-opacity: 1;
                    background-color: rgb(254 202 202/var(--tw-bg-opacity))
                }

                .bg-red-300 {
                    --tw-bg-opacity: 1;
                    background-color: rgb(252 165 165/var(--tw-bg-opacity))
                }

                .bg-red-400 {
                    --tw-bg-opacity: 1;
                    background-color: rgb(248 113 113/var(--tw-bg-opacity))
                }

                .bg-sky-200 {
                    --tw-bg-opacity: 1;
                    background-color: rgb(186 230 253/var(--tw-bg-opacity))
                }

                .bg-transparent {
                    background-color: transparent
                }

                .bg-white {
                    --tw-bg-opacity: 1;
                    background-color: rgb(255 255 255/var(--tw-bg-opacity))
                }

                .bg-yellow-200 {
                    --tw-bg-opacity: 1;
                    background-color: rgb(254 240 138/var(--tw-bg-opacity))
                }

                .bg-opacity-10 {
                    --tw-bg-opacity: 0.1
                }

                .bg-opacity-20 {
                    --tw-bg-opacity: 0.2
                }

                .bg-opacity-30 {
                    --tw-bg-opacity: 0.3
                }

                .bg-opacity-5 {
                    --tw-bg-opacity: 0.05
                }

                .bg-opacity-50 {
                    --tw-bg-opacity: 0.5
                }

                .bg-opacity-75 {
                    --tw-bg-opacity: 0.75
                }

                .bg-scroll {
                    background-attachment: scroll
                }

                .bg-center {
                    background-position: center
                }

                .bg-no-repeat {
                    background-repeat: no-repeat
                }

                .fill-blue-200 {
                    fill: #bfdbfe
                }

                .fill-cyan-200 {
                    fill: #a5f3fc
                }

                .fill-green-200 {
                    fill: #bbf7d0
                }

                .fill-lime-200 {
                    fill: #d9f99d
                }

                .fill-orange-200 {
                    fill: #fed7aa
                }

                .fill-red-200 {
                    fill: #fecaca
                }

                .fill-yellow-200 {
                    fill: #fef08a
                }

                .\!p-0 {
                    padding: 0px !important
                }

                .p-0 {
                    padding: 0px
                }

                .p-0\.5 {
                    padding: 2px
                }

                .p-1 {
                    padding: 4px
                }

                .p-2 {
                    padding: 8px
                }

                .p-3 {
                    padding: 12px
                }

                .p-4 {
                    padding: 16px
                }

                .p-5 {
                    padding: 20px
                }

                .\!px-3 {
                    padding-left: 12px !important;
                    padding-right: 12px !important
                }

                .\!py-2 {
                    padding-top: 8px !important;
                    padding-bottom: 8px !important
                }

                .px-1 {
                    padding-left: 4px;
                    padding-right: 4px
                }

                .px-2 {
                    padding-left: 8px;
                    padding-right: 8px
                }

                .px-3 {
                    padding-left: 12px;
                    padding-right: 12px
                }

                .px-4 {
                    padding-left: 16px;
                    padding-right: 16px
                }

                .px-5 {
                    padding-left: 20px;
                    padding-right: 20px
                }

                .py-1 {
                    padding-top: 4px;
                    padding-bottom: 4px
                }

                .py-12 {
                    padding-top: 48px;
                    padding-bottom: 48px
                }

                .py-16 {
                    padding-top: 64px;
                    padding-bottom: 64px
                }

                .py-2 {
                    padding-top: 8px;
                    padding-bottom: 8px
                }

                .py-3 {
                    padding-top: 12px;
                    padding-bottom: 12px
                }

                .py-4 {
                    padding-top: 16px;
                    padding-bottom: 16px
                }

                .py-6 {
                    padding-top: 24px;
                    padding-bottom: 24px
                }

                .py-8 {
                    padding-top: 32px;
                    padding-bottom: 32px
                }

                .py-px {
                    padding-top: 1px;
                    padding-bottom: 1px
                }

                .pb-1 {
                    padding-bottom: 4px
                }

                .pb-2 {
                    padding-bottom: 8px
                }

                .pb-4 {
                    padding-bottom: 16px
                }

                .pb-5 {
                    padding-bottom: 20px
                }

                .pb-8 {
                    padding-bottom: 32px
                }

                .pl-1 {
                    padding-left: 4px
                }

                .pl-10 {
                    padding-left: 40px
                }

                .pl-14 {
                    padding-left: 56px
                }

                .pl-16 {
                    padding-left: 64px
                }

                .pl-2 {
                    padding-left: 8px
                }

                .pl-4 {
                    padding-left: 16px
                }

                .pl-6 {
                    padding-left: 24px
                }

                .pl-8 {
                    padding-left: 32px
                }

                .pl-\[28px\] {
                    padding-left: 28px
                }

                .pr-10 {
                    padding-right: 40px
                }

                .pr-4 {
                    padding-right: 16px
                }

                .pt-1 {
                    padding-top: 4px
                }

                .pt-2 {
                    padding-top: 8px
                }

                .pt-24 {
                    padding-top: 96px
                }

                .pt-4 {
                    padding-top: 16px
                }

                .pt-8 {
                    padding-top: 32px
                }

                .text-left {
                    text-align: left
                }

                .text-center {
                    text-align: center
                }

                .text-right {
                    text-align: right
                }

                .align-baseline {
                    vertical-align: baseline
                }

                .align-middle {
                    vertical-align: middle
                }

                .align-bottom {
                    vertical-align: bottom
                }

                .align-text-top {
                    vertical-align: text-top
                }

                .align-text-bottom {
                    vertical-align: text-bottom
                }

                .align-sub {
                    vertical-align: sub
                }

                .font-mono {
                    font-family: Source Code Pro, monospace
                }

                .text-2xl {
                    font-size: 24px;
                    line-height: 32px
                }

                .text-3xl {
                    font-size: 30px;
                    line-height: 36px
                }

                .text-base {
                    font-size: 16px;
                    line-height: 24px
                }

                .text-lg {
                    font-size: 18px;
                    line-height: 28px
                }

                .text-sm {
                    font-size: 14px;
                    line-height: 20px
                }

                .text-xl {
                    font-size: 20px;
                    line-height: 28px
                }

                .text-xs {
                    font-size: 12px;
                    line-height: 16px
                }

                .font-semibold {
                    font-weight: 600
                }

                .uppercase {
                    text-transform: uppercase
                }

                .lowercase {
                    text-transform: lowercase
                }

                .\!capitalize {
                    text-transform: capitalize !important
                }

                .capitalize {
                    text-transform: capitalize
                }

                .italic {
                    font-style: italic
                }

                .tabular-nums {
                    --tw-numeric-spacing: tabular-nums;
                    font-variant-numeric: var(--tw-ordinal) var(--tw-slashed-zero) var(--tw-numeric-figure) var(--tw-numeric-spacing) var(--tw-numeric-fraction)
                }

                .leading-none {
                    line-height: 1
                }

                .leading-normal {
                    line-height: 1.5
                }

                .leading-tight {
                    line-height: 1.25
                }

                .text-accent {
                    --tw-text-opacity: 1;
                    color: rgb(var(--color-accent)/var(--tw-text-opacity))
                }

                .text-black {
                    --tw-text-opacity: 1;
                    color: rgb(0 0 0/var(--tw-text-opacity))
                }

                .text-blue-300 {
                    --tw-text-opacity: 1;
                    color: rgb(147 197 253/var(--tw-text-opacity))
                }

                .text-blue-400 {
                    --tw-text-opacity: 1;
                    color: rgb(96 165 250/var(--tw-text-opacity))
                }

                .text-gray-100 {
                    --tw-text-opacity: 1;
                    color: rgb(244 244 245/var(--tw-text-opacity))
                }

                .text-gray-200 {
                    --tw-text-opacity: 1;
                    color: rgb(228 228 231/var(--tw-text-opacity))
                }

                .text-gray-300 {
                    --tw-text-opacity: 1;
                    color: rgb(212 212 216/var(--tw-text-opacity))
                }

                .text-gray-400 {
                    --tw-text-opacity: 1;
                    color: rgb(161 161 170/var(--tw-text-opacity))
                }

                .text-gray-500 {
                    --tw-text-opacity: 1;
                    color: rgb(113 113 122/var(--tw-text-opacity))
                }

                .text-gray-600 {
                    --tw-text-opacity: 1;
                    color: rgb(82 82 91/var(--tw-text-opacity))
                }

                .text-gray-700 {
                    --tw-text-opacity: 1;
                    color: rgb(63 63 70/var(--tw-text-opacity))
                }

                .text-gray-800 {
                    --tw-text-opacity: 1;
                    color: rgb(39 39 42/var(--tw-text-opacity))
                }

                .text-green-400 {
                    --tw-text-opacity: 1;
                    color: rgb(74 222 128/var(--tw-text-opacity))
                }

                .text-green-500 {
                    --tw-text-opacity: 1;
                    color: rgb(34 197 94/var(--tw-text-opacity))
                }

                .text-green-600 {
                    --tw-text-opacity: 1;
                    color: rgb(22 163 74/var(--tw-text-opacity))
                }

                .text-primary {
                    --tw-text-opacity: 1;
                    color: rgb(var(--color-primary)/var(--tw-text-opacity))
                }

                .text-red-400 {
                    --tw-text-opacity: 1;
                    color: rgb(248 113 113/var(--tw-text-opacity))
                }

                .text-red-500 {
                    --tw-text-opacity: 1;
                    color: rgb(239 68 68/var(--tw-text-opacity))
                }

                .text-white {
                    --tw-text-opacity: 1;
                    color: rgb(255 255 255/var(--tw-text-opacity))
                }

                .text-yellow-400 {
                    --tw-text-opacity: 1;
                    color: rgb(250 204 21/var(--tw-text-opacity))
                }

                .text-yellow-500 {
                    --tw-text-opacity: 1;
                    color: rgb(234 179 8/var(--tw-text-opacity))
                }

                .underline {
                    text-decoration-line: underline
                }

                .opacity-0 {
                    opacity: 0
                }

                .opacity-25 {
                    opacity: 0.25
                }

                .opacity-50 {
                    opacity: 0.5
                }

                .opacity-70 {
                    opacity: 0.7
                }

                .opacity-75 {
                    opacity: 0.75
                }

                .shadow {
                    --tw-shadow: 0 1px 3px 0 rgb(0 0 0/0.1), 0 1px 2px -1px rgb(0 0 0/0.1);
                    --tw-shadow-colored: 0 1px 3px 0 var(--tw-shadow-color), 0 1px 2px -1px var(--tw-shadow-color);
                    box-shadow: var(--tw-ring-offset-shadow, 0 0#0000), var(--tw-ring-shadow, 0 0#0000), var(--tw-shadow)
                }

                .shadow-2xl {
                    --tw-shadow: 0 25px 50px -12px rgb(0 0 0/0.25);
                    --tw-shadow-colored: 0 25px 50px -12px var(--tw-shadow-color);
                    box-shadow: var(--tw-ring-offset-shadow, 0 0#0000), var(--tw-ring-shadow, 0 0#0000), var(--tw-shadow)
                }

                .shadow-lg {
                    --tw-shadow: 0 10px 15px -3px rgb(0 0 0/0.1), 0 4px 6px -4px rgb(0 0 0/0.1);
                    --tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);
                    box-shadow: var(--tw-ring-offset-shadow, 0 0#0000), var(--tw-ring-shadow, 0 0#0000), var(--tw-shadow)
                }

                .shadow-md {
                    --tw-shadow: 0 4px 6px -1px rgb(0 0 0/0.1), 0 2px 4px -2px rgb(0 0 0/0.1);
                    --tw-shadow-colored: 0 4px 6px -1px var(--tw-shadow-color), 0 2px 4px -2px var(--tw-shadow-color);
                    box-shadow: var(--tw-ring-offset-shadow, 0 0#0000), var(--tw-ring-shadow, 0 0#0000), var(--tw-shadow)
                }

                .shadow-xl {
                    --tw-shadow: 0 20px 25px -5px rgb(0 0 0/0.1), 0 8px 10px -6px rgb(0 0 0/0.1);
                    --tw-shadow-colored: 0 20px 25px -5px var(--tw-shadow-color), 0 8px 10px -6px var(--tw-shadow-color);
                    box-shadow: var(--tw-ring-offset-shadow, 0 0#0000), var(--tw-ring-shadow, 0 0#0000), var(--tw-shadow)
                }

                .outline {
                    outline-style: solid
                }

                .ring {
                    --tw-ring-offset-shadow: var(--tw-ring-inset)0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
                    --tw-ring-shadow: var(--tw-ring-inset)0 0 0 calc(3px + var(--tw-ring-offset-width)) var(--tw-ring-color);
                    box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0#0000)
                }

                .ring-2 {
                    --tw-ring-offset-shadow: var(--tw-ring-inset)0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
                    --tw-ring-shadow: var(--tw-ring-inset)0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
                    box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0#0000)
                }

                .ring-accent {
                    --tw-ring-opacity: 1;
                    --tw-ring-color: rgb(var(--color-accent)/var(--tw-ring-opacity))
                }

                .ring-red-400 {
                    --tw-ring-opacity: 1;
                    --tw-ring-color: rgb(248 113 113/var(--tw-ring-opacity))
                }

                .blur {
                    --tw-blur: blur(8px);
                    filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow)
                }

                .invert {
                    --tw-invert: invert(100%);
                    filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow)
                }

                .filter {
                    filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow)
                }

                .backdrop-blur {
                    --tw-backdrop-blur: blur(8px);
                    -webkit-backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);
                    backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia)
                }

                .backdrop-filter {
                    -webkit-backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia);
                    backdrop-filter: var(--tw-backdrop-blur) var(--tw-backdrop-brightness) var(--tw-backdrop-contrast) var(--tw-backdrop-grayscale) var(--tw-backdrop-hue-rotate) var(--tw-backdrop-invert) var(--tw-backdrop-opacity) var(--tw-backdrop-saturate) var(--tw-backdrop-sepia)
                }

                .transition {
                    transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, -webkit-backdrop-filter;
                    transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter;
                    transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter, -webkit-backdrop-filter;
                    transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
                    transition-duration: 150ms
                }

                .transition-colors {
                    transition-property: color, background-color, border-color, text-decoration-color, fill, stroke;
                    transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
                    transition-duration: 150ms
                }

                .transition-transform {
                    transition-property: transform;
                    transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
                    transition-duration: 150ms
                }

                .duration-200 {
                    transition-duration: 200ms
                }

                .ease-out {
                    transition-timing-function: cubic-bezier(0, 0, 0.2, 1)
                }

                .hoverable:hover {
                    background-color: rgb(39 39 42/var(--tw-bg-opacity));
                    --tw-bg-opacity: 0.05
                }

                :is(.dark .hoverable:hover) {
                    background-color: rgb(228 228 231/var(--tw-bg-opacity));
                    --tw-bg-opacity: 0.05
                }

                .bg-input {
                    background-color: rgb(0 0 0/var(--tw-bg-opacity));
                    --tw-bg-opacity: 0.05
                }

                .bg-input:hover {
                    --tw-bg-opacity: 0.1
                }

                :is(.dark .bg-input) {
                    background-color: rgb(228 228 231/var(--tw-bg-opacity));
                    --tw-bg-opacity: 0.05
                }

                :is(.dark .bg-input:hover) {
                    --tw-bg-opacity: 0.1
                }

                .bg-box-transparent {
                    background-color: rgb(0 0 0/var(--tw-bg-opacity));
                    --tw-bg-opacity: 0.05
                }

                :is(.dark .bg-box-transparent) {
                    background-color: rgb(228 228 231/var(--tw-bg-opacity));
                    --tw-bg-opacity: 0.05
                }

                .bg-box-transparent-2 {
                    background-color: rgb(0 0 0/var(--tw-bg-opacity));
                    --tw-bg-opacity: 0.1
                }

                :is(.dark .bg-box-transparent-2) {
                    background-color: rgb(228 228 231/var(--tw-bg-opacity));
                    --tw-bg-opacity: 0.1
                }

                :host,
                :root {
                    --color-primary: 59 130 246;
                    --color-secondary: 96 165 250;
                    --color-accent: 24 24 27
                }

                .dark {
                    --color-primary: 96 165 250;
                    --color-secondary: 59 130 246;
                    --color-accent: 244 244 245
                }

                :is(.dark *) {
                    --tw-border-opacity: 1;
                    border-color: rgb(63 63 70/var(--tw-border-opacity))
                }

                html.dark {
                    --tw-bg-opacity: 1;
                    background-color: rgb(24 24 27/var(--tw-bg-opacity))
                }

                body,
                :host {
                    font-family: "Inter var" !important;
                    font-size: 16px !important;
                    font-feature-settings: "cv02", "cv03", "cv04", "cv11";
                    --tw-bg-opacity: 1;
                    background-color: rgb(250 250 250/var(--tw-bg-opacity));
                    line-height: 1.5
                }

                :is(.dark body),
                :is(.dark :host) {
                    --tw-bg-opacity: 1;
                    background-color: rgb(24 24 27/var(--tw-bg-opacity))
                }

                table th,
                table td {
                    padding-top: 8px;
                    padding-bottom: 8px;
                    padding-left: 16px;
                    padding-right: 16px
                }

                input:focus,
                button:focus,
                textarea:focus,
                select:focus,
                [role="button"]:focus {
                    outline: none;
                    --tw-ring-offset-shadow: var(--tw-ring-inset)0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
                    --tw-ring-shadow: var(--tw-ring-inset)0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
                    box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0#0000);
                    --tw-ring-opacity: 1;
                    --tw-ring-color: rgb(var(--color-accent)/var(--tw-ring-opacity))
                }

                :is(.dark input:focus),
                :is(.dark button:focus),
                :is(.dark textarea:focus),
                :is(.dark select:focus),
                :is(.dark [role="button"]:focus) {
                    --tw-ring-opacity: 1;
                    --tw-ring-color: rgb(228 228 231/var(--tw-ring-opacity))
                }

                .text-overflow {
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap
                }

                .line-clamp {
                    display: -webkit-box;
                    -webkit-line-clamp: 2;
                    -webkit-box-orient: vertical;
                    overflow: hidden;
                    text-overflow: ellipsis
                }

                .custom-table thead {
                    background-color: rgb(0 0 0/var(--tw-bg-opacity));
                    --tw-bg-opacity: 0.05
                }

                :is(.dark .custom-table thead) {
                    background-color: rgb(228 228 231/var(--tw-bg-opacity));
                    --tw-bg-opacity: 0.05
                }

                .custom-table thead th {
                    font-weight: 600
                }

                .custom-table thead th:first-child {
                    border-top-left-radius: 8px;
                    border-bottom-left-radius: 8px
                }

                .custom-table thead th:last-child {
                    border-top-right-radius: 8px;
                    border-bottom-right-radius: 8px
                }

                .custom-table tbody>:not([hidden])~:not([hidden]) {
                    --tw-divide-y-reverse: 0;
                    border-top-width: calc(1px*calc(1 - var(--tw-divide-y-reverse)));
                    border-bottom-width: calc(1px*var(--tw-divide-y-reverse))
                }

                pre {
                    font-size: 15px
                }

                .scroll::-webkit-scrollbar,
                .scroll .cm-scroller::-webkit-scrollbar {
                    width: 7px;
                    height: 9px
                }

                .scroll::-webkit-scrollbar-thumb,
                .scroll .cm-scroller::-webkit-scrollbar-thumb {
                    --tw-bg-opacity: 1;
                    background-color: rgb(212 212 216/var(--tw-bg-opacity))
                }

                :is(.dark .scroll)::-webkit-scrollbar-thumb,
                :is(.dark .scroll .cm-scroller)::-webkit-scrollbar-thumb {
                    --tw-bg-opacity: 1;
                    background-color: rgb(63 63 70/var(--tw-bg-opacity))
                }

                .scroll::-webkit-scrollbar-thumb,
                .scroll .cm-scroller::-webkit-scrollbar-thumb {
                    border-radius: 8px
                }

                .scroll::-webkit-scrollbar-track,
                .scroll .cm-scroller::-webkit-scrollbar-track {
                    background: transparent
                }

                .scroll.scroll-xs::-webkit-scrollbar,
                .scroll .cm-scroller.scroll-xs::-webkit-scrollbar {
                    width: 5px;
                    height: 5px
                }

                .tippy-box[data-theme~="tooltip-theme"] {
                    border-radius: 6px;
                    --tw-bg-opacity: 1;
                    background-color: rgb(24 24 27/var(--tw-bg-opacity));
                    padding-left: 8px;
                    padding-right: 8px;
                    padding-top: 4px;
                    padding-bottom: 4px;
                    font-size: 14px;
                    line-height: 20px;
                    --tw-text-opacity: 1;
                    color: rgb(228 228 231/var(--tw-text-opacity))
                }

                :is(.dark .tippy-box[data-theme~="tooltip-theme"]) {
                    --tw-bg-opacity: 1;
                    background-color: rgb(228 228 231/var(--tw-bg-opacity));
                    --tw-text-opacity: 1;
                    color: rgb(0 0 0/var(--tw-text-opacity))
                }

                .Vue-Toastification__toast {
                    font-family: inherit !important
                }

                .ProseMirror>*+* {
                    margin-top: 0.75em
                }

                .ProseMirror img {
                    max-width: 100%;
                    height: auto
                }

                .ProseMirror img.ProseMirror-selectednode {
                    outline: 3px solid #68CEF8
                }

                .input-label {
                    margin-left: 4px;
                    font-size: 14px;
                    line-height: 20px;
                    --tw-text-opacity: 1;
                    color: rgb(82 82 91/var(--tw-text-opacity))
                }

                :is(.dark .input-label) {
                    --tw-text-opacity: 1;
                    color: rgb(228 228 231/var(--tw-text-opacity))
                }

                :is(.dark .dark\:prose-invert) {
                    --tw-prose-body: var(--tw-prose-invert-body);
                    --tw-prose-headings: var(--tw-prose-invert-headings);
                    --tw-prose-lead: var(--tw-prose-invert-lead);
                    --tw-prose-links: var(--tw-prose-invert-links);
                    --tw-prose-bold: var(--tw-prose-invert-bold);
                    --tw-prose-counters: var(--tw-prose-invert-counters);
                    --tw-prose-bullets: var(--tw-prose-invert-bullets);
                    --tw-prose-hr: var(--tw-prose-invert-hr);
                    --tw-prose-quotes: var(--tw-prose-invert-quotes);
                    --tw-prose-quote-borders: var(--tw-prose-invert-quote-borders);
                    --tw-prose-captions: var(--tw-prose-invert-captions);
                    --tw-prose-code: var(--tw-prose-invert-code);
                    --tw-prose-pre-code: var(--tw-prose-invert-pre-code);
                    --tw-prose-pre-bg: var(--tw-prose-invert-pre-bg);
                    --tw-prose-th-borders: var(--tw-prose-invert-th-borders);
                    --tw-prose-td-borders: var(--tw-prose-invert-td-borders)
                }

                .placeholder\:text-black::-moz-placeholder {
                    --tw-text-opacity: 1;
                    color: rgb(0 0 0/var(--tw-text-opacity))
                }

                .placeholder\:text-black::placeholder {
                    --tw-text-opacity: 1;
                    color: rgb(0 0 0/var(--tw-text-opacity))
                }

                .focus-within\:ring-2:focus-within {
                    --tw-ring-offset-shadow: var(--tw-ring-inset)0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
                    --tw-ring-shadow: var(--tw-ring-inset)0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
                    box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0#0000)
                }

                .focus-within\:ring-accent:focus-within {
                    --tw-ring-opacity: 1;
                    --tw-ring-color: rgb(var(--color-accent)/var(--tw-ring-opacity))
                }

                .focus-within\:bg-box-transparent-2:focus-within {
                    background-color: rgb(0 0 0/var(--tw-bg-opacity));
                    --tw-bg-opacity: 0.1
                }

                :is(.dark .focus-within\:bg-box-transparent-2:focus-within) {
                    background-color: rgb(228 228 231/var(--tw-bg-opacity));
                    --tw-bg-opacity: 0.1
                }

                .hover\:-translate-y-1:hover {
                    --tw-translate-y: -4px;
                    transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
                }

                .hover\:bg-gray-700:hover {
                    --tw-bg-opacity: 1;
                    background-color: rgb(63 63 70/var(--tw-bg-opacity))
                }

                .hover\:bg-red-400:hover {
                    --tw-bg-opacity: 1;
                    background-color: rgb(248 113 113/var(--tw-bg-opacity))
                }

                .hover\:bg-secondary:hover {
                    --tw-bg-opacity: 1;
                    background-color: rgb(var(--color-secondary)/var(--tw-bg-opacity))
                }

                .hover\:text-black:hover {
                    --tw-text-opacity: 1;
                    color: rgb(0 0 0/var(--tw-text-opacity))
                }

                .hover\:shadow-xl:hover {
                    --tw-shadow: 0 20px 25px -5px rgb(0 0 0/0.1), 0 8px 10px -6px rgb(0 0 0/0.1);
                    --tw-shadow-colored: 0 20px 25px -5px var(--tw-shadow-color), 0 8px 10px -6px var(--tw-shadow-color);
                    box-shadow: var(--tw-ring-offset-shadow, 0 0#0000), var(--tw-ring-shadow, 0 0#0000), var(--tw-shadow)
                }

                .hover\:ring-2:hover {
                    --tw-ring-offset-shadow: var(--tw-ring-inset)0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
                    --tw-ring-shadow: var(--tw-ring-inset)0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
                    box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0#0000)
                }

                .hover\:ring-accent:hover {
                    --tw-ring-opacity: 1;
                    --tw-ring-color: rgb(var(--color-accent)/var(--tw-ring-opacity))
                }

                .hover\:ring-gray-900:hover {
                    --tw-ring-opacity: 1;
                    --tw-ring-color: rgb(24 24 27/var(--tw-ring-opacity))
                }

                .focus\:outline-none:focus {
                    outline: 2px solid transparent;
                    outline-offset: 2px
                }

                .focus\:ring-0:focus {
                    --tw-ring-offset-shadow: var(--tw-ring-inset)0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
                    --tw-ring-shadow: var(--tw-ring-inset)0 0 0 calc(0px + var(--tw-ring-offset-width)) var(--tw-ring-color);
                    box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0#0000)
                }

                .focus\:ring-2:focus {
                    --tw-ring-offset-shadow: var(--tw-ring-inset)0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
                    --tw-ring-shadow: var(--tw-ring-inset)0 0 0 calc(2px + var(--tw-ring-offset-width)) var(--tw-ring-color);
                    box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0#0000)
                }

                .focus\:ring-red-400:focus {
                    --tw-ring-opacity: 1;
                    --tw-ring-color: rgb(248 113 113/var(--tw-ring-opacity))
                }

                .group:hover .group-hover\:visible {
                    visibility: visible
                }

                .group:hover .group-hover\:scale-100 {
                    --tw-scale-x: 1;
                    --tw-scale-y: 1;
                    transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y))
                }

                :is(.dark .dark\:divide-gray-700)>:not([hidden])~:not([hidden]) {
                    --tw-divide-opacity: 1;
                    border-color: rgb(63 63 70/var(--tw-divide-opacity))
                }

                :is(.dark .dark\:divide-gray-800)>:not([hidden])~:not([hidden]) {
                    --tw-divide-opacity: 1;
                    border-color: rgb(39 39 42/var(--tw-divide-opacity))
                }

                :is(.dark .dark\:border-accent) {
                    --tw-border-opacity: 1;
                    border-color: rgb(var(--color-accent)/var(--tw-border-opacity))
                }

                :is(.dark .dark\:border-blue-300) {
                    --tw-border-opacity: 1;
                    border-color: rgb(147 197 253/var(--tw-border-opacity))
                }

                :is(.dark .dark\:border-blue-400) {
                    --tw-border-opacity: 1;
                    border-color: rgb(96 165 250/var(--tw-border-opacity))
                }

                :is(.dark .dark\:border-cyan-300) {
                    --tw-border-opacity: 1;
                    border-color: rgb(103 232 249/var(--tw-border-opacity))
                }

                :is(.dark .dark\:border-gray-100) {
                    --tw-border-opacity: 1;
                    border-color: rgb(244 244 245/var(--tw-border-opacity))
                }

                :is(.dark .dark\:border-gray-700) {
                    --tw-border-opacity: 1;
                    border-color: rgb(63 63 70/var(--tw-border-opacity))
                }

                :is(.dark .dark\:border-gray-800) {
                    --tw-border-opacity: 1;
                    border-color: rgb(39 39 42/var(--tw-border-opacity))
                }

                :is(.dark .dark\:border-green-300) {
                    --tw-border-opacity: 1;
                    border-color: rgb(134 239 172/var(--tw-border-opacity))
                }

                :is(.dark .dark\:border-lime-300) {
                    --tw-border-opacity: 1;
                    border-color: rgb(190 242 100/var(--tw-border-opacity))
                }

                :is(.dark .dark\:border-orange-300) {
                    --tw-border-opacity: 1;
                    border-color: rgb(253 186 116/var(--tw-border-opacity))
                }

                :is(.dark .dark\:border-red-300) {
                    --tw-border-opacity: 1;
                    border-color: rgb(252 165 165/var(--tw-border-opacity))
                }

                :is(.dark .dark\:border-transparent) {
                    border-color: transparent
                }

                :is(.dark .dark\:border-yellow-300) {
                    --tw-border-opacity: 1;
                    border-color: rgb(253 224 71/var(--tw-border-opacity))
                }

                :is(.dark .dark\:border-opacity-40) {
                    --tw-border-opacity: 0.4
                }

                :is(.dark .dark\:border-opacity-50) {
                    --tw-border-opacity: 0.5
                }

                :is(.dark .dark\:bg-amber-300) {
                    --tw-bg-opacity: 1;
                    background-color: rgb(252 211 77/var(--tw-bg-opacity))
                }

                :is(.dark .dark\:bg-blue-300) {
                    --tw-bg-opacity: 1;
                    background-color: rgb(147 197 253/var(--tw-bg-opacity))
                }

                :is(.dark .dark\:bg-cyan-300) {
                    --tw-bg-opacity: 1;
                    background-color: rgb(103 232 249/var(--tw-bg-opacity))
                }

                :is(.dark .dark\:bg-gray-100) {
                    --tw-bg-opacity: 1;
                    background-color: rgb(244 244 245/var(--tw-bg-opacity))
                }

                :is(.dark .dark\:bg-gray-200) {
                    --tw-bg-opacity: 1;
                    background-color: rgb(228 228 231/var(--tw-bg-opacity))
                }

                :is(.dark .dark\:bg-gray-600) {
                    --tw-bg-opacity: 1;
                    background-color: rgb(82 82 91/var(--tw-bg-opacity))
                }

                :is(.dark .dark\:bg-gray-700) {
                    --tw-bg-opacity: 1;
                    background-color: rgb(63 63 70/var(--tw-bg-opacity))
                }

                :is(.dark .dark\:bg-gray-800) {
                    --tw-bg-opacity: 1;
                    background-color: rgb(39 39 42/var(--tw-bg-opacity))
                }

                :is(.dark .dark\:bg-gray-900) {
                    --tw-bg-opacity: 1;
                    background-color: rgb(24 24 27/var(--tw-bg-opacity))
                }

                :is(.dark .dark\:bg-green-200) {
                    --tw-bg-opacity: 1;
                    background-color: rgb(187 247 208/var(--tw-bg-opacity))
                }

                :is(.dark .dark\:bg-green-300) {
                    --tw-bg-opacity: 1;
                    background-color: rgb(134 239 172/var(--tw-bg-opacity))
                }

                :is(.dark .dark\:bg-indigo-300) {
                    --tw-bg-opacity: 1;
                    background-color: rgb(165 180 252/var(--tw-bg-opacity))
                }

                :is(.dark .dark\:bg-indigo-400) {
                    --tw-bg-opacity: 1;
                    background-color: rgb(129 140 248/var(--tw-bg-opacity))
                }

                :is(.dark .dark\:bg-lime-300) {
                    --tw-bg-opacity: 1;
                    background-color: rgb(190 242 100/var(--tw-bg-opacity))
                }

                :is(.dark .dark\:bg-orange-300) {
                    --tw-bg-opacity: 1;
                    background-color: rgb(253 186 116/var(--tw-bg-opacity))
                }

                :is(.dark .dark\:bg-red-200) {
                    --tw-bg-opacity: 1;
                    background-color: rgb(254 202 202/var(--tw-bg-opacity))
                }

                :is(.dark .dark\:bg-red-300) {
                    --tw-bg-opacity: 1;
                    background-color: rgb(252 165 165/var(--tw-bg-opacity))
                }

                :is(.dark .dark\:bg-red-400) {
                    --tw-bg-opacity: 1;
                    background-color: rgb(248 113 113/var(--tw-bg-opacity))
                }

                :is(.dark .dark\:bg-red-500) {
                    --tw-bg-opacity: 1;
                    background-color: rgb(239 68 68/var(--tw-bg-opacity))
                }

                :is(.dark .dark\:bg-secondary) {
                    --tw-bg-opacity: 1;
                    background-color: rgb(var(--color-secondary)/var(--tw-bg-opacity))
                }

                :is(.dark .dark\:bg-sky-300) {
                    --tw-bg-opacity: 1;
                    background-color: rgb(125 211 252/var(--tw-bg-opacity))
                }

                :is(.dark .dark\:bg-yellow-300) {
                    --tw-bg-opacity: 1;
                    background-color: rgb(253 224 71/var(--tw-bg-opacity))
                }

                :is(.dark .dark\:bg-opacity-10) {
                    --tw-bg-opacity: 0.1
                }

                :is(.dark .dark\:bg-opacity-60) {
                    --tw-bg-opacity: 0.6
                }

                :is(.dark .dark\:bg-none) {
                    background-image: none
                }

                :is(.dark .dark\:fill-blue-300) {
                    fill: #93c5fd
                }

                :is(.dark .dark\:fill-cyan-300) {
                    fill: #67e8f9
                }

                :is(.dark .dark\:fill-green-300) {
                    fill: #86efac
                }

                :is(.dark .dark\:fill-lime-300) {
                    fill: #bef264
                }

                :is(.dark .dark\:fill-orange-300) {
                    fill: #fdba74
                }

                :is(.dark .dark\:fill-red-300) {
                    fill: #fca5a5
                }

                :is(.dark .dark\:fill-yellow-300) {
                    fill: #fde047
                }

                :is(.dark .dark\:text-black) {
                    --tw-text-opacity: 1;
                    color: rgb(0 0 0/var(--tw-text-opacity))
                }

                :is(.dark .dark\:text-gray-100) {
                    --tw-text-opacity: 1;
                    color: rgb(244 244 245/var(--tw-text-opacity))
                }

                :is(.dark .dark\:text-gray-200) {
                    --tw-text-opacity: 1;
                    color: rgb(228 228 231/var(--tw-text-opacity))
                }

                :is(.dark .dark\:text-gray-300) {
                    --tw-text-opacity: 1;
                    color: rgb(212 212 216/var(--tw-text-opacity))
                }

                :is(.dark .dark\:text-gray-600) {
                    --tw-text-opacity: 1;
                    color: rgb(82 82 91/var(--tw-text-opacity))
                }

                :is(.dark .dark\:text-gray-900) {
                    --tw-text-opacity: 1;
                    color: rgb(24 24 27/var(--tw-text-opacity))
                }

                :is(.dark .dark\:text-green-400) {
                    --tw-text-opacity: 1;
                    color: rgb(74 222 128/var(--tw-text-opacity))
                }

                :is(.dark .dark\:text-red-300) {
                    --tw-text-opacity: 1;
                    color: rgb(252 165 165/var(--tw-text-opacity))
                }

                :is(.dark .dark\:text-red-400) {
                    --tw-text-opacity: 1;
                    color: rgb(248 113 113/var(--tw-text-opacity))
                }

                :is(.dark .dark\:text-red-500) {
                    --tw-text-opacity: 1;
                    color: rgb(239 68 68/var(--tw-text-opacity))
                }

                :is(.dark .dark\:text-red-600) {
                    --tw-text-opacity: 1;
                    color: rgb(220 38 38/var(--tw-text-opacity))
                }

                :is(.dark .dark\:text-secondary) {
                    --tw-text-opacity: 1;
                    color: rgb(var(--color-secondary)/var(--tw-text-opacity))
                }

                :is(.dark .dark\:text-white) {
                    --tw-text-opacity: 1;
                    color: rgb(255 255 255/var(--tw-text-opacity))
                }

                :is(.dark .dark\:text-yellow-300) {
                    --tw-text-opacity: 1;
                    color: rgb(253 224 71/var(--tw-text-opacity))
                }

                :is(.dark .dark\:hover\:bg-gray-200:hover) {
                    --tw-bg-opacity: 1;
                    background-color: rgb(228 228 231/var(--tw-bg-opacity))
                }

                :is(.dark .dark\:hover\:bg-primary:hover) {
                    --tw-bg-opacity: 1;
                    background-color: rgb(var(--color-primary)/var(--tw-bg-opacity))
                }

                :is(.dark .dark\:hover\:bg-red-500:hover) {
                    --tw-bg-opacity: 1;
                    background-color: rgb(239 68 68/var(--tw-bg-opacity))
                }

                :is(.dark .dark\:hover\:text-gray-100:hover) {
                    --tw-text-opacity: 1;
                    color: rgb(244 244 245/var(--tw-text-opacity))
                }

                :is(.dark .dark\:hover\:ring-gray-200:hover) {
                    --tw-ring-opacity: 1;
                    --tw-ring-color: rgb(228 228 231/var(--tw-ring-opacity))
                }

                @media (min-width:768px) {
                    .md\:relative {
                        position: relative
                    }

                    .md\:-ml-1 {
                        margin-left: -4px
                    }

                    .md\:mb-0 {
                        margin-bottom: 0px
                    }

                    .md\:ml-0 {
                        margin-left: 0px
                    }

                    .md\:ml-4 {
                        margin-left: 16px
                    }

                    .md\:mt-0 {
                        margin-top: 0px
                    }

                    .md\:block {
                        display: block
                    }

                    .md\:flex {
                        display: flex
                    }

                    .md\:hidden {
                        display: none
                    }

                    .md\:w-auto {
                        width: auto
                    }

                    .md\:flex-1 {
                        flex: 1 1 0%
                    }

                    .md\:grid-cols-2 {
                        grid-template-columns: repeat(2, minmax(0, 1fr))
                    }

                    .md\:items-center {
                        align-items: center
                    }

                    .md\:justify-between {
                        justify-content: space-between
                    }

                    .md\:space-x-4>:not([hidden])~:not([hidden]) {
                        --tw-space-x-reverse: 0;
                        margin-right: calc(16px*var(--tw-space-x-reverse));
                        margin-left: calc(16px*calc(1 - var(--tw-space-x-reverse)))
                    }

                    .md\:px-4 {
                        padding-left: 16px;
                        padding-right: 16px
                    }

                    .md\:pr-60 {
                        padding-right: 240px
                    }

                    .md\:text-left {
                        text-align: left
                    }
                }

                @media (min-width:1024px) {
                    .lg\:mb-0 {
                        margin-bottom: 0px
                    }

                    .lg\:ml-8 {
                        margin-left: 32px
                    }

                    .lg\:mt-0 {
                        margin-top: 0px
                    }

                    .lg\:block {
                        display: block
                    }

                    .lg\:inline-block {
                        display: inline-block
                    }

                    .lg\:flex {
                        display: flex
                    }

                    .lg\:hidden {
                        display: none
                    }

                    .lg\:w-4\/12 {
                        width: 33.333333%
                    }

                    .lg\:w-auto {
                        width: auto
                    }

                    .lg\:flex-1 {
                        flex: 1 1 0%
                    }

                    .lg\:grid-cols-3 {
                        grid-template-columns: repeat(3, minmax(0, 1fr))
                    }

                    .lg\:flex-row {
                        flex-direction: row
                    }

                    .lg\:items-center {
                        align-items: center
                    }

                    .lg\:justify-between {
                        justify-content: space-between
                    }
                }

                @media (min-width:1536px) {
                    .\32xl\:grid-cols-4 {
                        grid-template-columns: repeat(4, minmax(0, 1fr))
                    }
                }
            </style>
            <style class=sf-hidden>
                .list-item-active svg {
                    visibility: visible
                }
            </style>
            <div id=app data-v-app></div>
        </template></div>
    <script data-template-shadow-root>
        (() => {
            document.currentScript.remove();
            processNode(document);

            function processNode(node) {
                node.querySelectorAll("template[shadowrootmode]").forEach(element => {
                    let shadowRoot = element.parentElement.shadowRoot;
                    if (!shadowRoot) {
                        try {
                            shadowRoot = element.parentElement.attachShadow({
                                mode: element.getAttribute("shadowrootmode")
                            });
                            shadowRoot.innerHTML = element.innerHTML;
                            element.remove()
                        } catch (error) {}
                        if (shadowRoot) {
                            processNode(shadowRoot)
                        }
                    }
                })
            }
        })()
    </script>